# Syndicate MAIN.EXE: MZ bootstrap handoff

## Result

The recovered entry path invokes an external DOS extender executable. It searches for **dos4gw.exe**, then **dos4g.exe**, prepares the original program pathname and command tail as arguments, and uses Watcom-style overlay execution machinery to transfer into the selected external executable. The decisive instruction sequence sets **AX=4B03h**, far-jumps into a copied real-mode thunk, invokes **INT 21h**, then uses a header-derived entry on successful loading.

This is static causal evidence from code and data references. No guest was run and no external DOS4G/W binary was analyzed. It does not prove that the chosen external loader actually ran or consumed MAIN.EXE's LE tables in this environment.

## Target and bounds

Source MAIN.EXE SHA-256: bfbed760ab2def1fbe9f73588dc5a24747826c9b7660d615b02a8847d92bf078.

The MZ header is 96 bytes. Its declared file extent is 10,418 bytes, leaving a **10,322-byte file-backed DOS load image**. The LE header begins at 10,424 (0x28B8), so a six-byte interval lies between those declared extents. The static minimum-allocation model has 12,480 mapped bytes and six DOS segment relocations. The 2,158 bytes beyond the file-backed load image in that allocation are virtual allocation, not additional file bytes.

All CS offsets below use the MZ model's CS=1000h. Their source-file coordinates are 0x60 + CS offset, while static linear coordinates are 0x10000 + CS offset. Startup establishes DS=1249h under that model; DS offsets therefore use base 0x12490. These values describe the static load, not observed runtime placement.

Exactly one initial analysis was run with a 2,000-attempt budget. It decoded 1,508 instructions and stopped with 65 pending work items. Stored instructions and cross-references are preserved. Ten explicitly selected read-only decode windows (572 instruction records) close the remaining argument/overlay handoff edges; they do not mutate or continue the project worklist, and are not added to the 1,508 initial-pass count.

## Causal chain

### Startup and program identity

- Entry 1000:0210 jumps to 02D5, the C runtime setup.
- Startup saves the original PSP segment in DS:01F8, constructs the runtime data/stack context, and copies the command tail.
- On the DOS-version-at-least-3 branch, 0395 onward reads the PSP environment segment, passes the double-NUL terminator and following word, then copies the stored program pathname. The resulting pathname pointer is saved at DS:021C.
- Initializer dispatch 0855 -> 0808 walks the static initializer table at DS:03AA. Its first near-function entry is 0891. That initializer stores the DS:021C pointer as argv[0] (08E0/08E3), builds the remaining argument array, and publishes argv at DS:0416 and argc at DS:0418.
- 07D0 loads those values and calls 0055, the launcher main routine.

The pathname construction is conditional on the DOS version and environment layout. It was not runtime-observed.

### Selecting the external executable

Function 0006 first tries the filename at DS:0031 (**dos4gw.exe**) and then the filename at DS:003C (**dos4g.exe**). For each filename it invokes helper 00A4 with the two environment-name offsets stored at DS:01C2: 0022 (**DOS4GPATH**) and 002C (**PATH**).

Helper 00A4 first probes the supplied filename via 0480, which issues INT 21h with AX=4300h. When needed, it calls 0567, whose code traverses the environment-name list and checks a case-insensitive name followed by '='. It iterates semicolon-delimited path components, constructs a candidate path, and probes it. A found path is returned through DS:03C2. If all explicit searches fail, 0006 returns the literal dos4gw.exe pointer; the later exec wrapper has its own PATH fallback.

This connects the filenames and environment strings to the entry path. The strings are not being treated as sufficient evidence by themselves. Which path would succeed depends on files and environment that were not observed.

### Argument construction

At 0055 the launcher builds a four-pointer vector on its stack:

1. Selected loader executable pathname.
2. The original argv[0] pointer, obtained from the caller's argv array.
3. A buffer containing the original raw DOS command tail.
4. NULL terminator.

At 017D, the raw-tail helper reads the length at PSP:0080 and copies that many bytes from PSP:0081, then adds a NUL terminator. At 0082 the launcher calls wrapper 01AE with the selected executable and this vector. Wrapper 01AE loads the environment-vector pointer and calls 05F7, which reaches the exec-overlay implementation at 0BFD.

The command-tail builder at 1A46 skips vector element zero, copies subsequent argument strings using 1907, separates them with spaces, writes a carriage return, and stores the DOS length byte. Thus the selected loader receives the original program pathname and original command-tail contents. This inspection does not establish behavior for unusual overlong arguments or all quoting cases.

### Overlay loading and transfer

The selected-executable path at 0BFD prepares a filename, obtains and tests a 0x1C-byte header buffer, and distinguishes the MZ magic. At 0D7D onward it pushes the selected file's header SS, SP, CS and IP fields, its MZ/COM classification, filename and command-tail buffer into transfer routine 1BD7.

Transfer routine 1BD7:

- Copies command-tail/FCB state into the PSP.
- Allocates space for a small relocation-safe transfer area near the selected available-memory end.
- Copies the **0x98-byte MZ thunk template at source offset 1A9A**, or the **0xA5-byte generic COM template at 1B32**, into that area. Each template contains both executable instructions and embedded data/error strings.
- Copies the selected executable pathname to offset 0130 in the new transfer segment.
- For MZ, stores the selected executable's SS:SP and CS:IP, with segment values adjusted by PSP+10h, at offsets 0090..0097 in the transfer area.
- Sets the new stack, uses DS:DX in the copied thunk to identify the filename, and builds the overlay load/relocation parameter words at ES:BX = PSP:0100.
- Executes **MOV AX,4B03h at source 1CD4**, then **JMP FAR [DS:03A0] at 1CD7**. The pointer's offset starts at zero and its segment is set to the copied transfer area at 1C5D.

The MZ thunk begins with PUSH CS / POP DS / INT 21h (source 1A9A/1A9B/1A9C). With AX=4B03h this is DOS's load-overlay operation. On carry clear, its continuation at source 1B17 loads the prepared SS:SP, pushes the prepared CS:IP, restores DS from ES and executes RETF at 1B29. That is the static handoff to the selected external executable's entry.

The COM alternative is present in generic exec support; it is not evidence that the chosen DOS4G/W file is actually COM.

### Failure and exit paths

If the ordinary exec wrapper returns, main prints **Stub exec failed:**, the selected path and the translated error, then calls the runtime exit path with AX=1. The common termination sequence at 0471 sets AH=4Ch and invokes INT 21h at 0473.

The copied thunk has its own load-error path. It selects an embedded DOS '$'-terminated diagnostic, calls INT 21h/AH=09h, then sets AL=FFh, AH=4Ch and invokes INT 21h. The source MZ-thunk termination is at 1ACA; the generic COM-thunk counterpart is at 1B62. The memory-preparation path also has a failure termination at 0FA2 with AX=4CFFh.

These are requested exit codes in static code. No actual guest exit event was observed.

## What this settles and what remains

The previously unexamined DOS prefix has a concrete role on its recovered entry path: C runtime setup, external-loader discovery, argument/environment construction, overlay transfer and diagnostic exits. The LE payload is not the MZ loader's ordinary mapped image. MAIN.EXE supplies its own pathname to the external loader rather than jumping directly from this bootstrap to the LE preferred entry.

Remaining unknowns include the runtime loader search result, DOS/environment-specific branches, the external executable's actual LE loading behavior, protected-mode placement/selectors, and the unprocessed bootstrap worklist. The initial analyzer's remaining queues were deliberately preserved rather than cleared or called complete.

## Evidence files

- mz-inspect.json and its receipts: explicit MZ inspection.
- mz-import.json and its receipt: separate bootstrap project identity.
- mz-initial-analysis.json and receipt: the only initial pass.
- mz-analysis-status.json: preserved incomplete worklist status.
- bootstrap-stored-instructions.json and bootstrap-stored-xrefs.json: initial stored evidence.
- bootstrap-targeted-slices.json: extra selected decoder windows, mixed thunk templates and pointer/initializer data.
- bootstrap-summary.json: machine-readable findings and scope.
- bootstrap.fdb: private byte-retaining project; keep outside Git.
