# Syndicate LE whole-binary scope — continuation pack

Captured 30 October 2026 with fDisBull 0.26.0. This pack continues the selected
Syndicate MAIN.EXE investigation. Start with
[Syndicate_LE_Whole_Binary_Scope.md](Syndicate_LE_Whole_Binary_Scope.md).

## Result and limits

All 518,713 physical bytes are represented by 19 disjoint, contiguous intervals.
The independent reconstruction agrees on all four preferred-address objects and
all 10,060 relocation records (10,055 unique writes). The explicitly unassigned
398-byte zero gap and 524-byte physical page suffix are preserved.

The LE checkpoint has 22,910 stored instructions, 384 candidate functions and
27,027 xrefs. Basic discovery queues are drained. Sixteen derived jobs remain
partial, and all 60 stored indirect calls/jumps lack resolved control targets.
This is complete physical accounting for this selected format profile; it is
not complete code/semantic recovery, generic LE/LX validation, a runnable
rewrite, or an observation of the original DOS4GW loader at runtime.

## Contents

| Location | Purpose |
| --- | --- |
| Syndicate_LE_Whole_Binary_Scope.md | Full findings, physical and virtual maps, decisions, implementation acceptance criteria and next questions |
| scope-contract.json | Machine-readable claims, evidence locations and qualifications |
| checkpoints/syndicate-le.fdb | Clean SQLite backup of the continued LE project |
| checkpoints/syndicate-mz-bootstrap.fdb | Separate clean SQLite backup of the static DOS launcher analysis |
| checkpoint-receipts.json | Backup sizes, quick_check results and stored counts |
| original/ | Exact retained input and identity receipt |
| independent/ | Standalone selected-profile parser, full 10,060-record census, header CSV, physical map and exact stored classification coverage |
| independent-comparison.json | All-object mapped-byte agreement and complete record-field comparison |
| loader-audit/ | Loader validation probe, bootstrap instruction evidence and precise indirect-transfer diagnostics |
| spec-references/ | Pinned primary format references and independent scope review |
| continuation/ | Original bounded-analysis responses, receipts, full derived output and overlapping-instruction evidence |
| recovery-receipt.json | Recovery provenance from the prior analysis pack |
| MANIFEST.json | Pack members and uncompressed sizes |

Both checkpoint databases retain the original supplied executable bytes. Keep
these private investigation artifacts outside a public source checkout. Extract
into a writable private directory and continue from a working copy of the chosen
checkpoint. SQLite may create sidecar files when a project is opened; live WAL
and SHM files are deliberately absent from this clean checkpoint pack.

The DOS bootstrap checkpoint is deliberately separate from the protected-mode
LE checkpoint. Its entry and address context are different. The bootstrap trace
identifies a DOS 4B03h overlay-load handoff to an external DOS4G/W executable;
it does not observe that executable's subsequent behavior.

## Reproduce selected receipts when needed

The two independent analysis scripts use the Python standard library. From the
extracted pack root, use a fresh output path so the captured evidence remains
intact:

```sh
python3 independent/scope_le.py original/MAIN.EXE reproduced-physical
python3 independent/export_analysis_coverage.py checkpoints/syndicate-le.fdb reproduced-coverage.json --version 1 --fixups independent/independent-fixup-records.json
```

The physical parser intentionally checks the observed profile and rejects other
profiles rather than claiming broad LE conformance. The coverage exporter is
read-only, uses a consistent SQLite transaction, and parses every address TEXT
key as hexadecimal. Its counts describe stored classifications, not the true
instruction/data boundary or runtime reachability.

The in-memory optional-extent probe uses the installed fDisBull 0.26.0 Python
environment. It does not need a game file or alter a project:

```sh
python -I loader-audit/fixture-probe.py
```

The recorded responses already contain the completed investigations. Repeating
a broad derived pass is not the next discriminator. First inspect
loader-audit/indirect-scope-diagnostic.md: qualify the compare/reload identity and
partial-register merge at 0x10779, then qualify writable callback defaults
against stack and other possible aliases. Ten additional switch-table targets
are candidates awaiting that proof; they were not silently admitted as code.

Preserve both branch-supported interpretations at 0x3D1E9/0x3D1EA. Count unique
instruction bytes by interval union. Treat physical source bytes, virtual zero
fill, relocated values, analysis tags and runtime observations separately.

Absolute paths in raw receipts identify the original analysis environment; use
the relative paths in this README for the extracted pack. The executable,
installer and game were not executed or modified during this pass. No production
loader changes or GitHub mutations are part of this pack.
