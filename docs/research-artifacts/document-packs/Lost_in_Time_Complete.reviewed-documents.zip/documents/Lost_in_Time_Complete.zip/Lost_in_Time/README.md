# Lost in Time — Live text-adventure pack

**English · Edition 1.0.0 · 29 October 2026**

An original text-adventure adaptation of Coktel Vision's Lost in Time (1993), researched from walkthroughs, the original manual, and inspected screenshots. The adventure spans the ship opening, manor flashback, return to the ship, and island finale.

## Start playing

1. Attach **Lost_in_Time_Live.txt** to the conversation that will host the game. It contains the complete narrator contract and game data in readable form. The Markdown edition has the same content.
2. Give the start instruction below. Have the host confirm it can access the script, without summarizing the plot or solutions.
3. Start or continue Live in that same conversation. Play with ordinary spoken commands. When pausing, say **“save game”** and retain the resulting text checkpoint.

### Start instruction

Read the attached Lost in Time script privately as the game master. Start a new game at `a_hold` with its initial state. I control Doralice. Narrate in English, in second person, with concise atmosphere and occasional dry humor. Accept natural spoken actions, but resolve them against the script's rules and inventory. Keep future scenes, hidden information and solutions private. Do not solve puzzles, collect items, combine objects or move for me. Offer hints only when I ask. Begin with the opening scene and return control to me. When I say “save game,” provide the portable state block in text without reading its JSON aloud.

### Useful spoken commands

“Look around.” “Examine the poster.” “Search behind the barrel.” “What am I carrying?” “Use the sponge on the poster.” “Go back to the hold.” “What was I trying to do?” “Give me a small hint.” “Undo that.” “Save game.”

The narrator accepts equivalent wording. A single glance does not open a lock, and the host must not fill missing inventory with invented objects. The scripted timed encounters wait for deliberate choices, so voice latency does not cost the campaign.

## Files

| File | Purpose |
|---|---|
| `Lost_in_Time_Live.txt` | Complete file to attach for play. Contains spoilers for the game master. |
| `Lost_in_Time_Live.md` | Same full script with Markdown formatting. |
| `Lost_in_Time_World.json` | Canonical declarative world: scenes, actions, conditions, effects and provenance. |
| `Lost_in_Time_Initial_Save.json` | Clean starting state. |
| `Narrator_Contract.md` | Voice behavior, command interpretation, hints, saves and rule semantics. |
| `Act_A.md` through `Act_D.md` | Individual act reading/editing aids. Keep the full world for state validation. |
| `state_engine.py` | Standard-library reference runner for exact commands and action IDs. |
| `validate_world.py` | Focused structural, route and alternate-order checks. |
| `Validation_Report.md` and `.json` | Observed verification results and limits. |
| `IMPLEMENTATION.md` | How to connect the declarative data to a later game host. |

## Scope and evidence

There are **38 scenes, 188 authored actions, 117 item/state identifiers, and a 265-transition reference route**. Several camera views are merged into each text location. Narration, dialogue, additional atmosphere and connective passages are newly written. The major item chains and story order are grounded in the cited game material.

The source register is inside the master script and JSON. It separates written guides, original manual information, actually inspected screenshots, and YouTube references whose metadata was checked but whose footage was not watched. No original game assets or dialogue transcript are included.

The reference route and targeted alternate-order checks passed. The original game executable was not run for this work, and no ChatGPT Live play session was launched. The prompt version relies on the narrator following the rules; the Python runner shows how to enforce them programmatically.

## Voice setup reference

OpenAI's [ChatGPT Voice documentation](https://learn.chatgpt.com/docs/features/voice) describes using voice in a conversation, and its [file/project update](https://learn.chatgpt.com/docs/whats-new) documents support for uploaded files in Voice. [Supported text uploads](https://help.openai.com/en/articles/8555545-uploading-files-and-audio-to-chatgpt) include TXT. Availability depends on the client and account; manually attach the script in the game conversation before relying on it during voice play. These setup references were checked on 29 October 2026.

For an interrupted game, supply the full script and the latest save block to the host conversation. Ask it to restore that state, recap only discovered facts, and describe the current scene. A save should record state explicitly; do not rely on a new conversation remembering the previous one.
