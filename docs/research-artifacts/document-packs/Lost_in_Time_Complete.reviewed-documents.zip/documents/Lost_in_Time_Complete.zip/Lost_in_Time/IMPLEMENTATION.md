# Using the world in a game host

The world is declarative JSON, separate from the narrator's voice. The supplied Python runner is a small reference implementation of the state rules. It needs Python 3.10 or later and no third-party packages.

## Data model

`scenes` contains stable IDs, act IDs, titles, original arrival descriptions, inspectable features, exits, actions and source references. `initial_state` contains the player's location, inventory, discovered flags, completed actions and flashback stash. `solution` is a developer-only route used to check reachability; never expose it to the player as an automatic itinerary.

An action defines its command, aliases, prerequisites, prohibited conditions, inventory changes, Boolean flag changes, optional journal additions, optional destination and outcome narration. `requires` is an AND list; a nonempty `requires_any` is an OR list that must also pass. Conditions are `item:ID`, `flag:ID`, or `done:ID`. An action is once-only unless marked repeatable. Both movement and actions preserve an undo snapshot.

An action's normal scope is its scene. `portable: true` makes a held-item recipe available throughout its act. `inherit_actions` points to original action IDs whose searches remain available in the later version of a location; it preserves their completion records to prevent duplicated pickups. There is no arbitrary teleport operation in the player interface. A `goto` is only an effect of a successfully validated scripted event.

Flashback transitions temporarily exchange inventories. The 1840 inventory is stashed, the 1992 inventory begins empty, and the saved inventory returns when the flashback ends. All scene/action progress remains recorded. The final transition sets `game_complete`; the ending is not inferred from narration.

## Suggested narrator integration

For a future host with executable tools:

1. Supply the current scene, relevant inventory observations and legal action schema to an intent interpreter.
2. Interpret the player's utterance as an action ID or a direct exit. Preserve explicit object choices and code values. A wrong code must not become the correct action merely because both refer to the safe.
3. Submit that proposed action to the state runner. A missing prerequisite rejects the entire transaction; never let the language model patch the state to fit its proposed narration.
4. Give the accepted result and updated visible state to the narrator. Keep future solutions and hidden prerequisites out of its player-facing response.
5. Save the returned state after successful changes and at user-requested checkpoints.

The simple prompt edition combines these responsibilities in one conversation. It is usable as a game-master script, but it does not provide the same enforcement as an executable host. No connection to a Live API or plugin is implemented in this package.

## Reference commands

From this folder:

```bash
python3 state_engine.py --replay
python3 validate_world.py
python3 state_engine.py --interactive
```

The interactive developer shell accepts action IDs, exact commands/aliases, `go:SCENE_ID`, `look`, `inventory`, `undo`, and `quit`. `actions` and `exits` print developer information and contain spoilers. This shell does not parse unrestricted natural language. Arrival descriptions are templates; the Live narrator must adjust them to removed objects, open mechanisms and rescued characters.

For an explicit single action and local save:

```bash
python3 state_engine.py --command a_find_lamp --state-out session.json
python3 state_engine.py --state-in session.json --command inventory
```

The runner validates save identity, known token references and the shape of state fields and undo snapshots. It retains up to 30 undo states. It is not an adversarial anti-cheat system: a person editing a valid save can change their game. The intention is consistent play and recoverable mistakes.

## Verification boundaries

The included checks cover a complete route, alternate hose and blouse order, skipped opening items, later recovery of the corkscrew, portable recipes, an alternate soap tool, blocked-action atomicity, flashback undo and malformed saves. They establish consistency of this authored adaptation. They do not enumerate every possible state order, verify all original-game alternate solutions, or measure voice recognition quality.

The source URLs and explicit adaptation notes are retained in the data so a later fidelity pass can revise a scene without replacing the entire format. Changing mechanics requires a new version or an explicit migration for existing save blocks.
