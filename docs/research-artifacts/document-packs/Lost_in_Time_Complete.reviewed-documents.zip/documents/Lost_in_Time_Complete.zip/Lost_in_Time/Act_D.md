# Act D — St. Cristobald: the rescue

## d_beach — St. Cristobald

**On arrival — adjust to current state:**

Yellow sand gives way to blue water on one side and palms on the other. For the first time in hours, there is room to breathe. Yoruba rests nearby while Melkior studies the inland paths. A waterfall sounds beyond the vegetation; another route leads toward the plantation property.

### Inspection material

- **Melkior:** He has equipment and a short briefing for you.
- **Yoruba:** The rescued man needs rest while you investigate.

### Exits

- **waterfall** → `d_waterfall`. Requires none.
- **plantation property** → `d_property`. Requires none.

### Actions and state changes

#### d_briefing: Ask Melkior for the plan and communications device

Equivalent phrasing: talk to Melkior; take holocom.

**Requires:** none. Once only.

**Effects:** give items: `holocom`; set flags: `d_briefed`.

**Outcome:** Melkior gives you the holocom. Yoruba is ill and needs Makandal, the island healer. Find help for him, then reach Velvet before Jarlath can carry out his plans.

**Private hint ladder:**

1. Talk before leaving the beach.
2. Melkior can give you a way to contact him.
3. Ask Melkior for the holocom and briefing.

**Research anchors:** [late_won](https://advgamer.blogspot.com/2023/09/lost-in-time-won.html), [late_gallery](https://www.planete-aventure.net/jeux.php?num_jeu=1626&cat=screenshots). Narration is original.

## d_waterfall — The Boy at the Waterfall

**On arrival — adjust to current state:**

Water throws a steady curtain of sound across the clearing. A boy watches you from the shelter of the plants, cradling a small animal that barely stirs. A coconut lies nearby. In the rock, an opening seems determined to remain closed to everyone except its chosen visitor.

### Inspection material

- **Amilcar and his manicou:** The animal is cold and needs a drink.
- **coconut:** Its milk is inaccessible through the intact shell.
- **sealed rock passage:** It responds to a particular voice and word.

### Exits

- **beach** → `d_beach`. Requires none.
- **plantation property** → `d_property`. Requires none.
- **passage to Makandal** → `d_makandal`. Requires `flag:d_passage_open`.

### Actions and state changes

#### d_talk_boy: Talk to Amilcar about his animal

**Requires:** none. Once only.

**Effects:** set flags: `d_animal_need_known`.

**Outcome:** Amilcar asks you to help his chilled, thirsty manicou. He knows something about the concealed passage.

**Private hint ladder:**

1. The boy is worried about something he is carrying.
2. Ask about the animal before trying the passage.
3. Talk to Amilcar.

#### d_uncover_cage: Uncover Galipo's cage and remove the pirate flag

**Requires:** `item:covered_cage`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `covered_cage`; give items: `bird_cage`, `pirate_flag`.

**Outcome:** Galipo blinks at the light. The flag is free to use again.

**Private hint ladder:**

1. The cage's cover is also a piece of cloth.
2. Remove the flag from the covered cage.
3. Uncover the cage to get the pirate flag.

#### d_warm_animal: Wrap the manicou in the pirate flag

**Requires:** `flag:d_animal_need_known`, `item:pirate_flag`. Once only.

**Effects:** remove items: `pirate_flag`; set flags: `d_animal_warm`.

**Outcome:** The small animal settles into the makeshift blanket.

**Private hint ladder:**

1. The animal is chilled.
2. You have a portable cloth large enough to cover it.
3. Wrap the manicou in the pirate flag.

#### d_open_coconut: Pierce the coconut with the corkscrew

**Requires:** `item:corkscrew`. Once only.

**Effects:** give items: `opened_coconut`.

**Outcome:** The shell opens enough to draw out coconut milk.

**Private hint ladder:**

1. The drink is inside a hard shell.
2. The corkscrew can pierce a small opening.
3. Use the corkscrew on the coconut.

#### d_feed_animal: Draw coconut milk into the pipette and feed the manicou

**Requires:** `item:pipette`, `item:opened_coconut`, `flag:d_animal_need_known`. Once only.

**Effects:** set flags: `d_animal_fed`.

**Outcome:** The manicou drinks and begins to stir more strongly.

**Private hint ladder:**

1. A large coconut is awkward for the weak animal.
2. Feed it a little milk with the glass pipette.
3. Use the pipette on the opened coconut, then on the manicou.

#### d_learn_word: Ask Amilcar how the passage opens

**Requires:** `flag:d_animal_warm`, `flag:d_animal_fed`. Once only.

**Effects:** set flags: `d_password_known`.

**Outcome:** Amilcar gives you the word Madjumbe. Your voice alone does not open the passage; it expects his father's voice.

**Private hint ladder:**

1. The boy offered help after you helped his animal.
2. Ask him for the passage's word.
3. Ask Amilcar how to open the passage.

#### d_open_passage: Have Galipo say Madjumbe at the rock passage

Equivalent phrasing: use parrot on passage; ask Galipo to imitate Makandal.

**Requires:** `flag:d_password_known`, `item:bird_cage`. Once only.

**Effects:** remove items: `bird_cage`; give items: `empty_cage`, `flat_key`; set flags: `d_passage_open`, `d_parrot_with_boy`.

**Outcome:** Galipo supplies the voice the rock expects. Amilcar keeps his father's parrot, but gives you the empty cage and the flat key attached to Galipo's leg.

**Private hint ladder:**

1. You know the word; the voice is wrong.
2. The parrot imitates its former owner.
3. Use Galipo to say Madjumbe at the passage.

**Research anchors:** [late_won](https://advgamer.blogspot.com/2023/09/lost-in-time-won.html). Narration is original.

## d_property — Paths Across the Property

**On arrival — adjust to current state:**

The paths divide among shaded huts and the plantation buildings. Everyday life has not stopped for the danger you have brought with you. One track reaches Delia, another Serapion. A dog guards the route toward the kitchen, making its opinion of strangers unmistakable before you are close enough to argue.

### Inspection material

- **guard dog:** It blocks the kitchen path and currently refuses your approach.

### Exits

- **beach** → `d_beach`. Requires none.
- **waterfall** → `d_waterfall`. Requires none.
- **Delia's hut** → `d_delia`. Requires none.
- **Serapion's hut** → `d_serapion`. Requires none.
- **kitchen** → `d_kitchen`. Requires `flag:d_dog_friendly`.

### Actions and state changes

#### d_feed_dog: Give the sugar to the guard dog

**Requires:** `item:sugar`. Once only.

**Effects:** remove items: `sugar`; set flags: `d_dog_friendly`.

**Outcome:** The dog accepts the sweet offering and allows you past.

**Private hint ladder:**

1. You need to change the dog's mood, not fight it.
2. Serapion's gift can be transformed into something sweeter.
3. Give the transformed sugar to the guard dog.

**Research anchors:** [late_abandonware](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=31&page=1). Narration is original.

## d_makandal — Makandal's Hut

**On arrival — adjust to current state:**

Blue and purple shadows deepen the hut's interior. Herbs and ropes hang overhead, while the shutters decide how much daylight reaches the table. Makandal treats your arrival as a transaction before it becomes a conversation. A narrow slot in the door is his preferred way to receive an introduction.

### Inspection material

- **door slot:** Makandal wants payment before a full consultation.
- **closed shutters:** Opening them would bring daylight to the table.
- **table and drinking glass:** A glass stands on the tabletop. The shutters control the light falling across it.

### Exits

- **waterfall passage** → `d_waterfall`. Requires none.
- **Delia's hut** → `d_delia`. Requires `flag:d_makandal_task`.

### Actions and state changes

#### d_get_coins: Open the empty cage's hidden base with the flat key

**Requires:** `item:empty_cage`, `item:flat_key`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** give items: `gold_coins`.

**Outcome:** The heavy base opens to reveal gold coins.

**Private hint ladder:**

1. The cage remained heavy even without its bird.
2. Try the flat key in the concealed base.
3. Unlock the empty cage's base with the flat key.

#### d_pay_makandal: Put the gold coins in Makandal's door slot

**Requires:** `item:gold_coins`. Once only.

**Effects:** remove items: `gold_coins`; set flags: `d_makandal_paid`.

**Outcome:** The coins earn you an audience.

**Private hint ladder:**

1. The slot is for a gift, not a key.
2. The cage concealed something valuable.
3. Give Makandal the gold coins through the slot.

#### d_get_task: Ask Makandal to heal Yoruba and help you reach Velvet

Equivalent phrasing: ask Makandal to heal Yoruba; ask Makandal for help.

**Requires:** `flag:d_makandal_paid`. Once only.

**Effects:** set flags: `d_makandal_task`.

**Outcome:** Makandal agrees to take care of Yoruba, but demands a piece of Delia's clothing in return. She can also put you in touch with Velvet.

**Private hint ladder:**

1. An audience is only the start of the bargain.
2. Ask about the person you came to find.
3. Ask Makandal for help reaching Velvet.

#### d_give_blouse: Give Makandal Delia's silk blouse

**Requires:** `flag:d_makandal_task`, `item:silk_blouse`. Once only.

**Effects:** remove items: `silk_blouse`; set flags: `d_drink_invitation`, `d_yoruba_care_arranged`.

**Outcome:** Makandal accepts the blouse and confirms that Yoruba is in his care. He invites you to the table for a drink.

**Private hint ladder:**

1. Finish the first half of his bargain.
2. Bring him the clothing recovered at Delia's hut.
3. Give Makandal the silk blouse.

#### d_open_shutters: Open the shutters

**Requires:** `flag:d_drink_invitation`. Once only.

**Effects:** set flags: `d_shutters_open`.

**Outcome:** Daylight reaches the tabletop.

**Private hint ladder:**

1. The holocom needs light.
2. Let daylight into the room.
3. Open the shutters.

#### d_place_holocom: Place the holocom on the table

**Requires:** `flag:d_drink_invitation`, `item:holocom`. Once only.

**Effects:** remove items: `holocom`; set flags: `d_holocom_placed`.

**Outcome:** The device rests on the tabletop, ready to activate.

**Private hint ladder:**

1. You need a distraction on the table.
2. Place Melkior's device where daylight reaches it.
3. Put the holocom on the table.

#### d_activate_holocom: Activate the holocom

**Requires:** `flag:d_holocom_placed`, `flag:d_shutters_open`. Once only.

**Effects:** set flags: `d_makandal_distracted`.

**Outcome:** Melkior's hologram appears. Makandal ducks away in alarm, leaving his glass unattended.

**Private hint ladder:**

1. The device is placed and has daylight.
2. Call up the hologram now.
3. Activate the holocom to distract Makandal.

#### d_use_potion: Pour Delia's potion into Makandal's glass

**Requires:** `flag:d_makandal_distracted`, `item:delia_potion`. Once only.

**Effects:** remove items: `delia_potion`; set flags: `d_glass_dosed`.

**Outcome:** The charm dissolves into his drink while he is distracted.

**Private hint ladder:**

1. Delia's bargain depends on delivery of her potion.
2. Use the distraction to reach his glass.
3. Add Delia's potion to Makandal's glass.

#### d_take_proof: Retrieve the holocom, let Makandal drink, and take his glass

**Requires:** `flag:d_glass_dosed`. Once only.

**Effects:** give items: `holocom`, `makandal_glass`; clear flags: `d_holocom_placed`; set flags: `d_potion_delivered`.

**Outcome:** The hologram vanishes, Makandal drinks, and you recover the empty glass as Delia's requested proof.

**Private hint ladder:**

1. The glass is proof only after he drinks.
2. Put away the holocom, then take the emptied glass.
3. Recover the holocom and take Makandal's glass after he drinks.

#### d_get_bequiet: Ask Makandal for help once more

**Requires:** `flag:d_velvet_met`. Once only.

**Effects:** give items: `bequiet`.

**Outcome:** Irritated by another question, Makandal gives you a potion called Bequiet.

**Private hint ladder:**

1. The two hut owners have further gifts after your meeting.
2. Return to Makandal after meeting Velvet.
3. Ask Makandal again to receive Bequiet.

**Research anchors:** [late_won](https://advgamer.blogspot.com/2023/09/lost-in-time-won.html), [late_abandonware](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=31&page=1), [late_gallery](https://www.planete-aventure.net/jeux.php?num_jeu=1626&cat=screenshots). Narration is original.

## d_delia — Delia's Hut

**On arrival — adjust to current state:**

Wooden shutters and hanging household objects give this hut a lived-in warmth. Delia is less welcoming than the room. A book lies within reach, a small mirror stands nearby, and a spider guards a piece of fine cloth with an attention to duty that recalls the captain's parrot.

### Inspection material

- **Delia:** She searches for her glasses when she admits you.
- **recipe book:** Her work depends on it.
- **spider and silk blouse:** The spider will not let you simply take the cloth.
- **small mirror:** Portable and reflective.

### Exits

- **property paths** → `d_property`. Requires none.
- **Makandal's hut** → `d_makandal`. Requires `flag:d_passage_open`.

### Actions and state changes

#### d_hide_book: Take the recipe book while Delia looks for her glasses

**Requires:** `flag:d_makandal_task`. Once only.

**Effects:** give items: `recipe_book`; set flags: `d_delia_away`.

**Outcome:** Unable to find her book, Delia searches another part of the hut. You have a chance to examine the guarded cloth.

**Private hint ladder:**

1. Delia needs a reason to leave you alone.
2. Her misplaced book can send her searching elsewhere.
3. Take the recipe book during her search for her glasses.

#### d_take_mirror: Take the small mirror

**Requires:** `flag:d_delia_away`. Once only.

**Effects:** give items: `mirror`.

**Outcome:** You lift the small mirror.

**Private hint ladder:**

1. A reflective object is within reach.
2. Take the mirror beside the spider.
3. Take the mirror.

#### d_scare_spider: Show the spider its reflection

**Requires:** `flag:d_delia_away`, `item:mirror`. Once only.

**Effects:** set flags: `d_spider_gone`.

**Outcome:** The spider retreats from its own reflection, leaving the blouse unguarded.

**Private hint ladder:**

1. A creature guarding its territory may dislike an apparent rival.
2. Try the mirror on the spider.
3. Show the spider its reflection.

#### d_take_blouse: Take the silk blouse

**Requires:** `flag:d_spider_gone`, `flag:d_delia_away`. Once only.

**Effects:** give items: `silk_blouse`.

**Outcome:** You take the blouse while the spider is away.

**Private hint ladder:**

1. The cloth is no longer guarded.
2. Collect it before concluding the encounter.
3. Take the silk blouse.

#### d_return_book: Return the book and hear Delia's request

**Requires:** `item:recipe_book`, `done:d_take_blouse`. Once only.

**Effects:** remove items: `recipe_book`; give items: `delia_potion`; clear flags: `d_delia_away`; set flags: `d_delia_bargain`.

**Outcome:** Delia brews a love charm for Makandal. Bring his drinking glass back as proof, she says, and she will arrange your meeting with Velvet.

**Private hint ladder:**

1. You have the cloth; now complete the conversation.
2. Return Delia's book so she can make her potion.
3. Return the recipe book and receive Delia's potion.

#### d_meet_velvet: Show Delia Makandal's glass and ask to meet Velvet

**Requires:** `item:makandal_glass`, `flag:d_potion_delivered`. Once only.

**Effects:** remove items: `makandal_glass`; set flags: `d_velvet_met`.

**Outcome:** Delia brings you to Velvet and Celeucie. Maximin is Velvet and Yoruba's child—and the boy who will become your great-great-grandfather. Jarlath intends to destroy that future. Protecting Maximin now means protecting your own existence.

**Private hint ladder:**

1. The empty glass completes Delia's bargain.
2. Bring the proof back and ask for Velvet.
3. Show Delia Makandal's glass to arrange the meeting.

#### d_get_inverter: Ask Delia for further help

**Requires:** `flag:d_velvet_met`. Once only.

**Effects:** give items: `inverter`.

**Outcome:** Delia gives you an inverter: a fantastical preparation that changes certain things into their opposites.

**Private hint ladder:**

1. Return after the meeting; the magician has another useful object.
2. Ask Delia once more.
3. Ask Delia for the inverter.

**Research anchors:** [late_abandonware](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=31&page=1), [late_gallery](https://www.planete-aventure.net/jeux.php?num_jeu=1626&cat=screenshots), [late_manual](https://mocagh.org/sierra/lostintime-manual.pdf). Narration is original.

## d_serapion — Serapion's Silence

**On arrival — adjust to current state:**

Serapion listens carefully, then tries to answer. No useful sound follows. His expression makes clear that silence is neither consent nor indifference. Beyond his hut lies the guarded route toward the kitchen. If he can speak again, he may provide both a warning and a way forward.

### Inspection material

- **Serapion:** He wants to speak but has lost his voice.

### Exits

- **property paths** → `d_property`. Requires none.

### Actions and state changes

#### d_make_speakable: Use the inverter on Bequiet

**Requires:** `item:inverter`, `item:bequiet`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `bequiet`; give items: `speakable`.

**Outcome:** The silencing potion becomes Speakable. The inverter remains usable.

**Private hint ladder:**

1. A potion that removes speech has an obvious opposite.
2. Try the inverter on Bequiet.
3. Combine the inverter and Bequiet to make Speakable.

#### d_restore_voice: Give Speakable to Serapion

**Requires:** `item:speakable`. Once only.

**Effects:** remove items: `speakable`; set flags: `d_serapion_speaks`.

**Outcome:** Serapion's voice returns. He is eager to tell you what he knows.

**Private hint ladder:**

1. You now have a remedy for his silence.
2. Give him the transformed potion.
3. Give Speakable to Serapion.

#### d_hear_warning: Ask Serapion about Jarlath and the child

**Requires:** `flag:d_serapion_speaks`. Once only.

**Effects:** set flags: `d_serpent_warning`.

**Outcome:** Serapion warns that Jarlath's threat has already reached the household. Be especially wary of a serpent near the child.

**Private hint ladder:**

1. Ask for more than directions.
2. Serapion knows about the danger within the household.
3. Ask Serapion about Jarlath and Maximin.

#### d_get_salt: Ask Serapion how to pass the guard dog

**Requires:** `flag:d_serapion_speaks`. Once only.

**Effects:** give items: `coarse_salt`.

**Outcome:** Serapion gives you coarse salt. It is not yet an appealing peace offering.

**Private hint ladder:**

1. The restored witness can help with the blocked path.
2. Talk to Serapion again about the dog.
3. Ask Serapion for help and receive coarse salt.

#### d_make_sugar: Use the inverter on the coarse salt

**Requires:** `item:inverter`, `item:coarse_salt`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `coarse_salt`; give items: `sugar`.

**Outcome:** What was salt is now sugar. The inverter has lived up to its name.

**Private hint ladder:**

1. The inverter still works.
2. Change the salt into something sweet.
3. Use the inverter on coarse salt to make sugar.

**Research anchors:** [late_abandonware](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=31&page=1), [late_won](https://advgamer.blogspot.com/2023/09/lost-in-time-won.html). Narration is original.

## d_kitchen — The Crib Beside the Fire

**On arrival — adjust to current state:**

The room should feel ordinary: a table, a stool, a fire burning low. Instead, stillness gathers around the crib. The cook is unable to help, and a snake moves where the baby lies. A small bag rests on the table. You need to draw danger away before attempting anything else.

### Inspection material

- **crib and snake:** The snake threatens Maximin; direct grabbing is unsafe.
- **table bag:** It contains vanilla and a flower.
- **low embers:** A source of heat.
- **stool by the crib:** A place for a warm lure.

### Exits

- **property paths** → `d_property`. Requires none.

### Actions and state changes

#### d_take_bag: Take the bag from the table

**Requires:** `flag:d_velvet_met`. Once only.

**Effects:** give items: `kitchen_bag`.

**Outcome:** The bag contains a vanilla pod and a flower. Neither should be lost inside it.

**Private hint ladder:**

1. The table holds a useful container.
2. Pick up and inspect the bag.
3. Take the kitchen bag.

#### d_empty_bag: Remove the vanilla and flower from the bag

**Requires:** `item:kitchen_bag`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** give items: `vanilla`, `flower`; set flags: `d_bag_empty`.

**Outcome:** You keep both contents separately. The bag is now empty; the flower's dusty scent catches your nose.

**Private hint ladder:**

1. A container should be emptied before being put near a fire.
2. Keep both ingredients in your own inventory.
3. Remove the vanilla and flower from the bag.

#### d_fill_warm_bag: Use the empty bag to collect warm embers

**Requires:** `item:kitchen_bag`, `flag:d_bag_empty`. Once only.

**Effects:** remove items: `kitchen_bag`; give items: `warm_bag`.

**Outcome:** The embers warm the empty bag. You keep its opening clear.

**Private hint ladder:**

1. The snake can be attracted away from the baby.
2. The empty bag can carry warmth.
3. Collect warm embers in the empty bag.

#### d_lure_snake: Place the warm bag on the stool

**Requires:** `item:warm_bag`. Once only.

**Effects:** remove items: `warm_bag`; set flags: `d_snake_lured`.

**Outcome:** The warmth draws the snake toward the bag and away from the crib.

**Private hint ladder:**

1. Place the lure near, but away from, the baby.
2. The stool is the right position.
3. Put the warm bag on the stool.

#### d_capture_snake: Wait for the snake to enter, then close and pick up the bag

**Requires:** `flag:d_snake_lured`. Once only.

**Effects:** give items: `snake_bag`; set flags: `d_snake_captured`.

**Outcome:** The snake enters. You close the bag and lift it clear of the crib.

**Private hint ladder:**

1. Let the lure do its work.
2. Close the bag only once the snake has entered.
3. Wait for the snake, then close and take the bag.

#### d_save_child: Put the captured snake's bag into the fire

**Requires:** `item:snake_bag`, `flag:d_bag_empty`, `item:flower`. Once only.

**Effects:** remove items: `snake_bag`; set flags: `d_maximin_safe`; move to `d_bridge`.

**Outcome:** The threat to Maximin ends. Jarlath appears, his disguise of respectability gone. He flees toward the ravine; you follow, and he turns to bar the crossing.

**Private hint ladder:**

1. The baby is clear, but the contained snake remains dangerous.
2. Finish dealing with the captured snake; retain the flower.
3. Put the snake's bag into the fire, with the flower safely in inventory.

**Research anchors:** [late_abandonware](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=31&page=1). Narration is original.

## d_bridge — The Ravine Crossing

**On arrival — adjust to current state:**

A narrow crossing hangs over the green ravine. Jarlath blocks the way, his anger no longer hidden behind politeness. The drop leaves little room for a struggle. He pauses to rub his nose, then tightens his grip on the rope and orders you to stay where you are.

### Inspection material

- **Jarlath:** He stands close enough to confront, rubbing his irritated nose between threats.
- **ravine:** A fall would end the confrontation abruptly.

### Actions and state changes

#### d_defeat_jarlath: Hold the flower toward Jarlath's face

Equivalent phrasing: use flower on Jarlath; throw flower at Jarlath.

**Requires:** `item:flower`, `flag:d_maximin_safe`. Once only.

**Effects:** set flags: `game_won`, `d_jarlath_defeated`, `game_complete`; move to `d_epilogue`.

**Outcome:** The flower sets off a violent sneeze. Jarlath loses his balance and falls from the crossing. You hold your ground.

**Private hint ladder:**

1. This is not a contest of strength.
2. He reacts to the flower's pollen.
3. Use the flower on Jarlath.

**Research anchors:** [late_abandonware](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=31&page=1), [late_gallery](https://www.planete-aventure.net/jeux.php?num_jeu=1626&cat=screenshots). Narration is original.

## d_epilogue — A Future Still Possible

**On arrival — adjust to current state:**

The ravine is quiet again. Behind you, a child still has a future; ahead lies the impossible task of explaining where you have been. When familiar voices finally call you back, the journey already has the strange distance of a dream. You remember the choices that made it real.

### Inspection material

- **victory:** Maximin survives; Jarlath's immediate threat has ended. This short epilogue is original connective narration, not a transcription of the final cutscene.

### Actions and state changes

**Research anchors:** [late_won](https://advgamer.blogspot.com/2023/09/lost-in-time-won.html). Narration is original.

