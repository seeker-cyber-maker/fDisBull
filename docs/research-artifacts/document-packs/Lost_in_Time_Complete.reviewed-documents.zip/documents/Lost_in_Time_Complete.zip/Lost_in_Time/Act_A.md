# Act A — The Briscarde: awakening

## a_hold — The Briscarde — locked hold

**On arrival — adjust to current state:**

Timbers complain around you as the ship rolls. Amber light catches the edges of barrels and a low stool; cobwebs bridge the overhead beams. A heavy post rises toward the deck above. There is a lower opening in the floor, and a faded poster covers part of the wooden wall. Somewhere beyond that wall, another person shifts.

### Inspection material

- **stool:** A low stool has an uneven underside.
- **near barrel:** One barrel stands slightly away from the wall.
- **dark barrels:** The recess behind them is too dim to search properly.
- **water bucket:** A bucket contains enough water to wet something.
- **poster:** The paper is stuck against the wooden partition.
- **support post:** The overhead opening is out of reach; the wood could hold footholds.

### Exits

- **down to the bilge** → `a_bilge`. Requires `item:lamp`.
- **up to the mid-deck** → `a_middeck`. Requires `flag:a_steps_carved`.

### Actions and state changes

#### a_take_nail: Pull the nail from beneath the stool

Equivalent phrasing: use pliers on stool; take nail; pull nail.

**Requires:** `item:pliers`. Once only.

**Effects:** give items: `nail`.

**Outcome:** The pliers draw out a sound nail. You pocket it.

**Private hint ladder:**

1. Check what is holding the stool together.
2. There is a nail underneath; bare fingers will not pull it.
3. Use the pliers on the nail beneath the stool.

#### a_find_lamp: Search behind the near barrel

Equivalent phrasing: search barrel; take lamp; look behind barrel.

**Requires:** none. Once only.

**Effects:** give items: `lamp`.

**Outcome:** Your hand closes around a lamp. Its light makes the hold much easier to examine.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search behind the near barrel

#### a_find_sponge: Light and search the dark barrels

Equivalent phrasing: use lamp on barrels; search dark barrels.

**Requires:** `item:lamp`. Once only.

**Effects:** give items: `sponge`.

**Outcome:** In the lamplight you find a sponge tucked behind the barrels.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Light and search the dark barrels

#### a_wet_sponge: Wet the sponge in the bucket

Equivalent phrasing: use sponge on bucket; soak sponge.

**Requires:** `item:sponge`. Once only.

**Effects:** remove items: `sponge`; give items: `wet_sponge`.

**Outcome:** The sponge absorbs water.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Wet the sponge in the bucket

#### a_remove_poster: Wash the poster with the wet sponge

Equivalent phrasing: use wet sponge on poster; remove poster; wash poster.

**Requires:** `item:wet_sponge`. Once only.

**Effects:** set flags: `a_poster_removed`.

**Outcome:** The paper loosens. Beneath it is a knot in the wooden partition.

**Private hint ladder:**

1. The paper is hiding the wood beneath it.
2. Soften the paper before trying to peel it away.
3. Use the wet sponge on the poster.

#### a_remove_knot: Remove the wooden knot with the corkscrew

Equivalent phrasing: use corkscrew on knot; remove knot.

**Requires:** `flag:a_poster_removed`, `item:corkscrew`. Once only.

**Effects:** set flags: `a_hole_open`.

**Outcome:** The knot comes free, leaving an opening through the partition.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Remove the wooden knot with the corkscrew

#### a_meet_yoruba: Speak through the hole

Equivalent phrasing: talk to Yoruba; look through hole; call through hole.

**Requires:** `flag:a_hole_open`. Once only.

**Effects:** give items: `knife`; set flags: `a_yoruba_met`.

**Outcome:** Yoruba, another prisoner, answers. He lends you a knife to cut footholds in the post, asking for it back when you have finished. He also asks you not to leave him behind.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Speak through the hole

#### a_carve_steps: Carve footholds into the post and return the borrowed knife

Equivalent phrasing: use knife on post; carve post; make steps.

**Requires:** `item:knife`. Once only.

**Effects:** remove items: `knife`; set flags: `a_steps_carved`.

**Outcome:** You cut footholds into the post, then pass the borrowed knife back to Yoruba. The opening above is now reachable.

**Private hint ladder:**

1. The opening is above you, and there is no ladder.
2. A sturdy wooden support is close enough to climb if you improve your grip.
3. Carve footholds into the post with the knife.

**Research anchors:** [early_sierrahelp](https://sierrahelp.com/Walkthroughs/LostInTimeWalkthrough.html). Narration is original.

## a_bilge — The bilge

**On arrival — adjust to current state:**

The air changes as you descend: closer, wetter, heavy with the ship's neglected underside. Lamplight glances across standing water. A cask rests against the timbers, and a pump waits beside it. A length of chain disappears toward a low corner. Every movement of the hull sends another small ripple through the darkness.

### Inspection material

- **cask:** Its contents are worth checking.
- **bilge pump:** The handle resists movement.
- **chain:** The low corner beneath it is flooded until the pump works.

### Exits

- **up to the hold** → `a_hold`. Requires none.

### Actions and state changes

#### a_find_oil: Search the cask

Equivalent phrasing: inspect cask; take oil.

**Requires:** none. Once only.

**Effects:** give items: `palm_oil`.

**Outcome:** Inside the cask you find a bottle of oil.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search the cask

#### a_oil_pump: Oil the pump handle

Equivalent phrasing: use oil on pump; lubricate pump.

**Requires:** `item:palm_oil`. Once only.

**Effects:** remove items: `palm_oil`; set flags: `a_pump_oiled`.

**Outcome:** The oil works into the seized joint.

**Private hint ladder:**

1. The pump is present, but its mechanism is stiff.
2. The cask contains something suitable for a seized joint.
3. Use the oil on the pump handle.

#### a_pump_water: Work the pump

Equivalent phrasing: pump water; pull pump handle.

**Requires:** `flag:a_pump_oiled`. Once only.

**Effects:** set flags: `a_bilge_drained`.

**Outcome:** The handle moves. With repeated strokes, the water falls away from the corner beside the chain.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Work the pump

#### a_find_corkscrew: Search the drained corner beneath the chain

Equivalent phrasing: inspect chain; take corkscrew; search chain.

**Requires:** `flag:a_bilge_drained`. Once only.

**Effects:** give items: `corkscrew`.

**Outcome:** You retrieve a corkscrew from beside the chain.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search the drained corner beneath the chain

**Research anchors:** [early_sierrahelp](https://sierrahelp.com/Walkthroughs/LostInTimeWalkthrough.html). Narration is original.

## a_middeck — The mid-deck

**On arrival — adjust to current state:**

The deck stretches between heavy ribs of timber. Cannons and their ammunition crowd the passage; a damaged oar lies near the cannonballs. Containers stand farther aft, below a hanging ring and a wall panel. Forward, a sliding door refuses to move cleanly. There is someone behind it, close enough to hear you trying.

### Inspection material

- **wooden pegs:** A useful wooden pin can be pulled from the rack.
- **broken oar:** Damaged, but still a good length of wood.
- **containers:** The middle container holds something folded.
- **hanging ring:** Its surface is unpleasant to grip firmly.
- **concealed wall panel:** The hanging ring operates this panel.
- **chipped cannon:** The rough metal would abrade a softer material.
- **sliding door:** The lower runner is the source of the resistance.

### Exits

- **down to the hold** → `a_hold`. Requires none.

### Actions and state changes

#### a_take_pin: Pull a wooden pin from the rack

Equivalent phrasing: use pliers on peg; take wooden pin.

**Requires:** `item:pliers`. Once only.

**Effects:** give items: `wooden_pin`.

**Outcome:** A wooden pin comes away in the pliers.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Pull a wooden pin from the rack

#### a_take_oar: Take the broken oar

Equivalent phrasing: take oar; search cannonballs.

**Requires:** none. Once only.

**Effects:** give items: `broken_oar`.

**Outcome:** You take the broken oar from beside the cannonballs.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Take the broken oar

#### a_take_towel: Search the middle container

Equivalent phrasing: take towel; search containers.

**Requires:** none. Once only.

**Effects:** give items: `towel`.

**Outcome:** You find a towel in the middle container.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search the middle container

#### a_pull_ring: Pull the ring using the towel

Equivalent phrasing: use towel on ring; pull ring with towel.

**Requires:** `item:towel`. Once only.

**Effects:** set flags: `a_cache_open`.

**Outcome:** With the towel around your hand, you get a firm hold. The ring moves and a panel opens.

**Private hint ladder:**

1. The ring moves a mechanism, but it is difficult to hold.
2. Protect your hand and improve your grip.
3. Wrap the towel around the ring and pull.

#### a_take_soap: Search the opened wall compartment

Equivalent phrasing: take soap; search cache.

**Requires:** `flag:a_cache_open`. Once only.

**Effects:** give items: `soap`.

**Outcome:** The compartment contains a bar of soap.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search the opened wall compartment

#### a_shave_soap: Rub the soap against the chipped cannon

Equivalent phrasing: use soap on cannon; make soap shavings.

**Requires:** `item:soap`. **Forbidden when:** `done:a_shave_soap_corkscrew`. Once only.

**Effects:** remove items: `soap`; give items: `soap_shavings`.

**Outcome:** The rough metal scrapes the soap into shavings.

**Private hint ladder:**

1. The door runner needs something that will reduce friction.
2. A solid bar is awkward; a rough surface can reduce it to small pieces.
3. Rub the soap on the chipped cannon.

#### a_shave_soap_corkscrew: Shave the soap with the corkscrew

Equivalent phrasing: use corkscrew on soap.

**Requires:** `item:soap`, `item:corkscrew`. **Forbidden when:** `done:a_shave_soap`. Once only.

**Effects:** remove items: `soap`; give items: `soap_shavings`.

**Outcome:** The corkscrew scrapes usable shavings from the bar.

**Private hint ladder:**

1. The door runner needs lubrication.
2. You can scrape the soap with a rough tool.
3. Shave the soap with the corkscrew.

#### a_lubricate_door: Put soap shavings in the door runner

Equivalent phrasing: use soap shavings on door; lubricate door.

**Requires:** `item:soap_shavings`. Once only.

**Effects:** remove items: `soap_shavings`; set flags: `a_door_lubricated`.

**Outcome:** The shavings settle into the runner. The door can now slide.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Put soap shavings in the door runner

#### a_begin_flashback: Open the sliding door and speak to Melkior

Equivalent phrasing: open sliding door; talk to Melkior.

**Requires:** `flag:a_door_lubricated`. Once only.

**Effects:** checkpoint `begin_flashback`; set flags: `a_melkior_met`; move to `b_gate`.

**Outcome:** The bound man calls himself Melkior. He says this ship is sailing in 1840. As you try to explain that you belong in 1992, the memory returns: your inherited manor, the missing notary, a tractor, and a horse blocking the gate. The remembered day begins.

**Private hint ladder:**

1. Someone is behind the door.
2. Once its runner is lubricated, you can open it.
3. Open the sliding door and speak to Melkior.

**Research anchors:** [early_sierrahelp](https://sierrahelp.com/Walkthroughs/LostInTimeWalkthrough.html), [early_walkthroughking](https://www.walkthroughking.com/text/lostintime.aspx). Narration is original.

