# Act C — The Briscarde: escape

## c_middeck — Between Decks Again

**On arrival — adjust to current state:**

The ship answers your returning footsteps with a long wooden groan. Cannons crowd the passage, and ropes vanish into the beams. You remember this place differently now. The barred hatch behind you conceals another prisoner; ahead, someone still needs help. Small discarded fittings may be more useful than the guns.

### Inspection material

- **barred hatch:** A sliding bar and a separate iron lock keep it shut.
- **hanging ring:** The ring operates the wall compartment found earlier.
- **loose fittings:** There are loose wooden fittings near the ammunition racks. Examine any you have not already collected.

### Exits

- **hold** → `c_hold`. Requires none.
- **rigging closet** → `c_rigging`. Requires none.
- **Melkior's cabin** → `c_melkior`. Requires none.
- **upper passage** → `c_cellar`. Requires `flag:c_captain_entered`.
- **prisoner's hatch** → `c_yoruba`. Requires `flag:c_hatch_unlocked`.

### Actions and state changes

#### c_bend_nail: Bend the nail with the pliers

**Requires:** `item:nail`, `item:pliers`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `nail`; give items: `twisted_nail`.

**Outcome:** The nail becomes a small hook.

**Private hint ladder:**

1. A straight nail cannot catch a distant loop.
2. The pliers can change the nail's shape.
3. Bend the nail with the pliers.

#### c_make_boat_hook: Bind the broken oar and wooden pin with ribbon, then attach the twisted nail

Equivalent phrasing: make a boat hook; combine oar pin ribbon and hook.

**Requires:** `item:broken_oar`, `item:wooden_pin`, `item:ribbon`, `item:twisted_nail`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `broken_oar`, `wooden_pin`, `ribbon`, `twisted_nail`; give items: `boat_hook`.

**Outcome:** You bind the pieces into a long hook sturdy enough to pull a rope.

**Private hint ladder:**

1. The high rigging needs reach, not force.
2. Make a handle from the oar and pin; the ribbon binds it.
3. Combine broken oar, wooden pin, ribbon and twisted nail.

#### c_release_hatch_bar: Pull the ring with the towel and set the covered cage in the compartment

**Requires:** `item:towel`, `item:covered_cage`. Once only.

**Effects:** set flags: `c_hatch_unbarred`.

**Outcome:** The cage's weight trips the mechanism. You recover it; the bar over the hatch stays withdrawn.

**Private hint ladder:**

1. The wall compartment has a weighted bottom.
2. Try a heavy object you can retrieve afterward.
3. Use towel on ring, then put the covered cage inside and retrieve it.

#### c_unlock_hatch: Unlock the hatch with the iron key

**Requires:** `flag:c_hatch_unbarred`, `item:iron_key`. Once only.

**Effects:** set flags: `c_hatch_unlocked`.

**Outcome:** The iron key turns. The hatch opens onto Yoruba's cell.

**Private hint ladder:**

1. The bar and lock are separate obstacles.
2. The captain kept an iron key in his cupboard.
3. After retracting the bar, use the iron key on the hatch.

### Earlier ship searches still available

These are the same actions and completion records as in Act A. They permit collecting a previously missed object, not taking it twice.

- `a_take_pin`: Pull a wooden pin from the rack
- `a_take_oar`: Take the broken oar
- `a_take_towel`: Search the middle container
- `a_pull_ring`: Pull the ring using the towel
- `a_take_soap`: Search the opened wall compartment
- `a_shave_soap`: Rub the soap against the chipped cannon
- `a_shave_soap_corkscrew`: Shave the soap with the corkscrew
- `a_lubricate_door`: Put soap shavings in the door runner

**Research anchors:** [late_steph](https://jeux.dokokade.net/2017/07/24/soluce-retrocompatible-lost-in-time-pc-2/), [late_harmen](https://www.harmendeweerd.nl/lost-in-time/). Narration is original.

## c_hold — The Clothes Chest

**On arrival — adjust to current state:**

The low hold feels smaller after your journey through the manor. A stool stands beside the familiar barrels. Against the wall sits a deep chest. Its lock is modest, but the lid fits unusually far into the box. The ship creaks around you while the latch holds firm.

### Inspection material

- **locked chest:** A simple lock protects clothing; the interior has a suspicious spring.
- **stool:** The stool and earlier supplies remain available until collected.

### Exits

- **mid-deck** → `c_middeck`. Requires none.

### Actions and state changes

#### c_pick_chest: Pick the chest lock with the small hook and search it

Equivalent phrasing: open clothes chest; use hook on chest.

**Requires:** `item:small_hook`. Once only.

**Effects:** give items: `ribbon`; set flags: `c_clothed`.

**Outcome:** Inside are clothes you can wear and a ribbon. Beneath the lining, a spring conceals a second compartment.

**Private hint ladder:**

1. The new small hook fits a small lock.
2. Search beneath the clothing after opening the chest.
3. Pick the chest with the small hook, then take the ribbon.

#### c_open_false_bottom: Release the chest's false-bottom spring with the dagger

**Requires:** `done:c_pick_chest`, `item:dagger`. Once only.

**Effects:** give items: `beauty_powder`, `clean_handkerchief`; set flags: `c_false_bottom_open`.

**Outcome:** The false bottom lifts. You take cosmetic powder and a clean handkerchief.

**Private hint ladder:**

1. The chest is deeper than its usable interior.
2. A stiff, narrow blade can move the hidden spring.
3. Use the dagger on the false-bottom spring and search both recesses.

### Earlier ship searches still available

These are the same actions and completion records as in Act A. They permit collecting a previously missed object, not taking it twice.

- `a_take_nail`: Pull the nail from beneath the stool
- `a_find_lamp`: Search behind the near barrel
- `a_find_sponge`: Light and search the dark barrels
- `a_wet_sponge`: Wet the sponge in the bucket
- `a_remove_poster`: Wash the poster with the wet sponge
- `a_remove_knot`: Remove the wooden knot with the corkscrew
- `a_meet_yoruba`: Speak through the hole
- `a_carve_steps`: Carve footholds into the post and return the borrowed knife
- `a_find_oil`: Search the cask
- `a_oil_pump`: Oil the pump handle
- `a_pump_water`: Work the pump
- `a_find_corkscrew`: Search the drained corner beneath the chain

**Research anchors:** [late_steph](https://jeux.dokokade.net/2017/07/24/soluce-retrocompatible-lost-in-time-pc-2/), [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99). Narration is original.

## c_rigging — Rope Closet and Porthole

**On arrival — adjust to current state:**

A narrow storage bay presses you between hanging tackle and the ship's curved side. One loop hangs above your reach. Nearby, a porthole frames restless water and a thin rope trailing out of sight. These two ends of the same problem are close enough to see, but awkward to hold together.

### Inspection material

- **high halyard loop:** A loop can be pulled down with something long.
- **wall notch:** A firm metal peg would make an anchor.
- **porthole rope:** A bucket hangs outside; the rigging must be held before it can be recovered.

### Exits

- **mid-deck** → `c_middeck`. Requires none.

### Actions and state changes

#### c_lower_halyard: Catch the halyard with the boat hook

**Requires:** `item:boat_hook`. Once only.

**Effects:** set flags: `c_halyard_lowered`.

**Outcome:** The hook catches the loop. You pull its end within reach.

**Private hint ladder:**

1. Reach the loop without climbing.
2. The homemade boat hook is long enough.
3. Use the boat hook on the halyard.

#### c_anchor_halyard: Put the corkscrew in the notch and tie the halyard to it

**Requires:** `flag:c_halyard_lowered`, `item:corkscrew`. Once only.

**Effects:** remove items: `corkscrew`; set flags: `c_halyard_anchored`.

**Outcome:** The corkscrew holds the line fast.

**Private hint ladder:**

1. You need both hands free to retrieve the bucket.
2. The notch can hold the corkscrew as a temporary peg.
3. Anchor the halyard to a corkscrew in the wall notch.

#### c_get_saw: Pull up the porthole rope and search the bucket thoroughly

**Requires:** `flag:c_halyard_anchored`. Once only.

**Effects:** give items: `sawfish_saw`.

**Outcome:** Among the bucket's contents lies the toothed rostrum of a sawfish. It could cut bindings.

**Private hint ladder:**

1. The outside rope supports a container.
2. Raise and thoroughly search the bucket.
3. Pull the porthole rope and take the sawfish saw from the bucket.

#### c_recover_corkscrew: Untie the halyard and retrieve the corkscrew

**Requires:** `done:c_get_saw`, `flag:c_halyard_anchored`. Once only.

**Effects:** give items: `corkscrew`; clear flags: `c_halyard_anchored`.

**Outcome:** You free the corkscrew and put it away. The recovered saw stays with you.

**Private hint ladder:**

1. Your temporary anchor is a useful tool.
2. The bucket has been recovered; the line no longer needs securing.
3. Recover the corkscrew before leaving.

**Research anchors:** [late_steph](https://jeux.dokokade.net/2017/07/24/soluce-retrocompatible-lost-in-time-pc-2/). Narration is original.

## c_melkior — Melkior's Bindings

**On arrival — adjust to current state:**

Melkior has had ample time to plan while waiting for you, and rather less opportunity to move. His bindings are still tight. He glances at your improvised collection of tools with renewed interest. Beyond freeing him, you still have Yoruba to rescue and a captain whose cooperation seems unlikely.

### Inspection material

- **Melkior:** He needs something capable of sawing through his bindings.

### Exits

- **mid-deck** → `c_middeck`. Requires none.

### Actions and state changes

#### c_free_melkior: Cut Melkior free with the sawfish saw

**Requires:** `item:sawfish_saw`. Once only.

**Effects:** remove items: `sawfish_saw`; set flags: `c_melkior_free`, `c_captain_entered`; move to `c_captain`.

**Outcome:** The bindings part. With Oswald's help, Melkior arranges your access to Philibert. The captain promptly confines you to his quarters, leaving his parrot to watch you.

**Private hint ladder:**

1. The rostrum has a serrated edge.
2. The teeth can work through the bindings. Any tool left in the rigging can be recovered later.
3. Use the sawfish saw to free Melkior.

**Research anchors:** [late_steph](https://jeux.dokokade.net/2017/07/24/soluce-retrocompatible-lost-in-time-pc-2/), [late_lockbox](https://advgamer.blogspot.com/2023/09/lost-in-time-one-two-three-lock-box.html). Narration is original.

## c_captain — The Captain's Study

**On arrival — adjust to current state:**

Red-brown beams frame blue-green panels, and a bright parrot surveys the room as if it owns the ship. A desk, a locked cupboard and a maritime painting invite investigation. A balcony opens toward the sea; side doors lead to a washroom and bedchamber. The main door closes firmly behind you.

### Inspection material

- **Galipo the parrot:** He protests whenever you approach the cupboard or painting.
- **desk and chair:** A locked drawer faces a chair with an inspectable underside.
- **locked cupboard:** The parrot watches its silver-key lock.
- **music table:** An empty place waits for an instrument.
- **round furniture mark:** A circular mark suggests something once stood here.
- **battle painting:** A naval battle fills the frame. One cannon flash sits slightly proud of the painted surface.
- **stern balcony:** A pirate flag hangs within reach outside.

### Exits

- **washroom** → `c_washroom`. Requires none.
- **bedchamber** → `c_bedroom`. Requires none.

### Actions and state changes

#### c_take_flag: Take the pirate flag from the balcony

**Requires:** none. Once only.

**Effects:** give items: `pirate_flag`.

**Outcome:** You fold the flag and bring it inside.

**Private hint ladder:**

1. The balcony contains portable fabric.
2. A flag can cover more than a mast.
3. Take the pirate flag.

#### c_search_chair: Search beneath the desk chair

**Requires:** none. Once only.

**Effects:** give items: `silver_key`.

**Outcome:** A silver key is concealed beneath the chair.

**Private hint ladder:**

1. Look underneath furniture, not only on top.
2. Inspect the desk chair's underside.
3. Search beneath the desk chair for a silver key.

#### c_open_desk: Unlock the desk drawer with the brass key and search it

**Requires:** `item:brass_key`. Once only.

**Effects:** give items: `blotter`, `dagger`.

**Outcome:** You find a blotter and a dagger farther back in the drawer.

**Private hint ladder:**

1. The small brass key fits a small drawer.
2. Search the full depth of the desk drawer.
3. Use the brass key on the drawer; take blotter and dagger.

#### c_prepare_cage: Put the golden cage on the round mark and bait it with bananas

**Requires:** `item:golden_cage`, `item:banana_slices`. Once only.

**Effects:** remove items: `golden_cage`, `banana_slices`; set flags: `c_cage_prepared`.

**Outcome:** The cage fits the mark. Banana slices make it more inviting.

**Private hint ladder:**

1. Galipo needs somewhere preferable to his perch.
2. The cage fits the circular mark, and the bananas are bait.
3. Place the cage on the marked furniture and put bananas inside.

#### c_prepare_bowl: Set the bowl beneath Galipo and combine the two odor-making ingredients

Equivalent phrasing: mix salts and paint remover in the bowl; prepare the smell beneath the parrot.

**Requires:** `item:bowl`, `item:salts_flask`, `item:paint_remover`, `flag:c_cage_prepared`. Once only.

**Effects:** remove items: `bowl`, `salts_flask`, `paint_remover`; set flags: `c_odor_ready`.

**Outcome:** A sharp smell rises from the bowl. Galipo shuffles away from his perch and eyes the baited cage.

**Private hint ladder:**

1. Make the perch less comfortable while offering a better place.
2. The bowl belongs underneath Galipo.
3. Use the bowl, salts flask and paint remover beneath Galipo.

#### c_play_record: Set up the phonograph and record, wind it, and start it

**Requires:** `item:phonograph`, `item:record`. Once only.

**Effects:** remove items: `phonograph`, `record`; set flags: `c_music_playing`.

**Outcome:** A tune turns the study into a surprisingly comfortable prison.

**Private hint ladder:**

1. A music table deserves its name.
2. The phonograph needs its record, winding and starting.
3. Place the phonograph and record, turn the crank and start it.

#### c_cover_parrot: Cover Galipo's cage with the pirate flag

**Requires:** `flag:c_cage_prepared`, `flag:c_odor_ready`, `flag:c_music_playing`, `item:pirate_flag`. Once only.

**Effects:** remove items: `pirate_flag`; give items: `covered_cage`; set flags: `c_bird_quiet`.

**Outcome:** Galipo enters the baited cage. Under the flag, with music playing, he finally settles. You can carry the covered cage.

**Private hint ladder:**

1. Food, a changed perch and music prepare him; darkness finishes the job.
2. Wait until the cage, odor and phonograph are ready, then use the flag.
3. Cover the prepared cage with the pirate flag.

#### c_open_cupboard: Unlock the cupboard with the silver key and open its jewelry box

**Requires:** `flag:c_bird_quiet`, `item:silver_key`. Once only.

**Effects:** give items: `iron_key`.

**Outcome:** The jewelry box contains an iron key rather than jewels.

**Private hint ladder:**

1. The bird no longer guards the cupboard.
2. Try the key found under the chair.
3. Use the silver key on the cupboard and search the jewelry box.

#### c_reveal_safe: Press the cannon flash in the painting

**Requires:** `flag:c_bird_quiet`. Once only.

**Effects:** set flags: `c_safe_visible`.

**Outcome:** The painting swings away, exposing a safe.

**Private hint ladder:**

1. The battle picture has one unusually distinct detail.
2. Inspect the flash at the mouth of a cannon.
3. Press the cannon flash to reveal the safe.

#### c_open_safe: Enter 3E21 on the safe

Equivalent phrasing: open safe with the reflected code; enter three e two one.

**Requires:** `flag:c_safe_visible`, `flag:c_safe_code_known`. Once only.

**Effects:** give items: `puzzle_box`; set flags: `c_safe_open`.

**Outcome:** The safe opens. Inside is a small box with movable panels.

**Private hint ladder:**

1. The safe's answer is written elsewhere in reverse.
2. Reflect the blotter in the polished washbasin.
3. Enter the learned combination: 3E21.

#### c_box_key: Rotate the puzzle box and slide its upper panel

**Requires:** `item:puzzle_box`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** give items: `small_gold_key`; set flags: `c_box_key_found`.

**Outcome:** A hidden compartment reveals a tiny gold key.

**Private hint ladder:**

1. Examine the box from more than one side.
2. A compartment in the upper side hides its own key.
3. Rotate the box and slide its upper panel to get the key.

#### c_get_revolver: Move the box's front panels and unlock it with the small gold key

**Requires:** `item:puzzle_box`, `item:small_gold_key`, `flag:c_box_key_found`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** give items: `revolver`; set flags: `c_box_open`.

**Outcome:** The final panel opens on Philibert's revolver. Its mechanism is locked by something more unusual than an ordinary safety.

**Private hint ladder:**

1. The hidden key belongs to a second opening in the same box.
2. Move the front upper and middle panels to expose the lock.
3. Expose the box's keyhole and use the small gold key.

**Research anchors:** [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99), [late_harmen](https://www.harmendeweerd.nl/lost-in-time/), [late_gallery](https://www.planete-aventure.net/jeux.php?num_jeu=1626&cat=screenshots). Narration is original.

## c_washroom — The Tarnished Basin

**On arrival — adjust to current state:**

The washroom offers a little privacy and several neglected surfaces. The basin has lost its shine, the rug has curled at one corner, and a cabinet bears a shaped indentation instead of an ordinary handle. Here, at least, the parrot's objections are muffled by a wall.

### Inspection material

- **curled rug corner:** Something lies beneath it.
- **tarnished basin:** A polished surface could reflect small writing.
- **shaped cabinet indentation:** Its outline resembles a seal rather than a keyhole.

### Exits

- **captain's study** → `c_captain`. Requires none.
- **concealed music room** → `c_musicroom`. Requires `flag:c_musicroom_open`.

### Actions and state changes

#### c_get_brass_key: Lift the washroom rug's corner

**Requires:** none. Once only.

**Effects:** give items: `brass_key`.

**Outcome:** A brass key lies beneath the rug.

**Private hint ladder:**

1. One corner of the rug curls upward.
2. Look beneath the loose corner.
3. Lift the rug corner and take the brass key.

#### c_polish_sink: Polish the basin with polish on the clean handkerchief

**Requires:** `item:polish`, `item:clean_handkerchief`. Once only.

**Effects:** set flags: `c_sink_polished`.

**Outcome:** The dull basin becomes reflective.

**Private hint ladder:**

1. The blotter's reversed marks need a mirror.
2. Use polish on a clean cloth, then rub the basin.
3. Polish the basin with polish and the clean handkerchief.

#### c_read_code: Hold the blotter to the polished basin

**Requires:** `item:blotter`, `flag:c_sink_polished`. Once only.

**Effects:** set flags: `c_safe_code_known`.

**Outcome:** In the reflection, the reversed marks become 3E21. You remember the combination.

**Private hint ladder:**

1. Reversed writing can become readable in a reflection.
2. The polished basin is the mirror you need.
3. Reflect the blotter in the polished basin: 3E21.

#### c_open_musicroom: Press the signet ring into the cabinet indentation

**Requires:** `item:signet_ring`. Once only.

**Effects:** set flags: `c_musicroom_open`.

**Outcome:** The seal fits. A concealed passage opens behind the cabinet.

**Private hint ladder:**

1. The cabinet wants an impression, not a conventional key.
2. Compare the office's signet ring with the indentation.
3. Use the signet ring in the cabinet's shaped indentation.

**Research anchors:** [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99), [late_steph](https://jeux.dokokade.net/2017/07/24/soluce-retrocompatible-lost-in-time-pc-2/). Narration is original.

## c_bedroom — Philibert's Bedchamber

**On arrival — adjust to current state:**

A bed and a broad cabinet crowd the chamber. The room has the air of someone who expects others to tidy after him. A plate of bananas waits nearby. The rug covers an area of floor with a noticeably different outline, and the cabinet's two doors conceal separate spaces.

### Inspection material

- **two-door cabinet:** Both compartments deserve a search.
- **banana plate:** The slices are portable.
- **rug over an outline:** Something below the fabric interrupts the floorboards.

### Exits

- **captain's study** → `c_captain`. Requires none.
- **trapdoor to cellar** → `c_cellar`. Requires `flag:c_bedroom_trapdoor`.

### Actions and state changes

#### c_search_bedroom_cabinet: Open and search both sides of the bedroom cabinet

**Requires:** none. Once only.

**Effects:** give items: `salts_flask`, `bowl`.

**Outcome:** One side holds a flask of salts; the other holds a bowl.

**Private hint ladder:**

1. The cabinet is divided into separate compartments.
2. Opening one door does not search the other.
3. Search both cabinet compartments for the salts flask and bowl.

#### c_take_bananas: Take the banana slices

**Requires:** none. Once only.

**Effects:** give items: `banana_slices`.

**Outcome:** You pocket the banana slices.

**Private hint ladder:**

1. The parrot may respond to food.
2. Look at the plate in the bedroom.
3. Take the bananas.

#### c_cut_rug: Cut around the trapdoor with the dagger

**Requires:** `item:dagger`. Once only.

**Effects:** set flags: `c_bedroom_trapdoor`.

**Outcome:** You free the concealed trapdoor and open a route down to the cellar.

**Private hint ladder:**

1. The floor outline is larger than a loose board.
2. The rug must be cut free around it.
3. Use the dagger on the rug to uncover the cellar trapdoor.

**Research anchors:** [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99). Narration is original.

## c_cellar — Cellar and Upper Passage

**On arrival — adjust to current state:**

The post under the trapdoor is polished by years of handling and much too slippery to climb. A small opening interrupts its surface. Outside the cellar, the passage offers a practical choice: a storeroom, a more elegant office, or the stairs back toward the lower decks.

### Inspection material

- **slippery post:** An opening suggests a concealed fitting; the surface offers poor grip.
- **storeroom door:** Locked.
- **elegant office door:** Also locked, with a matching type of lock.

### Exits

- **mid-deck** → `c_middeck`. Requires none.
- **bedchamber above** → `c_bedroom`. Requires `flag:c_post_grippy`.
- **storeroom** → `c_storeroom`. Requires `flag:c_storeroom_unlocked`.
- **office** → `c_office`. Requires `flag:c_office_unlocked`.

### Actions and state changes

#### c_get_master_key: Use the corkscrew in the post's opening

**Requires:** `item:corkscrew`. Once only.

**Effects:** give items: `master_key`.

**Outcome:** The opening releases a concealed master key.

**Private hint ladder:**

1. The post's opening needs a temporary handle.
2. Try the tool that already served as a wooden plug puller.
3. Use the corkscrew in the post's opening.

#### c_powder_post: Rub beauty powder on the slippery post

**Requires:** `item:beauty_powder`. Once only.

**Effects:** remove items: `beauty_powder`; set flags: `c_post_grippy`.

**Outcome:** The powder improves your grip enough to climb back to the bedroom.

**Private hint ladder:**

1. You need friction, not another cutting tool.
2. The powder can dry the slippery surface.
3. Use beauty powder on the post.

#### c_unlock_store: Unlock the storeroom with the master key

**Requires:** `item:master_key`. Once only.

**Effects:** set flags: `c_storeroom_unlocked`.

**Outcome:** The storeroom door opens.

**Private hint ladder:**

1. The post concealed a key for this deck.
2. Try the master key.
3. Use the master key on the storeroom door.

#### c_unlock_office: Unlock the office with the master key

**Requires:** `item:master_key`. Once only.

**Effects:** set flags: `c_office_unlocked`.

**Outcome:** The elegant door opens into an office.

**Private hint ladder:**

1. The matching locks suggest one key.
2. The master key fits this door too.
3. Use the master key on the office door.

**Research anchors:** [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99). Narration is original.

## c_storeroom — The Storeroom

**On arrival — adjust to current state:**

Shelves and containers fill a room designed for things somebody might need later. Most are of no immediate use. A small bottle stands apart from the heavier supplies, its worn label identifying it as metal polish. The passage outside remains quiet.

### Inspection material

- **metal polish:** A small bottle on a shelf.

### Exits

- **cellar passage** → `c_cellar`. Requires none.

### Actions and state changes

#### c_take_polish: Take the bottle of polish

**Requires:** none. Once only.

**Effects:** give items: `polish`.

**Outcome:** You take the metal polish.

**Private hint ladder:**

1. A reflective surface may be hidden under tarnish.
2. Search the shelf for polish.
3. Take the polish bottle.

**Research anchors:** [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99). Narration is original.

## c_office — The Elegant Office

**On arrival — adjust to current state:**

Someone has tried to make this office feel less like part of a working ship. A secretary desk faces curtains that conceal the room's corner. The quiet is welcome. The drawer and the space behind those curtains offer two small investigations before you return to the captain's more vocal guard.

### Inspection material

- **secretary desk:** Its drawer is accessible.
- **corner curtains:** They conceal an object with a metallic outline.

### Exits

- **cellar passage** → `c_cellar`. Requires none.

### Actions and state changes

#### c_take_ring: Search the secretary desk drawer

**Requires:** none. Once only.

**Effects:** give items: `signet_ring`.

**Outcome:** You find a ring bearing a seal.

**Private hint ladder:**

1. The office has a modest piece of jewelry.
2. Search the secretary drawer.
3. Open the drawer and take the signet ring.

#### c_take_cage: Draw the curtains aside and take the golden cage

**Requires:** none. Once only.

**Effects:** give items: `golden_cage`.

**Outcome:** A golden cage waits behind the curtains. Its base feels surprisingly heavy.

**Private hint ladder:**

1. The corner is concealed rather than empty.
2. Look behind the curtains.
3. Open the curtains and take the golden cage.

**Research anchors:** [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99). Narration is original.

## c_musicroom — A Room Out of Its Century

**On arrival — adjust to current state:**

The hidden room feels wrong in a way the locked doors did not. A bar, comfortable seats and a record player suggest possessions assembled without much respect for their century. Jarlath has left more than secrecy behind him. For now, the music-making equipment offers a practical use.

### Inspection material

- **low table:** A record rests on its shelf.
- **bar counter:** A phonograph is tucked behind it.

### Exits

- **washroom** → `c_washroom`. Requires none.

### Actions and state changes

#### c_take_music: Search the low table and bar for the record and phonograph

**Requires:** none. Once only.

**Effects:** give items: `record`, `phonograph`.

**Outcome:** You take the record and phonograph. Their presence is another sign that the ship's owner has been traveling through time.

**Private hint ladder:**

1. The captain has a music table but no player beside it.
2. Search both the low table and bar.
3. Take the record and phonograph.

**Research anchors:** [late_mogelpower](https://www.mogelpower.de/cheats/loesung.php?id=17601&pf=99), [late_lockbox](https://advgamer.blogspot.com/2023/09/lost-in-time-one-two-three-lock-box.html). Narration is original.

## c_yoruba — Yoruba and the Sarcophagus

**On arrival — adjust to current state:**

Yoruba raises his head as you descend. His shackles keep him close to the ship's buried treasure. The mast contains a narrow door that refuses to remain open, and a bottle rests high inside it. Something shines between the floorboards. At last, your promises can become more than conversation.

### Inspection material

- **Yoruba:** He is shackled and concerned for his ancestral necklace.
- **shining floor crack:** A metal-bearing pendant is caught below the boards.
- **mast door and high shelf:** The door springs closed; a bottle would break if dropped.
- **cotton behind the sarcophagus:** A bale could cushion a fall.

### Exits

- **mid-deck** → `c_middeck`. Requires none.

### Actions and state changes

#### c_get_magnetite: Retrieve the necklace from the floor crack with the pliers

Equivalent phrasing: retrieve scarab.

**Requires:** `item:pliers`. Once only.

**Effects:** give items: `magnetite`; set flags: `c_necklace_recovered`.

**Outcome:** The scarab pendant clings to the tool. Its magnetite may replace the magnetic rings that operate Philibert's revolver.

**Private hint ladder:**

1. The revolver's lock and the shining necklace may be related.
2. Recover the pendant before leaving the pliers elsewhere.
3. Use the pliers to retrieve the magnetite necklace from the floor.

#### c_enable_gun: Hold the magnetite against the revolver

**Requires:** `item:magnetite`, `item:revolver`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** set flags: `c_revolver_enabled`.

**Outcome:** The magnetic interlock releases.

**Private hint ladder:**

1. The revolver was designed to respond to magnetism.
2. Use the magnetic necklace in place of the captain's rings.
3. Apply the magnetite to the revolver.

#### c_free_yoruba: Shoot Yoruba's shackles with the enabled revolver

**Requires:** `flag:c_revolver_enabled`, `item:revolver`. Once only.

**Effects:** set flags: `c_yoruba_free`.

**Outcome:** The shackles break. Yoruba stands free at last.

**Private hint ladder:**

1. The prisoner's restraints are the immediate target.
2. The enabled revolver can break them.
3. Use the enabled revolver on Yoruba's shackles.

#### c_take_cotton: Take the cotton bale from behind the sarcophagus

**Requires:** none. Once only.

**Effects:** give items: `cotton_bale`.

**Outcome:** You drag the cotton bale into reach.

**Private hint ladder:**

1. The bottle above the mast door needs a soft landing.
2. Search behind the treasure container.
3. Take the cotton bale.

#### c_wedge_mast: Prop the mast door open with the pliers

**Requires:** `item:pliers`, `flag:c_necklace_recovered`. Once only.

**Effects:** remove items: `pliers`; set flags: `c_mast_wedged`.

**Outcome:** The pliers keep the door open. You recognize where you will find them again, a century and a half later.

**Private hint ladder:**

1. You have seen these pliers lodged here before.
2. Recover Yoruba's necklace first, then leave the pliers as a wedge.
3. Use the pliers to hold the mast door open.

#### c_get_rum: Put the cotton beneath the shelf and hook down the rum bottle

**Requires:** `flag:c_mast_wedged`, `item:cotton_bale`, `item:boat_hook`. Once only.

**Effects:** remove items: `cotton_bale`; give items: `rum_bottle`.

**Outcome:** The bottle drops onto the cotton without breaking.

**Private hint ladder:**

1. Reach alone would send the bottle crashing down.
2. Make a soft landing before using the boat hook.
3. Place cotton below the shelf and use the boat hook on the bottle.

#### c_remove_label: Soak the rum label loose with the wet sponge

**Requires:** `item:rum_bottle`, `item:wet_sponge`. Once only.

**Effects:** give items: `rum_label`.

**Outcome:** The loosened label names the island destination.

**Private hint ladder:**

1. Melkior needs a destination, not a drink.
2. The bottle's label may provide it intact.
3. Use the wet sponge to remove the rum label.

#### c_leave_ship: Show Melkior the rum label and leave with Yoruba

**Requires:** `item:rum_label`, `flag:c_yoruba_free`. Once only.

**Effects:** set flags: `c_ship_completed`; move to `d_beach`.

**Outcome:** The label gives Melkior the information he needs. The three of you leave the ship for St. Cristobald.

**Private hint ladder:**

1. Yoruba must be free and a destination identified.
2. Show the intact rum label to Melkior.
3. Give Melkior the label after freeing Yoruba.

**Research anchors:** [late_lockbox](https://advgamer.blogspot.com/2023/09/lost-in-time-one-two-three-lock-box.html), [late_harmen](https://www.harmendeweerd.nl/lost-in-time/). Narration is original.

