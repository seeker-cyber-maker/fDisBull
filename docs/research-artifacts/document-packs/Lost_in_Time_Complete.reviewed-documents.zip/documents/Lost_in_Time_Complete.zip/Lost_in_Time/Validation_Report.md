# Validation report

29 October 2026 · edition 1.0.0

Declared adaptation state only; not original executable or ChatGPT Live session testing.

| Check | Result | Evidence |
|---|---|---|
| Referential integrity | PASS | Every scene, exit, inherited action, condition token and source reference resolves. |
| Complete reference route | PASS | 265 transitions reach d_epilogue with explicit game_complete. |
| Repair before attaching hose | PASS | The alternate order still permits filling the well and completing the entire adventure. |
| Deliver blouse before returning book | PASS | Delia accepts the book after the blouse is delivered; the potion chain and ending remain reachable. |
| Skipped opening items | PASS | Nail, wooden pin and broken oar can be collected after the flashback through shared searches. |
| Forgotten rigging tool | PASS | The corkscrew can be recovered after entering the captain suite; it is not an artificial prerequisite for cutting bindings. |
| Portable inventory recipes | PASS | Boat hook, cage coins and inverter recipe work outside their suggested introduction rooms and still reach the ending. |
| Documented soap alternative | PASS | Both the rough cannon and corkscrew routes produce the necessary shavings. |
| Blocked actions are atomic | PASS | Missing tools, locked travel, unsafe bag order, premature pliers loss, wrong code and an absent cage do not change state. |
| Flashback, save and undo | PASS | Both temporal boundaries restore the previous game state; mid-flashback save round-trip and nonmutating observation preserve inventory and stash. The runner keeps up to 30 undo snapshots. |
| Save validation | PASS | Incomplete saves, bad journal shape and a foreign-game undo snapshot are rejected before play. |

No actual voice session was launched. A language-model narrator can still misinterpret an utterance or lose state; the canonical JSON and portable saves provide a way to inspect and repair such errors.
