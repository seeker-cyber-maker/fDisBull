# Act B — The manor: the remembered day

## b_gate — The manor gate — 1992

**On arrival — adjust to current state:**

A pale stone wall encloses the property you have inherited. Shrubs crowd the approach, and an old tractor waits beside the entrance. A horse occupies the space in front of the gate with the confidence of an owner. Beyond it, a note has been fixed where a visitor should notice it. The gate is secured by a lock.

### Inspection material

- **tractor:** There is a basket above the cab, a toolbox, and a removable battery.
- **horse:** It blocks a comfortable approach to the gate.
- **gate note:** A dart fastens the note to the gate.
- **gate lock:** An old metal lock secures the gate.

### Exits

- **through the gate to the garden** → `b_garden`. Requires `flag:b_gate_open`.

### Actions and state changes

#### b_search_tractor: Search the tractor, basket, and toolbox

Equivalent phrasing: search tractor; search toolbox; inspect tractor.

**Requires:** none. Once only.

**Effects:** give items: `apple`, `battery`, `cigarette_pack`, `pipette`.

**Outcome:** You collect an apple, a battery, a cigarette pack, and a small pipette.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search the tractor, basket, and toolbox

#### b_open_pack: Open the cigarette pack

Equivalent phrasing: inspect pack; open pack.

**Requires:** `item:cigarette_pack`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `cigarette_pack`; give items: `foil`, `match_striker`.

**Outcome:** The pack contains foil and an empty matchbox with a usable striking surface.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Open the cigarette pack

#### b_move_horse: Give the apple to the horse

Equivalent phrasing: feed horse; use apple on horse.

**Requires:** `item:apple`. Once only.

**Effects:** remove items: `apple`; set flags: `b_horse_moved`.

**Outcome:** The horse follows the apple away from the gate.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Give the apple to the horse

#### b_read_gate_note: Read the note and remove its dart

Equivalent phrasing: read note; take dart; inspect gate.

**Requires:** `flag:b_horse_moved`. Once only.

**Effects:** give items: `dart`; set flags: `b_gate_note_read`.

**Outcome:** You read the note and remove the dart that held it in place. The gate's lock is now within easy reach.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Read the note and remove its dart

#### b_draw_acid: Fill the pipette from the battery

Equivalent phrasing: use pipette on battery; take battery acid.

**Requires:** `item:pipette`, `item:battery`. Once only.

**Effects:** remove items: `battery`; give items: `acid_charge`, `empty_battery`.

**Outcome:** The pipette takes up a small quantity from the battery. The emptied battery remains useful.

**Private hint ladder:**

1. The lock can be defeated using the game's improvised tools.
2. The tractor supplies both a liquid source and a small transfer tool.
3. Fill the pipette from the battery.

#### b_open_gate: Apply the filled pipette to the gate lock

Equivalent phrasing: use acid on lock; open gate lock; use filled pipette on lock.

**Requires:** `flag:b_horse_moved`, `item:acid_charge`. Once only.

**Effects:** remove items: `acid_charge`; set flags: `b_gate_open`.

**Outcome:** The lock yields. The gate swings into the garden.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Apply the filled pipette to the gate lock

**Research anchors:** [early_ltf1](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=0). Narration is original.

## b_garden — The garden and well

**On arrival — adjust to current state:**

Green growth softens the grounds around the stone house. A well occupies the garden, with a faucet on the manor wall nearby. The main entrance is close at hand; farther around the property stand the lighthouse and an ornate stone vault. The sea is somewhere beyond them, audible in the pauses between the wind.

### Inspection material

- **well:** Its water lies too low to retrieve a small floating object by hand.
- **garden faucet:** The supply is controlled elsewhere; a hose can carry its water.
- **hose repair area:** A leak will need both reinforcing material and a binding resin.

### Exits

- **to the manor entrance** → `b_entry`. Requires none.
- **to the lighthouse's north wall** → `b_lighthouse_north`. Requires none.
- **to the vault** → `b_vault`. Requires none.
- **back to the gate** → `b_gate`. Requires none.
- **down the established cliff rope** → `b_beach`. Requires `flag:b_cliff_route`.

### Actions and state changes

#### b_attach_hose_faucet: Attach the recovered hose to the garden faucet

Equivalent phrasing: attach hose to faucet; attach repaired hose to faucet; attach leaky hose to faucet.

**Requires:** none. **Also requires at least one:** `item:leaky_hose`, `item:repaired_hose`. Once only.

**Effects:** set flags: `b_hose_on_faucet`.

**Outcome:** You fasten one end of the hose to the faucet.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Attach the leaky hose to the garden faucet

#### b_patch_hose: Patch the hose with fiberglass and resin

Equivalent phrasing: repair hose; use fiberglass and resin on hose.

**Requires:** `item:leaky_hose`, `item:fiberglass`, `item:resin`. Once only.

**Effects:** remove items: `leaky_hose`, `fiberglass`, `resin`; give items: `repaired_hose`; set flags: `b_hose_repaired`.

**Outcome:** Fiberglass bridges the split, and resin binds it into a firm patch.

**Private hint ladder:**

1. The tear needs reinforcement as well as something adhesive.
2. The crypt and manor supply complementary repair materials.
3. Patch the hose using fiberglass followed by resin.

#### b_position_hose: Put the repaired hose's free end into the well

Equivalent phrasing: put hose in well; use hose end on well.

**Requires:** `item:repaired_hose`, `flag:b_hose_on_faucet`. Once only.

**Effects:** set flags: `b_hose_in_well`.

**Outcome:** The free end hangs inside the well.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Put the repaired hose's free end into the well

#### b_recover_cork: Turn on the faucet and recover the floating cork

Equivalent phrasing: fill well; turn on faucet; take cork.

**Requires:** `flag:b_water_supply`, `flag:b_hose_repaired`, `flag:b_hose_in_well`, `flag:b_cork_in_well`. Once only.

**Effects:** give items: `cork`; set flags: `b_cork_recovered`.

**Outcome:** Water flows into the well. The rising surface brings your escaped cork within reach.

**Private hint ladder:**

1. The missing cork can float.
2. Bring the water to the cork rather than climbing down to it.
3. With the supply valve open and the hose repaired, fill the well and take the cork.

#### b_make_club: Cut the hardened hose patch into a club

Equivalent phrasing: cut hose; use razor on hardened hose; make club.

**Requires:** `item:repaired_hose`, `item:razor`, `flag:b_cork_recovered`. Once only.

**Effects:** remove items: `repaired_hose`; give items: `club`; set flags: `b_hose_cut`.

**Outcome:** The reinforced section has hardened. You cut it free as a compact club, after the hose has finished its work.

**Private hint ladder:**

1. The repair has changed the material as well as sealing it.
2. Once the cork is recovered, the hardened section has another use.
3. Cut out the resin-hardened hose section with the razor.

**Research anchors:** [early_neppomuk](https://neppomuk.ch/PointClick/Coktel/LiT.pdf). Narration is original.

## b_entry — The manor entrance

**On arrival — adjust to current state:**

The manor door is solid and unwelcoming. A portrait hangs above it from a length of wire, and logs have been stacked nearby. The handle does not feel secure. Through the keyhole you can make out the irritating reason an ordinary key will not help: another key has been left in place on the far side.

### Inspection material

- **portrait:** The frame and its hanging wire can be removed together.
- **door handle:** Loose enough to come away.
- **logs:** A single dry log is manageable.
- **keyhole:** An inside key occupies the opening.
- **gap under door:** Wide enough for a thin object, but not for your hand.

### Exits

- **back to the garden** → `b_garden`. Requires none.
- **inside the manor** → `b_interior`. Requires `flag:b_manor_open`.

### Actions and state changes

#### b_take_portrait: Take the portrait and its hanging wire

Equivalent phrasing: take portrait; take picture.

**Requires:** none. Once only.

**Effects:** give items: `portrait`, `portrait_wire`.

**Outcome:** You lift down the portrait and keep the wire.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Take the portrait and its hanging wire

#### b_take_handle: Try the door handle

Equivalent phrasing: take handle; pull handle.

**Requires:** none. Once only.

**Effects:** give items: `door_handle`.

**Outcome:** The handle comes away in your hand. It is still a useful piece of metal.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Try the door handle

#### b_take_log: Take a log

**Requires:** none. Once only.

**Effects:** give items: `log`.

**Outcome:** You select a dry log from the stack.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Take a log

#### b_drop_key: Push the inside key out with the dart

Equivalent phrasing: use dart in keyhole; push key; use dart on lock.

**Requires:** `item:dart`. Once only.

**Effects:** set flags: `b_key_on_floor`.

**Outcome:** The key drops onto the floor on the far side of the door.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Push the inside key out with the dart

#### b_make_coil: Wind the portrait wire around the door handle

Equivalent phrasing: combine wire and handle; make coil.

**Requires:** `item:portrait_wire`, `item:door_handle`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `portrait_wire`, `door_handle`; give items: `coil`.

**Outcome:** You wind the wire around the handle to form a coil.

**Private hint ladder:**

1. You need to attract something metallic on the other side.
2. Wire and a metal core form one part of the solution.
3. Wind the portrait wire around the door handle.

#### b_charge_battery: Pour vinegar into the empty battery

Equivalent phrasing: use vinegar on battery; fill battery.

**Requires:** `item:vinegar`, `item:empty_battery`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `vinegar`, `empty_battery`; give items: `charged_battery`.

**Outcome:** The vinegar restores the battery for one more task.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Pour vinegar into the empty battery

#### b_make_magnet: Connect the coil to the restored battery

Equivalent phrasing: combine coil and battery; make electromagnet.

**Requires:** `item:coil`, `item:charged_battery`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `coil`, `charged_battery`; give items: `electromagnet`.

**Outcome:** The coil and battery become an electromagnet.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Connect the coil to the restored battery

#### b_get_key: Draw the fallen key under the door with the electromagnet

Equivalent phrasing: use magnet under door; get key; use electromagnet on gap.

**Requires:** `item:electromagnet`, `flag:b_key_on_floor`. Once only.

**Effects:** give items: `manor_key`.

**Outcome:** Metal scrapes across the far side of the floor. The key slides beneath the door.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Draw the fallen key under the door with the electromagnet

#### b_unlock_manor: Unlock the manor door

Equivalent phrasing: use key on door; open manor door.

**Requires:** `item:manor_key`. Once only.

**Effects:** set flags: `b_manor_open`.

**Outcome:** The lock turns, and the manor opens to you.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Unlock the manor door

**Research anchors:** [early_ltf1](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=0). Narration is original.

## b_interior — The manor room

**On arrival — adjust to current state:**

A broad stone fireplace dominates the room. An iron rod leans nearby, and a roasting spit rests at the hearth. An oar occupies a wall recess. On one side is a box holding electrical fittings; on the other, a chest contains fine sand. An extinguisher stands ready above it, a modern detail among older things.

### Inspection material

- **fuse box:** Copper wire fastens its cover; one fuse is broken.
- **fireplace:** The hearth has contact points suited to the loose iron rod.
- **sand chest:** Fine sand is available in quantity.
- **iron rod:** Too cumbersome for ordinary carrying, but easy to move within this room.
- **floor in front of hearth:** The mechanism beneath it is dormant until the fireplace is prepared.

### Exits

- **outside to the entrance** → `b_entry`. Requires none.
- **through the concealed passage** → `b_wreck`. Requires `flag:b_passage_open`.

### Actions and state changes

#### b_take_manor_tools: Collect the oar, roasting spit, and extinguisher

Equivalent phrasing: take oar; take extinguisher; take roasting spit.

**Requires:** none. Once only.

**Effects:** give items: `manor_oar`, `roasting_spit`, `extinguisher`.

**Outcome:** You collect the loose tools from the room.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Collect the oar, roasting spit, and extinguisher

#### b_open_fuse_box: Open and search the fuse box

Equivalent phrasing: open fuse box; search fuse box.

**Requires:** none. Once only.

**Effects:** give items: `copper_wire`, `resin`; set flags: `b_fuse_exposed`.

**Outcome:** You remove the copper fastening wire, find resin inside, and expose the broken fuse.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Open and search the fuse box

#### b_restore_power: Repair the broken fuse with the foil

Equivalent phrasing: use foil on fuse; repair fuse.

**Requires:** `flag:b_fuse_exposed`, `item:foil`. Once only.

**Effects:** remove items: `foil`; set flags: `b_power_on`.

**Outcome:** The improvised repair restores power to the property's mechanism.

**Private hint ladder:**

1. The lift requires electrical power.
2. The broken connection is in the manor, and the cigarette pack supplied a conductive scrap.
3. Use the foil on the broken fuse.

#### b_place_rod: Lay the iron rod across the hearth contacts

Equivalent phrasing: put rod in fireplace; use rod on hearth.

**Requires:** none. Once only.

**Effects:** set flags: `b_rod_placed`.

**Outcome:** You fit the rod across the fireplace contacts.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Lay the iron rod across the hearth contacts

#### b_place_log: Put the log in the fireplace

Equivalent phrasing: use log on fireplace.

**Requires:** `item:log`. Once only.

**Effects:** remove items: `log`; set flags: `b_log_placed`.

**Outcome:** The log settles into the hearth.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Put the log in the fireplace

#### b_prepare_fire: Add the handkerchief and kerosene to the hearth

Equivalent phrasing: prepare fireplace; use handkerchief and kerosene on fireplace.

**Requires:** `item:handkerchief`, `item:kerosene`. Once only.

**Effects:** remove items: `handkerchief`, `kerosene`; set flags: `b_kindling_ready`.

**Outcome:** The prepared hearth is ready for a flame.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Add the handkerchief and kerosene to the hearth

#### b_get_match: Break the bottled ship with the club

Equivalent phrasing: use club on bottled ship; break ship in bottle.

**Requires:** `item:bottled_ship`, `item:club`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `bottled_ship`; give items: `match`.

**Outcome:** The bottle breaks, releasing a match from the model.

**Private hint ladder:**

1. Your matchbox has a striker but no match.
2. The model ship contains a small combustible part.
3. Break the bottled ship with the club to obtain a match.

#### b_light_match: Strike the match on the matchbox

Equivalent phrasing: light match; use match on matchbox.

**Requires:** `item:match`, `item:match_striker`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `match`; give items: `lit_match`.

**Outcome:** The match catches.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Strike the match on the matchbox

#### b_light_hearth: Light the prepared fireplace

Equivalent phrasing: light fireplace; use lit match on hearth.

**Requires:** `item:lit_match`, `flag:b_log_placed`, `flag:b_rod_placed`, `flag:b_kindling_ready`. Once only.

**Effects:** remove items: `lit_match`; set flags: `b_hearth_active`.

**Outcome:** As heat spreads through the hearth, the iron rod shifts against its contacts. A slab in front of the fireplace rises into a working position.

**Private hint ladder:**

1. The fire is part of a mechanism.
2. The rod must span the contacts before heat can do its work.
3. Position the rod, prepare the fuel, and light the fireplace.

#### b_place_barrel: Put the empty barrel on the raised slab

Equivalent phrasing: use barrel on slab; place barrel on flagstone.

**Requires:** `item:barrel`, `flag:b_hearth_active`. Once only.

**Effects:** remove items: `barrel`; set flags: `b_barrel_on_slab`.

**Outcome:** The empty barrel rests on the slab, but it is not heavy enough.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Put the empty barrel on the raised slab

#### b_open_barrel: Open the barrel with the club

Equivalent phrasing: use club on barrel; open barrel.

**Requires:** `flag:b_barrel_on_slab`, `item:club`. Once only.

**Effects:** set flags: `b_barrel_open`.

**Outcome:** The top gives way, leaving the barrel ready to fill.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Open the barrel with the club

#### b_seal_barrel: Plug the barrel hole with the candle

Equivalent phrasing: use candle on barrel; plug barrel.

**Requires:** `flag:b_barrel_on_slab`, `item:candle`. Once only.

**Effects:** remove items: `candle`; set flags: `b_barrel_sealed`.

**Outcome:** The candle seals the hole where the contents would escape.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Plug the barrel hole with the candle

#### b_weight_slab: Fill the barrel with sand using the wooden shoe

Equivalent phrasing: fill barrel with sand; use shoe on sand; weight floor.

**Requires:** `flag:b_barrel_open`, `flag:b_barrel_sealed`, `item:wooden_shoe`. Once only.

**Effects:** set flags: `b_passage_open`.

**Outcome:** Scoop after scoop adds weight. The slab sinks, and a section of wall opens onto a concealed passage.

**Private hint ladder:**

1. The empty barrel does not exert enough pressure.
2. The room already contains a heavy material and you have a scoop.
3. Seal the barrel, open its top, and fill it with sand using the wooden shoe.

**Research anchors:** [early_ltf1](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=0), [early_ltf2](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=1), [early_walkthroughking](https://www.walkthroughking.com/text/lostintime.aspx). Narration is original.

## b_vault — The stone vault

**On arrival — adjust to current state:**

The little stone building is more ornate than its surroundings. A shallow recess interrupts the steps, with the proportions of something meant to fit there. A memorial plaque and a cross form part of the structure. This place looks ceremonial, but the railing and concealed machinery suggest a more practical purpose beneath the stonework.

### Inspection material

- **recess in steps:** Its shape matches the removable portrait.
- **memorial plaque:** The memorial is covered until its mechanism has been exposed.
- **lift railing:** A strong attachment point once the elevator is revealed.
- **lift control:** The mechanism depends on the manor's power supply.

### Exits

- **back to the garden** → `b_garden`. Requires none.
- **down in the lift to the crypt** → `b_crypt`. Requires `flag:b_vault_open`, `flag:b_power_on`.

### Actions and state changes

#### b_fit_portrait: Fit the portrait into the stair recess

Equivalent phrasing: use portrait on recess; put picture in steps.

**Requires:** `item:portrait`. Once only.

**Effects:** remove items: `portrait`; set flags: `b_plaque_exposed`.

**Outcome:** The portrait fits. Touching it exposes a memorial plaque with a two-digit mechanism.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Fit the portrait into the stair recess

#### b_read_plaque: Read Philibert's memorial plaque

Equivalent phrasing: read plaque; inspect dates.

**Requires:** `flag:b_plaque_exposed`. Once only.

**Effects:** set flags: `b_plaque_read`.

**Outcome:** The plaque gives two years: 1803 and 1840. Below them are two number wheels and the cross.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Read Philibert's memorial plaque

#### b_solve_plaque: Enter 37 and press the cross

Equivalent phrasing: 37; enter 37; Philibert was 37.

**Requires:** `flag:b_plaque_exposed`, `flag:b_plaque_read`. Once only.

**Effects:** set flags: `b_vault_open`.

**Outcome:** The mechanism accepts Philibert's age. The lift is revealed.

**Private hint ladder:**

1. The plaque asks for a relationship between the dates.
2. Calculate how old Philibert was when he died.
3. Subtract 1803 from 1840; enter 37 and press the cross.

#### b_tie_lift_end: Tie the hose's free end to the lift railing

Equivalent phrasing: tie hose to railing; use hose on lift rail.

**Requires:** `flag:b_vault_open`, `flag:b_hose_on_door`, `item:hose`. Once only.

**Effects:** set flags: `b_hose_on_lift`.

**Outcome:** The hose now links the lighthouse door and the lift.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Tie the hose's free end to the lift railing

#### b_pull_lighthouse_door: Lower the lift remotely to pull the lighthouse door

Equivalent phrasing: lower lift; press lift control; open lighthouse using lift.

**Requires:** `flag:b_power_on`, `flag:b_vault_open`, `flag:b_hose_on_door`, `flag:b_hose_on_lift`, `item:hose`. Once only.

**Effects:** remove items: `hose`; give items: `leaky_hose`; set flags: `b_lighthouse_open`.

**Outcome:** The lift descends and the hose pulls taut. The lighthouse door gives way. You recover the hose, now torn by the strain.

**Private hint ladder:**

1. The lift can exert more force than you can.
2. Connect the stubborn door to the moving lift, then operate it from outside.
3. Tie the hose to the lighthouse door and lift rail, then lower the powered lift.

**Research anchors:** [early_ltf1](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=0). Narration is original.

## b_lighthouse_north — The lighthouse's north wall

**On arrival — adjust to current state:**

The lighthouse rises above a narrow working space behind the manor. A barrel sits against the wall near a small basement window, and a bottle has been left beside it. Around the corner, the main door refuses to open. Its handle is solid enough to bear a substantial pull, if you can arrange one.

### Inspection material

- **bottle:** A bottle of vinegar stands beside the barrel.
- **barrel stopper:** The full barrel is awkward to move; its stopper can be pried free.
- **basement window:** The space around the barrel gives access to this low window.
- **lighthouse door:** Stubbornly closed, with a strong handle.

### Exits

- **back to the garden** → `b_garden`. Requires none.
- **inside the lighthouse** → `b_lighthouse_ground`. Requires `flag:b_lighthouse_open`.

### Actions and state changes

#### b_take_vinegar: Take the vinegar bottle

Equivalent phrasing: take bottle; take vinegar.

**Requires:** none. Once only.

**Effects:** give items: `vinegar`.

**Outcome:** You take the vinegar.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Take the vinegar bottle

#### b_empty_barrel: Remove the barrel stopper with the dart

Equivalent phrasing: use dart on barrel; empty barrel; take barrel.

**Requires:** `item:dart`. Once only.

**Effects:** give items: `barrel`; set flags: `b_barrel_emptied`.

**Outcome:** The contents drain away. You can now move and carry the empty barrel.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Remove the barrel stopper with the dart

#### b_break_window: Break the basement window with the roasting spit

Equivalent phrasing: use spit on window; break window.

**Requires:** `item:roasting_spit`, `flag:b_barrel_emptied`. Once only.

**Effects:** set flags: `b_window_broken`.

**Outcome:** The spit breaks the glass. A hose is visible through the opening.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Break the basement window with the roasting spit

#### b_take_hose: Retrieve the hose through the broken window

Equivalent phrasing: take hose; search window.

**Requires:** `flag:b_window_broken`. Once only.

**Effects:** give items: `hose`.

**Outcome:** You draw the hose out through the opening.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Retrieve the hose through the broken window

#### b_tie_door_end: Tie one end of the hose to the lighthouse door handle

Equivalent phrasing: use hose on door; tie hose to handle.

**Requires:** `item:hose`. Once only.

**Effects:** set flags: `b_hose_on_door`.

**Outcome:** One end is firmly attached to the door handle. You still need a source of pulling force.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Tie one end of the hose to the lighthouse door handle

**Research anchors:** [early_ltf1](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=0). Narration is original.

## b_lighthouse_ground — The foot of the lighthouse

**On arrival — adjust to current state:**

Stone steps curve upward from the lighthouse entrance. A wooden shoe rests close to the stairs, out of place but deliberately left within reach. A second door leads toward the lower workings. Through a broken window, the outside light picks out sharp remnants of glass. Above you, the tower promises a better view of the coast.

### Inspection material

- **wooden shoe:** A useful hollow shape; something rattles inside.
- **basement door:** Its old lock is still intact.
- **broken window:** A single manageable glass shard remains.

### Exits

- **outside to the north wall** → `b_lighthouse_north`. Requires none.
- **up to the study** → `b_lighthouse_study`. Requires none.
- **down to the canal gate** → `b_canal`. Requires `flag:b_basement_open`.

### Actions and state changes

#### b_take_shoe: Take the wooden shoe

Equivalent phrasing: take shoe.

**Requires:** none. Once only.

**Effects:** give items: `wooden_shoe`.

**Outcome:** You pick up the wooden shoe.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Take the wooden shoe

#### b_search_shoe: Look inside the wooden shoe

Equivalent phrasing: inspect shoe; search shoe; take key from shoe.

**Requires:** `item:wooden_shoe`. Once only.

**Effects:** give items: `rusted_key`.

**Outcome:** A key is hidden inside it.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Look inside the wooden shoe

#### b_unlock_basement: Unlock the basement door with the hidden key

Equivalent phrasing: use key on basement door; open basement door.

**Requires:** `item:rusted_key`. Once only.

**Effects:** set flags: `b_basement_open`.

**Outcome:** The key turns in the lower door.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Unlock the basement door with the hidden key

#### b_take_glass: Take a loose glass shard from the broken window

Equivalent phrasing: take glass; search broken window.

**Requires:** `flag:b_window_broken`. Once only.

**Effects:** give items: `glass_shard`.

**Outcome:** You take a shard with an edge suitable for scraping.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Take a loose glass shard from the broken window

**Research anchors:** [early_neppomuk](https://neppomuk.ch/PointClick/Coktel/LiT.pdf). Narration is original.

## b_lighthouse_study — The lighthouse study

**On arrival — adjust to current state:**

A writing table and lamp occupy the warm little room above the entrance. Papers rest near a drawer, and a chair faces the work surface. A field glass points out toward the sea. A cupboard stands nearby with a reluctant door. From here the coast becomes something you can search, rather than merely hear.

### Inspection material

- **desk drawer:** A thorough search may find more than the first sheet of paper.
- **cupboard:** Its door needs leverage.
- **field glass:** It can isolate distant details on the coast, including a wreck.
- **captain's papers:** The papers mention the Devil's Seven Teeth; a lead rather than a usable tool.

### Exits

- **down to the entrance** → `b_lighthouse_ground`. Requires none.
- **up to the lantern chamber** → `b_lighthouse_lantern`. Requires none.

### Actions and state changes

#### b_search_study_drawer: Thoroughly search the desk drawer

Equivalent phrasing: search drawer; read diary; take paint remover.

**Requires:** none. Once only.

**Effects:** give items: `paint_remover`; set flags: `b_diary_read`.

**Outcome:** The papers mention the Devil's Seven Teeth. Searching beneath them also produces a bottle of paint remover.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Thoroughly search the desk drawer

#### b_open_cupboard: Pry open the cupboard with the manor oar

Equivalent phrasing: use oar on cupboard; open cupboard.

**Requires:** `item:manor_oar`. Once only.

**Effects:** give items: `razor`.

**Outcome:** The oar provides the leverage you need. Inside is a razor.

**Private hint ladder:**

1. The cupboard needs leverage, not a key.
2. One of the manor's tools is long enough to act as a lever.
3. Use the manor oar to pry open the cupboard.

#### b_observe_wreck: Study the wreck through the field glass

Equivalent phrasing: use telescope; look through field glass; inspect wreck.

**Requires:** none. Once only.

**Effects:** set flags: `b_wreck_code_seen`.

**Outcome:** Three painted panels become clear, left to right: a green sword, a red cannon, and a red cannonball. You record their order as well as their colors.

**Private hint ladder:**

1. The crypt's decoration has a counterpart elsewhere.
2. The lighthouse's field glass can reveal small details offshore.
3. Look through the field glass and record the wreck's three colored symbols.

**Research anchors:** [early_ltf1](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=0), [early_neppomuk](https://neppomuk.ch/PointClick/Coktel/LiT.pdf). Narration is original.

## b_lighthouse_lantern — The lantern chamber

**On arrival — adjust to current state:**

The top of the lighthouse opens around its great cylindrical lens. Windows encircle the chamber, admitting a broad wash of daylight and a view of water. Curtains soften part of that glare. This is a place built to send light far away, yet the useful details are close: the folds of fabric, the space behind them, the tools of tending a lamp.

### Inspection material

- **curtains:** There is space behind the folds, and enough fabric to spare a small piece.
- **great lens:** An impressive part of the lighthouse, not a portable object.

### Exits

- **down to the study** → `b_lighthouse_study`. Requires none.

### Actions and state changes

#### b_take_kerosene: Search behind the curtains

Equivalent phrasing: move curtains; take kerosene.

**Requires:** none. Once only.

**Effects:** give items: `kerosene`.

**Outcome:** Behind the curtains you find a bottle of kerosene.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search behind the curtains

#### b_cut_rag: Cut a piece of curtain with the razor

Equivalent phrasing: use razor on curtain; cut curtain; take rag.

**Requires:** `item:razor`. Once only.

**Effects:** give items: `curtain_rag`.

**Outcome:** You cut a useful piece of cloth from the curtain.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Cut a piece of curtain with the razor

**Research anchors:** [early_ltf1](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=0), [visual_planete](https://www.planete-aventure.net/jeux.php?num_jeu=1626&cat=screenshots). Narration is original.

## b_crypt — The crypt below the vault

**On arrival — adjust to current state:**

The lift delivers you into a compact chamber where storage has taken over from ceremony. Bottles sit above easy reach, and another container rests on a high beam. A chest carries three adjustable weapon pictures with colored backgrounds. Its controls let you change both the pictures and their colors.

### Inspection material

- **high bottles:** A stable step would put them within reach.
- **container on beam:** Too high even with a step; a small launched object might dislodge it.
- **chest panels:** Three positions accept knife, pistol, or bullet symbols with colors. The correspondence is to larger weapons elsewhere.

### Exits

- **up in the lift** → `b_vault`. Requires none.

### Actions and state changes

#### b_take_cider: Stand on the barrel to reach a cider bottle

Equivalent phrasing: use barrel on high bottles; take cider; climb barrel.

**Requires:** `item:barrel`. Once only.

**Effects:** give items: `cider`.

**Outcome:** You use the barrel as a step, take a cider bottle, and reclaim the barrel.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Stand on the barrel to reach a cider bottle

#### b_launch_cork: Aim the cider cork at the container on the beam

Equivalent phrasing: shoot cork at bottle; use cider cork on beam bottle.

**Requires:** `item:cider`. Once only.

**Effects:** remove items: `cider`; give items: `rust_remover`; set flags: `b_cork_in_well`.

**Outcome:** The cork pops upward and knocks the container down. You recover rust remover, but the cork itself escapes through an opening toward the garden well.

**Private hint ladder:**

1. The container is beyond your reach.
2. The cider supplies a small projectile.
3. Aim the cider bottle's cork at the container on the overhead beam.

#### b_open_crypt_chest: Set green knife, red pistol, red bullet on the chest

Equivalent phrasing: green knife red pistol red bullet; green knife red gun red bullet; enter green knife, red pistol, red bullet.

**Requires:** `flag:b_wreck_code_seen`. Once only.

**Effects:** give items: `fiberglass`; set flags: `b_crypt_chest_open`, `b_ship_log_read`.

**Outcome:** The smaller weapons match their larger counterparts. The chest opens to reveal a ship's log with a piece of fiberglass tucked inside.

**Private hint ladder:**

1. The chest's images correspond to symbols somewhere along the coast.
2. Keep the observed colors and order, but translate each weapon to a smaller equivalent.
3. Set green knife, red pistol, red bullet, matching the chosen wreck clue.

**Research anchors:** [early_neppomuk](https://neppomuk.ch/PointClick/Coktel/LiT.pdf). Narration is original.

## b_canal — The lighthouse sea gate

**On arrival — adjust to current state:**

Stone steps descend toward an iron-barred opening above the water. A small boat waits on the sheltered side, carrying water of its own. Near the gate, algae cover part of the wall and a mechanism has stiffened with rust. A separate valve controls a channel. The route to the sea exists; it simply has several reasons to refuse you.

### Inspection material

- **channel valve:** Opening it enables the garden's water supply.
- **algae:** The growth conceals part of the gate mechanism.
- **gate mechanism:** It needs cleaning, lubrication, and a turning handle.
- **small boat:** Water has entered through a leak; the boat needs bailing and a firm plug.

### Exits

- **up to the lighthouse entrance** → `b_lighthouse_ground`. Requires none.

### Actions and state changes

#### b_open_water_supply: Open the channel valve

Equivalent phrasing: turn valve; open canal valve.

**Requires:** none. Once only.

**Effects:** set flags: `b_water_supply`.

**Outcome:** The channel opens, restoring the supply that feeds the garden faucet.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Open the channel valve

#### b_soften_algae: Apply paint remover to the algae

Equivalent phrasing: use paint remover on algae; use acid on algae.

**Requires:** `item:paint_remover`. Once only.

**Effects:** set flags: `b_algae_softened`.

**Outcome:** The stubborn growth softens.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Apply paint remover to the algae

#### b_scrape_algae: Scrape away the softened algae with the glass shard

Equivalent phrasing: use glass on algae; scrape algae.

**Requires:** `flag:b_algae_softened`, `item:glass_shard`. Once only.

**Effects:** set flags: `b_mechanism_exposed`.

**Outcome:** The glass clears the remaining growth and exposes the mechanism.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Scrape away the softened algae with the glass shard

#### b_free_mechanism: Apply rust remover to the exposed mechanism

Equivalent phrasing: use rust remover on mechanism; lubricate gate.

**Requires:** `flag:b_mechanism_exposed`, `item:rust_remover`. Once only.

**Effects:** set flags: `b_mechanism_freed`.

**Outcome:** The seized parts begin to move.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Apply rust remover to the exposed mechanism

#### b_open_sea_gate: Use the roasting spit as the mechanism's handle

Equivalent phrasing: use spit on mechanism; turn gate mechanism; open sea gate.

**Requires:** `flag:b_mechanism_freed`, `item:roasting_spit`. Once only.

**Effects:** set flags: `b_sea_gate_open`.

**Outcome:** The spit fits the exposed socket. Turning it opens the barred route to the sea.

**Private hint ladder:**

1. Cleaning and freeing the mechanism are only part of the job.
2. Its exposed socket needs a suitable lever.
3. After removing algae and rust, use the roasting spit to turn the gate mechanism.

#### b_bail_boat: Bail out the boat with the wooden shoe

Equivalent phrasing: use shoe on boat water; bail boat.

**Requires:** `item:wooden_shoe`. Once only.

**Effects:** set flags: `b_boat_bailed`.

**Outcome:** The hollow shoe serves as a bailer. The cleared water exposes the leak.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Bail out the boat with the wooden shoe

#### b_patch_boat: Pack the leak with the curtain rag and cork

Equivalent phrasing: repair boat; use rag and cork on leak.

**Requires:** `flag:b_boat_bailed`, `item:curtain_rag`, `item:cork`. Once only.

**Effects:** remove items: `curtain_rag`, `cork`; set flags: `b_boat_sealed`.

**Outcome:** Cloth fills the irregular gap; the cork wedges it firmly in place.

**Private hint ladder:**

1. A hard stopper alone does not match the irregular hole.
2. Use something flexible around the stopper.
3. Pack the leak with the curtain rag, then secure it with the cork.

#### b_row_to_cabin: Row out through the sea gate

Equivalent phrasing: use oar on boat; row boat; sail.

**Requires:** `flag:b_sea_gate_open`, `flag:b_boat_bailed`, `flag:b_boat_sealed`, `item:manor_oar`. Once only.

**Effects:** set flags: `b_boat_trip_complete`; move to `b_beach`.

**Outcome:** You paddle out. The short coastal journey proves less orderly than expected, and you come ashore by a small fisherman's cabin beneath the cliffs.

**Private hint ladder:**

1. The boat must float, and the barred passage must be open.
2. Bail, repair the leak, and bring a paddle.
3. With the gate open and boat repaired, use the manor oar to depart.

**Research anchors:** [early_neppomuk](https://neppomuk.ch/PointClick/Coktel/LiT.pdf). Narration is original.

## b_beach — The cabin beach

**On arrival — adjust to current state:**

Blue water presses against the narrow shore below a rocky cliff. A pale little building stands close to the beach. Something round has caught on its roof, with a length of rope attached, while gulls watch for food. The cliff is the direct route back toward the manor, but its face offers no easy handholds.

### Inspection material

- **buoy on roof:** A rope hangs with it, beyond your reach.
- **gulls:** They are interested in anything that smells edible.
- **cliff:** A grappling line could make the ascent possible.

### Exits

- **inside the cabin** → `b_cabin`. Requires none.
- **up the established cliff rope** → `b_garden`. Requires `flag:b_cliff_route`.

### Actions and state changes

#### b_scent_bread: Soak the bread in fish sauce

Equivalent phrasing: use fish sauce on bread; prepare gull bait.

**Requires:** `item:bread`, `item:fish_sauce`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `bread`, `fish_sauce`; give items: `scented_bread`.

**Outcome:** The bread takes on a strong smell.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Soak the bread in fish sauce

#### b_lure_gull: Throw the scented bread onto the roof

Equivalent phrasing: throw bread on roof; feed gulls.

**Requires:** `item:scented_bread`. Once only.

**Effects:** remove items: `scented_bread`; set flags: `b_buoy_down`.

**Outcome:** A gull lands to seize the food and knocks the buoy loose. It falls within reach.

**Private hint ladder:**

1. You cannot reach the buoy, but another creature can.
2. Give a gull a reason to land where the buoy is lodged.
3. Throw fish-sauce-soaked bread onto the roof.

#### b_take_rope: Cut the buoy's rope free with the razor

Equivalent phrasing: use razor on buoy; take rope; cut rope.

**Requires:** `flag:b_buoy_down`, `item:razor`. Once only.

**Effects:** give items: `rope`.

**Outcome:** You free a useful length of rope.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Cut the buoy's rope free with the razor

#### b_make_grapple: Attach the rope to the anchor

Equivalent phrasing: combine anchor and rope; make grapple.

**Requires:** `item:rope`, `item:anchor`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `rope`, `anchor`; give items: `grapple`.

**Outcome:** The anchor and rope make a grappling line.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Attach the rope to the anchor

#### b_climb_cliff: Secure the grapple on the cliff and climb

Equivalent phrasing: use grapple on cliff; climb cliff.

**Requires:** `item:grapple`. Once only.

**Effects:** remove items: `grapple`; set flags: `b_cliff_route`; move to `b_garden`.

**Outcome:** The hook holds. You climb back to the manor garden, leaving the line secured behind you.

**Private hint ladder:**

1. The cliff requires a secure line.
2. The cabin's improvised chandelier supplied the metal part.
3. Combine the anchor with rope, hook it over the cliff, and climb.

**Research anchors:** [early_ltf2](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=1), [early_neppomuk](https://neppomuk.ch/PointClick/Coktel/LiT.pdf). Narration is original.

## b_cabin — The fisherman's cabin

**On arrival — adjust to current state:**

The cabin is small enough that every object seems to perform several jobs. A dresser occupies one corner; clothing and odds and ends lie on a table. A chair sits unevenly beneath a hanging chandelier assembled from practical-looking parts. A folded paper has been used where proper furniture repair would have been more sensible.

### Inspection material

- **dresser:** Its contents extend beyond the first compartment.
- **clothing on table:** A thorough search can recover several small belongings.
- **chair:** A paper props one leg; the chair can be moved and climbed.
- **improvised chandelier:** Its upper fastening is too high until you arrange a step.

### Exits

- **outside to the beach** → `b_beach`. Requires none.

### Actions and state changes

#### b_search_dresser: Thoroughly search the dresser

Equivalent phrasing: search dresser; take bottled ship; take fish sauce.

**Requires:** none. Once only.

**Effects:** give items: `bottled_ship`, `fish_sauce`.

**Outcome:** You find a ship in a bottle and a bottle of fish sauce.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Thoroughly search the dresser

#### b_search_clothes: Search the clothing and table

Equivalent phrasing: search table; search clothing; search basket.

**Requires:** none. Once only.

**Effects:** give items: `handkerchief`, `cabin_nail`, `bread`.

**Outcome:** You recover a handkerchief, a nail, and bread.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Search the clothing and table

#### b_read_cabin_note: Read the paper beneath the chair leg

Equivalent phrasing: read notebook; search chair leg; read paper.

**Requires:** none. Once only.

**Effects:** set flags: `b_melkior_note_read`.

**Outcome:** The paper is associated with Melkior. It gives the scattered clues around the property the feeling of a route someone has already passed through.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Read the paper beneath the chair leg

#### b_move_chair: Move the chair beneath the chandelier and climb

Equivalent phrasing: move chair; climb chair.

**Requires:** none. Once only.

**Effects:** set flags: `b_chandelier_reachable`.

**Outcome:** From the repositioned chair you can reach the upper fastening.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Move the chair beneath the chandelier and climb

#### b_detach_chandelier: Release the chandelier fastening with the nail

Equivalent phrasing: use nail on chandelier; take chandelier.

**Requires:** `flag:b_chandelier_reachable`, `item:cabin_nail`. Once only.

**Effects:** give items: `chandelier`.

**Outcome:** The nail releases the fastening. You lower the improvised chandelier.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Release the chandelier fastening with the nail

#### b_dismantle_chandelier: Dismantle the chandelier

Equivalent phrasing: inspect chandelier; take chandelier apart.

**Requires:** `item:chandelier`. Once only.

**Portable recipe:** may be performed anywhere in this act when its required items are held.

**Effects:** remove items: `chandelier`; give items: `anchor`, `candle`, `floats`.

**Outcome:** The ornament separates into an anchor-like hook, a candle, and cork floats.

**Private hint ladder:**

1. The chandelier was assembled from useful components.
2. Examine it as a construction rather than a single decoration.
3. Dismantle the chandelier into anchor, candle, and floats.

**Research anchors:** [early_ltf2](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=1). Narration is original.

## b_wreck — The concealed wreck and sarcophagus

**On arrival — adjust to current state:**

The passage opens into the timbers of a wreck. A wooden case occupies the cramped space, wired in a way that makes careless handling unwise. Water gathers on the floor. Near a mast, pliers hold a small panel open. Beyond the case's fastenings lies the shape of something ceremonial, hidden inside a place built for cargo.

### Inspection material

- **mast panel:** A pair of pliers has been left holding the panel open.
- **wet floor:** There is room to arrange a small platform in front of the case.
- **electrical wire:** The connection must be diverted before it is cut.
- **crate lock:** After the electrical obstacle, the lock still needs to be defeated.
- **puddle:** The pipette can transfer a small amount of water.

### Exits

- **back through the passage** → `b_interior`. Requires none.

### Actions and state changes

#### b_take_pliers: Take the pliers from the mast panel

Equivalent phrasing: inspect mast; take pliers.

**Requires:** none. Once only.

**Effects:** give items: `pliers`.

**Outcome:** You retrieve the pliers. Their presence here will matter more than you yet understand.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Take the pliers from the mast panel

#### b_place_floats: Place the cork floats on the wet floor

Equivalent phrasing: use floats on floor; stand on floats.

**Requires:** `item:floats`. Once only.

**Effects:** remove items: `floats`; set flags: `b_standing_on_floats`.

**Outcome:** You arrange the floats as a platform before approaching the case.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Place the cork floats on the wet floor

#### b_divert_wire: Divert the connection with the copper wire

Equivalent phrasing: use copper wire on electrical wire; bypass wire.

**Requires:** `flag:b_standing_on_floats`, `item:copper_wire`. Once only.

**Effects:** remove items: `copper_wire`; set flags: `b_wire_diverted`.

**Outcome:** The copper wire diverts the connection away from the fastening.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Divert the connection with the copper wire

#### b_cut_wire: Cut the diverted wire with the pliers

Equivalent phrasing: use pliers on wire; cut electrical wire.

**Requires:** `flag:b_standing_on_floats`, `flag:b_wire_diverted`, `item:pliers`. Once only.

**Effects:** set flags: `b_wire_cut`.

**Outcome:** The pliers cut the diverted connection. The lock can now be handled.

**Private hint ladder:**

1. Do not start with the cutters.
2. Address both the wet footing and the live connection first.
3. Stand on the floats, divert the connection with copper wire, then cut with the pliers.

#### b_take_water: Fill the pipette from the puddle

Equivalent phrasing: use pipette on puddle; take water.

**Requires:** `item:pipette`. Once only.

**Effects:** set flags: `b_pipette_water`.

**Outcome:** The pipette takes up water.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Fill the pipette from the puddle

#### b_wet_lock: Put the pipette's water into the crate lock

Equivalent phrasing: use water on lock; wet lock.

**Requires:** `flag:b_wire_cut`, `flag:b_pipette_water`. Once only.

**Effects:** clear flags: `b_pipette_water`; set flags: `b_lock_wet`.

**Outcome:** Water enters the lock.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Put the pipette's water into the crate lock

#### b_freeze_lock: Use the extinguisher on the wet lock

Equivalent phrasing: freeze lock; use extinguisher on lock.

**Requires:** `flag:b_lock_wet`, `item:extinguisher`. Once only.

**Effects:** set flags: `b_lock_frozen`.

**Outcome:** The lock chills and stiffens under the extinguisher's discharge.

**Private hint ladder:**

1. Inspect the relevant object and consider what is preventing progress.
2. Use an available object that addresses that particular obstacle.
3. Use the extinguisher on the wet lock

#### b_break_lock: Strike the frozen lock with the club

Equivalent phrasing: use club on lock; break lock.

**Requires:** `flag:b_lock_frozen`, `item:club`. Once only.

**Effects:** set flags: `b_crate_open`.

**Outcome:** The brittle fastening breaks. The wooden case opens around a golden sarcophagus.

**Private hint ladder:**

1. The lock needs to be made vulnerable before impact.
2. Water, cold, and the hardened club form the final sequence.
3. Wet the lock, freeze it with the extinguisher, then strike it with the club.

#### b_end_flashback: Examine the revealed sarcophagus and finish the recollection

Equivalent phrasing: open sarcophagus; examine sarcophagus; finish memory.

**Requires:** `flag:b_crate_open`. Once only.

**Effects:** checkpoint `end_flashback`; give items: `small_hook`; set flags: `b_flashback_complete`; move to `c_middeck`.

**Outcome:** A stranger catches you beside the gold. Your face seems to frighten him; he warns that you have interfered with his plans. His escape pulls you into a distortion of the room. The memory ends with the ship moving beneath you again. Melkior names the stranger: Jarlath Equs. Both men come from 2092; Melkior is pursuing the stolen Americium 1492 hidden in the sarcophagus. Jarlath used the past to let its dangerous radioactivity diminish. You now understand how you reached 1840. As you turn back to Melkior, a loose fastening comes away from his door: a small hook.

**Private hint ladder:**

1. The crate has finally yielded its secret.
2. The sarcophagus links the manor to the ship.
3. Examine the revealed sarcophagus to finish the flashback.

**Research anchors:** [early_ltf2](https://www.abandonware-france.org/ltf_abandon/ltf_solutions.php?id_soluce=30&page=1), [early_walkthroughking](https://www.walkthroughking.com/text/lostintime.aspx), [early_koruchan](https://gamefaqs.gamespot.com/pc/564643-lost-in-time/faqs/55450). Narration is original.

