# DinoPark Algorithm Lab 0.8

Offline standalone browser workbench and dependency-free Node runner. Guide0.2s/E33.
Open DinoPark-Algorithm-Lab.html. No original assets, account, network or login.

```
node cli.cjs test
node cli.cjs scenario examples/foreclosure.json --out results/foreclosure.json
node cli.cjs replay examples/foreclosure-replay.json
node cli.cjs replay examples/quarterly-ticket-replay.json
node cli.cjs serve
```

## New terminal correction

A failed automatic installment now returns before the month increments or weekly/
quarter work runs. The lab keeps original day0, a terminal hold and, when reached,
weekly counter7. Debt can remain negative because foreclosure precedes its clamp.
Advance and resume cannot restart a terminal run. The browser marks foreclosure;
it does not implement the original bank advice, ending artwork or leaderboard UI.

The unchanged0.7 engine fails96 of320 new original-instruction scenarios.0.8 matches
all432 new snapshots. The original-DOS losing route and seven matched live finance
forks are separate evidence in native-terminal/live, not browser simulations.

Full regression186550cases/213724snapshots/60suites, zero mismatches.186unitchecks.
Chromium36baseline and12terminal application checks pass, plus1432 archived samples.
Counts are not independent review, binary coverage or full-game equivalence.
See native-terminal/REPORT.md, docs/VALIDATION.md and results/test-report.json.

## Existing facilities

Opt-in quarterly ticket controls preserve their original eligibility/price limits;
flat pricing remains a diagnostic mode. Financial history retains all15x60buffers
and distinguishes zero, unknown and unavailable. The Rule bench exposes recorded
algorithm kernels. Snapshot/CSV/replay exports share the same pure core under Node.
Graphics can subscribe to events later without owning simulation state.

## Compatibility and limits

Keep0.7 for old action replays and terminal snapshots. Older foreclosed snapshots
are rejected atomically because their calendar/hold state may be wrong. Compatible
nonterminal snapshots can migrate with a warning. No missing baseline, schedule
or historical transaction is invented. Original scene/media RNG, full shop/auction
controls and an earned winning playthrough remain incomplete. Use original input
files only with the separately bounded native reproduction tools; the LDT bridge
is not a security sandbox. Production Swift and remote repositories are untouched.
