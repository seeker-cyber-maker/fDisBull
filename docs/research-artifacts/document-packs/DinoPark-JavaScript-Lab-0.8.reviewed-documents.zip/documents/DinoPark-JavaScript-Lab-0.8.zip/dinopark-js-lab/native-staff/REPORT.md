# DinoPark: cached progression, staffing and quarter boundaries

**25 October 2026 | Guide 0.2m / E27 | Algorithm Lab 0.3**

## Result

The new native comparison found one composition error in Algorithm Lab 0.2:
quarter-end management recomputed progression after the month and finances had
changed, rather than incrementing the original day's stored progression.
This could cause either a premature resignation or a missed resignation.
It is a defect in the JavaScript reconstruction, not a new original-game bug.

The unchanged archived 0.2 engine fails **56 of 2,400 quarter-boundary fixtures**:
28 premature departures and 28 missed departures. Lab 0.3 matches the native
reference in all compared fields. The other new illness, management-kernel,
visitor-status and illness/revenue comparisons pass too.

E27 executes **13,320 cases/sequences and records 14,184 snapshots in eight
suites**. The complete JavaScript corpus now compares 183,655 cases and 191,239
recorded snapshots in 37 suites, with zero field-comparison mismatches. Counts
are not complete games or percentages of binary coverage.

## 1. The day computes a value; the quarter increments that value

At original static `38FF:4CCC-4D0B`, before illness, revenue and month rollover:

```text
q = signed_word(4 * internal_year + floor(internal_month / 3))
if working_cash > 100000:
    q = signed_word(q * 2)
DS:BF63 = q
```

The calendar values are zero-based. The financial comparison is strict.
Quarter entry `38FF:483A` then increments `DS:BF63` by exactly one. It does not
recompute the expression with the new month, later revenue or a loan payment.
The manager check at `38FF:48EB-49B3` uses that incremented stored value.

This ordering has two consequences that the old lab missed:

| Constructed quarter boundary | Original stored value | Lab 0.2 recomputation | Observed consequence |
|---|---:|---:|---|
| End of September, displayed Year 1, working cash 100,001 | Daily 4; quarter 5 | 6 | Original keeps the guide; old lab dismisses it |
| End of March, displayed Year 2, working cash 100,001 and debt 5,000 | Daily 8; quarter 9 | 5 after installment | Original dismisses the guide; old lab keeps it |

Both examples use positive recent visits and no manager. In the second example,
the original monthly installment is 165, leaving cash 99,836 and debt 4,885.
Falling below the cash threshold does not retroactively change that day's
progression. These are fixtures, not parks played to those dates.

The corrected Engine stores `progressionValue` at daily-prefix time and passes
it to `quarterManagement`, which increments it. A deferred quarter retains that
value until it actually runs. Reconstructing it from a later date/cash snapshot
would repeat the same mistake.

## 2. Management's individual rules also have broader comparisons

The quarter management block sums the previous three monthly visitor counters,
starting at `(new_month + 9) % 12`. It checks:

```text
incremented_progression >= 6
recent_visitors > active_managers * 100000
```

Equality with manager coverage does not cause a departure. If the conditions
hold, the original draws a starting nonmanager category using `rand()%5`, then
scans cyclically for an available worker. It removes one active worker and
reduces the corresponding pending count only when that count is nonzero.
The recorded quarter-announcement and departure message IDs are compared too;
those messages are not rendered by the native adapter.

A triggered scan with no removable worker can still consume the role draw.
There is no replacement rule about a fixed number of employees per manager.
The 3,392 management cases include controlled starts, original RNG states,
coverage equality, empty and manager-only staff, and differing pending counts.

## 3. Illness and return-to-work behavior

The new `illness` kernel is extracted from the lab's previous inline day logic;
its ordinary arithmetic needed no correction against this corpus. In 2,824
isolated native cases it agrees on progression, timers, selected category,
active/pending workers, changed-state flag, message IDs and RNG consumption.

The original only attempts a new illness when there is no current absence and
progression is at least eight. The initial lottery is `rand()%30 == 0`; a second
draw selects a starting category, then a cyclic scan finds an occupied category.
The message draw occurs only when a worker is actually selected. The existing
absence countdown has a separate branch: on its return day, the worker is
restored before revenue and there is no new illness attempt that same day.

Ninety-six ten-update sequences now connect original illness/return handling,
closure-countdown decrement, day increment, full attendance and concessions.
Native memory and the original RNG persist across updates. They span absence
expiry and inspection expiry together. This adds **960 snapshots**, not 960
independent scenarios. It does not execute the later payroll, feeding, monthly
or quarter portions of a complete day.

## 4. Visitor-status outcomes are not all visible messages

The six-bit weekly status loop now has 4,608 comparisons, including its guide
complaint, food-loss, no-vet mortality and parking-advice branches. The tested
threshold and message rules match the existing JavaScript kernel.

An unset outcome bit first consumes its lottery draw. A winning bit can be
marked even when its extra conditions prevent an observable effect; the two
upper tested bits also have no visible effect in this routine. Conversely, an
already marked bit skips its lottery. Thus a lack of displayed messages is not
proof that nothing changed or that no random numbers were consumed.

At progression at least eight, the tested food-loss branch requires
`active_guards * 50 < visitors`. Exactly 50 visitors with one guard is covered;
51 is not. It applies the recovered half-stock subtraction to all nine stock
fields, including planting inventory, and subtracts the same amount from pending
stocks. Odd counts follow original integer truncation. These are confirmations
of recorded mechanics, not a newly invented balancing rule.

Mortality fixtures always have two occupied pens. The known empty-herd
nonterminating scan is not executed by this new native corpus. The browser's
explicit bounded diagnostic for that path remains a deliberate safety difference.

## 5. What actually executed

The input identities are unchanged:

```text
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT     5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153
```

Addresses use the existing static convention, not relocated DOS breakpoints:
`file = 0x4800 + 16 * (static_segment - 0x1000) + offset`.

The inherited Linux x86-64 process-local LDT bridge executes the original 16-bit
instructions. Segment selectors and declared service boundaries are adapted;
original arithmetic, copies, RNG and relevant worker/animal state logic execute.
Message/formatting and presentation operations are supplied or recorded.
Exact original far-call bytes/targets are checked before adaptation.

The connected illness/revenue slice begins at `38FF:4CCC` and stops at `4E40`.
It restores the earlier artificial support stop at `3178` before running the
complete concession routine. Its synthetic one-Hadrosaurus park has known
staffing, facilities and food-independent state. No month end occurs in its
ten updates, and omitted later weekly processing is not simulated silently.

The quarter-boundary probe executes one original common-loop iteration at
`1B29:05C7`, the real daily calendar/loan code and the original quarter handler.
It deliberately retains E18's call-recording substitutes for attendance,
concessions, wages, feeding and other economic/animal subroutines. All these
fixtures have an empty herd and an existing absence to avoid unrelated new
illness draws; Guide is the only removable nonmanager role. They test the
composition boundary without claiming complete economics.

Two previously unused original arithmetic far calls in the monthly-loan path
were mapped to the existing native helpers. An initial adapter failure was
resolved before recording the final corpus; it was not a game defect.

## 6. Cases, compared fields and exclusions

| Suite | Cases/sequences | Recorded snapshots |
|---|---:|---:|
| Illness, controlled returns | 1,800 | 1,800 |
| Illness, original RNG | 1,024 | 1,024 |
| Management, controlled returns | 2,880 | 2,880 |
| Management, original RNG | 512 | 512 |
| Visitor status, controlled returns | 3,072 | 3,072 |
| Visitor status, original RNG | 1,536 | 1,536 |
| Connected illness/revenue, ten updates each | 96 | 960 |
| Original day/quarter boundary | 2,400 | 2,400 |
| **Total** | **13,320** | **14,184** |

- Illness: progression, absence role/countdown, changed flag, active and pending
  worker arrays, messages and RNG draws/state (real-RNG cases).
- Management: incremented progression, recent visitor sum, active/pending arrays,
  message IDs and RNG draws/state (real-RNG cases).
- Visitor status: mask, messages, all nine live/pending stocks, live/pending herd
  species/counts, RNG draws/state. No graphical refresh, duration or hardware data.
- Illness/revenue sequences: progression, absence, closure timer/discriminator,
  date, both cash balances, visitors, active/pending staff and full original RNG.
  Concession history/service buffers are not additionally compared in this slice.
- Quarter boundary: cached progression, year/month/quarter/day, pending-quarter
  flag, pause holds, phase, absence countdown, cash, working cash, debt and active
  roles. **RNG is excluded** because native revenue is recorded by adapters while
  JS runs empty-park revenue. With only one removable nonmanager role, matching
  departure does not establish exact role-choice RNG timing.

Some rows deliberately supply non-UI-reachable pending/live differences or
category combinations. Passing the corpus does not qualify every integer input.
The expectations and transcription were authored within this investigation;
this is not independent second-agent review.

## 7. Reproduction, artifacts and version boundary

```sh
python3 native-staff/reproduce.py /path/to/pinned/original/game --out [private-local-path]
node cli.cjs test
node tests/legacy-quarter.cjs
```

The reproduction command compiles into temporary directories and requires a new
output directory. It checks original input hashes before and after. A clean
rerun reproduced all **16 input/observation TSV identities**. This repeat is not
counted as new cases or independent review. Original files remain read-only.
The bridge is not a sandbox for arbitrary binaries or hostile states.

`results/native-manifest.json` identifies all native inputs, source files and
recordings. `legacy-quarter-comparison.json` records the unchanged 0.2 engine's
56 failing boundary cases, including all inputs/expected/actual values. The
current comparator and complete Node report record the corrected results.
No original executable, art, compiled native binary or emulator state is included.

Lab 0.3 preserves the 0.2 core under `history/0.2`. It rejects old-version action
replays. An old full snapshot can migrate with a warning when no quarter is
pending. An old snapshot with a pending quarter and no `progressionValue` is
rejected, because its historical cached value cannot safely be inferred from
current cash/month. This is the lab's JSON schema, not original DINOSG support.
The rule bench now exposes illness, management and visitor-status experiments.

## 8. Still missing

Full daily/weekly/quarterly composition still needs an original connected run
without the remaining economic adapters, including cash movement across gates,
payroll dismissals, feeding, visitor outcomes, events and escape ordering.
Detailed financial history/annual accounts, midmonth warnings, complete menu
RNG and animation/audio completion are not certified by these new tests.
Actual DOS startup, mouse/modal interaction, an earned winning route, rendered
ending and DOS score persistence remain separate acceptance work.

No fDisBull installation or release-status recheck occurred in E27; the native
instruction bridge, not fDisBull, produced the new evidence. No original game
file, production Swift source or remote repository was changed.
