# DinoPark: foreclosure ordering and the original losing route

**26 October 2026 | Guide 0.2s / E33 | Algorithm Lab 0.8**

## Result and separate evidence tracks

The original monthly loan-failure branch returns before the month increment,
weekly processing and quarter scheduling. Lab 0.7 instead marked foreclosure
and then advanced the month. The unchanged 0.7 core fails all 96 foreclosure
cases in the new 320-scenario corpus; Lab 0.8 matches all 432 checkpoints.

A separate original-DOS investigation uses the supplied fDisBull 0.15 candidate
at e91879c, real mouse controls, scene routing, rendering and modal dialogs.
Seven matched financial forks pass at exact original instruction boundaries.
One failed-payment route continues through the bank advice, Nice Try ending,
leaderboard and title. This is a constructed losing state, not an earned park
or successful winning route. No instruction layer or substituted economic
routine is used in that live track.

Original game inputs, production Swift, user Mac and remote repositories remain
unchanged. No new release check or tool patch is part of this continuation.

## 1. Foreclosure is an early return, not an ordinary month transition

The relevant original sequence in `38FF:4CA3` is:

```
Finish admission/concession and monthly inventory/reporting
Reset the internal day field to zero
If there is outstanding debt:
    calculate installment and principal reduction
    debit committed and working cash
    reduce the debt and record the payment in the fee history
    if committed cash is negative:
        acquire a terminal pause hold and mark the park inactive
        request bank advice or the ending route
        return from the daily routine
    otherwise clamp nonpositive debt to zero
Increment the month
Continue weekly work, when due, and quarter scheduling
```

The terminal dispatcher `38FF:55A8` calls pause-acquire `1B29:1306`, clears
`DS:3E02`, then routes according to the bank-feedback field. The known feedback
path requests context 15. The daily early-return boundary is `38FF:518F`.
The successful payment boundary at `51CE` precedes the month increment at `51D9`.

Thus a failed April installment leaves **internal month 3 and day 0**. This is
the original transient end state, not a reset to the start of May. If the
weekly counter has just reached seven, it remains seven because the weekly
reset, wages and feeding are not reached. A failed March/December installment
does not go on to schedule the ordinary quarter/year transition.

Lab 0.8 now preserves that return boundary, acquires the terminal hold, and emits
`day.terminated` rather than `day.complete`. Its final diagnostic row still
records revenue already processed that day. It does not invent the bank or
ending scenes inside the headless core.

## 2. The final-dollar loan trap can leave a negative displayed loan

The previously established uncapped installment is not reinterpreted here.
This pass follows its failure branch into the actual interface. With debt 1
and committed/working cash 164, the original charges 165, leaving:

```
Committed cash = -1
Working cash   = -1
Loan balance   = -164
```

The loan stays negative because foreclosure is tested before the debt clamp.
The bank visibly displays the negative loan and cash while presenting advice.
It is not a refund or a way to continue a productive park. The park is inactive.

With cash 165 instead, the same loan clears to zero and cash becomes zero:
there is no foreclosure at this particular test. This is not a promise that
zero cash is safe against every subsequent game cost.

### Seven matched real-DOS payment cases

A native checkpoint is captured at `38FF:4EEB` after naturally reaching month-end
from the supplied pmm park. Only committed cash, working cash and debt are
changed in each fork, with expected-old-byte guards. No date, code, RNG, staff,
stock or pen edit is made. The installment is then processed by the original
running game. Screens and exact branch stops are recorded.

| Start committed / working / debt | After committed / working / debt | Payment-branch outcome |
|---|---|---|
| 164 / 164 / 1 | -1 / -1 / -164 | Foreclosure |
| 165 / 165 / 1 | 0 / 0 / 0 | Normal continuation |
| 164 / 164 / 5000 | -1 / -1 / 4885 | Foreclosure |
| 165 / 165 / 5000 | 0 / 0 / 4885 | Normal continuation |
| 0 / 0 / 0 | 0 / 0 / 0 | No installment and no foreclosure here |
| 165 / 1 / 1 | 0 / -164 / 0 | Normal continuation at this boundary |
| 164 / 1000 / 1 | -1 / 835 / -164 | Foreclosure |

The final two are deliberately mismatched live/working diagnostic states, not
claimed normal player-reachable orders. They show that **committed cash**, not
the working balance, decides this branch. Each nonzero-debt fixture posts the
165 charge once in the closing month's fee history. The zero-debt control posts
nothing. Seven cases give 80 checked assertions and 19 snapshots, including
modal observations. They are not added to the JavaScript regression count.

## 3. The actual losing route and the advice's limitation

The live one-dollar-debt fork proceeds through:

```
Foreclosure notice
    -> Bank advice (context 15)
    -> Nice Try ending (context 17)
    -> Leaderboard (context 14)
    -> Title (context 18)
```

Real buttons dismiss the notices and advance the ending. The original falling
animation, waits and scene loops execute. Calendar, weekly phase and the
observed cash/debt remain stopped across this route. The negative score does
not qualify for a new leaderboard entry, so this experiment does not qualify a
successful DOS score-file write. The inspected working files remain unchanged.

The supplied park retains last-spending category `DS:5852=1`. The failure path
selects advice message 232 for that category, criticizing the last dinosaur
purchase. The same advice appears after the finance-only fork, even though the
test has not just purchased an animal. This is evidence that the message is
selected using stored spending context, **not proof that it accurately diagnoses
the reason the current payment failed**. Other advice categories are not newly
qualified by this pass.

The first accepted ending trace has 14 snapshots; a clean fresh-boot repetition
has 16 because polling/timing differs. Both traverse the same four contexts and
pass the same state invariants. Neither count represents distinct ending cases,
seconds, universal frame timing or deterministic whole-game replay.

## 4. Original daily/quarter composition corpus

The native instruction corpus crosses:

- Months January, March, April and December (internal 0, 2, 3, 11).
- Incoming weekly phases 0 and 6.
- Cash 0, 164, 165, 166 and 1000; debts 0, 1, 166 and 5000.
- Original RNG seeds 1 and 17.

This produces **320 scenarios, 432 snapshots and 96 terminal cases**. Fixtures
begin on the final day before month closure, with an explicit temporary closure
to avoid income masking the cash boundary, stated staff/food/herd, and no
concession facilities. The full original daily economics, original RNG, copies
and optional quarter code run. The terminal dispatcher is restored instead of
the earlier fail-fast terminal placeholder; its original pause/inactive/bank
request instructions execute.

Last-spending category 1 is explicitly initialized. An unexpected ranking or
stack-error path remains a fail-fast tripwire and was not reached. Physical
input, graphics, audio and modal services are still declared adapters in this
LDT track. Do not confuse it with the real-DOS track above.

The JavaScript comparison checks inherited scalar/economic fields, staff,
inventories, pens, seller flags, all 900 history elements, RNG state/draw count,
and the terminal flag. It independently decides whether to execute a quarter
and requires matching snapshot cardinality. Recorded native advice/scene IDs
are not claimed to have a corresponding JavaScript ending implementation.

The unchanged archived Lab 0.7 fails 96 scenarios: every terminal case has a
wrong month. Other terminal discrepancies, including its missing terminal hold,
are not added as separate failed cases. Lab 0.8 passes all compared fields.
A fresh native compilation reproduces cases.json, input.tsv and observed.jsonl
byte-for-byte. Repetition is not additional or independent evidence.

## 5. Lab 0.8 compatibility and UI behavior

The corrected terminal state has a counted hold and may retain weekly counter
seven. The validator accepts that counter only for foreclosure, not an ordinary
running park. The browser disables advance and resume after termination; the
core rejects explicit resume with `RUN_ENDED`. Additional advance calls leave
the terminal snapshot unchanged. The CLI's automatic-resume option also stops
at a terminal result rather than trying to clear its hold.

Current-version terminal snapshots round-trip exactly. An older-version
foreclosed snapshot is rejected atomically because its calendar/hold state may
contain the old error. Keep Lab 0.7 for its older terminal snapshots and action
replays. Compatible nonterminal snapshots can migrate with the existing warning;
missing histories or quarterly schedules are not invented.

The full combined corpus has **186,550 cases / 213,724 snapshots / 60 suites**,
zero compared-field mismatches, and **186 unit/integration checks**. Chromium
executes the standalone HTML bytes: 36 existing application checks and 12 new
terminal checks pass, including snapshot download/import, atomic old-terminal
rejection and browser-to-Node replay equality. Its 1,432 recorded-case sample
replays existing observations, not new native executions. File-URL launch,
Safari and Firefox remain unqualified here.

## 6. Tool friction and integrity

The supplied debugger, private libraries, guarded forks, mouse delivery,
breakpoints and native restore worked. No new debugger feature blocker was
identified. The earlier bounded-wait suggestion still applies to preparation.
One clean replay needed more guest-time after acknowledging the parking advice;
a 10-second budget stopped on the street before the loan breakpoint. Increasing
the bounded budget to 50 seconds reached it. The screenshot showed that the click
had worked; this was a harness timing assumption, not a failed game control.
That failed log/script is preserved under calibration, not counted as a pass.

An earlier fresh-state screenshot request needed normal guest progress to
refresh the framebuffer. That documented restore boundary was handled, not
patched in the tool. Exact pre/post-finance breakpoints avoid sampling an
unrelated later day. Known comparison-shape hardening was not retested or
silently considered fixed; explicit assertions are used instead.

All **192 original game files** match their private archive members. The task
input directory additionally contains three byte-identical archived repository
helper scripts. All 195 workspace files match all three working copies,
including the partial calibration workspace. All **25 native-state archives /
650 members** pass CRC and database digest checks. Private state/database bytes,
input game material, lifted original C and binaries are not redistributed.

## 7. Reproduction and remaining work

Day-level native reproduction, using separately supplied original files:

```
python3 native-terminal/reproduce.py /path/to/game --out /new/output
node cli.cjs test
node cli.cjs scenario examples/foreclosure.json
```

The native bridge requires compatible Linux x86-64, GCC and process-local LDT.
It authenticates EXE/VARS, disables core dumps, bounds subprocesses and uses
only temporary compiled code. It is not a security sandbox for arbitrary code.

The separate live scripts recreate checkpoints from a copied game:

```
/path/to/offline-venv/bin/python live/reproduce_live.py   --game-dir /path/to/game   --kit /path/to/fdisbull-linux-dos-offline-0.15.0-e91879c   --out /new/private-workspace
```

Run those with the supplied kit's complete environment. Output must be new and
separate from inputs. Check last captures/logs on any mismatch; timing is bounded,
not deterministic record/replay. Do not publish the generated private directory.
The accepted fresh reproduction passes all seven finance routes and the same
bank/ending/title route. Authored sources and selected safe observations are
included; private checkpoints are recreated, not shipped.

Remaining work includes other advice categories/terminal causes, actual DOS
handling of the auction zero-divisor, mixed purchase/undo/placement boundaries,
full live auction timing, and a genuinely earned successful sale with a displayed
ending and durable DOS scoreboard reload. Graphics/audio reconstruction remains
deferred. No independent second-investigator review or whole-game parity is
claimed.
