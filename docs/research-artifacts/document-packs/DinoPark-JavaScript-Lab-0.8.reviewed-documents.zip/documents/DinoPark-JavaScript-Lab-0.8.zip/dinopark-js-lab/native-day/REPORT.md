# DinoPark: connected daily economics, annual tax and midmonth financing advice

**25 October 2026 | Guide 0.2n / E28 | Algorithm Lab 0.4**

## Result

The original complete daily routine and optional quarter processor now run together
for bounded constructed parks, without replacing their economic subroutines with
call recorders. This exposed two omissions in Lab 0.3: annual tax and the conditions
and amount used for the midmonth financing warning. Lab 0.4 adds both, plus explicit
monthly/annual cash baselines and the maintenance-week counter. No rebalance was
made. Original game files, production Swift and remote repositories are unchanged.

Fresh native corpus: **705 scenarios, 2,874 snapshots, eight differential suites**
(seven conceptual families, with month/quarter fixtures split by snapshot count).
The corrected JS matches every compared field, including original RNG state and
draw count. The preserved 0.3 core disagrees in **274 scenarios**: 234 warning
sequences and 40 annual-boundary scenarios. Of the latter, 38 differ in cash and
two differ only in the positive-growth tax notice after integer rounding to zero.
New state fields absent from 0.3 are excluded from that legacy failure count.

This is not a live DOS session or an earned park. Logical days are delivered by
the native driver. Rendering, physical input, resources and modal services remain
explicit adapters. No independent second investigator is claimed.

## 1. Annual tax uses committed cash growth, not the profit ledger

Original `38FF:3859-3A27` compares committed cash `DS:5C3A` against the stored
annual baseline `DS:6FC4`. VARS offset `0x13C` contains 37 in the pinned build.
Within the ordinary positive range:

```text
if committed_cash > annual_baseline:
    tax = floor((committed_cash - annual_baseline) * 37 / 100)
    committed_cash -= tax
annual_baseline = committed_cash
```

The actual multiply retains the original unsigned 32-bit product behavior; the
cash/baseline comparison is signed. Tested values are documented in cases.json,
not a promise for every possible malformed 32-bit state. The original message
identifier 161 and original string resource identify this as annual income tax.
The reader does not redistribute that resource.

The annual handler changes committed cash. The enclosing quarter's later original
synchronizer reconciles working cash. The parent first wraps the month to zero,
then calls annual processing before year increment and breeding. The original
monthly automatic installment, if any, has already happened in the daily body.

Constructed case501: closed park, cash100000, annual baseline5000, no debt, final
day of December. The daily snapshot retains100000. Original quarter processing
charges35150 and both balances end at64850 after synchronization. The RNG state
and draw count remain unchanged between those two checkpoints. Lab0.3 kept100000.

A loss or equality produces no charge, but the annual baseline still becomes the
current balance. Positive growth of1 or2 rounds the tax to zero while still taking
the original tax-notice branch. The test does not infer a real-world tax policy,
an asset-valuation tax, or an optimal spending strategy from this game rule.

The tested charge reads cash and the saved baseline, not the signed expense-history
fields. An expense-ledger overflow is not evidence of reducing this annual charge.
The amount the player actually spent can affect cash, which is a different claim.

## 2. Monthly cash-change reporting precedes the installment

The monthly routine stores `cash - DS:6FB8` in `DS:6FBC`, then refreshes `6FB8`
with committed cash. These occur before the monthly loan debit in the enclosing
daily body. Lab0.4 stores `monthCashBaseline` and `monthProfit` explicitly rather
than inventing those figures from its summary metrics.

The original history buffers are recorded in native output. They are not all
implemented or compared by JS. In the case501 annual fixture, the tax is visible
in the first slot of the shifted previous-year fee array: the parent had already
set the month index to zero before posting it. That is a recorded accounting
placement, not a newly rendered ledger-screen acceptance or complete multi-year
history qualification.

## 3. Midmonth warning is conditional bank advice

The original daily block `38FF:527B-5321` runs on
`day == floor(month_length / 2)`. It estimates:

```text
estimate = min(automatic_installment(debt), debt)
for each ACTIVE worker category:
    estimate += truncate_toward_zero(signed16(count * monthly_salary) / 2)
warn only if estimate > committed_cash AND additional_credit_quote != 0
```

Monthly salaries in role order (maintenance, vets, security, guides, operators,
managers) are `[1400,1800,1250,900,1100,2400]`, read from the original staff table.
This is not one weekly payroll, and it does not add an absent worker simply because
ordinary payroll pays absences. The original message129 recommends the bank.

For one active guide and no debt, the estimate is450: cash449 warns,450 does not.
For one security employee it is625, not624 from doubling the rounded weekly wage.
At the5000 debt ceiling, the available-credit test suppresses this advice even
when money is insufficient. These are deliberate current-state fixtures with
admission closed to isolate the boundary, not financial recommendations.

The estimate caps the remaining loan part to debt. Thus debt1 contributes1 to
this warning even though the already-verified actual automatic installment still
charges165. The warning does not cure the final-payment overcharge.

Lab0.3 emitted an unconditional warning every midmonth and reported a weekly-wage
estimate. Lab0.4 uses the original guard and estimate. The original subsequent
February/August overeating test is still separate and runs when its own gates
permit it, regardless of whether a financing notice appears.

## 4. Connected execution rather than isolated formulas

Native driver executes original `38FF:4CA3` through its actual return, then runs
the original quarter-context predicate and `38FF:4827` when requested/permitted.
Context is ordinary main street, not a complete graphical scene. A quarter can
leave an annual pause; the bounded driver then stops rather than clearing it.

Within reached paths, the original illness/return, revenue, monthly inventory,
loan, payroll, feeding, visitor status, event/fee lottery, escapes, predation,
risk counters, midmonth checks and cash-cap code execute in their original order.
The original quarter management, animal removal/seller registration, annual tax,
breeding, counter resets and synchronization are available, not economic no-ops.
This corpus does not claim to reach every branch, every seller configuration or
all event outcomes. Prior isolated suites retain their original relevance.

Maintenance counter `DS:BF9F` is now retained: on the weekly path, an active
maintenance employee or a count above4 resets it; otherwise progression>=4
increments it. Its graphical consequences are not newly qualified here.

| Suite | Scenarios | Snapshots |
|---|---:|---:|
| Persistent weekly interactions,21 days |72|1512|
| Month/quarter boundaries, three snapshots |72|216|
| Month/quarter boundaries, four snapshots |36|144|
| Payroll-scarcity sequences |81|162|
| Midmonth calendar/credit fixtures |240|240|
| Annual boundary and baseline fixtures |108|216|
| Tight warning equality boundaries |48|48|
| Hunger/predation/fence/maintenance sequences |48|336|
| **Total** |**705**|**2874**|

Scenarios include returning/absent workers on payday, scarce food, closures versus
inspections, event/status masks, full-range normal loan debt, year/quarter changes,
weak/strong fences, carnivore/prey and zero-cash payroll boundaries. Inputs are
constructed rather than acquired through shops. Tests use the original RNG,
never random tapes for these connected sequences. Seed is fully recorded.

## 5. Fields checked and explicit exclusions

Every snapshot compares both balances, debt, visitors, hunger, year/month/quarter/
day/week, risk counter, cached progression, absence role/countdown, inspection/
closure, event/status/escape fields, pending quarter, hold count, overeating,
auction availability, annual notice, monthly/annual cash baselines, monthly cash
change, maintenance counter, all active/pending staff, all nine active/pending
stocks, ten live/pending pen records, effective monthly visitor totals, seller
flags, and full RNG state/draw count. Midmonth and annual notice presence are
compared. Other message IDs and financial-history arrays remain raw observations,
not claimed fully equivalent to the JS event text/ledger implementation.

JS executes its own day/quarter condition checks from inputs. Native snapshot
stage numbers do not tell JS when to run a quarter. Snapshot count differences
also fail the comparison. A comparison with the archived0.3 engine uses the same
input adapter and excludes only the four newly introduced state fields.

The historical E27 annual-boundary native probe used an explicit annual-call
recorder. Its comparator now chooses a no-charge baseline when running Lab0.4
against that old scope. Historical native observations remain byte-identical;
E27 is not promoted to annual-tax proof. E28's new native annual routine provides
that evidence.

The driver stops before executing the previously documented nonterminating
empty-herd/no-vet mortality configuration. A terminating/foreclosure path is a
fail-fast recorded trap rather than silently supplied success. No final705-case
observation hit that trap. There are no new malicious-save tests or security
exploitation claims. The LDT bridge is not a security sandbox.

## 6. Reproduction

```sh
python3 native-day/reproduce.py /path/to/pinned/original/game --out [private-local-path]
node native-day/pack.cjs
node cli.cjs test
node tools/build.cjs
```

The first command needs compatible Linux x86-64, GCC and process-local LDT;
CPython3.13.5 was used. It compiles in a temporary directory, disables core dumps,
bounds runtime, authenticates inputs before and after, and refuses to overwrite
an existing output directory. The packer normally consumes the delivered raw
recordings in native-day/results; reproductions can be compared byte-for-byte
without overwriting historical observations. Browser/Node use no compiler or
original game files.

Pinned inputs:

```text
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT     5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153
```

Original sim/transaction/credit/quarter support bytes are loaded from the pinned
EXE. Each adapted far-call opcode/target is checked. `adapters.json` classifies266
sites: original arithmetic/copy/RNG/pause/game calls or declared presentation and
error adapters. Original-code bytes are not distributed in this package. The
inherited helper's artificial economic stop is restored before execution.

A fresh temporary build reproduced cases.json, day-input.tsv and day-observed.tsv
byte-for-byte. Source, input and observation hashes are in results/VERIFICATION.json.
Repetition is not extra evidence cases and is not independent review.

## 7. Version and remaining work

Lab0.4 stores annualCashBaseline, monthCashBaseline, monthProfit and maintenanceWeeks.
Old replay versions are rejected. A snapshot lacking these fields is rejected
atomically, even if no quarter is pending: the historical annual baseline cannot
be inferred from current cash. Keep Lab0.3 for its old files; construct explicitly
labelled new fixtures when an old baseline is genuinely unknown.

The lab's preset starting finances are authored fixtures. Their annual baseline
is explicitly5000, not an inferred earned history. Changing it is a scenario edit,
not an automatic way to make an old run survive. Graphics remains an event
subscriber; no original media-RNG callbacks were added.

Remaining work: complete financial-history buffer comparisons and multi-year
rollovers; more connected domains and original end/foreclosure paths; original
scene/media RNG, physical input and timer/modal integration; continuous DOS
save/load/ending acceptance; an earned winning route. No fDisBull runtime or
release-status change was performed in this continuation.
