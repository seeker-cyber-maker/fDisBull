# Resume: guide 0.2p / E30 and Algorithm Lab 0.6

25 October 2026. No original game, production Swift, user Mac or remote changes.
Algorithms first; hardware/media rendering deferred. No new emulator/rebalance.
Peanut/fly remain documented, not added to Swift. fDisBull not used or accepted.

Read ledger-posting/REPORT.md (guide) or native-ledger/REPORT.md (lab).
Native receipts are results/NATIVE-RUN.json and transactions/NATIVE-RUN.json.
The lab's tests/ledger.cjs and ledger-transactions.cjs compare all900 history
entries at every recorded snapshot. Whole regression186219cases/211008snapshots/
57suites,159unit checks,1432browser samples/36application checks.

New E30:679 scenarios/sequences,13239snapshots,five suites.112 day cases include
four2190-day constructed runs;567 food/store cases cover history destinations.
Year-end uses original street release/sync slice plus explicit notice/scene
bookkeeping, not full office/media/physical input. Store orders are prepared
before original confirm/cancel; not a complete shop UI. Unknown concession
locals at zero operators are excluded from exact history corpus and flagged in JS.

Semantic corrections: C03B=food/plant purchases (formerly animalPurchases);
C12B=advertising (formerly foodPurchases); CA8B=active operator count.
C21B mixes capital/fees/automatic payments/tax; C30B includes animal purchases
and certain fees. Existing summary totals already included both renamed arrays.
Jan31 payroll posts February; Dec31 month12 posts index12, then annual shifts it
to index24, two-years-back January. Cash deduction occurs once. Example1675 wages
from200000->198325. Annual tax still lands prior-year January, a separate order.

Lab0.6 fills daily ledger and available food/seller policies, with a Financial
history tab. Old snapshots missing arrays preserve null and warning, no backfill.
Use old Lab for old replays. Valid current snapshots preserve financeUnknown cells.

Next: remaining land/fence/DinoMart full input/undo/placement history paths,
original quarterly ticket schedule controls, terminal/foreclosure composition,
then actual DOS input/modal/media timing and an earned route. Exact daily ledger
agreement is not full-game parity. Native bridge is not a hostile-code sandbox.
