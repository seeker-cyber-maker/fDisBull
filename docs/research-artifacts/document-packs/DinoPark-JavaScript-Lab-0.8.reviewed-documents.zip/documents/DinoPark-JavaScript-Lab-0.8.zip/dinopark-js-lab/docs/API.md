# API reference

Browser: `globalThis.DinoPark`. Node: `require('./src/core.js')`. Constants are available as `DinoPark.C`.

## OriginalRng and controlled returns

```js
const rng = new D.OriginalRng(1);
rng.next('reason');     // Original 15-bit result, advances shared state
rng.mod(100, 'event');  // Consumes one result even if later condition is false
rng.snapshot();        // {state, draws}

const tape = new D.TapeRng([79, 13, 56, 11]);
```

A tape throws `RNG_TAPE_EXHAUSTED` instead of inventing more draws. Semantic trace labels are the lab's labels.

## Rule kernels

All return new results rather than mutating caller-owned input arrays. RNG instances are intentionally advanced.

| Function | Main input |
|---|---|
| `capacity(pens)` | Ten pen records |
| `attendance(input, rng)` | Pens, active staff, parking, ads, cents ticket, terrain, quarter, year, hunger, closure; optional controlled `factor` |
| `concessions(input, rng)` | Visitors, foodStands, giftStands, restrooms, operators, inspection |
| `payroll(input)` | Cash, working, active staff, pendingStaff, absenceDays, absenceRole |
| `feeding(input, rng)` | Pens, active staff, food/pendingFood, hunger, overeating, statusMask, scene |
| `predation(input)` | Pens/pendingPens, hunger, progression |
| `illness(input, rng)` | Year/month/working cash, absenceDays/absenceRole, live/pending staff |
| `quarterManagement(input, rng)` | Cached daily progression, new month 3/6/9/12, old quarter, twelve monthly visitor counters, live/pending staff |
| `visitorStatus(input, rng)` | Weeks, progression, statusMask, visitors, working cash, parking, live/pending food and herd, staff |
| `escapes(input, rng)` | Pens/pendingPens, progression, tally, weeks, maintenance |
| `breeding(pens, rng)` | Species/count pen records |
| `monthlyInventory(input)` | Food/pendingFood and terrain |
| `weeklyEvents(input, rng)` | Progression, cash, calendar, staff, pens, pending state and event mask |
| `loanQuote(debt)`, `scheduledPayment(debt)` | Debt in dollars |
| `bankTransaction(input, command)` | Cash, working, debt; command `borrow` or `repay` |
| `automaticLoan(input)` | Cash, working, debt |
| `annualFinance(input)` | Committed cash and annualCashBaseline; returns post-tax cash/baseline, amount and notice IDs |
| `midmonthWarning(input)` | Committed cash, debt and six active staff counts; returns estimate, available credit and warning |
| `nextBid(current)` | Current asking price |
| `auctionSettlement(input)` | Working, cash, bid, winner (player=7), seller flag |
| `remainingSales(flags, rng)` | Twenty catalogue-index flags |
| `valuePark(input, rng)` | Cash, debt, year, terrain, ten pens, four facility counts |
| `rankScore(score, table, name)` | Ten score records; strict comparison for ties |
| `inventorySequence(input)` | Cash, page, slot, stock, clicks, undos, finish, held |

`RuleFault` has `code`, `message` and `details`. Kernels intentionally expose a relatively direct research interface; they are not an untrusted-input schema layer. The Engine and import functions validate constructed state and policy input. Use the browser examples or the native adapters for complete kernel fixture shapes.

## Engine

```js
const engine = new D.Engine({state: D.preset('lean'), seed: 1});
engine.apply({type:'advance', days:7});
engine.apply({type:'ticket', cents:500});
engine.apply({type:'food', index:3, quantity:25});
engine.apply({type:'borrow'});
engine.apply({type:'sync'});  // Deliberate working/committed synchronization
```

Actions: `advance`, `ticks`, `pause`, `resume`, `borrow`, `repay`, `sync`, `ticket`, `food`, `staff`, `markSale`, `settleOffers`, `sellPark`, `loadPark`.

`resume` is a declared policy that clears all modeled holds and returns the modeled context to main street. To exercise counted primitives directly use `acquire(reason)` and `release(reason)`; only `apply()` actions are captured in action replays. Do not mutate `engine.state` during an experiment and then expect its action replay to reconstruct that mutation. Load a new validated fixture first.

`advance` stops when paused, ended, or at the requested day count. `ticks` processes a bounded number of logical iterations. `day()` and `quarter()` are implementation methods; call `apply`/`tick` to retain scheduler order, rather than substituting direct daily calls for the parent loop.

## Events and presentation

`subscribe(fn)` returns an unsubscribe function. Events are JSON-compatible `{tick, day, type, data}` records. Examples include `day.complete`, `feeding`, `payroll`, `animals.escaped`, `animals.born`, `calendar.quarter`, `bank.borrow`, `park.loaded`, and `game.diagnostic`.

`scene.update.request` explicitly identifies an unimplemented original scene callback boundary. It is a notification, not a fake implementation. A future renderer can display these domain events, but original media RNG/completion semantics will need explicit deterministic scene drivers in the core, not random mutations performed by a renderer callback. Observers receive copied event data; exceptions from observers are isolated from simulation control flow.

Set `engine.traceRandom = true` for labelled RNG events. The in-memory event log retains at most 5,000 records. Daily history is retained separately. Imported snapshots restart those histories; action replay reconstructs them.

## Snapshot and replay

- `snapshot()`, `loadSnapshot(json)`: complete lab execution state, including full RNG and logical phase.
- `parkSave()`, `loadPark(json)`: separate lab-only park save with the recovered saved/live distinction; no binary compatibility implied.
- `replay()`: initial snapshot, applied action list, expected final snapshot.
- `Engine.fromReplay(record)`: reconstruct a new Engine using only the recorded initial state and actions.

The CLI and browser explicitly compare the replayed final snapshot with `record.expected`; `fromReplay` itself returns the reconstructed engine to permit custom comparisons. JSON files carry explicit schema and engine version metadata. Do not relabel them as original DOS saves.

## Inspection and engine versions (0.2)

Pass `closureDays` and `inspection` together to attendance and concessions.
Admission is closed only for a positive timer with no inspection. Concession
inspection effects require a positive timer and flag. The stored flag may stay
true after expiry. For compatibility, attendance accepts a resolved `closed`
when no timer is supplied, and concessions treats an omitted timer as an already
resolved inspection argument. The integrated engine always supplies the raw pair.

Cross-version action replay is rejected with `ENGINE_VERSION_MISMATCH`. Full
snapshot import may migrate, emitting `snapshot.migrated`; exact future replay
requires the matching engine. Snapshot schema remains 1; engine semantics are 0.3.0.

## Cached progression (0.3)

`state.progressionValue` is computed at the start of a daily update, before
illness/revenue/rollover. Quarter entry increments this exact stored value.
Do not recompute from current cash or the already advanced month, especially
after loan repayment or when a quarter is deferred by the current scene.
`quarterManagement` consumes the prior stored value and returns its increment.

An older pending-quarter snapshot without this field is rejected with
`MISSING_PROGRESS_CACHE`. Nonpending old snapshots may migrate with the explicit
version warning; their next day computes a fresh value normally. All cross-version
action replays require their original engine. This is a lab state contract, not
a claim that this importer supports the original DINOSG layout.

## E28 financial state

Snapshots require `annualCashBaseline`, `monthCashBaseline`, `monthProfit` and `maintenanceWeeks`. Missing historical values are not inferred. `finance.annual-tax` contains amount, cash and baseline in `event.data`. `payroll.warning` now represents the conditional midmonth bank advice, not every midmonth boundary.

## Original report buffers (0.5)

`makeFinanceHistory()` returns fifteen independent arrays, each sixty elements:
index `yearAge*12+month`, age0 current year through age4 oldest. `FINANCE_FIELDS`
is their ordered list; `validateFinanceHistory` rejects missing/malformed arrays.

`financialSummary({history,yearAge,month})` returns admission, income, expenses,
and profit. `monthlyGraph({history,page,year,month,yearMask,rect})` supports pages
3(visitor counts),4(food net),5(gift net) and returns source values, series,
scale and original line arguments. `rollFinancialYear({history,cash,
annualCashBaseline})` returns tax/cash/baseline and shifted cloned histories.
These are pure kernels; the Engine does not automatically populate the history.
All input buffers remain unchanged. No RNG is consumed by these three helpers.


## Lab 0.6 financial state

`state.financeHistory` contains 15 arrays of60 entries, indexed as yearAge*12+month.
`DinoPark.FINANCE_FIELDS` gives the canonical address-order field names.
`state.financeUnknown` contains [field,index] pairs for undefined accounting cells.
`DinoPark.stateFinancialSummary(state,yearAge,month)` returns the report plus
`complete`, `unknown` and a qualification string; it throws HISTORY_UNAVAILABLE
when no histories were supplied. It does not backfill older snapshots.

`financialSummary`, `monthlyGraph`, `rollFinancialYear` remain pure explicit-buffer
kernels. They cannot infer uncertainty markers from a bare array; use the state
wrapper/UI for integrated reports. Raw buffers retain original misdated entries.
The daily runner handles annual history shifting. `resume` is an explicit policy
release, not a replay of original office UI/media. New shop tests do not expose
new browser facility/advertising purchase commands.

## Quarterly schedules (0.7)

`ticketControl({schedule, quarter, day, target, direction})` returns a new
`{schedule, enabled, changed}` result. Four prices must be normal 50-cent steps
within 50..950; quarter/target are 0..3 and direction is -1 or +1. This models
control eligibility and price edits, not office navigation or media RNG.
`effectiveTicket(state)` returns the current-quarter schedule entry when present,
otherwise the flat diagnostic price.

```js
engine.apply({type:'ticketSchedule', prices:[250,250,300,250]}); // authored fixture
engine.apply({type:'ticketStep', quarter:2, direction:1});      // original UI gate
engine.apply({type:'ticketFlat'});                            // explicit diagnostic
```

Flat `ticket` edits are rejected while a schedule is active. Old snapshots with
no ticketSchedule default to null, not an invented set of four prices. A scheduled
day updates the cached scalar before attendance. Schedules survive year rollover.
