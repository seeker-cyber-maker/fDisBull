# Coverage at Lab 0.6 / E30

Prior kernels and evidence retain their exact scopes. Current test receipt:
`results/test-report.json`. Latest authored report: `native-ledger/REPORT.md`.

Daily ledger corpus compares 112 scenarios /10,728 snapshots, including all900
history values, economic state and RNG. Transaction corpus compares567 sequences /
2,511 snapshots, all900 values plus selected cash/stock state. The store fixture
starts with known pending orders, not live clicks. New native totals679/13,239.

Four six-year scenarios are constructed with ample unearned starting cash and
explicit year-end release adapters. They are not complete original sessions.
Positive operators keep the exact-history corpus away from undefined concession
locals; those are marked unknown in other lab states rather than certified zero.

Original monthly report and graph consumer behavior remains E29 evidence.
Hardware/scene media RNG, full purchase UI, per-quarter ticket schedules,
foreclosure/end transitions and an earned DOS route remain incomplete.

## E31 update

Three original day-level two-year runs compare state, RNG and all 900 history
slots using four different quarterly prices. Eight real-DOS calendar forks add
64 UI-control comparisons. Two actual gift-stand confirm/cancel/reentry routes
are recorded separately. Original driver/output no-ops are absent from the live
UI track, but remain declared in the two-year instruction track. No earned win,
complete game, full media fidelity or independent reviewer is claimed.

## E33 / Lab0.8 terminal update

The320-case corpus executes original daily/quarter and restored terminal code in
Linux LDT with explicit presentation/modal adapters. All900history values and
selected state/RNG are compared. Native advice IDs are recorded, not implemented
in JS. The live track uses originalDOS in the supplied fDisBull0.15/e91879c runtime
without economic stubs or code layers. Its three-field finance forks are declared
constructed states, not earned losses. No new score qualifies in its ending route.

The unchanged0.7 core fails96 cases on month; multiple symptoms are not counted as
extra cases. Current terminal snapshots round-trip and old terminal snapshots
reject without mutation. Browser-to-Node replay equality, download/import,
disabled advance/resume, error-free/no-network execution pass. Chromium loaded
actual standalone bytes using set_content; fileURL/Safari/Firefox not qualified.

Native rerun reproduced all3case/input/observation files byte-for-byte. Freshlive
reproduction passed7paymentroutes and the same endingroute. Its16polling snapshots
versus14 in the first route are not deterministic frame counts. Repetitions and
browser samples are not extra original cases or independent review.

Input audit distinguishes192 original gamefiles from3 unchanged archived helpers.
All195 workspacefiles unchanged;25native-state ZIPs/650members passCRC checks.
Those private archives/databases and original game material are not distributed.
Final package re-extraction/build/regression/replay checks have a separate receipt.

