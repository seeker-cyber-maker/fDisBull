# DinoPark: ticket-price graph, monthly reporting and five-year history

**25 October 2026 | Guide 0.2o / E29 | Algorithm Lab 0.5**

## Result

The ticket-pricing page's graph reads completed-month **visitor counts**, not
monthly cash change or dollar admission receipts. Following its consumer code
also exposes an original reporting discrepancy: financial summaries reconstruct
admission income from monthly visitors and a stored price, whereas actual cash
is rounded down separately on each day's admission calculation.

In one constructed January with $2.50 tickets, the original daily routines earn
$6,014 in ticket cash. The original account-summary routine reports $6,027 from
2,411 monthly visitors. Payroll is $900: the monthly cash-change report is $5,114,
while the accounting summary's profit is $5,127. There is no extra $13 in cash.

The five-year history shifter and original annual accounting execute against all
15 retained buffers. The tax is posted before shifting, after the caller's month
wrap, so it appears in the previous year's **January fee slot**. This is a history
placement quirk, not a second tax or a new cash deduction.

**1,180 new native cases/sequences, 3,656 checkpoints, seven suites.** The new
JavaScript reporting kernels and compared daily fields match every observation.
No original files, production Swift or remote repositories were changed. There
was no fDisBull installation, original DOS GUI, hardware playback, independent
review or earned winning route in this pass.

## 1. The ticket page's graph is an attendance history

Static labels use `file = 0x4800 + 16*(segment - 0x1000) + offset`.
They are not relocated DOS breakpoint addresses.

Original office page builder `302C:1F4C` uses page 3 for ticket pricing. Its page
switch reaches `224C`, builds four quarterly ticket controls, then calls the
graph at `235A -> 0BD5`. This connection is checked from original instructions
and the page-switch table, not inferred from a picture. The graph's page-3
branch selects the far data pointer `DS:CBF3` directly at `0C06-0C14`.

| Page / consumer | Values plotted |
|---|---|
| Ticket/admission page 3 | Monthly visitor counts at `CBF3` |
| Food-concession page 4 | `C8AB` food gross minus `C6CB` food cost |
| Gift-concession page 5 | `C7BB` gift gross minus `C5DB` gift cost |
| Financial-summary helper `09C0` | Reconstructed income, expenses and profit |
| Desk's last-month cash-change field | `6FBC`, not the ticket graph source |

The page heading is associated with admission revenues, but the graph itself
has no visitor-times-price conversion. Counterfactual graph fixtures change
money/price buffers while leaving visitor history fixed; the recorded ticket
graph line requests remain unchanged. Concession graphs use net amounts rather
than their gross sales alone. Negative-net and all-zero fixtures are included.

The graph supports five year slots: current year, then four earlier years. Its
current-year series draws `internal_month` monthly segments, so January has no
completed-month segment and February has one. An older available year draws
all twelve. This graph is not a continuously updated count of today's visitors.

The y-axis range scans all twelve entries of each available year through
`min(internal_year, 4)` before applying the visible-series mask. Therefore hiding
a year does not remove its extrema from the scaling calculation. Zero is always
included in the range. A year curve can start from the preceding December value;
the oldest stored year starts from zero. This preserves continuity rather than
starting every curve at January's value.

The original year-selection handler's ticket-page XOR branch is a static lead;
the new native graph tests supply the resulting masks directly. They do not
replay mouse clicks on the year selector.

### What was actually captured

The complete original graph routine executes with a supplied graph rectangle
`[390,55,582,144]` in the office's virtual coordinate system. Font dimensions,
text-width results and lower display services are explicit adapters. Original
math, source selection, range calculation, series iteration and line requests
execute. The recorder captures baseline, data segments and quarter-grid requests,
including the original palette indices. All those requests are compared.

The lab's monochrome SVG is a **diagnostic preview of those requests**, not the
original palette, font, clipping implementation or a pixel-equivalent DOS screen.
No extracted artwork is required or bundled. The existing Simulation cash chart
is a different lab diagnostic and has not been relabelled as the original graph.

## 2. Month-close data and actual daily cash take different paths

Attendance `38FF:211F` adds visitors to live month accumulator `DS:6FB2` and credits:

```
daily admission cash = floor(unsigned32(day_visitors * ticket_cents) / 100)
```

At month end, `38FF:4E6D-4EBD` copies the accumulated visitors into the current
`CBF3` month slot and clears the live accumulator. It writes a ticket value to
`CB03`, ultimately taking it from the current quarter's schedule at `BFCB`.
The month-close probe deliberately gives the temporary current ticket and the
quarterly schedule different values to distinguish the writers. That is a
synthetic diagnostic, not a claim that this mismatch is ordinarily UI-reachable.

Later in that monthly boundary, `6FBC = committed_cash - 6FB8` and `6FB8` becomes
the current committed cash. These occur before the enclosing daily routine's
loan installment. This independently corroborates E28's cash-change ordering.

Original summary helper `302C:09C0-0B67` takes year age and month, then calculates:

```
admission = floor(unsigned32(month_visitors * stored_ticket_cents) / 100)
income = admission + food_gross + gift_gross + animal_sale_income
expenses = payroll + food_cost + gift_cost + other_expenses
           + fees + food_purchases + animal_purchases
profit = income - expenses
```

The additions/subtractions retain 32-bit wrapping. That is the summary helper,
not a claim that every amount ever passing through cash is represented in these
particular categories. The helper does not change cash or consume random numbers.

For a constant price and ordinary nonoverflowing values, rounding each daily
receipt need not equal rounding once after adding a month of visitors. Therefore
the accounting summary and cash-change statement are not interchangeable.

## 3. Connected native January and report comparison

Seventy-six constructed parks cross four seeds and **all 19 normal ticket
settings, 50 through 950 cents in 50-cent steps**. Each runs the full original
daily routine for 31 consecutive updates in persistent native memory, then calls
the original financial-summary helper for January in that same memory.

Initial state is explicit: $5,000 in both balances, no debt, one active guide,
no concession facilities or parking, two occupied pens, abundant food, ordinary
Plains terrain, original RNG, and January of displayed Year 1. No purchases are
claimed. The driver does not edit cash, visitors or RNG between days. Rendering,
resources, modal messages, physical input and scene timing remain adapters.

| Seed-1 fixture at $2.50 | Original result |
|---|---:|
| Completed-month visitors | 2,411 |
| Actual ticket cash across 31 days | 6,014 |
| Payroll charged | 900 |
| Final committed cash | 10,114 |
| Stored month cash change | 5,114 |
| Original summary admission/income | 6,027 |
| Original summary profit | 5,127 |
| Summary excess over actual receipts | **13** |

There are **36 whole-dollar-price controls with zero discrepancy**. The 40
half-dollar-price cases report between **$2 and $13 more** than their actual
admission receipts. This supports the rounding explanation, rather than merely
noticing one disagreement. These are neither independent full games nor an
exploit. The annual tax reads actual committed cash and its baseline, not this
reconstructed income, so the report discrepancy does not itself change tax.

The JavaScript comparison checks each day's visitors, committed cash, RNG state
and cumulative RNG draw count. At month end it checks completed visitors,
monthly cash change, payroll, stored ticket and the original summary's income,
expenses and profit. It also checks actual admission cash against both the sum
of daily integer receipts and the lab's admission metric. It does not claim
full financial-array posting parity for every possible shop or event.

## 4. Five-year shifting and the tax's January slot

Original `38FF:37F2` copies slots 3 -> 4, 2 -> 3, 1 -> 2, 0 -> 1, then clears
slot 0. Original annual accounting `3859` applies this to fifteen arrays:

| Base | Element width | Lab field / bounded interpretation |
|---|---:|---|
| C03B | 32 bits | animalPurchases |
| C12B | 32 bits | foodPurchases |
| C21B | 32 bits | fees |
| C30B | 32 bits | otherExpenses |
| C3FB | 32 bits | payroll |
| C4EB | 32 bits | animalSales |
| C5DB | 32 bits | giftCost |
| C6CB | 32 bits | foodCost |
| C7BB | 32 bits | giftGross |
| C8AB | 32 bits | foodGross |
| C99B | 16 bits | giftStandCount |
| CA13 | 16 bits | foodStandCount |
| CA8B | 16 bits | counterCA8B, meaning deliberately not guessed here |
| CB03 | 32 bits | storedTicketCents |
| CBF3 | 32 bits | visitors |

Each contains five blocks of twelve monthly entries. Unique sentinel values
make every year/month distinguishable. The new corpus executes 1, 2, 5 or 6
annual calls in persistent memory, checking all 900 elements after each call.
This verifies shifting, oldest-slot loss and current-slot clearing. It is not
five or six years of gameplay. Cash/annual baseline/RNG and unchanged working
cash at this isolated boundary are also compared; the later quarter sync is
outside the isolated annual call.

The caller wraps the month index to zero before annual accounting. The tax is
posted to `C21B[0]` **before** shifting. Afterward it is in previous-year January,
while current-year fee slots are zero. With preexisting January fees of 3,001
and a 35,150 tax, that shifted January slot becomes 38,151. December's preexisting
fee remains in its own month slot. Repeated calls without new cash growth do not
charge the tax again. This is not a newly doubled debit or an opportunity to
avoid payment by manipulating a report.

## 5. Corpus and implementation boundary

| New native suite | Cases/sequences | Checked checkpoints |
|---|---:|---:|
| Ticket graph requests | 280 | 280 |
| Food graph requests | 280 | 280 |
| Gift graph requests | 280 | 280 |
| Financial summary helper | 180 | 180 |
| Annual history sequences | 48 | 168 |
| Month-close slice | 36 | 36 |
| 31-day January plus original report | 76 | 2,432 |
| **Total** | **1,180** | **3,656** |

All compared fields match the new JavaScript implementation. The original
program already contained these reporting quirks; Lab 0.4 had no complete
counterpart for these graph/history consumers. This pass adds diagnostic
kernels rather than claiming another defect in its economic day routine.

Lab 0.5 exposes `financialSummary`, `monthlyGraph`, and `rollFinancialYear`.
They consume explicit original-shaped history buffers. **The simulation does
not yet populate all fifteen arrays from every transaction.** Importing an old
state does not invent that history. All preexisting recorded-native regression
cases still pass. Old action replays remain version-bound; keep their matching
lab. This edition does not change daily economics or add menu/media RNG.

## 6. Reproduce and evidence boundaries

```
python3 native-finance/reproduce.py /path/to/pinned/game --out [private-local-path]
python3 native-finance/inspect_bindings.py /path/to/DINOPARK.EXE --out [private-local-path]
node tests/finance.cjs
node cli.cjs test
node tools/build.cjs
```

Native reproduction requires compatible Linux x86-64, GCC and process-local
LDT support. Original segment selectors and enumerated services are adapted;
original math, copies, daily economics, RNG and graph/report/history logic run.
The original graph's currency formatter and lower text/display services are
supplied, not qualified. The month-close mode stops at an explicit checked
boundary before loan handling; connected-month modes run complete daily calls.
The existing bridge is **not a sandbox for hostile inputs**.

Pinned input identities:

```
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT     5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153
```

The launcher verifies original identities before and after, compiles only in a
temporary directory, disables core dumps and refuses an existing output path.
`NATIVE-RUN.json` identifies sources/recordings; `static-bindings.json` separates
static callers from executed consumers. The comparison report retains the 76
month results. Generated game C is only a private inspection aid, not the tested
algorithm. No original executable, art, compiled probe or emulator state is
included in this packet. Prior E1-E28 counts and claims keep their scopes.

## 7. Remaining work

Trace all posting sites into these histories across transactions, refunds,
expenses and terminal paths, then compare the complete lab ledger across actual
multi-year day sequences and office releases. The new shift tests do not fill
that gap. Foreclosure/early-ending composition, original input/modal/media RNG,
continuous DOS startup/loading/endings and an earned winning route remain open.
No remote or debugger-release status was checked in this pass.
