# Live-DOS evidence and reproduction boundary

The focused drivers were actually run using the complete pinned 0.15 offline kit.
They are retained verbatim as task-local investigation scripts, not a portable
installer or independent game. Both import the real fDisBull package.

The expected task directory contains kits/fdisbull-linux-dos-offline-0.15.0-e91879c,
inputs/DinoParkTycoon-Research-Swift-2026-10-24/dinopark and live/game.fdb. live.py
copies the game, creates the project and consumes an append-only commands.jsonl.
Its native checkpoints are named in live/states.json. The focused drivers use
store-ready and ticket-base checkpoints created in that same private project.
The database and states are deliberately not shipped: their contents include
original game data. Recreate them using your separately owned original inputs.

exploratory-commands.jsonl records the actual investigation, including navigation
calibration and the abandoned mid-instruction breakpoint at 2b5d:043f. Do not
blindly replay it as a clean acceptance script or restart live.py against an
already-consumed append-only log. The accepted store_reentry.py uses the verified
2b5d:0440 boundary. The accepted ticket_grid.py rebuilds the actual office page
and delivers real clicks from calendar-edited native forks.

The clean day-level reproduction is independent of these checkpoints:
python3 ../reproduce.py /path/to/pinned/game --out [private-local-path]
It uses original instructions with the documented E30 adapters, not DOSBox.
Node tests replay its archived observations and the live-DOS control records.
