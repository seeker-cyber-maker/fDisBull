# DinoPark: live purchase transactions and quarterly ticket schedules

**26 October 2026 | Guide 0.2q / E31 | Algorithm Lab 0.7**

## Result and separate evidence tracks

This continuation uses the now-operational fDisBull 0.15.0 candidate, pinned to
e91879c, to boot the original game, load the supplied pmm park through its own
interface, navigate the office and General Store, deliver mouse clicks, inspect
memory and restore native checkpoints. No game code layer is enabled for these
experiments. Genuine rendering, generic hit testing, original scene loops and
confirmation dialogs execute in DOSBox, rather than supplied UI callbacks.

A separate three-scenario, two-year-per-scenario comparison runs the original
daily and quarterly instructions through the existing E30 LDT bridge. Those
long sequences retain E30's explicit presentation and year-end resume adapters.
They are not two-year continuous DOSBox playthroughs. Keeping these tracks
separate prevents a local GUI result from being mistaken for full-game parity.

Original files, production Swift, user Mac and remote repositories are unchanged.
The current package is Lab 0.7 and guide 0.2q; the debugger is a pinned 0.15
candidate, not a newly checked release. No independent reviewer or earned
winning route is claimed.

## 1. Ticket controls lock elapsed quarters

The supplied park loads in internal month 3, day 5, quarter 1: April of its first
year. The actual ticket page has Winter/Spring price labels but no corresponding
Less/More controls. Summer/Fall have controls. Its four prices initially read
[250,250,300,250] cents. A Summer More click changes only Summer to 350. Clicking
the absent Spring More position does nothing.

The original control builder at static 302C:224C, gate 22AC-22BD, implements:

```
enabled = target_quarter > current_quarter
       or (target_quarter == current_quarter and internal_day == 0)
```

The callbacks at 302C:28EF-2979 update the four 32-bit entries at DS:BFCB in
50-cent steps, with bounds 50 through 950 cents. Eligibility is enforced by
control registration, not by a universal check inside every price-writing
instruction. Lab's public ticketControl combines the UI gate and callback.
Addresses here are the established static labels, not raw runtime addresses.

Eight native checkpoint forks explicitly edit only quarter, month and day, with
expected-old-value checks. Four quarter starts are crossed with internal day 0
and day 5. The real page is rebuilt through Food/Visits tabs and all four More
and Less positions are clicked. All **64 control comparisons in eight scenarios**
match the gate. Money, holds, calendar and RNG stay unchanged across each tested
price-control interaction. These dates were constructed, not earned by playing.
The exact rule is internal day zero; elapsed real time or a universal mouse
opportunity at quarter rollover is not established by the constructed grid.

A separate live sweep makes eight Less clicks and twenty More clicks from
Summer 350, reaching 50 and then 950. Extra clicks at either end do not cross
the bound. The 28 observations are retained separately from the eight-scenario
regression count. Leaving the ledger and office preserves the edited schedule.
After April resumes and reaches day 8, the cached attendance price is still
Spring's 250, while Summer remains 950. Editing a future quarter does not replace
the current quarter's admission rate.

## 2. A real gift-stand purchase is staged, then committed

The tested General Store checkpoint has 10,781 in both cash balances, no gift
stands and no entry in the current month's capital/fee slot. It comes from the
supplied park after normal boot/load/navigation; no cash or inventory edits are
made in this route. The original parking-advice modal encountered during
navigation is dismissed through its visible control.

Two fresh emulator processes restore that same checkpoint. Both select Gift
Stand and click BUY; one confirms the order, the other clicks Cancel and confirms
cancellation in the real modal. Observations at the street cash-sync boundary
use the verified instruction breakpoint 2B5D:0440 before another simulated day.

| Boundary | Committed | Working | Live gift stands | Pending gift stands | New fee entry |
|---|---:|---:|---:|---:|---:|
| Initial | 10,781 | 10,781 | 0 | 0 | 0 |
| After BUY | 10,781 | 3,281 | 0 | 1 | 0 |
| Confirm, then street cash sync | 3,281 | 3,281 | 1 | 1 | 7,500 |
| Cancel accepted, then street cash sync | 10,781 | 10,781 | 0 | 1 | 0 |

The pending stand after cancellation is stale order state, not an owned asset.
Reentering the store performs the full synchronization and changes pending gift
count back to zero on the cancelled branch. The confirmed branch retains one.
No second expense is posted. Reentry allows a normal additional day, so balances
at those later snapshots are 3,686 and 11,186 respectively, not the earlier
street-boundary balances. Each branch has five recorded checkpoints.

In a separately recorded exploratory sequence, declining the cancellation
modal keeps the pending order and working debit. Accepting cancellation requests
exit without immediately clearing all pending fields. It is incorrect to model
Cancel as instant wholesale zeroing of scratch state. Conversely, observing a
nonzero pending stand after Cancel does not establish a free-purchase bug.

These live results qualify the gift-stand selection/BUY/confirm/cancel/reentry
route. They do not qualify all land, fence, animal placement or undo controls.
The lab did not gain a complete General Store scene in this turn.

## 3. Schedule selection through two years of original daily processing

Three constructed parks use explicit schedules and seeds:

| Profile, cents per quarter | Seed | Original days | Compared checkpoints |
|---|---:|---:|---:|
| [50,250,500,950] | 1 | 730 | 740 |
| [950,500,250,50] | 17 | 730 | 740 |
| [250,250,300,250] | 123 | 730 | 740 |

The original instructions select each quarter's price and retain the schedule
across annual rollover. The JS comparison checks daily/quarter/resume state,
cash, debt, staff, food, herd, event state, original RNG state/draw count and all
900 financial-history elements. All **2,220 checkpoints** match. This catches
wrong-quarter revenue or month-close stored-price errors that isolated price
button tests cannot establish.

These parks start with 4,000,000 cash and explicit assets/stocks to exercise
rollovers, not to demonstrate a viable strategy. Their final cash values are
2,381,773; 2,404,436; and 2,387,340. They are test observations only. Scene/media
RNG is not injected into these day-level runs. Annual continuation retains the
E30 original street-release slice and explicit notice/context bookkeeping.

The native launcher pins EXE/VARS, compiles an authored bridge in a temporary
directory, executes original game instructions and checks the inputs afterward.
A second fresh build reproduced cases.json, input.tsv and observed.jsonl hashes.
That repetition does not create more native cases or an independent review.

## 4. Lab 0.7: explicit original schedule or flat diagnostic mode

New optional state: ticketSchedule, either null or four 50-cent-stepped prices
within 50..950 cents. A scheduled day selects the current quarter's entry before
attendance. The scalar ticket remains the cached applied price; it is not a
substitute for the four-entry schedule.

The browser has a four-quarter editor and per-quarter Less/More controls. Setting
all four entries is explicitly labelled fixture configuration, not a claim that
the original player can rewrite locked quarters. The controls use the native gate.

Existing flat-price scenarios remain flat by default. Loading an older snapshot
does not invent a missing historical schedule. Explicit Flat mode retains the
current quarter price and resumes diagnostic scalar control. Old action replays
remain version-bound; keep Lab 0.6 for them. The new browser-recorded quarterly
example replays in Node to an identical final snapshot.

No original scene timings, artwork, audio or whole-shop behavior were added to
the browser. The price-control kernel is not an office-enter/exit simulator.
Full-game equivalence still requires the missing scene/media dependencies.

## 5. Verification, navigation calibration and limits

| Check | Result |
|---|---:|
| New day-level native scenarios / checkpoints | 3 / 2,220 |
| New original-DOS calendar scenarios / control snapshots | 8 / 64 |
| Matched live store branches / snapshots | 2 / 10 |
| Additional live ticket-bound sweep observations | 28 |
| Full JS recorded comparison corpus | 186,230 cases / 213,292 snapshots / 59 suites |
| Compared-field mismatches | 0 |
| Separate JS unit/integration checks | 174 passed |
| Browser application checks in this pass | 18 passed |
| Browser inherited recorded sample | 1,432 passed |
| Browser comparison of the new control snapshots | 64 passed |

The two new JS suites add 11 cases and 2,284 snapshots to the inherited corpus.
Store branches and exploratory/boundary navigation are separate acceptance
observations, not silently folded into that total. Browser samples replay
existing native observations and are not additional native executions.

The accepted scripts were refined after exploratory navigation. An early 350 ms
page transition had not reached the expected page; the final grid waits 1,200 ms.
An early 2B5D:043F breakpoint request was inside an instruction and did not establish
the desired stop. Disassembly identified 0440, and the final store comparisons
require that actual breakpoint. Neither setup mistake is a game defect, and
neither failed exploratory stop is counted as accepted boundary evidence.

The installed fDisBull candidate's comparison-shape hardening remains absent.
This work does not rely on compare_trials silently declaring equality: explicit
control counts/identities, state assertions and independent JS comparison are
used. Native state CRCs and the original/working file trees are audited separately.
Native checkpoints and databases remain private and are not shipped.

Original input identities:
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT 5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153

## 6. Remaining work

Continue remaining land/fence/DinoMart selection, undo and placement posting;
foreclosure/early-ending composition; original complete auction/input timing;
then an earned route and actual DOS ending/save/score persistence. The new UI
checks do not close all terminal or media behavior, and the long native sequences
are still not continuous DOS play. Graphics reconstruction remains deferred.
