# DinoPark JavaScript Lab 0.1: validation receipt

## Delivered application

A self-contained browser workbench and the same algorithm core under Node. Based on research checkpoint 0.2k. No production Swift, original game files or remote repository was changed.

## Executed checks

| Check | Result |
|---|---:|
| Archived native-input cases replayed by JavaScript | 146,488 |
| Archived observation snapshots compared | 152,536 |
| Differential suites | 21 |
| Mismatches in compared fields | 0 |
| Separate unit/specification/integration checks | 70 passed, 0 failed |
| Browser subset of recorded-native cases | 664 passed |
| Browser application checks | 13 passed, 0 failed |

Node runtime: v22.16.0. Source hashes and exact per-suite results are in `results/test-report.json`. Fixture provenance, copied source paths and content hashes are in `fixtures/manifest.json`. The browser build is bound by SHA-256 in `results/browser-smoke.json`.

**These are JavaScript comparisons with archived original-instruction results, not new original-DOS executions.** Complete rows are checked for payroll/survival and other suites; selected financial columns are checked for bank and auction kernels. Exact field coverage is documented, rather than inferred from the number of cases.

## Application acceptance

The standalone HTML was executed in Chromium. Checks covered stepping and policy controls, pause/resume, native-fixture comparisons, the loan rule bench, invalid-state rejection, snapshot download/reload, browser-to-Node replay equality, mobile document width, JavaScript errors and HTTP requests. No HTTP requests or script errors were observed.

The managed Chromium installation blocked `file:` navigation. Acceptance therefore loaded the actual standalone HTML bytes with Playwright `set_content`. A double-click file launch, Safari and Firefox were not independently qualified in this environment. The app has no external scripts/assets and requires no server by design.

## Integrated simulation smoke results

These results are observations of **authored fixtures in the experimental composition**, not original-game balance evidence or winning strategies:

| Fixture | Seed | Completed days | Ending cash | Animals |
|---|---:|---:|---:|---:|
| lean-90 | 1 | 90 | $76,320 | 1 |
| concessions-365 | 17 | 365 | $142,802 | 1 |
| risk-365 | 1 | 365 | $47,997 | 0 |
| loan-tail | 1 | 1 | $835 | 0 |

## Main open boundary

Attendance/concession examples and routine-level parity do not establish complete day/quarter or scene-level equivalence. Original bank/menu/animation RNG draws, sound completion, physical input, complete auctions, original sale eligibility and binary save formats remain outside this prototype. The pure core and explicit event stream allow these dependencies to be added without putting simulation state inside a renderer.

The safety-oriented JSON importer and bounded diagnostic for a known nonterminating scan are deliberate differences from the unsafe original paths. No fake original graphics, sound output or complete-game acceptance is claimed.
