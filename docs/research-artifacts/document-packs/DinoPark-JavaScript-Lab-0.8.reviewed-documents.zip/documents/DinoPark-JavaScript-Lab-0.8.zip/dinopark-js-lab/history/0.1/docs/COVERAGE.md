# Coverage and fidelity boundaries

## Recorded-native differential corpus

The source of observations is `DinoPark-Scene-Integration-0.2k.zip`. Its bundled historical probes executed original 16-bit instructions with declared adapters. This implementation does **not** rerun those probes; it compares JavaScript output with their immutable archived observations. The exact copied paths, byte hashes, input counts and row multipliers are in `fixtures/manifest.json`.

Original build identities:

```text
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT     5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153
```

| Kernel / suite | Fields compared with native recordings | Exclusions |
|---|---|---|
| Payroll | Both cash accounts, absence timer, number of dismissal messages, total paid, all active/pending role counts | Rendered messages, parent day and actual menu calls |
| Breeding | Draw count, RNG state where actual RNG was used, birth count, all new and original herd counts | Annual caller, UI acquisition of large herds, rendered announcements |
| Escapes / maintenance | Tally, draw count/state, all message IDs, every live/pending species/count/fence/electric field | Complete daily/quarter integration or rendering |
| Feeding / predation / mortality | All 86 recorded fields: food, pending food, hunger, mask, overeat, RNG draws, message ID/count, target/attacker marker, redraw count and live/pending herd | Actual resource redraw; endless empty-herd case intentionally replaced with a diagnostic |
| Credit / scheduled payment | Exact helper result | Full bank scene |
| Bank callbacks | Committed cash, working cash and debt | Native hover, message formatting, button availability and scene routing fields |
| Automatic loan block | Both cash accounts, debt, installment and foreclosure branch | Original ending, dialog and monthly income-history buffer |
| Auction bid | Computed next bid | NPC competition, animation, countdown or player-input acceptance |
| Auction settlement | Both balances, paid amount, credited amount | Hammer presentation, subsequent placement and ledger history |
| Staged food purchase | Five complete 26-field snapshots per sequence | Actual input timing, resource and display services |

Cases are not independent complete games. Some grids deliberately use synthetic catalogue-only species, large counts, unusual cash/pending differences or otherwise non-UI-reachable states. The validated domain is the provided corpus, not every integer representable in JavaScript. The original probes' adapters remain a limit on those observations. This implementation and its test adapters were written within the same investigation, not an independent second team's audit.

## Additional implementations

**Attendance:** compound capacity, parking reach, four advertisements, average pen grade, admission bands, terrain/season, guide/security, hunger, closed/no-staff gates and first-year boost. Checked against selected inherited arithmetic examples and the saved pmm fixture's reported attendance. This package does not contain an exhaustive native attendance corpus.

**Concessions:** operator allocation, separate food/gift draws, the 400-visitors discontinuity, capped rates, gross-before-cost truncation and inspection accounting flag. Checked against selected inherited examples with their explicit random residues. The earlier 5,760-case native receipt is not counted as a fresh JS replay: its complete per-case outputs are not in this new corpus. The lab uses the original RNG, not the old Swift SplitMix generator; the inherited expected examples are run using exact controlled residues rather than copying seed labels across generators.

**Monthly inventory, weekly events, other visitor-status branches, illness, management, sale valuation and their composition:** source/guide-derived implementation with selected unit checks. They require broader archived-native differential coverage before being described like the suites above. The event lottery retains shifted masks and consumes randomness explicitly. Names and trace labels are authored explanations, not original symbols.

## Integrated runner: known gaps and simplifying decisions

- Uses a fixed logical 20-iteration day threshold by default, with counted holds and deferred quarter dispatch. Its scene context is a modeled field, not an executing original scene router. No wall-clock rate is claimed.
- The main simulation path connects attendance, concessions, monthly inventory/loan, weekly payroll/feeding/status/events/escape/predation, quarter resets and annual breeding. The full composed state and RNG sequence have not been compared against a continuous original run.
- Original bank visitors, common scene setup, Diner/auction callbacks and other media-driven RNG consumers are absent. Animation/sound/music options are preserved session fields; changing them currently does not execute those omitted callbacks.
- Physical clicks, exact GUI control enablement, staged shop lifecycle, original title/demo playback, official starting-park construction and complete shop/land/dinosaur acquisition are not implemented. Direct staff/food/ticket actions and the JSON fixture editor support experiments; they are explicitly policy-level actions, not recovered navigation.
- Seller marks and remainder-settlement arithmetic are modeled. Complete animated NPC bidding, placement UI and zero-cash exit fault are not reproduced in the integrated runner. Isolated bid/settlement kernels can be tested independently.
- Park valuation and ranking are callable kernels. The runner's `sellPark` is explicitly confirmed but does not enforce original sale-button eligibility or render/write the original ending/leaderboard.
- Tracks useful summary metrics, not all original signed-width financial history buffers or complete annual accounts. Any conclusion about profit-history-based downstream behavior remains out of scope.
- The auction-availability countdown is retained, but expiration/entry routing is not a complete original auction lifecycle. `settleOffers` is an explicit caller action.
- Snapshots use validated lab JSON. No binary save importer/exporter, DOS errors, native file-buffer behavior or short-read vulnerabilities are emulated.
- Imported playable fixtures exclude Vegasaurus ownership; low-level kernels accept the catalogue-only synthetic controls used by the archived research tests.

## Arithmetic and safety

The original random primitive uses `Math.imul(state, 0x015A4E35) + 1` modulo 2^32, then `(state >>> 16) & 0x7fff`. Seed initialization can truncate to 16 bits through the explicit `seed()` method; a complete snapshot can restore all 32 state bits. Controlled tapes carry raw random returns, not a second generator.

Explicit signed/unsigned word operations are used where recovered boundaries require them. JavaScript Number is exact for the ordinary-domain products exercised here. This is not a general proof of faithful 16/32-bit wraparound on every absurd state; unsupported extreme domains should receive native fixtures before acceptance.

Importer validation, input/run budgets, renderer-exception isolation and the bounded mortality scan are deliberate lab safety boundaries. They are not presented as original game behavior. Original financial quirks remain available in the kernels, including strict payroll affordability, final-payment overcharge and staged-food accounting wraparound.

## Claims that passing does not support

No winning strategy has been verified; no general DOS or Mac port has been certified; no frame/audio parity has been established; no independent review has happened; no percentage of binary coverage follows from the case count; no original-code execution occurred during this JavaScript implementation pass.
