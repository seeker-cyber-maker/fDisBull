# Resume: guide 0.2q / E31, Algorithm Lab 0.7

26 October 2026. Algorithms first. No original files, production Swift, user Mac
or remote repository changes. No new debugger-release check. fDisBull0.15 candidate
at e91879c is operational locally with the genuine supplied offline kit.

Current task environment: [private-local-path]; backend under
kits/fdisbull-linux-dos-offline-0.15.0-e91879c/backend/linux-amd64/dosbox-x-offline.
Private working game/project/checkpoints are in [private-local-path]
A future session may need extraction/reinstallation; do not assume these survive.
No private database/state/input contents are included in this evidence packet.

Read live-tickets/REPORT.md in the guide docs or native-ticket/REPORT.md in Lab0.7.
The live subdirectory contains safe selected observations, scripts and screenshots.
Drivers are task-local and need the separately recreated private checkpoints;
read REPRODUCTION.md rather than blindly replaying the exploratory commands.

New results:
- Ticket UI enables target>current quarter, or target==current and internal day0.
  Eight explicit calendar forks,64 real mouse-control comparisons pass. Actual
  April future-price edit persists; current Spring attendance stays250 cents.
  Additional28 live controls verify50..950-cent bounds in50-cent steps.
- Gift BUY stages7500 and pending stand, not committed cash/history. Confirm
  commits; accepted Cancel leaves committed fields unchanged. Street prefix at
  valid instruction2B5D:0440 syncs working cash, but stale pending stand clears
  only at full store resync/reentry. Two fresh-process routes/10 snapshots pass.
- Three730-day original-instruction sequences verify varying quarterly prices,
  all900 histories, economy and RNG. They use E30 annual-resume adapters, not DOS
  media/physical input. Startingcash4million is explicit fixture, not earned.
- Lab0.7 schedule is opt-in; flat diagnostic pricing remains separate. Do not
  invent missing historical schedules. Keep0.6 for old action replays.

Full Node186230cases/213292snapshots/59suites,zero mismatches;174unit checks.
Browser18 new app checks,1432 inherited samples and64 recorded live-control
snapshots pass. Samples/repeats are not new native cases or independent review.

Next: remaining land/fence/DinoMart full selection/undo/placement accounting,
foreclosure/terminal composition, complete scene/media RNG and an earned DOS
winning route with actual displayed ending and saved score. No rebalance or
hardware rewrite. Peanut/fly remain documented, not added to Swift.
