# DinoPark Algorithm Lab 0.7

Offline browser workbench and dependency-free Node runner. Guide 0.2q / E31.
Open DinoPark-Algorithm-Lab.html. No original artwork, network, account or login.

```sh
node cli.cjs test
node cli.cjs simulate --preset concessions --seed 1 --days 90 --out results/run.json
node cli.cjs replay examples/quarterly-ticket-replay.json
node cli.cjs serve
```

## Quarterly schedules

The Simulation controls now offer an opt-in four-quarter ticket schedule.
The four-value editor creates an explicitly authored scenario. Less/More uses
the original UI rule: future quarters editable; current quarter only at internal
day zero; past quarters locked. Prices move by 50 cents within 50..950.
Default presets retain flat diagnostic pricing. Missing historical schedules
are not inferred on import. Flat mode is an explicit switch, not a silent reset.

Original DOS rendering/hit-testing confirmed eight calendar-fork scenarios and
64 control clicks. Three separately constructed two-year original-instruction
runs verify schedule selection with every financial-history field and the RNG.
See native-ticket/REPORT.md for the separate live-DOS and day-level scopes.
The General Store gift confirmation/cancellation route now has live-DOS evidence,
but this lab still does not implement that entire scene or every shop action.

## Financial histories and validation

The Financial history tab retains 15-by-60 original-shaped buffers, distinctions
between unknown/unavailable and zero, and the original reporting quirks. See
native-ledger/REPORT.md for inherited six-year and transaction scope.

Full regression: 186,230 recorded cases / 213,292 snapshots / 59 suites, zero
compared-field mismatches. 174 unit/integration checks. Browser: 18 new application
checks, 1,432 inherited sampled cases and 64 new recorded control snapshots.
Counts do not establish independent review, earned strategies or full-game parity.

## Compatibility and remaining scope

No npm install. Browser and Node share src/core.js. Keep Lab 0.6 for its old
version-bound action replays. Compatible economic snapshots may continue, but
missing histories remain unavailable and an absent schedule remains flat.
Old required-finance-baseline validation still applies. Unknown original
concession locals remain marked; unreliable reports are not invented.

Original scene/media RNG, complete shop/placement and terminal interactions
remain open. The UI is a diagnostic workbench, not original artwork.
The DOS evidence used the real pinned fDisBull 0.15 candidate; the day-level
reproduction requires Linux x86-64/GCC/LDT and separately owned original inputs.
The instruction bridge is not a safe executor for arbitrary binaries.
