# Coverage and fidelity boundaries

## Recorded-native differential corpus

The inherited source of observations is `DinoPark-Scene-Integration-0.2k.zip`. New E26, E27 and E28 recordings are separately identified in the manifest. Its bundled historical probes executed original 16-bit instructions with declared adapters. This implementation does **not** rerun those probes; it compares JavaScript output with their immutable archived observations. The exact copied paths, byte hashes, input counts and row multipliers are in `fixtures/manifest.json`.

Original build identities:

```text
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT     5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153
```

| Kernel / suite | Fields compared with native recordings | Exclusions |
|---|---|---|
| Payroll | Both cash accounts, absence timer, number of dismissal messages, total paid, all active/pending role counts | Rendered messages, parent day and actual menu calls |
| Breeding | Draw count, RNG state where actual RNG was used, birth count, all new and original herd counts | Annual caller, UI acquisition of large herds, rendered announcements |
| Escapes / maintenance | Tally, draw count/state, all message IDs, every live/pending species/count/fence/electric field | Complete daily/quarter integration or rendering |
| Feeding / predation / mortality | All 86 recorded fields: food, pending food, hunger, mask, overeat, RNG draws, message ID/count, target/attacker marker, redraw count and live/pending herd | Actual resource redraw; endless empty-herd case intentionally replaced with a diagnostic |
| Credit / scheduled payment | Exact helper result | Full bank scene |
| Bank callbacks | Committed cash, working cash and debt | Native hover, message formatting, button availability and scene routing fields |
| Automatic loan block | Both cash accounts, debt, installment and foreclosure branch | Original ending, dialog and monthly income-history buffer |
| Auction bid | Computed next bid | NPC competition, animation, countdown or player-input acceptance |
| Auction settlement | Both balances, paid amount, credited amount | Hammer presentation, subsequent placement and ledger history |
| Staged food purchase | Five complete 26-field snapshots per sequence | Actual input timing, resource and display services |

Cases are not independent complete games. Some grids deliberately use synthetic catalogue-only species, large counts, unusual cash/pending differences or otherwise non-UI-reachable states. The validated domain is the provided corpus, not every integer representable in JavaScript. The original probes' adapters remain a limit on those observations. This implementation and its test adapters were written within the same investigation, not an independent second team's audit.

## E26 fresh native comparisons, replayed by the lab

Attendance: 5,144 cases compare visitors, both admission cash deltas, monthly
visitor accumulation and RNG draw/state. Concessions: 7,360 cases compare both
cash deltas, recorded food/gift gross/cost, service loads and RNG. With zero
operators, uninitialized food/gift locals are explicitly excluded; their observed
zeroed-stack values are not treated as a rule.

Monthly inventory: 2,543 cases compare nine live and nine pending stock words,
including 36 labelled synthetic signed-width controls. Weekly events: 8,704 cases
compare cash, event mask, inspection/countdown, message IDs, RNG and live/pending
herd. Two detailed financial-history buckets are recorded but not implemented
or compared by JS. Native results, commands and sources are in `native/`.

The connected daily prefix contains 96 eight-update sequences (768 snapshots)
through original countdown, date, attendance and concession instructions. It stops
before monthly/weekly work, so is not a full daily or earned-route qualification.
Original objects and specified adapters, not the JS model, generated these values.

These historical E26 tests did not qualify illness, management or whole-day composition; later sections describe E27/E28 additions. Sale valuation remains a separate kernel scope. See `native/REPORT.md` for exact
fields, limits and the two corrected lab defects.

## E27 staffing, status and quarter-boundary comparisons

See `../native-staff/REPORT.md` for exact addresses, adapters, reproduction and
native-field definitions. 13,320 new cases/sequences, 14,184 snapshots:

| Component | Cases | Compared fields and exclusions |
|---|---:|---|
| Illness and return | 2,824 | Progression, timer/category, changed flag, live/pending staff, messages, RNG |
| Quarter management | 3,392 | Incremented stored progression, previous-three-month sum, live/pending staff, messages, RNG |
| Visitor status | 4,608 | Mask, messages, all live/pending food and herd fields, RNG; no empty-herd native nontermination |
| Illness/revenue sequence | 96 x 10 snapshots | Prefix through attendance/concessions, absent/returning workers, closure/inspection, finances, visitors, RNG; stops before full daily tail |
| Day/quarter boundary | 2,400 | Progression, calendar, holds/phase/pending, absence, balances/debt, active staff; native economics have declared call-recording substitutes and RNG is not compared |

Lab 0.2 fails 56 boundary fixtures. Lab 0.3 preserves the daily progression
cache and increments it on actual quarter processing rather than recomputing
it after rollover and loan payment. This is scoped connected evidence, not a
complete-day or full-economy qualification.

## Integrated runner: known gaps and simplifying decisions

- Uses a fixed logical 20-iteration day threshold by default, with counted holds and deferred quarter dispatch. Its scene context is a modeled field, not an executing original scene router. No wall-clock rate is claimed.
- The main simulation path connects attendance, concessions, monthly inventory/loan, weekly payroll/feeding/status/events/escape/predation, quarter resets and annual breeding. E28 now compares705 bounded day-level native scenarios with original economic subroutines and full RNG. It is not continuous scene execution or all-state coverage.
- Original bank visitors, common scene setup, Diner/auction callbacks and other media-driven RNG consumers are absent. Animation/sound/music options are preserved session fields; changing them currently does not execute those omitted callbacks.
- Physical clicks, exact GUI control enablement, staged shop lifecycle, original title/demo playback, official starting-park construction and complete shop/land/dinosaur acquisition are not implemented. Direct staff/food/ticket actions and the JSON fixture editor support experiments; they are explicitly policy-level actions, not recovered navigation.
- Seller marks and remainder-settlement arithmetic are modeled. Complete animated NPC bidding, placement UI and zero-cash exit fault are not reproduced in the integrated runner. Isolated bid/settlement kernels can be tested independently.
- Park valuation and ranking are callable kernels. The runner's `sellPark` is explicitly confirmed but does not enforce original sale-button eligibility or render/write the original ending/leaderboard.
- Tracks useful summary metrics, not all original signed-width financial history buffers or complete annual accounts. E28 adds the actual annual cash-growth charge and its baseline, not all ledger arrays. Any conclusion about profit-history-based downstream behavior remains out of scope.
- The auction-availability countdown is retained, but expiration/entry routing is not a complete original auction lifecycle. `settleOffers` is an explicit caller action.
- Snapshots use validated lab JSON. No binary save importer/exporter, DOS errors, native file-buffer behavior or short-read vulnerabilities are emulated.
- Imported playable fixtures exclude Vegasaurus ownership; low-level kernels accept the catalogue-only synthetic controls used by the archived research tests.

## Arithmetic and safety

The original random primitive uses `Math.imul(state, 0x015A4E35) + 1` modulo 2^32, then `(state >>> 16) & 0x7fff`. Seed initialization can truncate to 16 bits through the explicit `seed()` method; a complete snapshot can restore all 32 state bits. Controlled tapes carry raw random returns, not a second generator.

Explicit signed/unsigned word operations are used where recovered boundaries require them. JavaScript Number is exact for the ordinary-domain products exercised here. This is not a general proof of faithful 16/32-bit wraparound on every absurd state; unsupported extreme domains should receive native fixtures before acceptance.

Importer validation, input/run budgets, renderer-exception isolation and the bounded mortality scan are deliberate lab safety boundaries. They are not presented as original game behavior. Original financial quirks remain available in the kernels, including strict payroll affordability, final-payment overcharge and staged-food accounting wraparound.

## Claims that passing does not support

No winning strategy has been verified; no general DOS or Mac port has been certified; no frame/audio parity has been established; no independent review has happened; no percentage of binary coverage follows from the case count; the E26/E27/E28 native runs are bounded and separate from the Node/browser replays, not full-game execution.

## E28 connected complete daily and optional quarter routines

705 scenarios,2874 snapshots in8 suites compare money, debt, staff, food, herd,
masks, counters, calendar, holds, pending quarter, cached progression, cash
baselines, monthly cash change, maintenance count, seller flags and full original
RNG. Warning129 and annual notice161 are checked. Source/corpus details are in
../native-day/REPORT.md. The JavaScript independently dispatches its days/quarters;
it is not told which stage to run by native observations.

Physical common-loop delivery, scene/media calls, whole history buffers and earned
acquisition are not covered. Native fixtures run at most21days; annual cases stop
on the year-end hold. Complete multi-year trajectories are unqualified. Known
empty-herd mortality nontermination is guarded, and early endings fail explicitly.

The old E27 annual call was a recorder. Its comparator selects a no-tax baseline
when using the current core, without modifying native records or claiming an
annual-tax test. E28 supplies the newly executed original annual handler.

## E29 reporting/history extension (Lab0.5)

financialSummary, monthlyGraph and rollFinancialYear have explicit native
consumer/shift comparisons.76 connected January runs compare visitors/cash/RNG
per day and original summary values at the end. **Not all history postings are
integrated into Engine.** 840 original graph cases capture high-level line
requests using supplied rectangle/font/text/display adapters, not original pixels.
CA8B is retained by address rather than inventing a meaning. See native-finance.
