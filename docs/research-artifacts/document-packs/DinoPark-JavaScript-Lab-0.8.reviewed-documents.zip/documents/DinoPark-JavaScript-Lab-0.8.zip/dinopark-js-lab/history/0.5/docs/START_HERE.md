# Resume: Lab 0.5 / guide 0.2o / E29

Read `native-finance/REPORT.md`, its `results/NATIVE-RUN.json`, and
`results/finance-comparison.json`. Use `node cli.cjs test` and `node tools/build.cjs`.
Original files, Swift and remotes remain unchanged; fDisBull is not credited here.

New original execution: 1,180 cases/sequences, 3,656 checkpoints, seven suites.
Ticket page graph reads completed-month visitors, not dollar income or 6FBC cash
change. Food/gift graphs use net. Five year slots, completed months only in the
current line; deselected history still determines the scale. Line requests and
palette indices are captured with a supplied rectangle/font, not rendered DOS.

Native original 31-day January plus original financial summary: 76 scenarios
cover four seeds and all19 normal prices. Whole-dollar36 controls agree; half-
dollar40 cases overreport ticket income by2..13 because monthly rounding differs
from daily cash. Seed1/$2.50:2411 visitors,6014 cash receipts,900payroll,10114cash,
5114 cash-change report versus6027 income/5127 profit. No extra cash or tax change.

Original annual accounting shifts all15 arrays with unique sentinels over1/2/5/6
calls. Tax posts at month0 before shifting, ending in previous-year January fees.
These are not multi-year earned parks. CA8B's meaning is still explicit unknown.

New `financialSummary`, `monthlyGraph`, `rollFinancialYear` kernels use explicit
history arrays. **Engine does not yet populate the full history from all actions.**
Existing cash chart is not the original ticket graph. The monochrome line preview
is diagnostic, not original graphics. Daily engine economics are unchanged.
Old replay versions reject; preserve original labs for old replay trajectories.

Next: ledger posting sites/complete multi-year day and office-release sequences,
terminal/foreclosure flows, then actual original DOS input/modal/media timing and
an earned route. Preserve all previous scope qualifications and held-RNG findings.
