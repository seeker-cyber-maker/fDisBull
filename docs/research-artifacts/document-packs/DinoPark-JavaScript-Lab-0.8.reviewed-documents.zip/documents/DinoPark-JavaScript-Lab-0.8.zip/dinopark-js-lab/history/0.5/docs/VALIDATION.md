# DinoPark Algorithm Lab0.5: validation receipt

25 October2026. Guide0.2o / E29. Original game, Swift and remotes unchanged.

| Check | Result |
|---|---:|
| New original-instruction cases/sequences | 1,180 |
| New recorded checkpoints | 3,656 |
| New suites | 7 |
| Compared-field mismatches | 0 |
| Combined recorded-native cases | 185,540 |
| Combined recorded checkpoints | 197,769 |
| Combined suites | 52 |
| Unit/specification/integration checks | 137 passed |
| Browser recorded-native subset | 1,432 passed |
| Browser application checks | 27 passed |
| Fresh native recording identities reproduced | 6 of6 |

Native E29 executes original x86-16 instructions with the inherited process-local
LDT bridge. Node and browser replay observations; they do not execute DOS. The
browser1432-case subset is inherited sampling, not an E29-native rerun. Five new
browser application checks exercise the summary, rollover, graph selection,
diagnostic preview and invalid-history rejection. All27 application checks pass.
Chromium used the actual standalone bytes via Playwright set_content. NoHTTP
requests or script errors occurred. File-URL double-click, Safari and Firefox
are not newly qualified. Screenshots and app hash are in results/browser-smoke.json.

## What the new comparisons establish

840 graph fixtures compare original line-request geometry/palette indices with
supplied rectangle/fonts/output.180 summary fixtures compare income/expenses/
profit.48 annual sequences produce168 full history snapshots.36 month-close
slices test visitor/price storage and cash baseline.76 January sequences record
31 daily cash/visitor/RNG checkpoints plus the original financial summary each.
Whole-dollar36 controls agree; half-dollar40 fixtures overreport ticket income
by2..13 through monthly versus daily integer rounding. This is original report
behavior, not extra cash or a new correction to the daily simulation.

The full original finance consumers and all15 annual shifts are checked, but not
all transaction posting sites or continuous multi-year ledger behavior. The new
reporting kernels consume explicit histories; Engine does not invent those
arrays from its aggregate metrics. No original artwork/palette rendering,
physical input, independent review, complete original parity or earned win.

## Reproduction and compatibility

`node cli.cjs test` and `node tools/build.cjs` require no npm dependencies.
Native reproduction needs pinned original EXE/VARS, Linux x86-64, GCC and LDT.
`native-finance/reproduce.py GAME --out NEW_DIRECTORY` recompiles temporarily and
checks inputs before/after. A fresh build reproduced all six input/observation
identities; repetition is not extra cases or independent review. The bridge is
not a sandbox for hostile code. Original inputs and compiled probes are excluded.

Daily economics stay as in0.4. Old replays remain explicitly version-bound;
keep their matching lab. Ordinary snapshots keep the existing strict finance-
baseline/cache checks. No missing transaction history is backfilled or guessed.
