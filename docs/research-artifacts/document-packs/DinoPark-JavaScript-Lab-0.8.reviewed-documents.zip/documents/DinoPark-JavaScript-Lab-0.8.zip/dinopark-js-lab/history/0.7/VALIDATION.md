# DinoPark Algorithm Lab 0.7: validation receipt

26 October 2026. Guide 0.2q / E31. No production Swift, original inputs or remote changes.

| Check | Result |
|---|---:|
| Combined recorded cases | 186,230 |
| Combined recorded snapshots | 213,292 |
| Differential suites | 59 |
| Compared-field mismatches | 0 |
| Unit/integration checks | 174 passed |
| Browser application checks in this pass | 18 passed |
| Browser inherited recorded sample | 1,432 passed |
| Browser new recorded control snapshots | 64 passed |

The two new differential suites comprise 3 original-instruction two-year scenarios
with 2,220 snapshots and 8 real-DOS calendar-control scenarios with 64 snapshots.
The 10 live store checkpoints and extra price-bound sweep are separate research
evidence, not included again in the Node corpus. Browser samples replay archived
observations and are not additional original executions.

Original DOS evidence uses pinned fDisBull 0.15/e91879c and its corrected private
Linux DOSBox. Original day-level evidence uses the inherited LDT bridge with
explicit E30 year-end resume/presentation adapters. No complete DOS playthrough,
earned strategy, independent review or media-equivalent browser is implied.

The native recordings reproduced byte-for-byte from a fresh temporary build.
Chromium /usr/bin/chromium executed the standalone HTML with set_content. No
script error or HTTP request occurred. Browser replay matches Node's final
snapshot exactly; snapshot import and invalid-schedule atomic rejection passed.
Direct file-URL launch, Safari and Firefox are not newly qualified.

Keep Lab0.6 for old action replays. Null/missing schedules remain diagnostic flat
mode. No historical prices or missing financial histories are fabricated.
