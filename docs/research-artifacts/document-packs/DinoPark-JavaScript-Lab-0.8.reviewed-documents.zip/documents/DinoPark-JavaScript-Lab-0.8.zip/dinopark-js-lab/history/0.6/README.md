# DinoPark Algorithm Lab 0.6

Offline browser workbench and dependency-free Node runner. Guide 0.2p / E30.
Open `DinoPark-Algorithm-Lab.html`. No original artwork, network or login.

```sh
node cli.cjs test
node cli.cjs simulate --preset concessions --seed 1 --days 90 --out results/run.json
node cli.cjs replay examples/lean-replay.json
node cli.cjs serve
```

## Integrated financial histories

The new Financial history tab consumes the Engine's live 15-by-60 buffers.
It reports income/expenses and original-style visitor/concession graph geometry,
exports the buffers, and distinguishes unknown or unavailable data from zero.
Daily/quarter posting is compared against original instructions in 112 scenarios
including four six-year constructed runs. Another 567 food/store cases test
posting destinations and commit/cancel boundaries. See `native-ledger/REPORT.md`.

The original's December-31 payday can post into a two-years-back January slot.
This is retained as reporting behavior, not corrected or charged twice. C03B is
food/plant purchases; C12B advertising; CA8B active operators. The previous
semantic labels are superseded, while historical observations remain preserved.

Full regression: 186,219 cases / 211,008 snapshots / 57 suites, no field mismatches.
159 unit/integration checks; 1,432 sampled browser cases; 36 application checks.
These are not independent reviews, complete DOS sessions or earned strategies.

## Compatibility

No npm install. Browser and Node share `src/core.js`. Keep Lab 0.5 for old replay
files. Old economic snapshots with valid required baselines may continue, but
missing financial histories stay unavailable; no historical backfill is invented.
Explicit obsolete report-key names reject rather than being silently relabelled.
Unknown original concession locals are marked, and unreliable plots are withheld.

The original scene, media RNG, physical input, full shop interactions, quarterly
price schedules and terminal paths still require further integration. The UI is
a diagnostic workbench, not original artwork. `docs/MISSING.json` tracks scope.
Native reproduction needs the separately owned original EXE/VARS and compatible
Linux x86-64/GCC/LDT; the supplied bridge is not a sandbox for untrusted code.
