# Algorithm Lab 0.6 validation receipt

25 October 2026. Guide 0.2p / E30. No original game, production Swift or remote changes.

| Check | Result |
|---|---:|
| New native E30 cases/sequences | 679 |
| New native E30 snapshots | 13,239 |
| New suites | 5 |
| Total recorded-native cases | 186,219 |
| Total recorded snapshots | 211,008 |
| Total suites | 57 |
| Compared-field mismatches | 0 |
| Separate unit/integration checks | 159 passed |
| Browser sampled archived cases | 1,432 passed |
| Browser application checks | 36 passed |

E30 runs original instructions using the existing Linux x86-64 LDT bridge under
CPython 3.13.5/GCC. Node v22.16.0 and Chromium replay/check the separate JS core.
Neither Node nor the browser executes the original binary. Browser cases are a
subset of the inherited corpus; long E30 comparisons run under Node.

All 900 history elements are compared at every new native snapshot. Day runs
also compare cash, calendar, workers, animals, pending/live fields and RNG.
Four authored sequences span 2,190 days each, with explicit original street-slice
resume and supplied scene/media services. They are not earned winning routes.
Prepared store orders do not prove the complete original purchasing UI.

Fresh native builds reproduced eight case/input/observation file hashes.
Repeated runs do not increase evidence counts or constitute independent review.
See native-ledger/REPORT.md and both NATIVE-RUN.json receipts for exact scope.

Chromium loads the actual self-contained HTML bytes with Playwright set_content.
No HTTP requests or script errors occurred. Financial-history export, unknown
cell warnings/plot suppression, missing-history import, desktop/mobile layout,
state validation and browser-to-Node replay were exercised. File-URL navigation,
Safari/Firefox, original DOS GUI and native fDisBull acceptance are not claimed.

Lab 0.6 preserves the original's expense month ordering, including December's
payroll index shifting to two-years-back January. Previous category labels were
corrected against actual writers; totals had already included both categories.
Older snapshots missing histories remain unavailable, not silently backfilled.
Unknown zero-operator concession fields remain explicitly qualified.
