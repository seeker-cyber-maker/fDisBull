# DinoPark Algorithm Lab 0.2: validation receipt

25 October 2026. Guide0.2l / E26. No production Swift, original inputs or remote edits.

## Checks performed

| Check | Result |
|---|---:|
| Combined recorded-native cases | 170,335 |
| Recorded snapshots | 177,055 |
| Suites | 29 |
| Field-comparison mismatches | 0 |
| Separate unit/integration checks | 79 passed |
| Browser sampled cases | 920 passed |
| Browser application checks | 16 passed |

The combined corpus includes 146,488 inherited archival cases and 23,847 fresh
E26 native cases/sequences. The browser subset is not additional evidence cases.
E26 executed original x86-16 instructions in the preserved LDT bridge; Node and
browser tests replay observations rather than executing the original game.

A fresh temporary native build regenerated all16 input/observed TSV files with
matching identities. Repetition does not multiply the number of native cases.
This is not independent review, continuous DOS or an earned winning strategy.

## Corrections and scope

0.1 failed1,669 cases /2,005 snapshots in the E26 corpus. 0.2 fixes inspection
admission closure and timer-expiry concession effects. See native/REPORT.md.
Old snapshots can explicitly migrate; cross-version replays are rejected.

The standalone HTML was executed in Chromium with Playwright set_content.
Direct file-URL launch, Safari and Firefox remain unqualified. App HTTP requests
and JavaScript errors were absent. Mobile width, imported ticket value, snapshot
download/reimport, browser-to-Node replay and active/expired inspection rule
bench output were exercised. Screenshots and exact app hash are in results/.

Whole daily/weekly/quarter integration and original scene/media RNG remain open.
The connected eight-update revenue prefix does not run other weekly/monthly
subsystems. Routine parity is not full-game parity.

## Experimental smoke outputs, not original-game acceptance

| Fixture | Days | Cash | Animals |
|---|---:|---:|---:|
| lean-90 | 90 | 76320 | 1 |
| concessions-365 | 365 | 142802 | 1 |
| risk-365 | 365 | 47997 | 0 |
| loan-tail | 1 | 835 | 0 |
