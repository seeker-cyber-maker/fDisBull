# DinoPark: ledger writers, December payroll and connected six-year histories

**25 October 2026 | Guide 0.2p / E30 | Algorithm Lab 0.6**

## Result and boundary

The original daily and quarter routines now have comparisons of all **900 financial-history elements** at each recorded boundary, alongside cash, calendar, staff, inventories, pens, pause state and the original RNG. Four constructed six-year sequences complete, using an explicit year-end resume adapter rather than a replay of the office interface.

Fresh shop callback tests establish two category-name corrections: C03B receives dinosaur food/plant purchases; C12B receives advertising. The previously unnamed CA8B buffer records the active concession-operator count. The original's December payday ordering can place its payroll expense in the retained slot **two years back**, although the actual cash debit happens only once.

E30 contains **679 scenarios/sequences, 13,239 snapshots, five suites**. Every compared field matches. Of these, 112 daily/quarter scenarios provide 10,728 snapshots; 567 food/store scenarios provide 2,511. These are not 679 games, independent investigations, exhaustive input coverage or live DOS sessions.

No original game file, production Swift source or remote repository was changed. No fDisBull installation, native DOSBox acceptance, full rendered office, physical input or earned winning route is claimed.

## 1. Corrections to our category names

The former field names in the E29 implementation were interpretations, not original debug symbols. C03B was called `animalPurchases`, C12B `foodPurchases`, and CA8B `counterCA8B`. Following actual writers shows:

| Original base | Current Lab field | Supported meaning and writers |
|---|---|---|
| C03B | foodPurchases | Dinosaur food and planting supplies. Original Diner purchase commit posts here. |
| C12B | advertising | Newly confirmed General Store advertising flags post their prices here. |
| C21B | fees | Mixed capital/fee bucket: facility and fence purchases, land-related postings, automatic loan installments, repaving and annual tax. These are not all taxes. |
| C30B | otherExpenses | Dinosaur purchases, ordinary purchase undo, licensing and lawsuit charges among the inspected writers. |
| C3FB | payroll | Weekly cash paid, posted using the then-current month index. |
| C4EB | animalSales | Net auction-sale proceeds. |
| C5DB / C6CB | giftCost / foodCost | Recorded concession costs. |
| C7BB / C8AB | giftGross / foodGross | Recorded concession gross sales. |
| C99B / CA13 | giftStandCount / foodStandCount | Counts written by daily processing. |
| CA8B | operatorCount | Active concession operators, from DS:6F90. |
| CB03 | storedTicketCents | Month-close price from the quarter schedule. |
| CBF3 | visitors | Completed-month visitor total. |

Each array contains five years of twelve months. C99B, CA13 and CA8B use signed 16-bit entries; the others are 32-bit. These are author-assigned semantic labels. The full original financial-summary screen's displayed category labels were not rendered here.

Correcting the first two names does **not** change the financial summary's total: both buffers were already included in its expense sum. Historical E29 code and receipts remain under their original scopes; the new names supersede those interpretations. An older explicit report fixture with the obsolete names is not silently reinterpreted.

`static-postings.json` identifies selected original writer/source instructions and their byte-range hashes. It is a checked site map, not proof that every indirect write in the executable has been found. DinoMart and several capital/fee destinations are statically mapped in E30; their entire transaction lifecycles were not newly executed here.

## 2. Confirmation, cancellation and food-cost overflow

The original food command handler is exercised for all nine products, months January/June/December, no finish/OK/Cancel, and quantities 1/7/328, with one undo in the seven-click fixtures. Every sequence records selection, purchase, undo, finish and subsequent live-to-pending synchronization.

Cash is staged during selection. **The history expense posts at successful confirmation**, not on each click. Cancellation does not post it; the later original synchronization discards the pending order. All 900 financial-history entries are checked at every snapshot, not only the proposed destination.

The known signed-word subtotal is retained. Buying 328 large feeders at 100 each spends 32,800 but posts **-32,736** to C03B after confirmation. This is not a cash refund or a tax deduction: actual cash and the annual cash-growth tax are separate. The E30 fixture simply corroborates the earlier overflow in the now-correctly named field.

General Store tests prepare known pending orders, then invoke the actual OK/Cancel callback. The grid crosses six advertising masks, six facility masks, three months and three completion choices: **324 sequences**. It does not claim to execute every preceding shop click or fence-placement interaction.

Examples from the original callbacks:

- A confirmed 750 flier order posts 750 to **C12B** and reduces committed cash by 750.
- A confirmed 5,000 food-stand order posts 5,000 to **C21B**.
- Preparing all tested ads/facilities and then cancelling leaves both history buckets unchanged; the original synchronization restores working cash from committed cash.

Food fixtures are compared to the existing independently written JS purchase-sequence kernel. Store fixtures use explicit expected posting/cash calculations, not an invented assertion that the browser already implements the whole original shop.

## 3. End-of-month payroll uses the next month

The original daily routine performs month-close work and the automatic installment before incrementing the month. It then reaches the weekly payroll path when the weekly counter is due. The payroll writer uses the **already incremented** month.

A constructed park with two vets, one guide and two operators pays **1,675** at the relevant weekly settlement. With 200,000 starting cash and admission closed:

| Boundary | Cash after payday | Nonzero payroll history slot |
|---|---:|---|
| January 31 daily return | 198,325 | Index 1: current-year February |
| December 31 daily return, before quarter | 198,325 | Index 12: previous-year January |
| December annual quarter return | 198,325 | Index 24: two-years-back January |

The December case occurs because month temporarily equals **12** between the daily rollover and annual quarter processing. Index 12 is still inside the complete 60-entry array, but it is in the next retained year block. The annual shift then moves that value to index 24.

Paired non-payday controls post no wages. Both seeds 1 and 17 produce the same 1,675 placement in these controlled cases. The annual cash baseline equals the starting cash, so these loss-making boundary examples have no annual tax to obscure the payroll result.

This is an original reporting/order quirk, not a new cash debit. A safe display of the original histories must not silently move the entry back into December and then claim byte-for-byte ledger fidelity. Corrected reporting could be offered as a clearly different view later.

The automatic installment behaves differently: it posts to the closing month's **C21B** before month increment. Annual tax still follows E29's separate rule: month is reset to zero, tax posts to current January, then shifting places it in the previous year's January. Do not conflate that tax placement with the new two-years-back wage placement.

## 4. CA8B is an active-operator snapshot

The concession routine reads active operators at `38FF:2BDC`, saves the value in a local, and writes that value to CA8B at `315B-3161`. It overwrites rather than accumulates it.

A long-run checkpoint during an operator absence records one active operator and CA8B equal to one. It is neither a monthly cash total nor a cumulative number of workers hired. The daily count is taken before later weekly processing, so a payday departure can occur after the recorded count for that update. No stronger statement about a full rendered office is inferred from these data writers.

## 5. Connected multi-year history comparison

The native driver runs original `38FF:4CA3` through return, checks the original quarter gate, and runs `38FF:4827` when requested and allowed. Original economic routines, arithmetic/copy helpers and RNG execute. Graphics, modal services, audio and physical input remain explicit adapters.

Eight long scenarios cross seeds 1/17, empty/two-animal parks and 400/2,190 days. Four therefore span **six 365-day years**, not just six repeated annual-shift calls. They start with deliberately authored cash of 4,000,000, explicit baseline/history values, known staff and stock, and optional 5,000 debt. Starting assets were not earned and no shop sequence is implied.

After an annual pause, an explicit host policy runs the original main-street release/synchronization slice `2B5D:041B-043F`. The adapter clears the already handled notice and sets the next scene bookkeeping. **It does not execute the complete office notice/navigation, common scene loop or media RNG.** This preserves the defined day-level experiment without pretending those presentation paths have no consequences.

There are no cash, herd or RNG edits between daily calls. The only between-year control edit is the declared resume adapter. All cases retain a veterinarian to exclude the previously documented nonterminating empty-herd/no-vet scan. No final accepted case reaches the terminal/foreclosure adapter.

Each daily, quarter and resume snapshot compares:

- All 15 by 60 history entries, including overwritten count arrays and previous years.
- Committed/working cash, debt, calendar, monthly/annual baselines and cash-change report.
- Progression, absence, event/inspection flags, risk/maintenance counters, pause/quarter state.
- Active/pending staff, all food stocks and pens, seller flags, RNG state and draw count.

The expectations come from the separate JS implementation and explicit field comparator. RNG counts use the probe's recorded counter and are not a second investigator's independent control-flow model. A passing six-year constructed run does not establish a strategy, every possible transaction path or complete original-game equivalence.

## 6. Implementation and uncertain original locals

Lab 0.6 now posts daily attendance/price, concession accounts/counts, payroll, automatic loan charges, reached event fees, annual shifting/tax, and its available food-purchase/seller-settlement policies into the retained histories. The original expense/period ordering is preserved. The lab still lacks full original land/facility/advertising/DinoMart scene actions; prepared native store tests do not magically implement those interfaces.

Old snapshots without history arrays retain `financeHistory: null` and emit `history.unavailable`. Their economic state can continue when the already-required baselines/cache are valid, but no past ledger is reconstructed from cash or summary metrics. Old action replays remain version-bound.

E26 already established that the zero-operator concession path can leave accounting locals uninitialized. Lab 0.6 marks affected financial cells unknown rather than asserting that a zero-initialized probe stack is the original rule. These uncertainty markers survive later additions and annual shifts. The new exact native history corpus has positive active operators, so it does not certify any arbitrary choice of undefined values.

The Financial history browser tab uses the live simulation buffers. It distinguishes completed/open months, shows all categories and original base addresses, exports the arrays with uncertainty markers, and withholds unreliable concession plots. The ticket graph remains a visitor graph. Rendered lines are diagnostic, not original artwork.

## 7. Counts and reproducibility

| E30 suite | Scenarios/sequences | Snapshots |
|---|---:|---:|
| Month/posting-order boundaries | 96 | 216 |
| Payday calendar controls | 8 | 12 |
| Connected multi-year days/quarters/resume | 8 | 10,500 |
| Food purchase/undo/finish histories | 243 | 1,215 |
| Prepared store order confirmation/cancellation | 324 | 1,296 |
| **Total** | **679** | **13,239** |

Full regression: **186,219 cases, 211,008 snapshots, 57 suites, zero compared-field mismatches**. Separate JS unit/integration checks: **159 passed**. Browser sampled archived cases remain **1,432**, plus **36 application checks**. The long E30 suites run in Node; they are not included in the browser's smaller recorded-case sample.

```sh
python3 native-ledger/reproduce.py /path/to/original/game --out [private-local-path]
python3 native-ledger/reproduce_transactions.py /path/to/original/game --out [private-local-path]
node cli.cjs test
node tools/build.cjs
```

The native commands require Linux x86-64, GCC and process-local LDT support, and authenticate the original EXE/VARS. They compile into temporary directories, disable core dumps, bound child execution and refuse existing output directories. The bridge is not a sandbox for untrusted executable bytes or malicious states.

Original input SHA-256:

```text
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT     5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153
```

Fresh native builds reproduced eight case/input/observation file hashes. The repeat and browser subset are not additional native scenarios or independent review. During probe development an incorrect 16-bit assignment to a byte-sized resume flag touched adjacent debt; it was corrected before final recording. That was a harness error, not a game defect. Final native/JS comparisons include debt at every checkpoint.

Original code bytes, game artwork, compiled probes, runtime images and privately inspected generated game C are excluded from this package. Earlier evidence retains its dates and scopes.

## 8. Remaining work

Complete original shop/undo/placement paths and quarter-specific ticket schedules are not all available through the browser Engine. Extend their transaction coverage without inferring ledger postings from cash alone. Also pending are terminal/foreclosure composition, continuous office/input/modal/media sequencing, DOS save/load acceptance, and an earned original-game route with a rendered ending and persisted score. E30 does not qualify every malformed state, negative expense boundary or hardware timing path.
