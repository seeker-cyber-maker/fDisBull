# DinoPark: inspection expiry, revenue integration and JavaScript Lab 0.2

**25 October 2026 | Guide 0.2l / E26 | Native instruction comparisons**

## Result

Fresh execution of the pinned original exposed two JavaScript Lab 0.1 defects:
food inspection incorrectly closed admissions, and concession inspection effects
remained active after their shared countdown reached zero. These are errors in
our new JavaScript composition, not newly discovered defects in the DOS game.
The task-owned Lab 0.2 corrects them without rebalancing any original formula.
Production Swift, original game inputs and remote repositories are unchanged.

E26 executes **23,847 cases/sequences and records 24,519 snapshots in eight
suites**. The corrected JavaScript matches every compared field. The preserved
0.1 core fails **1,669 cases/sequences and 2,005 snapshots** against the same
observations and adapter. All 146,488 earlier archival cases still pass.
Many cases are deliberate boundary fixtures, not independent complete games.

## 1. One timer has two different meanings

The original attendance routine checks `DS:BF9D`, the remaining event countdown,
and `DS:BF9B`, the inspection discriminator, at static `38FF:2717-2730`:

```text
Countdown zero:                      no closure effect
Countdown nonzero, inspection zero: zero visitors
Countdown nonzero, inspection set:  do not zero visitors here
```

Other attendance restrictions, including no active staff and hunger, still apply.
Lab 0.1 passed `closed = closureDays > 0` and therefore treated inspection as a
whole-park closure. In one controlled constructed park with a guide, one
Hadrosaurus, $2.50 tickets and attendance factor 1, the original reports **54
visitors and $135 admission income** during inspection; Lab 0.1 reported zero.
This is a synthetic fixture, not an official starter save or a played route.

`attendance` now accepts the raw `closureDays` and `inspection` pair. When raw
countdown is supplied it takes precedence over the legacy pre-resolved `closed`
parameter. The Engine passes both fields rather than resolving them incorrectly.

## 2. The stored inspection flag survives expiry

The daily prefix at `38FF:4E12-4E1C` decrements a nonzero countdown before
incrementing the calendar day and calling attendance. It does not clear the
inspection flag. Concession allocation and account recording separately test
whether the countdown is still active. The account gate is at
`38FF:30F3-3100`; operator allocation is in the original `38FF:2AF7` helper.

Lab 0.1 used the stored flag alone. After expiry it could keep assigning all
operators to gifts, suppress food accounting, and consume extra RNG draws.
The 1,094 isolated concession mismatches all have **timer 0, inspection 1**.
The correction computes active inspection from both fields. It intentionally
does not clear the stored flag, which is part of the original state.

Example: 100 visitors, one food stand, one gift stand, one operator, supplied
random returns `[79,13,56,11]`:

| State | Original concession cash | RNG draws | Food account entries |
|---|---:|---:|---|
| Active inspection | 173 | 4 | Suppressed |
| Expired timer, flag still set | 89 | 2 | Recorded normally |

These amounts are fixture results, not a fixed daily income promise. Active
inspection retains the unusual original food/gift allocation and cash/account
distinction. It is not replaced with a more intuitive zero-food-income rule.

## 3. Connected original daily revenue prefix

Ninety-six scenarios each execute eight successive updates from the original
`38FF:4E12-4E3F` control flow. This includes countdown decrement, date increment,
original attendance, the zero-availability auction gate, and full original
concessions, in their original order. State and RNG persist between updates;
there are no host edits between them. A checked far-return boundary stops before
`4E40`, so this is **not the complete daily routine**. Weekly payroll, illness,
feeding, monthly rollover and the outer scheduler are not executed here.

All fixtures use an explicitly constructed single-Hadrosaurus park, one guide,
positive operators, one food and one gift stand, one restroom, known cash,
month 3, day 5 and original RNG. They cross four initial countdowns, both flag
values, three seeds, two operator counts and two parking counts. No month ends
occur in these eight updates. Calendar dates in this slice do not imply that
omitted weekly processing was executed.

For countdown 7 / flag 1 / seed 1 / one operator / no parking:

| Update | Countdown after decrement | Visitors | Cash | Total RNG draws | Cumulative recorded food gross |
|---:|---:|---:|---:|---:|---:|
| 1 | 6 | 108 | 100429 | 5 | 0 |
| 6 | 1 | 162 | 103063 | 30 | 0 |
| 7 | 0 | 54 | 103248 | 33 | 246 |
| 8 | 0 | 108 | 103604 | 36 | 676 |

The inspection flag stays 1 throughout. A timer initially set to 7 is active
for six subsequent revenue passes; the seventh decrements it to zero. Food accounting resumes at expiry and
the revenue RNG pattern changes. These are logical updates, not measured seconds.
The generated fixture remains in the packet for exact reproduction.

## 4. Comparison coverage

| New suite | Cases/sequences | Snapshots | 0.1 failing cases | 0.2 failing cases |
|---|---:|---:|---:|---:|
| Event deck, controlled RNG | 6656 | 6656 | 0 | 0 |
| Event deck, original RNG | 2048 | 2048 | 0 | 0 |
| Monthly inventory | 2543 | 2543 | 0 | 0 |
| Attendance, controlled RNG | 3096 | 3096 | 144 | 0 |
| Attendance, original RNG | 2048 | 2048 | 383 | 0 |
| Concessions, controlled RNG | 6336 | 6336 | 898 | 0 |
| Concessions, original RNG | 1024 | 1024 | 196 | 0 |
| Connected revenue prefixes, 8 snapshots each | 96 | 768 | 48 | 0 |
| **Total** | **23847** | **24519** | **1669** | **0** |

Fields actually compared:

- **Events:** committed/working cash, mask, inspection/countdown, draw count,
  actual RNG state in real-RNG cases, message IDs/count, all live/pending species
  and counts. Two separate original financial-history buckets are recorded but
  excluded from the JS comparison because the lab does not model those buffers.
- **Monthly inventory:** all nine live and nine pending stock fields. There are
  36 explicitly synthetic signed-word boundary cases beyond ordinary shop stocks.
- **Attendance:** visitors, both cash deltas, monthly visitor accumulation,
  draw count and RNG state. Internal animation-density fields are not compared.
- **Concessions:** both cash deltas, food/gift gross and costs recorded by the
  original, three service fields, draw count and RNG state. With zero operators,
  food/gift account and service locals can be uninitialized; those fields are
  deliberately excluded instead of turning the probe's zeroed stack into a rule.
  Cash deltas, restroom service and RNG are still compared in zero-operator cases.
- **Connected prefix:** countdown, flag, day, visitors, both running balances,
  accumulated monthly visits, four account totals, three service fields and RNG.

Output comparison is separate JavaScript logic. It is not an independent second
investigator or an exhaustive proof over every input. No test count is a binary
coverage percentage. The new event/monthly checks extend earlier research rather
than constituting new discovery of every rule they cover.

## 5. Execution and provenance

Original inputs, authenticated before and after:

```text
DINOPARK.EXE 2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c
VARS.DAT     5e4b32d6e4afd060d72da79bfcac27fdca493905a7e19e299729e31431a1d153
```

The inherited Linux x86-64 process-local LDT bridge executes original 16-bit
instructions, multiplication/division, copies and (where selected) the original
RNG. Exact far-call bytes/targets are checked before selector adaptation.
Controlled RNG tapes and explicit message/format/modal adapters are used in the
event suites. Attendance/concession bodies have no substituted revenue formula.
The earlier support's artificial stop at `3178` is restored from the pinned EXE
before full concession execution; otherwise its post-income tail would be lost.

Addresses follow `file = 0x4800 + 16*(static_segment-0x1000) + offset`, not relocated
DOS breakpoints. The bridge is **not a sandbox for hostile code or malformed
states**. No actual DOS GUI, physical input, complete scene loop, earned win,
rendered graphics/audio or emulator restore is qualified by this pass.

The packet contains authored sources and observations, not the original game,
resource art, compiled native probes or lifted game-code files. A reproducibility
launcher compiles in a temporary directory and rechecks all eight recordings.

## 6. fDisBull 0.14 status, separate from E26

GitHub's release API now identifies v0.14.0 as published at
2026-10-25 19:15 UTC, neither draft nor prerelease, at commit
6a0aeb3830eb544cd744d3410881c1c951a5ffb7. The tag-CI package artifact was downloaded
and its wheel, source archive and tool ZIP match the published release digests.
The prior push-CI wheel archive has different bytes, but all 84 uncompressed
entries match the tag wheel exactly. This is packaging provenance, not runtime
acceptance.

The documented compact kit is fdisbull-linux-dos-offline-0.14.0-6a0aeb3.zip,
98,555,019 bytes, SHA-256
8adef6ec336a1a9efb43695479bbbc38bca63e8ccfc9b5e38b4f59a825bc1868.
It was not retrieved into this sandbox. The current interpreter still lacks
capstone, iced-x86 and lief; no local fDisBull or DOSBox acceptance is claimed.

Published delivery notes separately report 49 passing native checks and two
Vga-record CRC restore failures in a Mac-hosted QEMU/TCG Linux probe. That is not
this sandbox's test result and does not negate the distinct passing tag-CI scope.
E26 evidence comes from the existing LDT bridge, not fDisBull.

## 7. Implementation disposition

Lab 0.2 includes the corrected gates, 79 unit/integration checks and all new
recordings in its Node/browser comparison pipeline. Its full corpus is now
170,335 cases / 177,055 snapshots in 29 suites. Node/browser and fresh-package
checks have separate receipts; do not equate them with new native executions.

Old full snapshots may migrate with an explicit event/warning. Old-version
replays are rejected rather than silently promising 0.1 trajectories under
corrected semantics. The 0.1 engine and prior result are preserved in history.
Remaining gaps include entire daily/weekly/quarter composition, illness/management
and other visitor-status branches, original menu/media RNG, full DOS loading,
input, endings and a genuinely earned winning route. No economic rebalance was
made to obtain favorable survival results.
