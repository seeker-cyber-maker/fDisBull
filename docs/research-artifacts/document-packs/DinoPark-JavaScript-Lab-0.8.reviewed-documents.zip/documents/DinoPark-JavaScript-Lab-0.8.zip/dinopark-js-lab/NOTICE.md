# Research prototype notice

This package contains a newly authored JavaScript research implementation, a diagnostic browser interface, and numeric input/output observations from the user's DinoPark investigation. It does not contain the original DOS executable, original game artwork, sound recordings, binary saves, emulator runtimes, compiled native probes, or archived generated-C reconstruction units.

No public-project license decision or publication was made in this task. Do not interpret the package as a licence to distribute the original game or its resources. Preserve the provenance and qualification notes when sharing research results.
