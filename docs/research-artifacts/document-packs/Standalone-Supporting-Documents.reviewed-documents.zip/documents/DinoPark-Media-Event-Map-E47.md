# Media/event handoff after E47

This is a source-bound evidence map, not a new language or implementation. Sixteen records separate triggers, resources, state effects, completion, clocks and randomness. They are not fifteen newly executed tests or a complete animation census.

## scene.common_loop

**Trigger:** A scene loop iteration

**Resources:** Service-level or unspecified here.

**Effects:** Animation/update callback precedes input; Commands precede calendar pause check; Sound service precedes requested-transition test.

**Completion:** Requested scene alone does not skip the remainder of the current iteration.

**Randomness:** Callbacks may consume shared RNG while calendar is paused.

**Clock/input:** Counted pause holds gate daily processing, not every callback.

**Evidence:** E18, E25. Inherited bounded original-instruction scheduling; not a new E47 execution.

**Still open:** Hardware cadence and all scene-specific callbacks.

## music.route

**Trigger:** Scene initialization or Music-on command

**Resources:** DINO5A.XMI, DINOCITY.XMI, DINOFKEY.XMI, EXTINCT.XMI, DINOPARK.XMI, AUCTION.XMI

**Effects:** Scene-to-selector table at DS:3C8B; six pointer entries at DS:3C71; Cached selector at DS:3C89 avoids a redundant resource reload.

**Completion:** New selection loads a sequence; the start/resume wrapper has separate state-dependent behavior.

**Randomness:** No universal RNG cost inferred.

**Clock/input:** Music off and volume zero are distinct.

**Evidence:** E20, E47. Static selection helper 1B29:03D6 plus live settled contexts 18 -> 1 -> 8 -> 1 in E47.

**Still open:** XMI event stream, synthesis, all scene routes, sound device completion.

## samples.scene_registry

**Trigger:** DinoMart setup, then ordinary street return

**Resources:** EGGCLAMP.ABT, EGGDROP.ABT, SPLOIT22.ABT, CRACKLE.ABT, SHORTMTR.ABT, BIPLANE.ABT, ROOSTER.ABT

**Effects:** DinoMart registers five samples; CRACKLE rate word becomes header rate + 8000: 22000 -> 30000; Street return replaces registry with BIPLANE and ROOSTER.

**Completion:** Registration completion is not proof that the scene image or input is ready.

**Randomness:** No RNG-neutrality claim for the whole scene.

**Clock/input:** Fresh bounded waits establish the intended displayed page separately.

**Evidence:** E47. Fresh live DOS registry observations plus byte-inspected calls at 334B:22F2..236D.

**Still open:** Audible waveform/timing and each sample trigger.

## sample.submit_and_busy

**Trigger:** One-shot/repeating sound service or cleanup

**Resources:** Service-level or unspecified here.

**Effects:** 1862:0498 and 0544 perform lookup before preference gate; 1862:0A34 returns not-busy without device polling when disabled/uninitialized; 1862:0A15 waits on the wrapper while enabled.

**Completion:** Busy, wait and stop results remain observable even with a replacement or silent host audio backend.

**Randomness:** Preserve caller-side RNG; do not infer it from audible output.

**Clock/input:** Cleanup can wait before a scene transition completes.

**Evidence:** E20. Inherited original wrappers with declared device adapters.

**Still open:** Actual device scheduling and restored sound-state issue in E45.

## sample.preference_change

**Trigger:** Original Sound FX option toggle

**Resources:** Service-level or unspecified here.

**Effects:** Toggle-off clears repeat marker; Turning back on does not automatically restart the old repeat; Direct flag assignment is not equivalent to the handler.

**Completion:** Preserve handler ordering; do not invent a device stop that the inspected disabled branch did not call.

**Randomness:** Toggle boundary tested separately from later effects.

**Clock/input:** Does not itself toggle Animation or counted calendar pause.

**Evidence:** E20. Inherited bounded original-code preference lifecycle.

**Still open:** Already-submitted physical audio after the off transition.

## dinomart.ordinary_arrival

**Trigger:** Eligible ordinary BUY

**Resources:** DINOMART.PIC, DINOMART.ACT, EGGCLAMP.ABT, EGGDROP.ABT, SPLOIT22.ABT, CRACKLE.ABT, SHORTMTR.ABT

**Effects:** Debit working cash and post C30B expense before arrival; Animation-off selects direct-position alternative; Placement modifies pending pens; confirmation commits; cancellation refunds and reverses against current month.

**Completion:** Arrival/placement mode, pause acquisition, control installation and displayed frame are separate boundaries.

**Randomness:** Maintain actual callback draws rather than assuming pure decoration.

**Clock/input:** Normal days can pass during arrival; placement acquires a hold.

**Evidence:** E19, E32, E46. Inherited original slice plus live ordinary purchases, not full frame reconstruction.

**Still open:** All arrival frame/path choices and sample-to-phase trigger map.

## dinomart.vegasaurus

**Trigger:** Eligible special BUY

**Resources:** DINOMART.ACT

**Effects:** Reserve 25000; Completion refunds cash, disables the gag and delivers no pen animal; Tested expense record retains 25000; Animation-off performs the refund at purchase-time.

**Completion:** Completion/refund must survive even when the visual sequence is skipped.

**Randomness:** No total RNG claim for full sequence.

**Clock/input:** Availability at later quarter refresh respects gag-completion flag.

**Evidence:** E14, E20, E46. Inherited bounded original special path; restock exception static in E46.

**Still open:** Full rendered gag and physical audio behavior.

## employment.appearance_and_draft

**Trigger:** Select role or edit staffing

**Resources:** EMPOFF.ACT

**Effects:** Animation-on categories 0..4 select appearance state3; off selects state2; category5 bypasses; HIRE/FIRE edit draft; Detail OK retains draft, outer OK commits; Detail Cancel resets all roles; outer equal-cash Cancel can leave stale pending state.

**Completion:** Pending count, rendered number and control-enable update are separate.

**Randomness:** Appearance initializer itself was adapted in E19, no full RNG total supplied.

**Clock/input:** Employment calendar continues in tested routes.

**Evidence:** E19, E41, E42. Inherited native selection slice and real-DOS transactions.

**Still open:** Complete appearance resources and event timing for every category.

## auction.bid_and_hammer

**Trigger:** Eligible BID or ordinary bidder update

**Resources:** AUCTION.ACT

**Effects:** BID begins a raising-hand state before bid acceptance; Ready predicate also requires no active bidder actor; Winning player is charged at hammer before placement; Payment updates DS:585A shopping amount, not the checked expense histories.

**Completion:** Actor phase, bid acceptance, hammer, placement readiness and pen commit are distinct.

**Randomness:** Animation-off sprite selector can add one RNG draw; fixed actor frame does not freeze phases.

**Clock/input:** Calendar pause does not stop auction updates.

**Evidence:** E19, E21, E44. Inherited slices plus live buying and two placement branches.

**Still open:** Complete audio/animation timing and all actor phases.

## auction.information_excursion

**Trigger:** Information, optional paging, then return

**Resources:** AUCTION.ACT

**Effects:** Tested ordinary-lot prices and high bidder survive exact reconstruction interval; Idle in settled information preserves measured bidding state.

**Completion:** Selection must agree with displayed title before a next-page action; shared footer alone is insufficient.

**Randomness:** Observed: entry1, each tested page rebuild1, return-before-init1, initializer4; later updates can add more.

**Clock/input:** Information pause is distinct from merely waiting in an active auction.

**Evidence:** E24, E43. Actual interface routes with precise original stops; not all lots/platforms.

**Still open:** Complete repeated excursions and seller-lot timing variants.

## auction.seller_credit

**Trigger:** Quarter consignment, hammer or early ordinary exit

**Resources:** AUCTION.ACT

**Effects:** Consignment removes animals before payment; Hammer credits floor(accepted*90/100); Early exit sums individually truncated estimates then subtracts floor(total/10); Early payout message can appear before cash/history credit.

**Completion:** Acknowledge the displayed notice before declaring credit committed.

**Randomness:** Early fallback consumes one percentage draw per outstanding species in catalogue order.

**Clock/input:** Scene cleanup/presentation remains separate from posting.

**Evidence:** E24, E45. Live watched and early exit routes with different starts; not a strategy comparison.

**Still open:** Restored-exit stall cause; all sound cleanup branches.

## bank.visitors

**Trigger:** Enter bank or wait while bank is open

**Resources:** BANK.ACT

**Effects:** Initialize visitors and update their motion/timers; Animation preference does not gate the inspected visitor updater.

**Completion:** Finance action and eventual office/street synchronization have separate boundaries.

**Randomness:** Bank waiting advances shared RNG even with Animation off in inherited matched fixtures.

**Clock/input:** Calendar may remain paused while visitor callbacks run.

**Evidence:** E20, E25. Inherited connected original routines with declared resources/presentation adapters.

**Still open:** Exact visible visitor composition and live per-interval RNG census.

## park.vegetation

**Trigger:** First eligible store-spending promotion, then month updates

**Resources:** PLANTS1.ACT, PLANTS2.ACT, PLANTS3.ACT

**Effects:** First scenery promotion initializes ten variant choices; Age advances monthly up to24 in normal range; Resource stage uses truncate(age/12)+1.

**Completion:** Scenery level and age are retained state, not only a renderer preference.

**Randomness:** First promotion consumes ten shared draws; later promotions in the tested block do not repeat it.

**Clock/input:** A single >=10000 qualifying subtotal raises one level, not one per10000.

**Evidence:** E37. Original transition slices; resource-stage consumer statically inspected.

**Still open:** Rendered variants/placement and complete scene use.

## windowshop.peanuts

**Trigger:** Feed control in Window shop

**Resources:** WINSHOP.PIC, WINSHOP.ACT, CRUNCH2.ABT

**Effects:** Original peanut quota/reward logic remains separate from Diner fly; Original scene302C:0626 installs update02F0, input04CE, setup0557.

**Completion:** Feed input, animation updates and financial award are distinct.

**Randomness:** Retain scoped RNG behavior; absence of local Animation test is not proof all callers ignore it.

**Clock/input:** Documented original side activity, excluded from Swift recreation by user scope.

**Evidence:** E17, E18. Inherited original-instruction side-game evidence, not fresh E47 play.

**Still open:** Full rendered timing and audio completion.

## diner.fly

**Trigger:** Diner update and page-turn action

**Resources:** DINER.PIC, DINER.ACT

**Effects:** Fly update is Animation-gated; Page-related splat history has nine-record limit.

**Completion:** Page transition and fly effects are separate from food-order commitment.

**Randomness:** Flight decisions and pitch jitter consume shared RNG.

**Clock/input:** Can update while calendar held; not every frame has the same draw count.

**Evidence:** E17, E18. Inherited callback execution and live Diner order coverage in E40, not new full fly reconstruction.

**Still open:** Precise sprite/collision/audio rendition.

## capture_and_display_boundary

**Trigger:** Any completed state change followed by a requested screenshot

**Resources:** Service-level or unspecified here.

**Effects:** Preserve pending/committed/displayed values separately; Passive captures need not show newly committed state; An explicit settle wait advances execution.

**Completion:** Do not retry a state-changing action solely because an image is old, black or occluded.

**Randomness:** Settling may consume draws and advance normal income.

**Clock/input:** Fresh scene/content/control predicates are separate from a frame existing.

**Evidence:** E41, E42, E43, E44, E46, E47. Cross-cutting evidence obligation, not a new API or UIL contract.

**Still open:** Universal readiness remains unsupported; authored predicates are scoped.
