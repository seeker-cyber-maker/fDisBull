# fDisBull investigation skill: methodology review and proposed patch

## Disposition

Keep the current skill's structure and operating principles. Add a scoped
interface-first rule, action-boundary reasoning and a short diagnostic reference.
Do not turn the skill into a target-specific walkthrough or another API manual.
The files under `proposed/` and the patch are a proposal only. No repository,
installed skill, tool runtime or original target file was changed by this review.

## Exact material reviewed

Repository: `seeker-cyber-maker/fDisBull`.
Source revision fetched: `41da677bcfda708d2d03c60d9f7f853b86bcb641`.

- `src/fdisbull/skills/fdisbull-investigate/SKILL.md`
  - Git blob: `9570f26f9ecf33aa68e12895227364dc4dcd76e8`.
- `src/fdisbull/skills/fdisbull-investigate/references/scenes.md`
  - Git blob: `5a8bcf296d26be946c66d8077a225162352b10ee`.

The two files extracted from the previously supplied 0.17 CI wheel have those
same Git blob hashes. This review therefore covers both that actual bundled
skill and the skill at the fetched source revision. It does not certify a later
release, a different skill revision or any tool behavior changed since the
recorded experiments.

Source links:

- https://github.com/seeker-cyber-maker/fDisBull/blob/41da677bcfda708d2d03c60d9f7f853b86bcb641/src/fdisbull/skills/fdisbull-investigate/SKILL.md
- https://github.com/seeker-cyber-maker/fDisBull/blob/41da677bcfda708d2d03c60d9f7f853b86bcb641/src/fdisbull/skills/fdisbull-investigate/references/scenes.md

## What the existing skill already does well

The source already puts the requested outcome first, prioritizes decision value
per cost, distinguishes runtime/project/file coordinates, treats names as
hypotheses, and keeps one active question. It already separates visibility,
readiness and enablement, recommends real guest input with bounded outcomes,
retains failed branches and recognizes that native checkpoints do not roll back
mounted files. These should be retained, not advertised as missing features.

Its separate scenes reference is the appropriate home for APIs and schema
syntax. This proposal leaves that reference byte-for-byte unchanged.

## Main amendment: the interface constrains the interpretation

Suggested rule:

> Observed interface behavior overrules an inferred backend interpretation of
> what the user can currently see or do.

A backend scene selector can establish an internal state change while controls
are still unavailable. A returned success code can establish delivery without
application consumption. A callable routine can establish a mechanism without
establishing reachability from ordinary user input.

The qualification matters: a displayed number is not automatically the
committed amount, and an old frame is not the current interface. A report can
round or cache a value. Successful typing can be committed before a requested
intermediate image visibly refreshes. Keep these observations separate and
trace the first divergence; do not discard one merely to defend a hypothesis.
For a CLI, protocol implementation or file processor, use its actual external
interface rather than imposing a graphical acceptance requirement.

## Proposed amendments and their evidence basis

The experience column summarizes prior reports, not new executions in this
review. The rule column is the recommended generalization.

| Area | Experience motivating the change | General rule |
| --- | --- | --- |
| Interface versus inferred state | E32 records placement fields changing while the original still displayed a waiting state and had not installed controls. | Fresh observable availability outranks a guessed backend meaning for a user-facing claim. |
| Temporal boundaries | E32 observed a correct cancellation followed by unrelated daily revenue before the later snapshot. E39 similarly observed background revenue during the keep-order branch. | Attribute deltas at the relevant causal boundary; do not assume an action freezes every other subsystem. |
| Display versus committed state | E29 distinguishes reported income from collected cash. E36 records a restored trial with a blank intermediate field but correct final screen and stored output. | Verify the exact claim: display, committed state and persistence are separate observations. |
| Normal reachability | The project has isolated callback probes as well as later original-input route checks. | Do not promote an edited state or direct callback to normal user-facing behavior. |
| Failure triage | E39's wrong coordinates and host-timeout interruption were harness/calibration problems, not established target or backend faults. | Classify context, timing, focus, harness, capability and target/tool explanations before assigning blame. |
| Matched preparations | E36 had to reset the disposable output file before native restoration. | A checkpoint and equal seeds are not the whole experiment; include relevant external state and pending work. |
| Scene semantics | E39's text adapter reports unknown scene instead of inventing object absence. Quantity-specific literal outcomes limited repeated purchase reuse. | Keep identity, visibility, availability and action meaning distinct; prefer relationship-based assertions where supported. |
| Observation economics | E39 measured repeated memory checks and large observation documents despite cheap pixel probes. | Reuse qualified evidence, return compact summaries and scope regression to the actual change. |
| Scope and independence | Reports distinguish field comparisons, snapshots, repeated runs, live UI and independent review. | Keep verdict, method, scope and independence separate; test counts are not whole-program coverage. |

Supporting local research files already supplied in this conversation:

- `DinoPark-Live-Placement-Report-0.2r.md`, section 5: readiness and timing calibration.
- `DinoPark-Ticket-Graph-and-Ledger-Report-0.2o.md`, sections 2-3: reporting versus actual receipts.
- `DinoPark-E36-Report.md`, section 2: matched native restore and file boundaries.
- `DinoPark-E39-Report.md`, sections “Actual transaction checks”, “Recognition and readiness”, “Text-facing adapter” and “Friction and unsuccessful calibration”.
- `fDisBull-E39-Friction.md`, sections 1-4: observation cost, outcome generalization and portability.

These project-specific examples belong in the review rationale, not in the
proposed methodology instructions.

## Structure of the proposed change

1. Add “Let the interface settle user-facing claims” and “Follow the behavior
   across boundaries” after target/claim establishment.
2. Strengthen the existing prioritization section with explicit reopening,
   calibration triage, change-based regression scope and stopping conditions.
3. Clarify reusable scene knowledge versus current presence and availability.
4. Expand matched-run preparation and separate evidence scope from independence.
5. Add `references/methodology.md` for the deeper decision table and diagnostic
   procedure, linked from the main skill.

There are no invented new API calls, program addresses, pixel signatures,
resource values, purchase recipes or target-specific strategy recommendations
in the new text. Relational outcome checks are methodological assertions, not a
claim that the installed scene predicate API implements them.

The core grows from 697 to 1,123 whitespace-delimited words. The optional new
reference is 797 words. The existing 458-word scene API reference is unchanged.

## Review-only validation

The accompanying validation checks confirm the source blobs, Markdown links,
frontmatter identity and clean application of the patch to the exact reviewed
files. They do not evaluate agent performance or prove the methodology reduces
error rates. No runtime regression suite was rerun for these documentation-only
changes. A useful later evaluation would compare investigator behavior on a
small set of stale-frame, premature-readiness, delayed-commit and external-file
restore scenarios, without counting prose agreement as successful tool use.

## Applying the proposal

Review the diff before use. In a checkout whose two source blobs still match the
identities above:

```bash
git apply --check fdisbull-methodology.patch
git apply fdisbull-methodology.patch
```

For a newer skill revision, reconcile the wording rather than overwriting it.
The included `proposed/` directory is a complete review copy of this skill and
its two references, not a separately installed or published plugin.
