# fDisBull 0.20 and DinoPark's animation interpreter

**Assessment date: 28 October 2026.**  
**Verdict:** the current offline fDisBull development snapshot has a processor interface that can describe DinoPark's ACT animation programs. A small custom animation interpreter is a practical reconstruction component. The processor interface supplies instruction inspection; the reconstruction must supply state transitions, timing, actor scheduling and host services.

This review checks the uploaded development artifacts against the preserved DinoPark research. It does not implement a new ACT processor, change fDisBull, modify the original game, or replace the completed E53 milestone.

## 1. Which 0.20 snapshot is current?

Use the package inside **fdisbull-0.20.0.dev0-linux-x86_64-offline.tar.gz**. Its embedded wheel contains `processor.py`, `agi.py`, the `agi-logic` CLI/JSON operation, explicit COM import and dot-mode options.

There are two materially different wheels labeled `0.20.0.dev0`:

| Artifact | SHA-256 | Processor / AGI presence |
| --- | --- | --- |
| Wheel embedded in the offline bundle | `74655dee308f60ae7fd6cc8bcb44fec4fe31e93054916d09648fa23611d3195a` | Present |
| Separately uploaded wheel | `23922b2b79f53dfa75596b416478ff4082eb69c95103564523982f45dd1cede2` | Absent |

The separately uploaded `src(1).zip` matches the older standalone package's 93 Python files byte for byte. Version text alone therefore cannot identify the feature set. The runtime bundle README identifies its source as commit `001901d1361ab3a536de61e0292520af1ac32afd`; this is supplied provenance, not an independently checked Git checkout.

The complete offline archive is 22,890,831 bytes, SHA-256:

```text
fcf53a97b38e4ae59f479105cd4617a23d8e28856f7529bd8948811feaa01106
```

Its expected hash matches the supplied start note. All 14 entries in its supplied SHA256SUMS matched the extracted files.

[Current offline bundle]([private Library link omitted])

Evidence: `evidence/input-source-hashes.json`, `evidence/offline-payload-check.json`, `evidence/standalone-package-capabilities.json`, `evidence/runtime-api-probes.json`.

## 2. What a processor module actually supplies

The integrated `fdisbull.processor` module is an explicitly supplied, in-process decoder interface:

```python
ProcessorInfo(identity, version, address_space, address_unit,
              capabilities, state_schema)
Location(space, offset)
Successor(kind, target_or_none, evidence)
DecodedInstruction(location, facts, successors)

processor.decode(program, location)
decode_instruction(processor, program, location)
```

These are real API names in the checked package. A module describes its identity and coordinate system, decodes one instruction, and returns instruction facts plus explicit successor locations. The program argument can be a whole resource or another document; it is not restricted to a native machine-code window.

The dispatcher validates the descriptor, location and result structure. It does not establish opcode correctness, evaluate branch conditions, mutate virtual-machine state, advance a clock, or run successor edges. `state_schema` is a descriptive string, not a state implementation. Successor kinds are free-form strings.

The runtime currently includes native x86/ARM64 and CIL adapters plus the AGI consumer. The native analyzer now invokes `NativeProcessor`, but still feeds its returned fact dictionary into the existing native analysis/database assumptions. It does not expose generic VM project import or arbitrary custom-processor persistence. There is no automatic plugin discovery, processor registry or generic step/run engine.

For DinoPark, the immediate useful deliverable would be a dedicated ACT inspector that calls a supplied `DinoParkACTProcessor` and returns a standalone document, following the AGI inspector's architectural pattern. Native SQLite project integration would be separate work. The eventual reconstruction can share a small decoding/semantics core without requiring the whole fDisBull application at runtime.

Sources: embedded-runtime `processor.py`, `analysis.py`, `project.py`; independent review in `notes/processor_contract.md`.

## 3. What the AGI inspector demonstrates

The current `agi.py` provides `AGI2917Processor` and `inspect_logic`. The actual command is:

```text
fdisbull agi-logic LOGDIR VOLUME_DIRECTORY LOGIC_NUMBER \
  --profile 2.917 --max-instructions 1000
```

It reads a LOGDIR entry and a v2 VOL resource, extracts the code subsection, creates a resource-hash-based address space, and follows decoded successor offsets from entry zero. It records directory/volume hashes and resource/code file offsets.

The supported subset recognizes 21 action encodings plus return, goto and if. Conditions include fixed-length operands, variable-length `said`, and OR/NOT markers. It identifies encodings and branches; it does not perform assignments, evaluate conditions, draw objects, display messages, play sounds or execute room transitions. AGI and DinoPark ACT are different bytecode languages, so the ACT module needs its own encoding and behavior contract.

The traversal is bounded to 1–10,000 instructions, with a default of 1,000. Unsupported opcodes stop a path without guessing the next instruction's length. Truncation, unresolved targets, overlapping instructions and budget exhaustion remain visible.

**The `complete` flag describes static traversal.** The authored three-byte loop `FE FD FF` branches to itself and returns `complete=true`: its reachable graph was fully decoded. This is not a termination result or a statement that a game has been reconstructed correctly.

Fresh checks covered 13 authored AGI fixtures, generic processor dispatch, invalid inputs and CLI capability exposure. All assertions passed. They used temporary authored LOGDIR/VOL resources, not KQ1/PQ1 assets. The full test suite, CIL dependencies, DOSBox gameplay and actual AGI game compatibility were not exercised.

Source and complete fixture documents: `reviewed_source/fdisbull/agi.py`, `evidence/runtime-api-probes.json`, `notes/runtime_probe.md`. The format reference cited by the module is [AGI logic bytecode specification](https://peterkelly.github.io/agi-re/spec/logic_bytecode.html); DinoPark conclusions come from the project's original assets and binary evidence.

## 4. How this applies to DinoPark's “videos”

The preserved E48 inventory identified no conventional AVI/FLI/FLC/MPEG movie asset among the 191 supplied files. The identified presentations combine compressed pictures, masked sprites, embedded ACT animation programs and native callbacks. This is an inventory result, not a claim about every possible path in the executable.

The fresh ACT reparse found:

| Item | Count |
| --- | ---: |
| ACT resource files | 57 |
| Sprite records | 1,514 |
| Files containing embedded animation programs | 11 |
| Animation programs | 48 |
| Stored instructions | 679 |
| Distinct opcode values in those programs | 32 |

Program-bearing files are ABOUT, AGES, BANK, CREDITS, DINOMART, EVOL, MALL, MANLEY, RECONS, SIZES and THEORIES. Assets without embedded programs can still animate through native callbacks.

Three components need different treatment:

| Component | Existing basis | Required role |
| --- | --- | --- |
| ACT container and sprite runs | `act_codec.py`, UNC2/UNCS contracts | Load original assets and retain program slices, palette indices and separate opacity masks |
| ACT animation commands | `animation_tokens.py`, E51 opcode contracts and `contract_model.py` | Decode and execute actor commands, branches, waits, frame selection, movement and signals |
| Scene/native orchestration | Preserved dependency map and native routines | Supply real clock, signal producers, sound completion, input, scene changes and resource ownership |

The sprite run stream is a raster codec. The animation stream is the processor-module target. Treating all ACT bytes as one instruction stream would mix these distinct structures.

`INTRO.DMO` is another mechanism. The saved research identifies an initial seed and saved-state payload followed by recorded-input playback. The remaining playback grammar and original timing are separate work; an ACT interpreter does not implement it.

Evidence: `notes/video_context.md`, fresh `evidence/act-model-replay.json`, preserved E48 report and E51 contracts. The evidence archive includes selected unchanged reference sources and documents.

## 5. The reconstruction architecture

```mermaid
flowchart TD
    A["Original ACT resource"] --> B["Container and instruction decoder"]
    B --> C["fDisBull instruction and branch view"]
    B --> D["ACT interpreter"]
    E["Scene clock, signals and sound events"] --> D
    D --> F["Draw requests and actor state"]
    F --> G["Reconstruction renderer"]
```

The shared component is the recovered instruction contract and decoder. The inspector exposes what commands mean and where they can continue. The interpreter applies those commands to state and emits observable events. The host provides the game services those commands depend on.

A proposed ACT processor descriptor should use a byte-addressed space such as:

```text
dinopark.act.sha256:<resource-sha256>:program:<index>
```

This keeps program zero in one resource distinct from program zero in another. The module should record an explicit contract version, separate from the fDisBull package version.

Recommended instruction facts include:

- Opcode, raw bytes, consumed length and decoded operands.
- Logical program offset and resource-file offset.
- Read extent and scratch/lookahead bytes where these exceed consumed length.
- Operation name drawn from E51's complete opcode contracts.
- Effective branch target and predicate, including raw encoded displacement.
- Effects on actor fields, signal slots or frame state.
- Whether execution blocks, what releases it, and the eventual resume location.
- Source hash and native routine anchors as explicit provenance.

These additional fields are a proposed ACT contract, not fields automatically supplied or semantically validated by fDisBull. The current arbitrary `facts` dictionary can carry them. Use `inventory/opcode-contracts.json` for complete meanings: the shorter, older label table in `animation_tokens.py` predates some E51 semantic work.

The runtime needs actor/program state, visibility and suspension, position/motion, frame selection and cadence, blocked PC and deadlines, shared signals, draw ordering and deterministic host inputs. The existing E51 model already implements bounded versions of these behaviors using a 64 KiB data segment. A portable reconstruction can introduce clearer state objects only after preserving the documented wrapping, retained fields and cross-record effects that matter to its compatibility target.

A possible future public runtime interface is:

```text
load_actor_resource(original_bytes)
inspect_program(resource, program_index)
start_actor(resource, program_index, scene_context)
tick(logical_tick, host_events) -> actor_state, draw_requests, host_events
```

Those names are design suggestions, not implemented APIs. The interface should accept logical time and explicit external events; sleeping inside an instruction handler would obstruct deterministic replay and multi-actor scheduling.

## 6. A concrete first interpreter target

**DINOMART program 0** is a small real program with no external signal producer or RNG dependency. It contains 28 bytes, 12 instructions and 10 stored opcode values:

```text
1b4f1c01470000100240000441001b12014e001212004e0012178a03
```

| Local offset | Decoded behavior |
| --- | --- |
| 0000 | Select base sprite 79 |
| 0002 | Set frame count 1 |
| 0004 | Set group 0 |
| 0007 | Set draw-order bucket 2 |
| 0009 | Set X to 4 |
| 000C | Set Y to 27 |
| 000F | Show actor |
| 0011 | Set deadline to current tick + 18 and yield |
| 0014 | Hide actor |
| 0016 | Set deadline to current tick + 18 and yield |
| 0019 | Branch back to 000F |
| 001B | Terminal marker, outside the repeated path |

The byte `8A` in the branch means an adjustment of -12 under the original biased encoding. The target is `0x19 + 2 - 12 = 0x0F`; ordinary signed-byte decoding would produce a different result.

I replayed the existing E51 reference model on this original program with a declared one-actor fixture over ticks 0–39. It produced 21 drawing requests and no diagnostic events:

| Tick | Draw during update | State after scheduling |
| --- | --- | --- |
| 0 | None | Visible, PC 0011, blocked until tick 18 |
| 1–17 | Sprite 79 at (4,27) | Same wait |
| 18 | Sprite 79 at (4,27) | Hidden, PC 0016, blocked until tick 36 |
| 19–35 | None | Same wait |
| 36 | None | Visible, PC 0011, blocked until tick 54 |
| 37–39 | Sprite 79 at (4,27) | Same wait |

The timer command retains the PC on the wait instruction. The update later releases it and advances the PC; scheduling then runs following commands. Because drawing occurs before the new visibility change, the sprite is still drawn at tick 18 and reappears at tick 37, not tick 36.

This fresh run executed the existing Python model only. It did not execute original x86, the proposed ACT processor, real DOS time, resource I/O or final-pixel rendering. The complete 40-tick state records, original hashes, token list, command trace and reproducible inline recipe are saved in `evidence/act-model-replay.json`; rerunning that embedded recipe reproduced every non-reproduction evidence field.

The preserved E51 work provides separate historical original-code comparison evidence for all 48 programs under 33 declared clock/signal profiles. It remains bounded evidence, not proof of every full scene or native event schedule.

## 7. Compatibility details to preserve

### Encoding and branches

ACT container fields and sequence lengths are little-endian, while instruction word operands are big-endian. Variable-length F2/F3 instructions can read a next-instruction lookahead byte into scratch without consuming it. Decode using the full bounded program and retain the distinction between read extent and instruction length.

ACT branches use biased byte arithmetic and subsequent PC advancement. Do not let a generic graph builder replace that with signed-8 displacement arithmetic. Targets outside a bounded program or inside an operand need explicit unresolved/boundary status.

### Waiting and phase order

Normal commands advance PC; waiting commands retain it until release. The original updater processes deadline/movement effects, invokes rendering/cycling, then evaluates other waits and advances released scripts. The scheduler then visits actors in context order and executes until yield/error.

A signal written by an earlier scheduled actor can affect a later actor's branch in the same sweep. Already-blocked waits are evaluated through update, not continuously after every signal write. Signals are 16-bit values, not automatically normalized booleans.

### Original quirks and scope

The preserved core has 65 recognized/fallthrough values and diagnostic routes for the other 191 byte values. Only 32 opcode values occur in the supplied stored programs. A first player can declare that narrower asset scope; a full compatibility interpreter must retain the broader established behavior and explicit gaps.

Examples include opcode 66's reader gap, opcode 90's displacement overwrite, F7's scratch/length behavior and high-bit waits whose sign-extended release tests cannot match their positive constants. Do not silently repair them and claim faithful original behavior. Unsupported behavior in a proposed pilot should produce an explicit stop/diagnostic with provenance.

### Connecting to pixels

E52 and E53 provide strong separate sprite, routing and resource-lifetime contracts. However, the ACT model's emitted draw request uses **destination kind 3**, whereas E52/E53's connected software-memory router corpora qualify **kinds 1 and 2**. Their successes do not establish the animation kind-3 route through to final pixels.

The first playback integration must therefore verify that destination mapping and the actual frame composition/palette behavior. Merely wiring the existing model to a convenient drawing function would be a useful prototype, but not yet proof of matching original presentation.

Source: E51 `docs/CONTRACTS.md`, `contract_model.py`, opcode contracts; E52 `router_model.py:route`; E53 rendering and lifetime handoff.

## 8. Role of dot-mode, movement and bounded proofs

Once a pilot exists, dot-mode can let the user observe the original session while the agent controls it. Reusable input sequences and scene-readiness checks can make the route to a target presentation repeatable. They help reach and observe the native scene; they do not supply the ACT instruction semantics.

Use original runtime observation to connect the native dispatcher, the active actor and resource/program offsets. The processor interface does not infer that mapping. Record the source hashes, execution context and event/tick observations explicitly.

The bounded proof API can compare authored expressions for selected arithmetic or guarded transitions under stated assumptions. Useful future targets include biased branch arithmetic, 16-bit signal wrapping or a deadline predicate. Its `proofs.py` explicitly does not lift machine instructions or establish model fidelity. The offline bundle omits the optional Z3 dependency, and no Z3 proof was run for this review.

A favorable model comparison would supplement original-code and replay evidence. It would not establish complete game, renderer, scheduler, filesystem or audio equivalence.

## 9. Recommended implementation sequence

| Stage | Deliverable | Acceptance boundary |
| --- | --- | --- |
| 1. ACT inspection | Dedicated processor over the shared recovered decoder | All 48 stored programs / 679 instructions retain bytes, lengths, lookahead, resource identity and correct known targets |
| 2. Minimal runtime | DINOMART program 0, then its eight-program resource | Match actor state, waits and ordered draw events against preserved original-code fixtures |
| 3. Rendering connection | Verify the animation destination-kind-3 path and compose its frames | Match actual original pixels/palette and relevant state at agreed ticks |
| 4. Education presentation | ABOUT program 0 | Establish native signal-0 timing, F3 frame-list behavior, scene composition and any relevant audio relationship |
| 5. Broader compatibility | Remaining program-bearing resources and native callback cases | Preserve shared signals, actor order, resources and original edge contracts under declared scenarios |

ABOUT is a useful second presentation: its single 74-byte / 20-instruction program waits for signal 0, uses custom F3 frame lists and waits on frame indices. Feeding synthetic pulses is useful for a fixture; identifying the original scene's producer is necessary for original timing.

This sequence lets the reconstruction retain original animation programs instead of manually translating every presentation. It does not require generic VM database support in fDisBull before the first ACT decoder or runtime can exist.

## 10. Evidence and preservation

Fresh work in this review:

- Verified the offline archive and all 14 supplied payload checksums.
- Distinguished the current embedded wheel from the older same-version wheel/source.
- Inspected the real integrated processor, AGI, native-consumer and proof interfaces.
- Passed 13 authored AGI API fixtures plus generic-dispatch and CLI capability checks.
- Reparsed 57 ACT resources, including 48 stored programs / 679 instructions.
- Replayed one real program through the existing bounded model for 40 ticks; captured 21 draw requests and all intermediate state.
- Recorded exact input/source hashes and saved the complete evidence and review notes.

No current-package full-suite pass, DOSBox gameplay run, live KQ1/PQ1 acceptance, new ACT processor, new shipping interpreter, final-pixel ACT integration or whole-game equivalence is claimed. Independent reviewers repeated some small checks; those repetitions are not added to the fixture counts.

Original game files, prior DinoPark milestones and fDisBull input archives were read without modification. E53 remains the last completed whole-binary research milestone. This is a separate feasibility and integration assessment, not a new declaration of whole-binary completion.

### Evidence archive contents

- This assessment.
- Three focused review notes.
- Raw runtime API probes and complete ACT model replay.
- Input/source hashes, offline payload verification and older-wheel capability record.
- Exact reviewed processor/AGI and related interface sources.
- Selected unchanged E51/E52 contract/model sources and E53 handoff.
- The current embedded wheel and its metadata, bound by SHA-256.
- A per-file manifest.

The complete original game and full runtime bundle remain in their existing saved artifacts; they are not duplicated inside this review.

