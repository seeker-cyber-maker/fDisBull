# Mixed-language u8 handoff: native C -> JavaScript -> native C

## What was executed

A C Node-API addon is compiled to native machine code and loaded in the same
Node.js process as a JavaScript vector operation. This is not a simulation of
C in JavaScript and not a pipe-based subprocess handoff.

For inputs x and k, each an unsigned integer in 0..255:

1. Native C calculates a = (3*x + 7) modulo 256.
2. JavaScript constructs Uint8Array([a, k]).
3. JavaScript calculates b = (vector[0] + vector[1]) modulo 256.
4. Native C calculates result = b XOR 165.

Example: x=82, k=5 -> native 253 -> JS vector [253,5] -> byte 2 -> native 167.

The scalar transport carrier is a JavaScript Number, not a scalar eight-bit
JavaScript storage type. Every value of the declared u8 contract is represented
exactly. Values are copied, and the JavaScript vector is not passed by pointer
into native code. Each boundary checks that input is an integer in 0..255.
Arithmetic explicitly wraps; input validation explicitly rejects malformed values.
These are separate policies.

## Results

- All 65,536 ordered pairs of the two u8 inputs passed, with stage-by-stage checks.
- 52 malformed-value or argument-count rejection checks passed.
- Omitting the JS wrapping step is detected at the next strict native boundary.
- Results, build identity and source hashes are in results/results.json.

The numerical reference collapses the nested modular additions to
((3*x + 7 + k) modulo 256) XOR 165. It is separate from the executed C/JS stages,
but shares their declared arithmetic specification. This is exhaustive testing
of this small pure value contract, not a general compiler-correctness proof.

## Reproduce

On Linux with Python 3, a C compiler, Node.js and matching Node headers:

```sh
python3 run.py
```

If header discovery fails:

```sh
python3 run.py --node-include /path/to/node/include/node
```

Run an individual case after building:

```sh
node -e 'console.log(require("./pipeline.cjs").run(82, 5))'
```

The tested environment is Linux x86-64, Node v22.16.0 and GCC 14.2.0.
No external package install or network is needed by the runner.

## Relationship to UDL / UIL / UDC

This is a hand-authored integration fixture, not an installed fDisBull UDC.
The contract.json file is illustrative definition data, not canonical UIL syntax.
It demonstrates the proposed mixed-backend execution boundary: one block may
use native code while the next uses JavaScript, as long as adapters preserve
the declared value/effect contract. A production UDC would select backings,
generate/validate adapters, build/link artifacts and supply the orchestration.

No Rust code was run. No performance comparison, shared-memory ownership test,
recovered game behavior, full UDL-to-UDC compiler or automatic block extraction
is claimed. Buffers stay in synchronous JavaScript; the scalar ABI does not
exercise foreign container layouts, pointer identity, concurrency or lifetimes.

## Primary documentation

- Node-API v22.16.0: https://nodejs.org/download/release/v22.16.0/docs/api/n-api.html
- ECMAScript Number semantics: https://tc39.es/ecma262/multipage/ecmascript-data-types-and-values.html#sec-ecmascript-language-types-number-type
- ECMAScript typed arrays: https://tc39.es/ecma262/multipage/indexed-collections.html#sec-typedarray-objects
- Rust wrapping arithmetic (design comparison, not an executed stage): https://doc.rust-lang.org/std/primitive.u8.html#method.wrapping_add
- Canonical ABI design precedent: https://component-model.bytecodealliance.org/advanced/canonical-abi.html
