# DinoPark E47: mechanics closeout, exact sample decoding and media handoff

27 October 2026. This is a consolidated mechanics baseline and a first media
recovery checkpoint, not a complete graphics/audio recreation. Lab 0.8, the E38
importer, production Swift, original inputs and remote repositories are unchanged.
UIL, decompiler and runtime-language design remain with their existing owner.

## Completed result

* Reader edition **0.3** integrates the supplied 0.2s guide with E34-E46 findings
  and qualifications. This is editorial consolidation, not a rerun of every
  historical claim or an independent review.
* A dependency-free decoder reproduces **all 44 original ABT samples**, totaling
  **636,978 output bytes**, plus **200 constructed valid cases**, against original
  decoder instructions through a disclosed segment-access adapter. Zero mismatches
  in output bytes, returned length or the tested output guard.
* A fresh original-DOS route confirms scene music selection and five DinoMart
  sample descriptors, including **CRACKLE's rate change from 22,000 to 30,000**.
  The final accepted route has **22 assertions**, including source/copy integrity
  and process cleanup. There is no checkpoint restoration or target-memory edit.
* A source-bound inventory covers **133 media files**, and a separate 16-record
  event/interface map preserves inherited state, clock, randomness and completion
  obligations. Neither is a claim to have decoded all animation or music behavior.

## 1. Close the mechanics branch at an explicit boundary

The 0.3 reader retains the established rules and original quirks while removing
stale blanket statements that live auctions, rendered endings and score writing
have never been exercised. It integrates the two staffing OK boundaries,
detail-versus-outer cancellation, quarterly shop restocking, no-room rejection,
auction pen rearrangement, seller notice/credit order, actual name entry and
lossless-save/import qualifications.

The major corrected interpretation is E21's auction "animal expense" label.
E44 showed that the hammer updates DS:585A, current shopping-visit expenditure,
not the monthly animal-expense history. Its checked fifteen history arrays stayed
unchanged through street entry. E45 seller proceeds, in contrast, reach the
sale-income history. The consolidation does not normalize this inconsistency.

Historical reports remain unchanged. Their source hashes are indexed. This
compact package includes reports, not the entire earlier raw grids, source
probes or multi-megabyte snapshots. Those remain in their original checkpoint
packages. The guide's new editorial state does not imply a new Lab or Swift
implementation, a successful independent campaign, or optimal strategy.

The remaining mechanics qualifications are retained: one 48-byte save block,
partly interpreted fields, explicit unsaved session requirements, the reported
restore discrepancy, untested route variants and separately defined strategy
objectives. These do not require restarting settled formula discovery before
working on media.

## 2. Sound-sample bytes are now directly recoverable

The original decompressor begins at static **1000:0E50**, with helpers at
0F2E, 103B and 10DE. The input carries decoded length, nominal rate, packed-group
size, two still-uninterpreted header fields and an initial sample. Subsequent
packets are literal sample resets, previous-sample repeats or packed delta codes.
See [the format specification](ABT-FORMAT.md) for the exact bit order and arithmetic.

The signed-byte delta table matters. In a four-bit group at step 16, a nominal
+128 entry wraps to -128 before accumulation and saturation. The Python decoder
preserves that behavior instead of silently widening it.

### Original-instruction comparison

The verifier authenticates the supplied executable before execution. It compiles
an inherited local Linux x86-64 LDT bridge, then runs the original arithmetic and
control flow. All 44 original inputs match byte-for-byte. A separate set of 200
constructed valid inputs exercises all four modes, all sixteen steps, boundary
sample levels, absolute packets, repeats and the initial-only case. Those inputs
are synthetic conformance cases, not additional original sounds.

The probe checks the returned output count and that every remaining byte of its
64 KiB output buffer keeps its guard value. It is not an exhaustive proof of
arbitrary malformed-input behavior; malformed cases go only to the strict new
Python codec, not to the historical decoder.

**Adapter disclosure:** the real-mode routine writes a temporary delta table
through CS. Under this protected-mode bridge, CS cannot be written as a data
segment. Fifteen guarded CS segment overrides are therefore replaced in the
private execution buffer by GS overrides pointing at a writable alias of that
same buffer. Arithmetic and branches remain original; the source EXE is unchanged.
The initial attempt without that adapter failed. A calibration note records it;
the original failed executable and a complete crash trace were not retained.
This is adapted original-instruction execution, not an unmodified DOS environment.

There is no claim of audible waveform, driver, mixer or completion-timing
identity. WAV export uses mono unsigned 8-bit samples at the nominal header rate.
No original or decoded audio asset is distributed in this packet.

## 3. A real scene changes the resource's nominal playback rate

Static inspection of DinoMart's initializer registers EGGCLAMP, EGGDROP,
SPLOIT22, CRACKLE and SHORTMTR via the original sample loader. It then obtains
CRACKLE's rate, adds **8,000** at `334B:2361`, and calls the rate setter. The
registration/getter/setter references are in the original window
`334B:22F2..236D`; the getter/setter entries are `1862:0673` and `1862:06AD`.

A fresh original-game run loaded the supplied April park through OLD GAME,
entered DinoMart through its actual control, observed its settled catalogue and
sample table, then left through its normal exit. It used real rendering, sound
configuration and input, without native checkpoints, restores, low-level
stepping, execution breakpoints, guest edits or substituted game callbacks.

| Sample | Decoded bytes | Header rate | Live playback-rate word |
|---|---:|---:|---:|
| EGGCLAMP.ABT | 3,328 | 11,000 | 11,000 |
| EGGDROP.ABT | 3,072 | 11,000 | 11,000 |
| SPLOIT22.ABT | 8,128 | 22,000 | 22,000 |
| CRACKLE.ABT | 28,416 | 22,000 | **30,000** |
| SHORTMTR.ABT | 12,992 | 11,000 | 11,000 |

The live sample registry at DS:8D1C uses 16-byte entries; the observed decoded
count is at +4 and playback-rate word at +10. These observations are linked to
the source loader order, not inferred from a screenshot or filename alone.

On returning to the street the registry contains BIPLANE (9,856 bytes / 11,000)
and ROOSTER (32,128 / 22,000), rather than the five DinoMart samples. This is a
scene resource lifecycle observation, not proof of every trigger within it.

### Music selection is also scene state

The helper at `1B29:03D6` uses the current context to index DS:3C8B, selects among
six resource pointers at DS:3C71, and compares its cached selector at DS:3C89.
The six resource names are DINO5A, DINOCITY, DINOFKEY, EXTINCT, DINOPARK and AUCTION,
all XMI. The seventh supplied XMI is MUSICTST; not being in this six-pointer table
is not proof that it is globally unused.

The fresh run observes these settled contexts:

| Context | Observed selector | Table-linked resource |
|---|---:|---|
| Title menu, context 18 | 1 | DINOCITY.XMI |
| Main street, context 1 | 0 | DINO5A.XMI |
| DinoMart, context 8 | 1 | DINOCITY.XMI |
| Return to main street | 0 | DINO5A.XMI |

No note stream, soundtrack or musical synthesis is reconstructed here. The
other table entries are statically indexed candidates, not newly executed scenes.

## 4. Inventory is not an animation-coverage percentage

| Family | Files | What this pass actually checks |
|---|---:|---|
| PIC | 25 | 166 images decoded to exact expected dimensions and packet boundaries; palette/index hashes retained. This corroborates the inherited decoder rules. |
| ACT | 57 | 55 UNC2 directories with 1,258 records checked. BUS.ACT and PEOPLE.ACT use UNCS and remain undecoded by this script. |
| ABT | 44 | New exact sample decoding and original-routine comparisons described above. |
| XMI | 7 | IFF chunk lengths, nesting and padding checked, not MIDI events or synthesis. |
| **Total** | **133** | Not 133 complete runtime behaviors. |

The executable index also records **106 literal media names** and **93
relocation-backed literal load-call candidates** to the inspected loader entries.
Formatted filenames, indirect callers and external names require separate
resolution. A missing direct reference does not prove an unused resource. A
sprite directory record is not automatically one complete animation.

The 16-record [media/event map](MEDIA-EVENTS.md) links resources and triggers to
known state changes, completion, clocks and RNG. It incorporates earlier sound
busy/wait semantics, alternate Animation paths, vegetation initialization,
bank visitors, auction information, pending transactions and side-game logic.
It is a project evidence handoff, **not** a UIL specification or implementation.

## 5. Calibration and friction

The first live checker assumed the settled title menu was context 0. The actual
menu was context 18, with music selector 1. The checker failed correctly; its
receipt and source are retained. Context labels were corrected rather than
changing the target to fit a guess.

The first otherwise passing descriptor route captured DinoMart after its sample
registry and controls existed but before its actual catalogue redraw. That
black capture is retained and labelled post-load, not a completed interface.
The final driver waits for a source-bound footer signature from E46 together
with scene/control conditions. Its accepted image shows the original catalogue.
The original descriptor result was not invalidated, but its visual claim was
narrower. This is the known state-versus-display boundary, not a new tool defect.

Screenshots explicitly disable hooks and remain passive relative to the
compared state; bounded waits are separately logged. The final live route
passes 22 assertions and reaps its emulator process. The earlier runs are not
added to those counts or treated as independent confirmation.

No new essential fDisBull capability was required. The E45 auction-restoration
stall is neither fixed nor retested here; the fresh-run approach avoids it.

## 6. Reproduction

```
python -m unittest discover -s tests -v
python scripts/media_inventory.py /path/to/owned/game --out /new/inventory
python scripts/verify_abt.py /path/to/owned/game --out /new/native-audio
python scripts/abt_codec.py /path/to/owned/SAMPLE.ABT --output SAMPLE.wav

/path/to/qualified/venv/bin/python scripts/verify_media_live.py \
  --game-dir /path/to/owned/game \
  --backend /path/to/qualified/dosbox-x-offline \
  --output /new/private/run --evidence /new/shareable/evidence

python tools/build_dinopark_reader.py
```

The codec and unit tests use standard-library Python. Native verification also
requires compatible Linux x86-64, GCC and process-local LDT support. The live
route uses the existing CPython 3.13.5 / fDisBull 0.19.0 source `57824bd`, matching
native ELF `367c554a2405d50a929f64b107476084bf2fae2c266b240a7419d40ba646b0ad`,
and genuine supplied offline dependencies/private loader. This is pinned reuse,
not a new latest-release check or sealed-delivery certification. Reader building
uses `markdown-it-py` and is independent of the game runtime.

All 191 original files and the final live working copy are unchanged. Native
verification additionally checks the original EXE and all ABT input hashes.
The package contains authored source, reports, hashes and selected original-DOS
captures, but no original executable/resources/saves, generated full-program C,
private database, native state, decoded sound, dependency library or font.

See the delivery receipt for exact format, browser, extraction, unit and native
reproduction checks. These checks are not new independent experiments. No full
Lab regression is rerun for this media-only and editorial checkpoint.
