# DinoPark E53 — Resource Lifetimes and Connected Rendering

## Outcome

E53 establishes a larger original-code execution path than E52: conventional
allocation creates a real resident handle; the original sprite caller locks
it, renders through original software routines and releases it; the original
free routine then releases the allocation and coalesces its heap extent.
Every one of the 421 inherited sprite scenarios passes this sequence. The
pixels match E52, including its clipped, fast and rejected cases.

Separate experiments establish bounded contracts for the handle services,
conventional heap operations and seven file wrappers. They preserve several
original behaviors that a cleaned-up reconstruction could otherwise erase:
Boolean pinning, validation after reload, partial mutation on free failure,
low-word-only clearing after product allocation, register restoration quirks,
and shared-buffer string reads with ignored return values.

The work is preserved as a new milestone. All 191 original inputs, 325 recorded
E52 working files and six E47–E52 archives were rehashed unchanged.
The full unchanged E52 ZIP is also embedded under `baseline/E52/`. Earlier
guide, Lab, Swift and milestone artifacts remain separate preserved work.

This is a bounded research milestone. The whole binary remains unfinished and
no fDisBull v0.20 build has been executed or validated.

## Accepted evidence

| Family | Accepted corpus | Original behavior exercised | Result |
| --- | --- | --- | --- |
| Handle services | 1,088 fixtures, 1,121 calls | Lock, availability gate, capacity query, release and header clear | 0 mismatches |
| Conventional allocator | 208 fixtures, 1,103 calls | Allocation, pinning, release, splitting, compaction, discard, statistics and selected initialization | 0 mismatches |
| Resource-file wrappers | 611 cases, including 242 actual string records | Indexed strings, open, close, read, write, length and seek | 0 mismatches |
| Resident sprite chains | 433 cases | Original callers, actual resident lock/release and original software drawing | 0 mismatches |
| Allocated sprite lifetimes | 421 sequences | Original create → caller/draw → free/coalesce | 0 mismatches |

The last two rows reuse the same 421 E52 scenarios; the resident family adds
twelve pin-state cases. They are separate execution experiments, not 854 unique
sprite inputs. The original asset-wide sprite evidence from E52 remains in
the preserved E52 package and is not recounted as new E53 coverage.

All new execution uses Unicorn 2.1.4, a complete authenticated MZ image, the
ordinary relocation table, and zero opcode patches. These are instruction
emulation comparisons, not native DOS/VGA runs. The pinned DINOPARK.EXE is
268,480 bytes with SHA256
`2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`.

The comparison engine maps a 0x110000-byte image. The handle, allocator and
resource matrices compare all 1,048,576 nonstack bytes after each original call
or wrapper case. The sprite draw oracle additionally excludes only 34 known
renderer scratch bytes and compares 1,048,542 bytes. Every CPU write is also
checked against a bounded set of allowed stack and fixture locations. This
combines final-state comparison with detection of writes outside each declared
contract; it does not claim a full independent oracle for every write's order.

Canonical receipt paths and their hashes are in `inventory/PROGRESS.json`.
Detailed semantics, source files, original-byte anchors, fixture definitions,
per-case receipts and independent reviews accompany this report. Earlier
calibration directories are explicitly historical and excluded from totals.

The raw instruction counters are emulator code-hook visits. The handle counter
of 27,094 includes 139 intercepted adapter entries, leaving 26,955 original-body
visits. The resource counter of 93,635 includes 1,917 intercepted stream/fatal
entries, leaving 91,718 original-code visits. The original receipt field names
are retained and clarified in `evidence/counting/COUNTING-NOTES.json`. REP can
produce repeated visits; none of these counters is a native retired-instruction
measurement. Original-byte coverage already excludes intercepted entries.

## 1. Resident handles and validation order

### Layout and pin state

A handle occupies five bytes. Its first word is an offset, its second a data
segment, and its final byte contains flags. For a resident allocation, the data
offset is zero and the heap header is the preceding paragraph. The header
contains a previous-header segment at +0, extent size in paragraphs at +2,
owner handle offset at +4, and flags at +8.

| Flag | Observed role |
| --- | --- |
| `80h` | Allocated record/block |
| `20h` | Pinned resident allocation |
| `40h` | Discardable allocation |
| `08h` | Nonresident state requiring reload in the ordinary lock path |
| `10h` | Unavailable/discarded condition recognized by the availability gate |

`3EE1:0688` sets `20h` in both the resident handle and its heap header.
`3EE1:0797` clears it in both. These services do not maintain a nesting count.
Two locks followed by one release leave the allocation unpinned. The connected
sprite experiments also show that a draw's release clears a pin which existed
before the draw. Other flag bits are preserved by these resident operations.

This distinction matters when reconstructing ownership. A reference-counted
replacement would have different observable behavior, even though it might
look more defensive. E53 records the actual state transitions without assigning
an unsupported intended ownership policy to the original callers.

### Three different validation policies

The resident lock validates only that the handle segment equals `DS:7424` and
its unsigned offset is below `DS:7428`. It does not validate five-byte alignment
or an allocation bit on that path. Odd, high and wrapping offsets are included
as explicit adversarial fixtures; they are not claimed to be allocator-produced
records.

The ordinary lock reads the nonresident flag before that validation. On the
reload path it can allocate, call a selected restore routine, rewrite the
record, and write the new header's owner offset before discovering an invalid
pool segment or record offset. It then reports error 4 and returns null while
retaining those earlier writes.

`3EE1:074B` behaves differently: if `08h` or `10h` is present, it returns null
before validating the pool or setting an error. Otherwise it enters the common
resident lock tail. An ordinary `0688` lock ignores `10h` when `08h` is clear.

`3EE1:0766` performs no pool validation. If the record is resident, it reads its
header's paragraph count and returns:

`((header_paragraphs - 1) & 0xFFFF) * 16`

A zero paragraph count therefore yields `000F:FFF0`; a one-paragraph extent
yields zero payload capacity. Flag `10h` does not block this query.

### Callback and direction-flag details

On reload allocation failure, `0688` sets error 3. Its optional error callback
loads a far argument with `LES DX,[BP+8]`: the original handle segment becomes
the callback offset, and the next caller stack word becomes the callback
segment. This differs from passing the original far handle at `[BP+6]`.

Release saves ES in CX. On an invalid-handle path, it may invoke the error
callback and then restore ES from CX. A callback which changes CX changes the
returned ES. The tests deliberately clobber callback registers to establish
that boundary behavior; they do not claim that the game's real callback
violates its expected register convention.

The small `067A` header-clear helper uses eight `STOSW` operations without
issuing `CLD`. Both directions are tested. With DF clear it zeros a normal
16-byte header. With DF set it writes the word at offset zero and then wraps
backward through offsets `FFFEh..FFF2h`.

The five selected handle bodies span 377 original bytes. Across the bounded
fixtures, 373 execute and four skipped one-byte NOPs remain. That is a coverage
description for the selected instruction bodies, not proof of their entire
input space. The 64 nonresident dispatch fixtures adapt allocation and restore;
their evidence covers dispatch, ordering and lock-side writes, not actual
backing-store data or eviction.

See `docs/HANDLE-CONTRACTS.md` and `evidence/handles/accepted/RESULT.json`.

## 2. Conventional allocation and lifetime

The allocator matrix includes 114 constructed allocation → lock → lock →
release → free lifetimes, plus eighteen sequences which begin with the original
initializer. Only those initialization cases supply two modeled DOS AH=48h
responses: a largest-block probe and successful conventional allocation.
The subsequent conventional heap operations execute original code.

### Placement and coalescing

`3EE1:011B` scans the five-byte table from its saved cursor, wraps at the
exclusive end, and selects a record whose allocation bit is clear. The heap
request includes one paragraph for the header. Placement walks the heap from
its circular cursor and chooses the first suitable unallocated extent.

Exact fits consume the entire extent. A one-paragraph remainder is also
absorbed; it is not exposed as a header-only free block. Larger remainders get
a zeroed header, adjusted links, and the remaining paragraph count. Release
can merge with a free predecessor, a free successor, or both, and updates the
heap cursor and neighboring previous-header link.

Compaction moves unpinned blocks and updates the owning handles' data segments.
Across a pinned barrier it chooses the largest later block which fits the
hole; equal-size candidates favor the later address. Fixtures cover overlapping
downward copies, multiple moves, exact and split remainders, ties, pins, and a
copy large enough to exercise the original segment-normalization helper.

Discard considers `40h` and refuses a pinned block. It marks an eligible
handle with `10h` and releases its extent, retaining the old pointer fields.
A discarded record is therefore different from an ordinary free handle slot.

### Failure paths have observable side effects

Resident handle release `047C` clears the record's flags before checking that
the heap header's owner offset matches the handle. An owner mismatch sets
error 6 while leaving the heap block allocated. The record is already marked
free and its pointer fields remain stale. A reconstruction which makes this
failure atomic would change the original behavior.

After finding an available handle slot, the oversized-input branch in `011B`
rejects requests at or above 1 MiB. It takes that branch after an extra `PUSH DI`
and rejoins an epilogue which does not balance that push in the usual way.
The tested calls still reach the correct far-return sentinel and return
AX=DX=0 with the correct final SP, but DI receives the candidate slot, SI receives
the caller's saved DI, and ES receives the caller's saved SI. This is preserved
as an original calling-contract quirk.

The near-overflow size interval `FFFF0h..FFFFFh` remains unqualified. The code's
paragraph arithmetic must not be silently replaced with an assumed checked
allocation policy.

### Product allocation clears only the low word

`3EE1:0269` requests the complete product of two input words, but its clearing
loop initializes CX from only the low product word. After the first
`REP STOSB`, the high-word loop never reloads CX or advances the payload segment.

| Inputs | Bytes allocated/requested | Bytes cleared in the original routine |
| --- | ---: | ---: |
| `255 × 257` | 65,535 | 65,535 |
| `2 × 32768` | 65,536 | 0 |
| `3 × 21846` | 65,538 | 2 |

These results come from complete original-routine execution against nonzero
payload patterns and independent byte-state expectations. The suite includes
ten product cases and a focused test which distinguishes low-word clearing
from a corrected full-product implementation.

Twenty-one allocator entries receive scoped descriptions. Six remain static
only and `0A6F` is qualified only for its no-backend early failure return.
Backing-store eviction, resize and shutdown are not promoted to complete
contracts by the successful conventional-memory tests.

See `docs/ALLOCATOR-CONTRACTS.md` and `evidence/allocator/accepted/RESULT.json`.

## 3. Original allocation connected to original drawing

E52's two software sprite callers used adapted successful lock/release services.
E53 first replaces both adapters with actual resident service execution, using
the same independent E52 routing and pixel expectations. All 433 cases pass:
337 draws and 96 rejections. The twelve new cases specifically test existing
pin bits and other flag-bit preservation.

E53 then begins from a free conventional extent, invokes original `011B`, runs
the original sprite caller, and invokes original `047C`. This second corpus
contains exactly the original 421 E52 scenarios. All pass, with the unchanged
classification of 230 clipped draws, 95 fast draws and 96 rejections. Every
pixel hash matches both the resident E53 run and the E52 result.

No runtime service is intercepted in either connected corpus. The lifecycle
sequence compares allocation state, drawing state and released state separately.
The reference retains independent heap, global, handle, descriptor and pixel
expectations throughout. Only the renderer's explicitly excluded scratch bytes
are adopted from observation before free, so free must preserve them too.
Deliberate pixel and free-header corruptions were detected; an earlier failed
drawing comparison cannot be hidden by a later successful release.

The ACT bytes are synthetic fixture data supplied before allocation, and the
heap begins initialized. This does not execute an ACT file loader or assert
that the original game allocates/frees each resource around every draw. It
establishes the compatibility of the original conventional allocator, handle
services, callers and software renderers under the documented fixture.

See `docs/RESIDENT-ROUTER-CONTRACTS.md`, `docs/ALLOCATED-ROUTER-CONTRACTS.md`,
and the two accepted router receipt directories.

## 4. Indexed strings and file wrappers

The seven W03 entries at `295E` are file wrappers rather than the handle manager.
`295E:000D` opens `strings.dat`, seeks to `uint16(index*4)`, reads a four-byte
little-endian absolute text offset, seeks there, and requests up to 255 input
bytes plus a terminator in the configured shared far buffer.

The original STRINGS.DAT is 13,445 bytes. Its first text offset is 968, yielding
242 four-byte index entries. All 242 records were compared with independent
parsing. The accepted matrix also covers index multiplication wrap, embedded
NULs, CR/LF, long lines, EOF, stale buffers, read-product truncation, descriptor
sign extension, offset wrapping and fatal open/close/seek paths.

Several behaviors require exact preservation:

- Indices separated by `4000h` can select the same index-table entry because
  multiplication wraps at sixteen bits. The wrapper has no index-count check.
- The routine ignores the offset-read and line-read return values. At EOF,
  the old shared buffer can remain and its trailing LF can still be removed.
- It removes LF only. CR from CRLF remains before the new terminator.
- An empty string makes the final-character check address the preceding
  segment offset. If that byte is LF, the original writes NUL there.
- The general read wrapper converts the request to byte units using the low
  sixteen bits of `size * count`. The length wrapper sign-extends the byte at
  FILE+4; all 256 values and twelve wrapping-offset fixtures are tested.

The wrappers, their nested calls, original `strlen`, and original `sprintf`
formatting execute unchanged. Seven CRT stream functions remain explicit
adapters. The fatal UI/exit entry is captured and stopped, never made to return.
Consequently, the eleven terminal cases establish the wrapper's outgoing fatal
request and formatted message, not the full exit/cleanup implementation.

The selected wrapper bodies total 595 bytes. The fixtures execute 551; the
remaining 44 consist of seven avoided stack-guard calls and post-fatal stack
adjustments. The static map also records 337 relocation-backed far callers,
which are call-site evidence rather than proof of runtime reachability.

Partial four-byte index reads, actual CRT/DOS filesystem behavior, invalid far
pointers, long-filename formatting overflow and complete fatal cleanup remain
outside this bounded result. See `docs/RESOURCE-CONTRACTS.md`.

## 5. Review, preservation and inventory

Independent reviewers checked original bytes and the contracts rather than
accepting implementation summaries alone. They reran the complete 208-fixture
allocator matrix and complete 611-case resource matrix; the canonical outputs
were byte-identical. They also reviewed every handle and router receipt,
executed focused original-code cases, and used deliberate faults to check
oracle and write-guard sensitivity.

Review found two defects in the new inventory evidence gate. Omitted
conditional rejection assertions could previously pass, and an unfamiliar
qualification label defaulted to a stronger execution class. Both were
reproduced and fixed. The final gate requires rejection assertions for rejected
draws and accepts only explicitly known qualification labels. Thirteen full
builder fault injections now fail with `EvidenceError` before an output
directory is created. Their pre-fix evidence is retained as calibration history.

The final E53 focused suite contains 55 tests. With the pinned original inputs
supplied, all pass with zero skips. The independent inventory rebuild reproduces
all twelve generated files byte for byte; final delivery also verifies a fresh
extraction and rebuild, with its exact results in the separate delivery check.

| Accounting item | E53 state |
| --- | ---: |
| Candidate identities retained | 927 |
| Prior routine-contract records retained exactly | 81 |
| E53 contract records appended | 35 |
| Total routine-contract registry records | 116 |
| Physical ledger ranges | 1,948 |
| Bytes covered by the physical partition | 268,480 |
| Remaining indirect physical sites | 152 |
| Remaining indirect observations | 155 |
| Actual undecoded ledger-category bytes | 18,480 |
| Physical reclassifications / newly resolved indirect sites | 0 / 0 |

The 35 E53 records retain ownership: 26 W10 runtime entries, seven W03 file
entries and two W08 routers. Their evidence classes are 20 bounded direct,
six bounded transitive, two bounded connected, one early-return-only and six
static-only. They are not 35 universally closed functions.

The physical ledger and indirect lists deliberately remain unchanged. E53
adds semantics and connected execution evidence; it does not derive a new
whole-binary traversal or a semantic coverage percentage. All inherited queue
fields and prior contract objects remain intact.

## 6. Next work and v0.20 preparation

The strongest next target is actual backing-store behavior: original eviction
at `3EE1:0A6F`, backend descriptors and link helpers, followed by a real restore
path through `0688`. The resident lifetime corpus now provides a stable
comparison baseline for replacing those remaining adapters one boundary at a
time. Resize `0891` / `0A21`, shutdown, actual resource loading, and scene-owned
lifetimes remain separate obligations.

For fDisBull v0.20, these are concrete original-behavior regression targets:
packed five-byte handles, validation after reload, shifted callback arguments,
callback-sensitive segment restoration, oversized saved-register shuffling,
low-word-only product clearing, partial free failure and truncating stream
arithmetic. E52's CS-sensitive rendering, computed targets and glyph contracts,
and E51's animation contracts remain available in the preserved milestones.

No release build has been run here. When available, pin its exact build and
compare fresh tool output against the saved original bytes and contracts.
Keep tool discrepancies separate from original-game quirks and from any fixture
or reference-model corrections. `START_HERE.md` carries the complete continuity
instructions, and `docs/REPRODUCE.md` provides the commands.
