# Ordered work plan

Every candidate has one primary owner; these are research assignments, not code changes.

## W00: Address and boundary reconciliation

Priority: 0. Primary candidates: 0.

Scope: Cross-cutting inventory integrity.

Anchors: `MZ 1000:0000`, `1984:11CA`, `2984:04F4`, `2A4E:000A`

**First action:** Compare each conflicting byte window with its incoming direct edges and original caller context. Do not run a whole-game replay.

**Completion:** Review all six current decoding conflicts and five legacy-only entries; establish correct CS aliases, instruction starts, embedded tables and callable/shared-body relationships. Rebuild ledger with no unrecorded overlaps.

Dependencies: none

## W01: Animation interpreter, frame cycling, motion and signals

Priority: 1. Primary candidates: 36.

Scope: 2984/2A4E and ACT programs.

Anchors: `2984:0122`, `2984:04F4`, `2984:0B5A`, `2984:0C66`, `2A4E:000A`, `2A4E:0169`, `2A4E:0DCC`

**First action:** Resolve used-but-unclassified 01 and 04; then 05/06/07 and F2/F3 with the actual cycle update. Reuse E48 operand and raster tests.

**Completion:** Contract every dispatched opcode and default branch, including opcodes absent from supplied assets; account for renderer-owned cycling, motion, deadlines, signals and suspension. Compare all 48 supplied programs within explicit scene/clock assumptions.

Dependencies: W00

## W02: Renderer, surfaces, clipping, palette and fades

Priority: 2. Primary candidates: 44.

Scope: 1907/191D and alternate 1984 context.

Anchors: `1984:11CA`, `1984:1248`

**First action:** Separate the qualified software blit from wrapper clipping and VGA paths; target the 0x7000 normalization boundary and scene composition ordering.

**Completion:** Specify clip edges, mirror/source coordinates, destination preservation, segment normalization, palette changes, fade steps and composition order. Give hardware I/O routines explicit input/output and timing contracts, not ignored stubs.

Dependencies: W00

## W03: Resource and actor lifetime

Priority: 2. Primary candidates: 7.

Scope: 295E and resource-facing helper calls.

Anchors: `295E:000D`, `295E:0187`, `295E:01CD`

**First action:** Explain the high-fan-in 295E helper cluster before repeatedly substituting allocation/resource adapters.

**Completion:** Map creation, ownership, lock/unlock, load/free and failure behavior; distinguish PIC/ACT/sequence handles, cached descriptors and resource replacement. Names below are triage candidates until body inspection.

Dependencies: W00

## W04: Native park actors and scenery

Priority: 3. Primary candidates: 48.

Scope: 23C5.

Anchors: `23C5:06D6`, `23C5:081A`, `23C5:17E7`, `23C5:19C5`, `23C5:3517`, `23C5:3911`

**First action:** Trace one ordinary pen actor through initialize/update/draw and one bus/person path; bind results to already decoded ACT files.

**Completion:** Account for dinosaur/visitor/vehicle/scenery state machines, source-sprite choices, movement, visibility, priority, clock and RNG consumers, including Animation alternatives.

Dependencies: W01, W02, W03

## W05: Native shop, bank, office and auction presentation

Priority: 3. Primary candidates: 111.

Scope: 2D0A/302C/334B/37B0.

Anchors: `334B:1402`, `334B:1D1E`, `334B:1D66`, `334B:2775`, `37B0:0563`, `302C:02F0`, `2D0A:2F03`

**First action:** Ordinary arrival state transitions and sample calls, then Vegasaurus and auction actor/hammer completion. Do not redo bid arithmetic.

**Completion:** Contract arrival/gag/employee/bank/auction/sidegame phases and sound triggers; preserve established transaction boundaries, shared RNG and pause behavior. Reuse known finance and stock rules.

Dependencies: W01, W02, W03

## W06: Startup, title, help/education, ending and demo playback

Priority: 4. Primary candidates: 68.

Scope: 1C6A/27E5/3619/3742/2B51.

Anchors: `1C6A:0429`, `1C6A:07C4`, `27E5:1019`, `3619:1061`

**First action:** Trace the post-payload INTRO.DMO reader and its consumer; build a record grammar, then compare one complete playback interval.

**Completion:** Explain title/credit/help/ending routing, resource changes and completion; decode all remaining INTRO.DMO input records with seed, timing, stop and input semantics.

Dependencies: W01, W02

## W07: Sound and music service plus external-driver contracts

Priority: 4. Primary candidates: 25.

Scope: 1862 and external driver boundary.

Anchors: `1862:03D8`, `1862:0452`, `1862:0498`, `1862:0544`, `1862:05F7`, `1862:0673`, `1862:06AD`, `1862:0955`, `1862:0A15`, `1862:0A34`

**First action:** Explain busy/wait and cleanup ownership against the existing restore-stall evidence; decode XMI events without assuming samples and music share one completion rule.

**Completion:** Map every main-EXE audio wrapper, XMI selection/lifecycle, sample rate/busy/stop/cleanup behavior and callbacks. Inventory dynamically loaded driver binaries separately; EXE closure is not driver closure.

Dependencies: W00, W03

## W08: Common loop, input, controls, text and dialogs

Priority: 3. Primary candidates: 155.

Scope: 1B29/1D88/1F0B/20AE/2B5D.

Anchors: `1B29:04AA`, `1B29:05C7`, `1B29:1306`, `1B29:131C`, `2B5D:041B`

**First action:** Resolve common-loop indirect calls and high-fan-in UI helpers; use known E41-E44 readiness counterexamples as acceptance cases.

**Completion:** Specify callback order, hit testing, focus, control registration/destruction, text/layout and modal returns. Match semantic state, control readiness and completed display as distinct phases.

Dependencies: W00, W02

## W09: Economy/persistence contract closure, not formula rediscovery

Priority: 5. Primary candidates: 40.

Scope: 38FF.

Anchors: `38FF:00CC`, `38FF:055F`, `38FF:211F`, `38FF:4827`, `38FF:4CA3`

**First action:** Translate established evidence into routine contracts and flag only uncovered exits/data consumers.

**Completion:** Attach E1-E47 receipts to every relevant instruction region/exit, reconcile corrected names, and cover genuinely missing branches. Retain E44 auction-history correction and unsaved-session boundary.

Dependencies: W00

## W10: Compiler/runtime, arithmetic, memory, files and hardware support

Priority: 5. Primary candidates: 392.

Scope: 1000/1693/17xx/3Exx and otherwise unassigned code.

Anchors: `1000:0000`, `1000:172F`, `1000:31FF`, `3EE1:0A21`

**First action:** Verify high-fan-in stack guard/arithmetic/copy helpers once; explain the code beyond the old heuristic cutoff, then work outward by callers.

**Completion:** Classify every support routine by exact behavior or reproducible library signature, including arithmetic signedness, stack/heap, errors and OS/hardware interactions. Merely naming a familiar runtime helper is insufficient.

Dependencies: W00

## W11: Initialized data, tables, flags and all remaining byte ranges

Priority: 5. Primary candidates: 0.

Scope: DGROUP + inline tables + extended header + code gaps.

Anchors: `file 0x00001C..0x00003D`, `DS:C00B`, `file 0x034A00..0x0418BF`

**First action:** Join data-field labels to readers/writers; resolve relocation-backed pointer tables and the largest undecoded code-band gaps.

**Completion:** Every range gets a layout/meaning or a justified padding/reserved/dead-data classification. Every flag bit and table index is documented; the 48-byte save region and all opaque resource trailers remain explicit until resolved.

Dependencies: W00, W09

## W12: Indirect edges and final closure audit

Priority: 6. Primary candidates: 0.

Scope: All candidate entries, jumps, callbacks and error paths.

Anchors: whole inventory

**First action:** Maintain this cross-cutting queue during every package; at final audit, inspect all residual gaps and unreachable/dead-code claims.

**Completion:** No unclassified file bytes; no unreviewed candidate starts or boundary conflicts; no unenumerated indirect target set without an explicit external contract; every routine has a scoped semantic contract and linked acceptance. Rebuilds reproduce inventory identities.

Dependencies: W01, W02, W03, W04, W05, W06, W07, W08, W09, W10, W11

