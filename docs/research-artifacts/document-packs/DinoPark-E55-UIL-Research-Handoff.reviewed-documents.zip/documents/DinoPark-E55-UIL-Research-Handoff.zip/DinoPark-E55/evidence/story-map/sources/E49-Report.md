# DinoPark E49: whole-binary inventory and explanation plan

**27 October 2026.** This is a static inventory and evidence-indexing pass. No new original-game execution, whole-function proof, or live route is claimed.

## Result

The inventory accounts for **all 268,480 bytes** of the pinned DOS executable in **1,931 contiguous, non-overlapping ranges**. It reconciles two inherited analysis artifacts and a new bounded static direct-call traversal into **926 candidate entrypoints**. Each candidate is assigned to one primary review package. These are candidates, not a proved count of source functions.

**The denominator is now the actual file, not the number of gameplay features or passing tests.** Every byte is represented even when its purpose remains unknown. Structural accounting is not semantic completion.

Target SHA-256: `2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`.

## 1. Physical inventory

| File range, inclusive | Bytes | Classification |
|---|---:|---|
| `0x000000–0x00001B` | 28 | Standard MZ header fields |
| `0x00001C–0x00003D` | 34 | Extended header: not fully interpreted |
| `0x00003E–0x0040E9` | 16,556 | 4,139 parsed relocation entries |
| `0x0040EA–0x0047FF` | 1,814 | Observed zero-filled header remainder |
| `0x004800–0x0349FF` | 197,120 | Startup-to-DGROUP candidate code envelope, including embedded tables and unresolved bytes |
| `0x034A00–0x0418BF` | 52,928 | Initialized DGROUP image: strings, tables, values and buffers |
| **Total** | **268,480** | Exact file length; no appended bytes beyond the declared MZ image |

The DGROUP envelope comes from the relocated entry instruction's segment operand and the following DS initialization. It is not a protected-section boundary. Code can contain data, and an initialized-data region can contain pointers and values whose semantics remain unknown. Zero-filled bytes are not automatically dead or irrelevant. No claim about heap contents created at runtime follows from file coverage.

## 2. Why the old function count was not an adequate denominator

The archived prologue index has **693 rows**. The later lifted C has **920 distinct candidate entries**. Their union is **925**: 688 shared, five only in the earlier index and 232 only in the later lift. A fresh relocation-backed direct-call traversal adds `1000:172F` (`file 0x005F2F`), reaching **926 candidates**. It is an additional indexed entry into a shared arithmetic body, not a new gameplay discovery.

The five legacy-only file entries are `0x004C19`, `0x004DE0`, `0x007204`, `0x007235`, `0x00A3E8`. Reconcile rather than silently delete them.

The old analyzer stopped its candidate code envelope at **`0x034031`**, based on a large-function heuristic. Startup establishes DGROUP at **`0x034A00`**, leaving **2,511 bytes** between those boundaries. The later lift has **31 candidate entries** in this tail. Fresh disassembly at `3EE1:0A21` (`0x034031`) starts with a normal prologue and contains calls/returns. Therefore the older cutoff cannot simply be used to declare all of this region data.

Next-entry ranges are **review buckets**, not verified function bodies. They may split shared tails or contain multiple entry paths and embedded tables. The existing lift also explicitly uses nearest-segment fallback for some CS assignments. The ledger preserves those assumptions rather than upgrading them to proof.

## 3. The concrete remaining queues

| Queue | Current measured size | Meaning |
|---|---:|---|
| Candidate routine entries | 926 | Every one has an address, origins, bucket hash, primary work package and review status |
| Entry buckets with literal code-address references in the scanned reports | 127 | At least some nearby behavior is discussed; not 127 completely explained functions |
| Entry buckets without such a reference | 799 | Evidence-linking/classification queue, not proof that these have never been understood |
| Indirect-control-transfer observations | 160 across 157 physical instruction sites | Calls/jumps whose complete target sets are not resolved by this scanner |
| Conflicting instruction-start pairs | 6 | Require code/data/alias/entry adjudication; not target defects |
| Undecoded ranges within the code envelope | 506 ranges / 19,506 bytes | Could be switch tables, data, skipped code, padding or unseeded routines; no automatic conclusion |
| Data far-pointer candidates | 32 | Relocated words with an adjacent offset pointing into the code envelope; not all are proved callbacks |
| Save-mapped runtime fields overlaid on initialized data | 71 | Inherited schema labels with evidence and original limitations preserved |

The source index retains **63 distinct reports and 329 literal code-address mentions**, including the exact source line and excerpt. This intentionally conservative pass misses module-relative addresses and explanations without literal segment:offset notation. For example, the graph helper at `302C:0BD5` is described in the finance-history report via a local `235A -> 0BD5` reference; it must not be rediscovered merely because this automatic join does not attach the report to its bucket.

The instruction traversal decoded 70,723 CS/file-position observations at 69,036 physical start offsets, covering a union of 177,614 candidate instruction bytes. **This is not an explained-byte metric.** Wrong inherited seeds, embedded data, alias contexts and assumed return paths can produce valid-looking instructions. Six conflicting boundaries are explicitly retained. No percentage of the executable understood is reported.

## 4. Work packages

| ID | Review package | Primary candidate entries | Priority |
|---|---|---:|---:|
| W00 | Address and boundary reconciliation | Cross-cutting | 0 |
| W01 | Animation interpreter, frame cycling, motion and signals | 36 | 1 |
| W02 | Renderer, surfaces, clipping, palette and fades | 44 | 2 |
| W03 | Resource and actor lifetime | 7 | 2 |
| W04 | Native park actors and scenery | 48 | 3 |
| W05 | Native shop, bank, office and auction presentation | 111 | 3 |
| W06 | Startup, title, help/education, ending and demo playback | 68 | 4 |
| W07 | Sound and music service plus external-driver contracts | 25 | 4 |
| W08 | Common loop, input, controls, text and dialogs | 155 | 3 |
| W09 | Economy/persistence contract closure, not formula rediscovery | 40 | 5 |
| W10 | Compiler/runtime, arithmetic, memory, files and hardware support | 392 | 5 |
| W11 | Initialized data, tables, flags and all remaining byte ranges | Cross-cutting | 5 |
| W12 | Indirect edges and final closure audit | Cross-cutting | 6 |

Priority is proposed work order, not confidence. W00, W11 and W12 operate across existing ownership rather than claiming additional routines. The 926 primary assignments sum exactly once; dependency relationships can overlap.

### First focused pass

1. Adjudicate the six boundary conflicts and five legacy-only entries. Confirm CS-sensitive shared entries and the missing arithmetic entry.
2. Follow animation dispatch `2A4E:0169`, scheduling `2984:0B5A` and renderer/cycle routine `2984:0122` together. An opcode's effect may live partly in another callback.
3. Resolve used opcodes **01 and 04**, still labelled unclassified in E48. Then qualify **05/06/07, F2/F3 and frame cadence**, followed by motion and shared signals.
4. Expand from the eight DinoMart programs to BANK/CREDITS, then MALL/MANLEY, then the education sequences. Preserve old qualified cases; reject unsupported operations rather than making them no-ops.

E48 decoded **48 programs, 679 instructions and 32 used opcode values**. Its execution subset covers 11 values in eight DinoMart programs. **21 used opcode values and 40 other programs remain outside that execution qualification.** A decoder-supported opcode is not thereby semantically proved. Dispatch arms for values absent from supplied assets still belong to whole-binary explanation and need their own inventory.

## 5. What counts as explaining a routine

A routine is not closed by a persuasive name, a decompiler listing, or one successful route. Its contract records:

- exact bytes/versions and all relevant CS:IP aliases; entries, exits, shared tails and embedded tables;
- purpose, arguments and implicit register/global/resource inputs;
- writes, preserved state, stack/flag behavior and side effects;
- numeric widths, signedness, overflow, truncation and comparison boundaries;
- timing, RNG consumption, pause/focus, audio completion and interface relationships;
- ordinary, failed, disabled, cancelled and cleanup paths;
- callees, indirect targets and external service contracts;
- readable pseudocode tied to the bytes, existing evidence, discriminating tests and residual uncertainty.

`docs/CONTRACT-TEMPLATE.json` is a draft schema for the research ledger, **not UIL**. UIL and decompiler implementation remain with their current owner.

Keep three independent attributes: byte classification; semantic/contract status; evidence scope. A compiler helper with a validated exact signature can be closed through that contract without inventing a game scenario for every instruction. Hardware-specific routines remain in the inventory and receive explicit service/timing contracts; they are not removed from the denominator.

## 6. Data and bit-level closure

Every initialized-data interval gets either a typed layout with consumer/writer evidence or an explicit unresolved record. Describe individual flag bits, enums, table indices, signed values and lifetime/initialization rules. Describe a repeated zero or padding run once with its exact extent and reason; do not produce thousands of meaningless per-byte paragraphs.

The **48-byte save block at `DS:C00B`** remains preserved and unresolved. Its corresponding initial-image file range is **`0x040A0B–0x040A3A`**. Save offset 582 is a different coordinate and is retained separately. Remaining ACT trailer bytes, sample header fields and demo/XMI records are tracked as external-resource obligations, not smuggled into the EXE byte count.

No claim of unused/dead code follows from no direct callers or no observed execution. Indirect dispatch, callbacks, alternate configurations, errors and driver entrypoints must be considered first.

## 7. Main executable versus the whole runtime

The main target is **DINOPARK.EXE, 268,480 bytes**. The archived directory also has **38 other executable/driver-format candidates** (`.EXE`, `.COM`, `.ADV`, `.AD`) that are listed separately, along with all original-file identities in that archive. This is an extension-based candidate inventory, not a claim that all are loaded or all are executable in the same way.

The archival directory contains 192 files, including an analysis `.i64` file; later live-game packages used 191-file extractions. The target EXE identity matches. This pass does not conflate these directory counts or execute either directory.

For complete game behavior, link external resources and actually loaded drivers to the EXE contracts. Explaining the EXE and explaining every external sound driver are separate finite inventories. Both can be pursued without hiding one under the other.

## 8. Method, validation and limitations

The build reads the owned original research archive, the E47/E48 packages and the E37 save schema. It uses a genuine previously supplied Capstone 5.0.9 wheel installed into a task-local vendor directory. There is no new network/package retrieval, target launch, patch, native-state restore or remote write.

Recursive static decoding starts from inherited candidate entries plus explicit report anchors. It follows directly resolved near transfers under their CS contexts and relocation-backed far transfers; indirect jumps stop that path. It keeps indirect calls and potential call fallthrough explicit. It does not solve all switch tables, certify dynamic DS contents or prove ordinary reachability.

Validation checks gap-free byte partition, exact byte totals, all relocation locations, deterministic source-bound rebuilding, candidate IDs and ownership, opcode/program totals and preserved unknowns. Source reports are copied unchanged with hashes. Fresh source processing, not a rerun of old game experiments, reproduces the raw inventory. The review routing and contract template are authored planning data.

**No original binary, full generated program C, sprites, sounds, fonts, private database or native checkpoints are shipped.** Only authored inventory/planning code, addresses/hashes, metadata and previously supplied research reports are included. Original inputs, guide0.3, Lab0.8, E38, Swift and remotes remain unchanged.

## 9. Closing the whole-binary branch

Completion requires: no unclassified byte range; all candidate boundaries reconciled; all control-flow target sets or external interfaces accounted for; all routine/data/flag contracts linked to their evidence; and no unresolved behavioral contradiction hidden by a high test count. Hardware details may be represented by explicit contracts, not silent omissions. Unreached code and rare errors remain in the review queue.

Each investigation updates a small, permanent unit: explain one dependency-connected routine group, close its bytes/data/edges, attach evidence, and regenerate the ledger. Stop rerunning settled broad suites unless the change intersects their contract. The inventory is designed to shrink a finite unknown list rather than keep producing unrelated discoveries.

## Delivery results

- 18 inventory invariant tests passed.
- A second run of the static builder reproduced all 22 raw output files byte-for-byte.
- 14 Chromium checks passed after fixing the authored viewer; desktop/mobile captures were inspected. The browser loaded the exact HTML via set_content because its file:// navigation is disabled.
- No new original-game executions were performed.

See the external delivery receipt for clean ZIP extraction, manifest and rerun results.
