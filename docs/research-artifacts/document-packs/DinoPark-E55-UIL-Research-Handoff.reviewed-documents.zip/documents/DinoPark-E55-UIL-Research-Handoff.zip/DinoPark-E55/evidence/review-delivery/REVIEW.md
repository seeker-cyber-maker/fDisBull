# E55 delivery-source review

**Accepted within the reviewed scope. No unresolved material source findings
remain.** This review concerns the frozen delivery scripts and README commands,
with bounded component probes. The parent performs the final 117-test run,
package construction and successful fresh-extraction verification afterward.
This receipt does not claim that those final production steps have already run.

## Findings closed

Three concrete gaps were reproduced against the original delivery scripts in
small disposable fixtures. The before-source snapshots and
`calibration-before.json` retain that evidence.

| Finding | Before correction | Accepted correction |
|---|---|---|
| Original-container exclusion | A synthetic file named `DINOPARK.EXE` was included despite the manifest's exclusion claim. | Packaging rejects original filenames, pinned original file digests and game-container suffixes before creating the archive or changing its manifest. |
| Exact preserved-baseline membership | A manifest's listed bytes passed even with an unlisted extra file beside them. | Manifest validation requires the exact file set, rejects symlinks and requires the expected E55/E54 manifest format and root. |
| Immutable final reference | Reloading the manifest allowed a payload and its recorded hash to be changed together. | The verifier captures the initial manifest bytes and parsed rows, requires unchanged manifest bytes, then checks payloads against those captured rows. |

Eight correction probes passed. They distinguish the suffix, filename and
digest exclusion routes; preserve legitimate `.bin`, `.whl`, negative `.zip`
and nested-manifest payloads; exclude private/cache files; reject extra
manifest entries and wrong milestone identities; and reject a resealed payload
against the captured original reference.

The actual `baseline/E54` contains exactly **117 manifest payloads plus its
manifest**, and all sizes/hashes match. Its manifest SHA-256 is
`02e72e5cea68945d03c597c5d4b414f9d7c78b174deb51a4f9409d23bfaedba8`.
The current E55 source tree has no collision with the packaging exclusions for
the preserved original-game inventory. The component tests used synthetic
markers rather than original game bytes.

## Independent archive rejection probes

The separate reviewer `/root/dinomart_runtime` exercised nine ordinary archive
faults against the same frozen verifier revision: duplicate member, traversal,
absolute path, normalized alias, backslash path, directory member, symlink,
CRC corruption and unaccounted member. All were rejected. Eight failed before
extraction; the extra-member case extracted only its authored files beneath the
new output directory, then failed exact manifest membership.

The probes blocked and counted verifier subprocess calls: **zero** were
attempted. No original game bytes or native instructions were used. The
disposable inputs were removed. `archive-safety-review.json` and
`archive_safety_probe.py` preserve the result and its reproduction. This covers
the stated faults, not comprehensive archive resource-exhaustion behavior.

## Test runner, CLI and research reproduction

`scripts/check.py` selects seven explicit portable suites and adds the native
ABOUT-host suite only with `--native-game`. Every selected suite must discover
at least one test; failures, errors, skips or changing tested source files fail
the run. The log is flushed and synchronized before its digest is recorded.
The declared final suite is **117 tests**: 21 processor, 14 DinoMart runtime,
15 ABOUT runtime, 8 raster, 16 CLI, 13 contracts, 13 story-export and 17 native
host tests. Those counts are the expected final gate, not a new run performed
by this review.

The fresh-delivery verifier requires the extracted test counts and per-suite
counts to match the recorded successful run. It authenticates the recorded
source hashes and complete test log. It also invokes the public ABOUT inspect
and two-signal playback commands and compares their bytes with the recorded
outputs.

The corrected CLI evidence audit requires the complete four-command
ABOUT/DinoMart × inspect/play set, successful exits and every recorded output
digest. It authenticates the 16-test CLI receipt and its log. This review
checked all of those retained bytes and source bindings successfully; it did
not rerun the CLI here.

Research verification rebuilds and checks the retained six-file packet, then
regenerates it in a separate output directory. Both the exact filename set and
every file's bytes must match. The exporter's own receipt/source gates remain
responsible for the bounded actor/host/research evidence. The prior E54
evidence audit is reused without rerunning or relabeling its original corpora
as new E55 coverage.

README commands match the current parsers, output-refusal policy and external
input/dependency requirements. Packaging and delivery-check examples now
include the required arguments. The README retains the research-input status
of the UIL handoff and the distinction between supplied signals and physical
page/audio timing.

## Earlier host log

The preserved rejected log is an exact 1,235-byte prefix of the later complete
2,745-byte log. No later child task wrote the old qualified log: the runtime
review used its own directory, host tests do not write logs, and story-evidence
tests copy into independent temporary directories. The cause of truncation
remains **unestablished**.

The fresh host receipt is
`268edc353bfc81d6b1dbeb2868b6b668bb3fc49157252413f928b171ca8c9fd7`.
Its complete 17-test summary and all five artifact hashes verify. The old
directory remains explicitly rejected under `calibration-pre-export`.
`host-log-investigation.json` records this narrow investigation; it does not
attribute an unobserved cause or add unique native coverage.

## Freeze and remaining production step

`REVIEW.json` binds the accepted delivery sources, correction probes and
independent archive review. Production sources were read-only for the
reviewers. No full public suite, valid production delivery or optional native
corpus was rerun during this delivery review. The parent should now run the
already-planned final suite and fresh package verification against this frozen
source revision, then bind and save those final production receipts.
