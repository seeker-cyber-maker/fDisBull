# DinoPark E51: animation command-set closeout

**27 October 2026.** Continuation of E50's whole-binary inventory. This pass closes the previously untested **opcode-family queue**, supplies bounded actor-construction/reset/resource-binding contracts, and retains the remaining dependencies explicitly. It does not declare the entire executable or presentation system complete.

Pinned target: `DINOPARK.EXE`, 268,480 bytes, SHA-256 `2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`.

## Result

* All **256 opcode values** pass through the original operand reader and dispatcher, and separately through its decode-without-execution path.
* All **65 recognized or normal-fallthrough values** now have bounded handler execution evidence. This closes E50's 33-value recognized-route gap. The other **191 values** reach the shared diagnostic path under valid, bounded operand fixtures.
* **2,458 constructed cases / 3,984 original calls** match a separate reference implementation. Each endpoint compares 63,488 bytes of the supplied data segment, excluding only the 2,048-byte instrumentation area. Observed service calls, specified return values and the restored stack pointer are checked separately. Zero mismatches.
* The extended model also matches the **48 original programs in 11 resources**, under E50's 33 declared clock/signal profiles: **115,344 actor snapshots and 97,319 ordered drawing requests**. This is regression of those profiles, not another 48 complete game scenes.
* All **36 W01 candidate-entry buckets** receive scoped contracts. Two constructor/resource-binding entries outside W01 and the signal-table reset subentry have additional bounded evidence. None is promoted to unconditional whole-function proof.

The static byte partition still contains 268,480 bytes in 1,941 adjacent ranges. All 926 candidate entries remain. The 154 unresolved indirect sites and 19,146 instruction-decoder-gap bytes remain separate obligations. Opcode-route coverage is not an explained-byte percentage.

## 1. Six wait instructions install but cannot match their release arms

Wait bytes `B1`, `B2`, `B4`, `B5`, `B6` and `B7` are recognized by the original classifier. Normal scheduling stores the byte and operands, blocks the actor's script and leaves its program pointer on that command.

The updater then loads the wait **byte**, sign-extends it to a word at `2984:066D–0672`, and compares that result with positive word constants such as `00B1`. Byte B1 becomes FFB1, so it cannot equal 00B1. The same mismatch affects the other five values. The corresponding positive-word arms remain in the code; their coordinate comparisons are recorded rather than silently repaired or discarded.

| Example from the connected fixture | Installed | After update | After scheduler runs again |
|---|---|---|---|
| `B1`, coordinates satisfying the equality condition | PC 512, blocked, wait B1 | Still PC 512, blocked, wait B1 | Still blocked |
| `45`, matching x-coordinate | PC 512, blocked, wait 45 | PC 515, unblocked, wait cleared | Executes the following frame command |

The corpus includes direct wait-release grids and installation through the actual scheduler, not only host-supplied wait flags. All six high-bit values are **absent from the supplied ACT programs**. This is therefore an established interpreter-path inconsistency under declared fixtures, not a newly reproduced visible hang in normal gameplay. A native callback or another state transition could still change the record; no universal claim about every possible external intervention is made.

The local reasoning is stronger than a frequency observation: a sign-extended high-bit byte cannot equal the positive 16-bit constants in these tests. The native cases corroborate the composed installation/update behavior.

## 2. The reader and branch handler disagree in two more places

### Byte 66 receives no operands

The reader's word-plus-byte class starts **above** 66, rather than at 66. Consequently, normal decoding of byte 66 consumes one byte and yields `a=0, b=0`. Its branch handler tests x against zero, but the branch displacement is also zero. Through this ordinary decode/dispatch path, it advances by its one-byte instruction length instead of implementing a useful parameterized x-equality branch.

A direct call to the branch helper with invented nonzero parameters would not describe what the actual reader supplies. The reference preserves the composed behavior.

### Byte 90 overwrites the encoded displacement

This instruction reads a signal index, a comparison byte and an encoded third-byte branch displacement. Its branch handler then copies the comparison byte into the scratch location that held the displacement.

For the tested instruction `90 02 03 07`, with signal 2 equal to 3 and initial PC 512:

```
Decoded instruction length: 4
Encoded displacement:       7
Displacement actually used: 3
Final PC:                   512 + 3 + 4 = 519
```

Thirty-six additional cases deliberately separate comparison values from encoded displacements, cover taken/not-taken branches, and include high-bit values. These are not just tests where the two bytes happen to agree. Original biased-byte displacement arithmetic remains intact.

Neither 66 nor 90 is used by the supplied embedded programs. Their behavior still belongs to the binary explanation.

## 3. Complete custom-cycle modes, including shared randomness

E50 qualified modes 05/06/07/F2/F3. E51 adds F4/F5/F6 and tests the renderer's caller-controlled no-cycle mode.

| Mode | Established bounded behavior |
|---|---|
| F4 | Reverse through a custom list, wrapping from index zero to the last entry before FF. |
| F5 | Reverse through a custom list and hold at index zero. |
| F6 | Scan to the FF marker, call the original shared PRNG once, and select `floor(rand15 * list_length / 32768)`. |

F6 is **scaled selection, not modulo selection**. With incoming RNG state 1 and a four-entry list, the first random return is 346. The selected index is 0; `346 % 4` would instead select 2. The native PRNG, multiplication and division instructions execute; random values are not supplied by the host.

The random mode consumes nothing in the separately tested hidden, suspended, timed-wait-blocked and caller-suppressed-cycle conditions. An eligible visible cycle consumes one transition; an intervening invocation before its deadline does not consume another. This does not establish that any currently supplied scene uses F6, which is absent from the supplied programs.

Custom setup initializes the cursor to **unsigned FF**. F4/F5 can decrement this to 254 before any conceptual negative-one normalization. Like E50's F3 observation, this may read outside the actor's nominal frame list and into neighboring record storage. The full data-segment model preserves that behavior. It is bounded byte-level evidence, not a claim of a visible ordinary-play defect or permission to treat arbitrary malformed lists as safe.

## 4. Signals have word values and phase ordering

The signal store is **32 little-endian 16-bit words**, occupying 64 bytes at `DS:A8B8`. Set, add, clear-one and clear-all entrypoints execute in the new corpus. Addition wraps at 16 bits; values are not automatically normalized to Boolean flags. Some consumers test exactly one, some exactly zero, and another compares a supplied value.

Two connected two-actor cases establish ordering:

* A signal written by an earlier actor during the scheduler sweep is visible to a later actor's branch during that same sweep.
* An actor already blocked on a signal does not get a second wait-release pass merely because a producer writes the signal later in that tick. The next updater releases its wait, and subsequent scheduling runs its continuation.

Native scene producers are also indexed in `inventory/dependencies.json`. Examples include the bank updater at `334B:2790`, information setup at `3619:0F06`, and shared scene initialization's clearing call at `1B29:0094`. These are **statically established source references**, not newly executed complete bank or information scenes. The index explicitly retains alias contexts and does not claim exhaustive resolution of computed writes or indirect callers.

Thus signal semantics are now executable contracts. The exact occasions on which every native scene emits a signal remain linked W04/W05/W06 work, rather than guessed interpreter behavior.

## 5. Initialization is not a single memset

### Reset preserves actor identity and some control state

The actual reset at `2984:0038` clears motion, wait metadata, coordinates, visibility, cycle fields and the frame-list area, then initializes the cycle deadline from the current logical clock. It retains:

* program and frame-buffer pointers;
* base sprite and frame count;
* group and resource-context identity;
* cached dimensions; and
* the **suspension byte**.

The patterned-record fixtures test preservation, including nonzero suspension. Calling the all-actor reset at `2984:0000` operates over the allocated total, not merely the currently selected resource context. A zero-filled actor record is therefore not an interchangeable implementation of reset.

### Actual creation and program binding were followed

The static-actor append routine `1D88:0955` reads its descriptor bank, binds a program pointer, sets sprite/dimensions, calls the real reset, and updates context/global counts. Thirty-six cases exercise declared counts, sprite IDs and contexts without substituting that reset.

The sequence-bank routine `1D88:0C4B` reads length-prefixed program records, binds each actor's far program pointer and resource-context field, and updates range/count metadata. Another 36 cases cover nonempty and empty program-bank preparations. **Allocation/locking/file-read services are declared adapters returning a supplied source bank**, and the fixture requests no newly decoded sprite records. Original record parsing and binding instructions execute; allocation lifetime, failed I/O, full ACT loading and cleanup are not claimed complete.

The indexed resource-bank sprite setter also matches its mode-dependent cached-width additions: +3 for mode 4, +7 for mode 1 and +1 for mode 2. This is stored geometry behavior, not a new screen-resolution interpretation.

## 6. Default diagnostics and errors are part of the contract

All 191 default-dispatch byte values were executed twice, covering the buffered-bell and unbuffered-service alternatives. Their reader forms remain valid and bounded; this is not malformed-input testing against the historical program.

The original error path leaves the PC at the offending opcode, builds its diagnostic through the recorded formatting/output services, updates its stream counter, emits or queues byte 7, and returns FFFF (-1). The formatting/output endpoints are adapters, so the result is a **diagnostic-boundary contract**, not byte-for-byte terminal text or actual device output.

The scheduler has a noteworthy return convention. On the first error, it marks the actor blocked, but its aggregate result only recognizes an exact normal-wait result of 1. A newly encountered -1 therefore need not make that aggregate return nonzero. On the next invocation, the already-blocked actor does count as waiting.

**A zero scheduler result is not a generic proof of successful command execution.** The error return, blocked state and PC must remain distinct.

Opcode F7 is also not an error: normal dispatch falls through without an actor mutation. Nevertheless, operand reading can write scratch and advance the PC using its original unusual length convention. A no-op dispatch arm is not necessarily a no-op complete instruction.

## 7. The last previously unclassified helper in this group

`2A4E:0CE4` iterates stored far frame-buffer pointers and works row by row. It copies a row to a temporary buffer, appends a zero byte, calls the original string-reversal routine `1000:601A`, and copies the row back.

That reverses only the **prefix before the first zero byte**, not necessarily the full raster row. For example:

```
Input row:  1 2 0 3 4
Output row: 2 1 0 3 4
```

All 128 bounded frame-count/dimension/zero-position cases match the original helper and original reversal routine. The current corrected direct-call traversal finds no caller to this entry. That absence is not a proof that no indirect caller exists or that the routine is dead. Its role is not silently substituted for the already qualified ACT mirroring loop.

## 8. Coverage and what actually executed

| New corpus family | Cases |
|---|---:|
| Decode/dispatch for each byte | 256 |
| Decode-only for each byte | 256 |
| Alternative default diagnostic output branch | 191 |
| Conditional/unconditional branch grids | 816 |
| Distinct signal-branch operands | 36 |
| Wait-release grids | 504 |
| Wait installation through scheduler | 18 |
| Additional custom-cycle profiles | 48 |
| Random-cycle eligibility gates / render-only modes | 18 |
| Field setters | 25 |
| Reset and preservation | 47 |
| Descriptor/context routing | 18 |
| Group suspension | 15 |
| Signal lifecycles and two-actor order | 6 |
| Scheduler error continuation | 4 |
| Frame-row helper | 128 |
| Static-actor creation / program-bank binding | 72 |
| **Total** | **2,458** |

These cases produce **3,984 call endpoints**. They compare a total of **252,936,192 supplied data-segment bytes**, with the same 2,048-byte adapter-observation region excluded at every endpoint. The large byte count is preservation coverage of overlapping fixture state, not millions of independent facts or a whole-game metric. AX is asserted only where a return contract is assigned; full CPU flags/register equivalence is not claimed.

The separate regression uses E50's compact original-code oracle and the new extended model: 48 programs, 11 files, 33 profiles, 115,344 actor records and 97,319 ordered drawing requests, all matching. It preserves supplied clocks, resource dimensions and external signal profiles. E50's 40 undispatched terminal command positions remain an ordinary-reachability qualification; executing terminal opcode 03 in constructed fixtures does not make those original offsets reached.

## 9. Execution adapters and preservation

The inherited Linux x86-64 LDT bridge executes the authenticated 16-bit instructions. Guarded far-call selector rebinding makes original code modules addressable. New tests execute original dispatch, reader, update/render-cycle/scheduling, reset, signal operations, PRNG arithmetic, selected constructors and row-prefix reversal. No original file is patched.

The final draw and device-service calls are recorders. Six default-diagnostic string/format/output calls are recorders. Three program-bank allocation/lock/read calls return the declared already-populated source-bank pointer and record their arguments. Those adapters are explicit test boundaries, not fabricated original implementations. Valid fixture counts, pointers, stack space, program bytes, clocks, descriptor banks and signal inputs are supplied.

This is not a live DOSBox campaign, an fDisBull upgrade test, a decompiler implementation, a UIL exporter, or an independent second-investigator review. The current compiler/OS stack-failure service and malformed pointer/length behavior remain support-code obligations. Physical rendering and resource lifetime remain other work packages.

All 191 original files are unchanged. Guide 0.3, Lab 0.8, E38, Swift and remote repositories remain untouched. The previous native-state restoration discrepancy was not used, retested or declared fixed.

## 10. Closeout disposition and next boundary

**Closed for this pass:** no unidentified opcode byte routes; no remaining E50 recognized-byte execution gap; every W01 candidate bucket has a scoped behavior/dependency record; reset, context binding, signals, cycle modes and error outcomes have explicit boundaries.

**Not silently closed:** malformed-program behavior, universal CPU register/flag proof, stack/runtime diagnostic formatting and OS output, complete resource allocation/free/error paths, scene-specific signal production and timing, real drawing/clipping/palette/fade behavior, and sound/music completion.

The next primary package is **W02: rendering/composition/clipping/palettes**, with W03 resource lifetime and the indexed native signal producers followed when required. There is no need to keep reopening the same animation opcode catalogue or the economic formulas.

See `CONTRACTS.md`, `inventory/opcode-contracts.json`, `inventory/routine-contracts.json` and the independent recording/delivery receipts. Counts from reruns and unit tests are not added to the original-case totals.

## 11. Delivery verification

Fresh ZIP extraction passed the complete file manifest and original archive CRC checks. The delivered native sources rebuilt and passed all 2,458 cases / 3,984 calls again; all per-case JSON receipts reproduced byte-for-byte. The extended-model asset regression reproduced its 33 complete results, including original-oracle output identities. The 34 unit tests, 39 recording/ledger checks and 12 Chromium checks passed; desktop and mobile captures were inspected. Repetitions do not add new original cases.

One repeatability boundary is retained explicitly: raw generic-adapter dumps are **not** byte-identical between processes. Their extra captured stack words, beyond the actual service argument counts, vary within the already excluded instrumentation region. All checked data state and meaningful observations reproduce. `evidence/reproduction-boundary.json` records the offsets and separates this from the identical per-case receipts. No discrepancy is concealed under a full-raw-output identity claim.
