# Independent review: ACT research contracts and evidence export

**Result: accepted within the declared research-packet scope.** The corrected
contract catalog and exporter have no remaining concrete blocking defect from
this review. The packet is a deterministic, source-bound research handoff for
the existing UIL owner. This result does not certify a UIL grammar, evaluator,
complete scene or complete game.

The final verification consists of 13 contract tests, 13 independently authored
receipt-gate tests, 29 independent source/artifact checks, and a byte-for-byte
regeneration of all six packet files. These checks performed **zero new original
executions and zero new original actor ticks**. Reading saved native observations
does not add to the execution totals reported by their producers.

## Exact reviewed state

| Subject | SHA-256 |
|---|---|
| `src/dinopark_act/contracts.py` | `a9afc1926e27996a95327ef6360c473d70e8e6df6005b7b1002b4165b2755573` |
| `scripts/export_story.py` | `d5fa629bc72bbe733205f516bc563c32cad5518338584c8bd4a658efefb53be9` |
| `tests/test_contracts.py` | `4ffc211238bd3046caddd959e3d9ab7f5cc4c491689baf70276c12b8a36d8f97` |
| `tests/test_story_export.py` | `1b7165e077960768a414a9d3c7b8f5302b443db35a0bf9fe96f1f5de272492e6` |
| Frozen portable `runtime.py` | `b97eec278a282798ca130b19804e478c03367c9139539f866d90d229abc76e19` |
| Packet `EXPORT-RECEIPT.json` | `7700b7a9c3b17d320a03eb67b5bd15b898530ea93cd2b5ba68c4f44d16b33867` |

The accepted audit binds all packet files, the exporter/processor/runtime
sources and pinned fDisBull wheel. The receipt-gate test run and contract test
run also checked that their subject files did not change during execution.

## Findings and closure

| Finding | Original consequence | Corrected behavior and verification |
|---|---|---|
| JSON type drift | Python equality accepted numeric zero for a boolean, a boolean for consumed length, and a float for an integer file offset. | Canonical JSON byte comparison distinguishes those types. All three negative cases now fail validation. |
| Mutable qualification and uncertainty | A mandatory uncertainty could retain its ID while being marked closed; claim text and shared catalog objects also needed protection. | Required uncertainty records and qualification fields are compared in full; duplicate uncertainty identities are refused; independent deep copies prevent a payload mutation from altering the regeneration baseline. |
| Unresolved CFG exported as complete | An out-of-program branch, an interior-instruction branch and an ending fallthrough could be serialized with a null target while reporting zero unresolved rules. | Unclosed traversal or unresolved edges prevent export. Accepted edges retain their evidence, rule identity and traversal scope. |
| Known opcode outside the bounded runtime domain | Invalid F3 lists and signal slots were described as normal executable behavior despite constructor rejection. | Rules distinguish opcode recognition from operand-domain applicability. Inadmissible inputs retain source facts but have no normal effects or release condition, and constructor admission is explicitly false. Base-sprite bounds are covered too. |
| Incomplete state/order description | Release bookkeeping and F3 neighboring-record storage could be too easy for a consumer to normalize away. | Tick phases include resetting released actors' frame deadline and clearing cycle mode at retained opcode 03. F3 names the 234-byte records, sixteen-record bank, initial next-record C3 lookahead, C2 held-frame read and unavailable storage outside that bank. |
| Evidence accepted without its claimed comparison shape | The initial export authentication relied on permissive defaults, optional artifacts and unnamed all-true check dictionaries. Original identities and conflicting duplicate digest declarations also needed checks. | Per-family formats, explicit acceptance, positive integer counts, original identities, mandatory artifacts, source/artifact hashes, required case comparisons and host run-integrity gates now apply. The independent tests mutate copied real receipts and reseal changed artifacts so structural rejection cannot be mistaken for a stale hash failure. |
| Ambiguous topic control IDs | `[100,118]` looked like two literal IDs, whereas the native topic branch admits every ID in that inclusive range. | The interface link uses `native_control_id_range` with `first=100` and `last=118`; navigation retains its literal list `[2,6,7]`. |

The initial contract review actually executed and preserved **nine accepted
negative probes** in `initial/negative-probes.json`, alongside byte-identical
pre-fix sources and their bindings. The receipt-authentication findings were
initially identified by source inspection; the maintained receipt tests ran
after the corrections and passed. This review does not invent a historical
failed run of that later suite.

The review's own independent packet checker had one calibration error: it first
treated wait instructions as ordinary fallthrough. The processor correctly
exposes a retained blocked self-edge and a delayed resume edge. The checker was
corrected to that source-supported distinction. Its initial source and failure
explanation are retained in `audit-calibration/`; this was not a product defect.

## Semantic review

The source descriptions preserve byte/word storage, signed frame and draw
bucket interpretation, uint32 clock wrapping and signed deadline comparisons.
The biased branch calculation remains `raw` below 128 and `126 - raw`
otherwise. The bounded static graph refuses an unresolved unwrapped target;
it does not manufacture a loaded instruction by wrapping an address. Runtime
constructor admission is separately labelled and is not termination or
all-path proof.

Timer deadline zero remains a nonreleasing sentinel. Eligible rendering and
frame cycling precede conditional-wait release and script scheduling. A wait
for a signal requires the exact uint16 value one. Later actors can observe
earlier actors' scheduler writes, but the prior wait-release scan is not
repeated after every write. Released waits advance their retained instruction
once and set their frame deadline to the current supplied tick.

F3 preserves two different extents: the bytes consumed by the command and the
additional byte read by the original operand reader. Only the specified copied
list enters the cleared 32-byte frame table. Initial cursor 255 participates in
the original cross-record read; zero-filled inactive records are a declared
fixture, not a universal claim about adjacent memory. Attempts beyond the
declared sixteen records remain outside the bounded runtime.

The six ABOUT story phases match the original program: initial configuration,
first signal wait, first forward gesture, return to frame five, clear-and-hold,
and the shorter repeating gesture. The terminal marker at program offset 73
is preserved but statically unreachable through the ordinary loop. The story's
source partitions and phase edges were checked independently against raw ACT
bytes, not only against exporter-generated IDs.

The native producer is initialization: the shared routine advances the shared
PRNG once, resets the graphics page/dirty maps, clears the signal bank, then
genuinely calls ABOUT initialization, which assigns signal zero to one. In the
six saved composed host calls, the review independently checked every original
DS record, ordered write replay, all sixteen preserved actor records, exact
signal writes, RNG arithmetic, scroll values and graphics state. This supports
the declared bounded producer chain; it does not execute intervening page,
resource, picture, control or audio services.

The saved actor timeline also supports the word-latch interpretation. Host
writes at tick calls 20 and 72 occur during active gestures; subsequent script
clears return to the wait at offset 52 with signal zero. They do not become
queued gestures in this supplied fixture. The nineteen topic IDs, navigation
IDs and native event kind are separately recorded from unknown geometry,
control readiness and completed rendering.

## Independent verification and evidence

| Evidence | What it establishes |
|---|---|
| `contracts-recheck/RESULT.json` and `tests.log` | All 13 contract tests pass against the final source: source/semantic tampering, type changes, closed uncertainty, aliases, CFG gaps, operand limits and exact F3/release descriptions. |
| `export-gate-checks/RESULT.json` and `tests.log` | All 13 independently authored receipt tests pass. All five retained families are accepted; malformed or inconsistent copies are rejected. Neither real receipts nor native inputs are modified. |
| `accepted/RESULT.json` | 29 independent standard-library audit checks pass, binding the reviewed source and packet bytes. |
| `rebuild-check/RESULT.json` and `verify.log` | The current exporter regenerates the exact six-file packet, including its receipt. |
| `initial/` | The nine reproduced pre-fix contract gaps and original reviewed sources. |
| `audit-calibration/` | The independently corrected checker expectation for blocked/resume edges. |

`review_packet.py` imports neither the exporter nor the contract catalog,
processor, runtime, Unicorn or Capstone. It reads raw container headers and the
operand forms actually present in the two fixed ACT resources. It checks all
122 rules' consumed/read extents and hashes, numeric/list parameters, successor
targets and graph reachability across nine programs. It also applies the MZ
relocation table independently and matches all 26 native anchors and 15 spans
to the original executable, preserving the distinction between relocated
bytes and pre-relocation file coordinates.

For composition, the audit reconstructs the 36 timeline rows from all 190 saved
actor/signal/return/draw records and replays all six saved host DS write logs.
It checks the packet's 22 broader game-story cards against the frozen source
cards, authenticates their fourteen prior research sources, and checks the
five bounded receipt identities. This is source and artifact verification,
not another execution oracle.

## Remaining limits

The count of 122 catalogued rules is coverage of the supplied ABOUT and
DinoMart instruction instances. It is not coverage of every ACT opcode, all
possible actor states, the entire executable, or the broader game-story map.
The nine constructor admissions do not prove all paths terminate or remain in
range under every future input.

The packet keeps canonical UIL encoding unresolved, pins the retrieved
proposal revisions, leaves the UIL core version null, and declares that no UIL
evaluator or canonical syntax validation ran. The existing UIL owner must map
these research facts into that implementation's actual contract. No competing
grammar or interpreter was introduced by this export.

Full scene timing, resource and page services, final pixels/background
restoration, palette, audio completion and control readiness remain separate
from the bounded actor/host evidence. The unknown caller of `3619:0E57` is still
visible. The broad game-story cards retain their own evidence maturity and
holes; candidate inventories are not promoted into semantic completeness.
