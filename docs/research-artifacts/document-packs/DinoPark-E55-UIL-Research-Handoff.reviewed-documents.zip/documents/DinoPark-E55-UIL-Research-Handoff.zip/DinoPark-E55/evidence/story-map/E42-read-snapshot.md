# DinoPark E42: interface contracts, screenshot phases and outer staffing cancellation

27 October 2026. This is an evidence addendum, not a new Lab or full-game release.

## Requested repository changes

- PR #5, `docs: separate state completion from UI-ready pre/post screenshot captures`.
  Commit `78b2f5b35321b1b58a30da69d6467fe0f266ad3b` on
  `codex/ui-capture-boundaries-e42`, based on main `2544b604`. One documentation
  file, no production implementation. It explicitly relates the E41 finding to
  pre/post screenshot hooks and notes the user-reported similar issue already
  known to the fDisBull agent. E42's later capture-phase evidence was added as a
  PR conversation comment.
- Draft PR #7, `RFC: supplement UIL events with a linked interface description`.
  Commit `82ab246c7e4e6959957329f2b564c7db45c7f2c6`, one RFC added on a new
  branch stacked against `codex/uil-export-boundary` / PR #3. The owner's branch
  was not modified. A comment on #3 points to the amendment. Required interface
  descriptions apply to interactive-fidelity claims; event-only analysis and
  explicitly nonvisual interfaces remain possible. Grammar, implementation and
  the provisional identifier stay with the UIL owner.

The PRs distinguish dispatched input, changed state, updated controls, rendered
observations and persistent results. They are proposals based on evidence, not
newly implemented screenshot hooks or a competing UIL interpreter. Their
synthetic acceptance vectors are specifications, not executed UIL tests.

Canonical PRs:
https://github.com/seeker-cyber-maker/fDisBull/pull/5
https://github.com/seeker-cyber-maker/fDisBull/pull/7

## 1. New original-game finding: outer Cancel does not check roster dirtiness

The E41 packet qualified detail-panel Cancel, which restores all pending staff
from active staff. It explicitly left dirty outer-screen Cancel unqualified.
E42 closes that narrower boundary for roster-only edits with equal cash balances.

The outer employment command-4 branch at static `2D0A:1DBE` calls helper
`2D0A:0560`. The helper compares the full working cash at `DS:BAD4` against
committed cash at `DS:5C3A`. When equal it returns 1 immediately at `0583`, without
calling the confirmation service in its unequal-cash branch. It does not compare
the active and pending rosters. The caller requests street scene 1 at `1DC9`.

A byte-verified breakpoint and 17-record native trace observed that equal-cash
path. DOS trace records are pre-instruction; subsequent caller records establish
that the helper return and scene-request write actually executed. The last trace
record is not claimed to have completed. No direct callback call, target-memory
edit or code layer was used.

Ordinary tested staff changes cost nothing up front, so the balances remain
equal even though pending workers differ. Outer Cancel exits without an extra
confirmation dialog. It does not commit those workers and does not immediately
clear their pending scratch values. Reentering employment synchronizes the
pending roster back to the active roster.

### First accepted route

| Boundary | Active maintenance / guides | Pending maintenance / guides | Cash / working |
| --- | --- | --- | --- |
| Starting employment | 0 / 1 | 0 / 1 | 10,466 / 10,466 |
| Both draft hires accepted on detail panels | 0 / 1 | 1 / 2 | 10,871 / 10,871 |
| Outer Cancel helper returns | 0 / 1 | 1 / 2 | 10,871 / 10,871 |
| Street visibly matched | 0 / 1 | 1 / 2 | 10,871 / 10,871 |
| Reentered employment | 0 / 1 | 0 / 1 | 10,871 / 10,871 |

The earlier cash increase is normal gameplay revenue during preparation, not a
refund or hiring bonus. No money was edited. A second branch fired the existing
guide and proposed one maintenance employee, then cancelled: active staff stayed
unchanged; the mixed pending array remained on street and reset on reentry.
A third case repeated the named cancellation after a fresh emulator restore.

This is not a qualification of unequal-cash pending orders, every payroll/illness
interruption, negative staffing, the 99-guide rumor or persistent park saving.
No complete NEW GAME campaign was run here.

## 2. A direct pre/post screenshot-phase example

A separate route reused the qualified private baseline and prepared the same
mixed draft through six actual named actions. It captured the following phases:

| Capture phase | Scene / request | Frame / captured ticks | Visible result |
| --- | --- | --- | --- |
| Pre-input | 3 / -1 | 242 / 47801 | Employment posters |
| Post-helper / scene request written | 3 / 1 | 255 / 48056 | Employment posters still visible |
| After explicit scene wait | 1 / -1 | 348 / 49884 | Main street |

The post-helper capture is an authentic, valid image of the old interface. It
is not failed keyboard/mouse input or evidence that cancellation did not happen.
A passive screenshot does not advance the guest to render the requested scene.
Each of the three screenshots left the compared cash/roster/calendar/RNG/control
state unchanged. The explicitly requested bounded wait did advance execution.
Frame identities/ticks are this run's observations, not universal delay values.

An earlier exploratory capture, after an arbitrary delay, showed an all-black
transition frame even though the scene and control-table values had changed.
That image is retained as calibration, not presented as the settled street or
a proven debugger rendering fault. The accepted named path waits for its
calibrated scene predicates. A completed frame alone is not application readiness.

This adds direct support to PR #5's pre/post-hook distinction. It does not
implement those hooks or claim a universal readiness predicate.

## 3. Scene update and validation

Added one qualified named action, `employment.cancel_pending`, to the E41 outer
employment definition. Its conditions require the outer scene, enabled Cancel,
a pending roster difference and equal cash balances. Its outcome requires the
matched street and preserved active/pending rosters. Reentry is a separate action
with a separate observed synchronization result. No hidden callbacks are used.

The updated bundle contains eight scenes and 34 targets, inheriting the 33 E41
targets and adding one. E42 does not claim to retest all 34: the accepted run
completed 24 named actions in three cancellation cases, plus one raw mouse action
observed through the helper trace. The additional capture-phase route used six
named preparation actions and one raw traced cancellation. These are not 30
independent games. One restart case uses a compatible private checkpoint in the
same project; it is not a new cross-project acceptance of the whole updated pack.

The original E41 bundle is supplied as the verifier's input. The updated bundle
can be imported into a fresh compatible project; scene names retain the `e41_`
prefix. Existing-name collisions require the supported explicit import policy,
not silently overwriting another agent's definitions.

Accepted records are under `evidence/accepted`; capture-phase records are under
`evidence/capture-phases`. Two accepted native-state archives, 26 members each,
passed CRC checks. Their bytes and the private database are not distributed.
All 192 original files and the accepted working copy retained their hashes.
Accepted main-run emulator processes were reaped.

## 4. Runtime and retained calibration

The investigation intentionally reused the qualified environment instead of
waiting for new decompiler/UIL work: Linux x86-64, CPython 3.13.5, fDisBull 0.18
CI package from `416b64d`, native scene/keyboard ELF
`c04b1c189530af93cf054505ee92f2336c83b86e819bae8d8370350d23259fc6`.
Genuine dependencies/private loader came from the supplied 0.15 offline kit.
The kit manifest passed after restoring ZIP-declared executable permissions;
Python's initial ZIP extraction had not restored those modes. No system install.
This is the established composite runtime, not acceptance of a sealed newer kit.

The first authored verification attempt compared a relocated far-call segment
against unrelocated file bytes. It correctly failed the assertion. The correction
checks the nonrelocated entry prefix plus fDisBull's byte-verified breakpoint,
while source authenticity remains pinned by the complete executable hash. The
failed script/log are retained. No source game bytes or tool code were changed
to obtain a pass.

Original EXE SHA-256:
`2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`.

## 5. Reproduce and limits

```sh
python scripts/verify_outer_cancel.py \
  --game-dir /path/to/owned/original/dinopark \
  --backend /path/to/qualified/dosbox-x-offline \
  --scenes scenes/Employment-E41-Input.zip \
  --output /new/private/e42-run \
  --evidence /new/e42-evidence
```

Use the compatible installed fDisBull 0.18 package. Outputs must not already
exist and must be separate from original inputs. `capture_phases.py` preserves
the additional as-run task-local phase probe; its workspace paths need rebinding
and it expects the accepted verifier's private database and checkpoints. It is
not advertised as an independent portable boot driver.

The portable main verifier was executed successfully. The phase probe reused its
qualified baseline. The delivered archive is checked by a content manifest and a
recording validator. No whole Lab suite is rerun for these UI-only changes.
Lab0.8, E38, Swift, original inputs and other agents' work remain unchanged.
Only the user-requested docs/RFC branches, PRs and coordination comments were
written remotely. No new backend blocker was demonstrated.

## Next

Continue ordinary DinoMart or auction scene coverage, or accept the other agent's
normal-route receipt. Treat interface identity, event effects and presentation
completion as linked but distinct evidence. Keep UIL/decompiler implementation
with its existing owner; use the new PRs as reviewable input, not authority to
build a competing runtime.
