# ABOUT: native host, page changes and signal 0

The demonstrated ABOUT animation trigger is **page initialization**. The
original shared initializer clears 32 signal words and then calls ABOUT's
initializer, which writes the exact word value **1** to signal 0. It does not
wait for audio, text, a clock deadline or a user action inside that callback.
The callback and shared initializer preserve every byte of the 16 actor
records in the qualified fixtures.

The user callback changes the selected topic and requests a page rebuild. It
does not itself write the animation signal. The original scene code routes
that request back through page setup and the shared initialization path.
This establishes a useful reconstruction rule: a host initialization event
can release the retained actor's signal wait. It does not establish that the
complete ABOUT scene has been reproduced, or that every intervening graphics
service preserves actors under all inputs.

## What is freshly qualified

The canonical evidence is under `evidence/about-host/qualified/`:

- `RESULT.json` binds the input executable, ABOUT.ACT, loader, executor, public
  tests, this document and verifier sources to the run.
- `CASES.json` contains 83 original routine calls with explicit fixture
  overrides, independent expected changes, all ordered CPU data-segment writes,
  register results and full-data comparison hashes.
- `SOURCE.json` authenticates exact relocated bytes at the cited source
  anchors and preserves the surrounding function spans.
- `DISASSEMBLY.txt` decodes those spans for review; raw bytes remain the source.
- `FIXTURE.json` preserves the complete default fixture, including all 3,744
  opaque actor bytes used to detect resets.
- `tests.log` records the 17 public tests. These include branch and word-width
  boundaries, reinitialization, input refusal and hook restoration. The unit
  tests execute additional fresh fixtures; their calls are not added to the
  83-call qualification totals.

The original executable is
`2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`
and ABOUT.ACT is
`924bb322aef40a241ec2badb1a3106e7c1b907f05801e752df7c6d5b9aab3e08`
(SHA-256). The pinned E53 `OriginalMachine` loader has SHA-256
`225b8cd7ad93e818d8038ecbcf84c62170df8a4c6467f38165e55f3ccd22deaa`.
Unicorn 2.1.4 executes the original relocated instructions in 16-bit mode.
This is instruction emulation, not a DOSBox/device run.

| Native operation | Original entry | Case calls | Directly checked behavior |
|---|---|---:|---|
| ABOUT initialization | `3619:0EE5` | 16 | Exact signal value, overview scroll, preservation of all other DS bytes |
| Shared scene initialization | `1B29:0044` | 12 | Original RNG, both dirty maps, ordered signal clear and genuine indirect callback |
| UI reset | `1B29:087B` | 1 | Two control counts and selection reset; actor and signal preservation |
| ABOUT user callback | `3619:0F7D` | 54 | Topic selection, back/previous/next, event tracking, signed and wrapping word rules |

Every case compares **all 65,536 DS bytes** against independently specified
changes, not a selected set of actor fields. The ordered CPU-write log is
replayed over the initial data segment and must reconstruct the complete
final data segment. Each case separately checks all **16 × 234 actor bytes**.
The actor records are conspicuous nonzero sentinel data, not a claim that an
ACT resource was loaded or that every sentinel describes a valid actor.

These four routines need **no service adapters**. Their original RNG and
memory helpers execute. The harness rejects undeclared writes outside DS and
the declared stack, requires the original far return and an instruction budget,
and checks that the original code region remains equal to the relocated
image. No opcode, branch or segment arithmetic is patched. Initial DS remains
the executable's initialized data plus listed fixture writes.

The initial absence of the host harness is retained in
`evidence/about-host/calibration-initial/`. It is an expected failed import
before implementation, not a completed native qualification.

## Shared initialization: exact order and preserved state

`1B29:0044` executes the following original operations in order:

1. Run the original RNG at `1000:1B4D`. For the fixture's 32-bit seed, the
   resulting seed is `(seed × 22695477 + 1) mod 2^32`. The returned value is
   `(new_seed >> 16) & 0x7FFF`; DS:91CF receives `value % 500 + 1`.
2. Set the active graphics-page byte DS:4292 to zero.
3. Clear the two 520-byte dirty maps beginning at DS:91DB. Both original
   `1B29:1033` calls and the original memory helper execute.
4. Clear exactly 64 bytes beginning at DS:A8B8 through the original memory
   helper `1000:5000` at call site `1B29:0094`.
5. Make the original indirect far call through DS:97EF at `1B29:009C`.

ABOUT installs the far pointer `3619:0EE5` into DS:97EF/97F1. In every shared
initialization case the native callback enters with all 32 signal words zero,
all actor bytes unchanged, and a real return frame for `1B29:00A0`. The CPU
write log contains 32 ascending two-byte zero writes, followed by the
callback's two-byte write of 1 to DS:A8B8.

At `3619:0EE5`, the page value DS:BB3E has only one special case: if it is
`0xFFFF`, current scroll DS:3DEE becomes 320. The callback then copies current
scroll to pending scroll DS:3C58 and writes signal 0 = 1 at `3619:0F06`.
It returns AX = 0. For other page words, it preserves current scroll and still
sets signal 0 to exactly 1. Previous signal values 0, 1, 2 and 65535 are all
covered; this is an assignment, not an increment or a truthiness operation.

The actors begin immediately after the signal array, at DS:A8F8. Neither
shared initialization nor ABOUT initialization writes that actor region.
The repeated-initialization public test also runs the same machine twice,
changes the selected page between calls and checks that all actor bytes remain
unchanged. Thus these functions do not reset an actor's PC, wait state,
frame table, counters or program pointer.

The surrounding UI reset `1B29:087B` clears DS:3C54 and DS:3C56 and sets
DS:95F3 to `0xFFFF`. It preserves AX; the standalone fixture initializes AX to
zero. It does not clear actors or signals. Do not interpret its name as a
general animation reset.

### Source-boundary correction to the earlier inventory

The E51 dependency index associated the store at `3619:0F06` with its nearest
earlier indexed routine boundary (`3619:0C75`). The original bytes establish
the smaller standalone callback at `3619:0EE5`, ending in `retf` at `0F0E`.
E55 qualifies that body and its genuine shared-initializer caller. The older
inventory is retained unchanged; the recovered function boundary is recorded
in this milestone's source evidence.

## Resource loading and page re-entry

The ABOUT scene function begins at `3619:1061`. Its entry argument becomes
both the current selected page, DS:BB3E, and the originally requested page,
DS:BB3C. It saves the previous scene value in DS:BE44.

At `3619:108E..1093`, it pushes a pointer to **DS:6BAF, `about.act\0`**, and
calls the resource-loader entry `1D88:0005`. The file-name bytes, argument
instructions and call bytes are authenticated in `SOURCE.json`. This is the
concrete original loading site for ABOUT.ACT; the host callback tests do not
emulate file I/O or claim to have executed this loader.

The scene installs the following native callbacks:

| Pointer location | Original target | Supported interpretation |
|---|---|---|
| DS:97DF | `23C5:4112` | Background tile callback; not an audio callback |
| DS:97E3 | `3619:0F0F` | ABOUT frame/body drawing |
| DS:97E7 | `2B5D:0CD6` | Shared background/scene callback; not qualified here |
| DS:97EB | `3619:0F7D` | ABOUT control/event callback |
| DS:97EF | `3619:0EE5` | ABOUT initialization and signal-0 assignment |
| DS:97F3 | `3619:0189` | Help/text callback |

The page-setup block begins at `3619:10F6`. It resets UI controls, arranges
the page's control list and, for the overview entry route, constructs topic
controls 100–118. It requests an image from **DS:6BA5, `about.pic\0`** through
`1D88:17B3` at call site `3619:1203`. The supplied image index is the current
page plus one as a 16-bit word: overview `0xFFFF` selects image 0. The overview
uses scroll 320; topic pages use scroll 0.

It enters the shared scene loop `1B29:04AA` at `3619:1252`, with scene code
11 and the current resource-bank index. After that loop returns, scene request
DS:3C5C = **99 (`0x63`)** takes the jump at `3619:1277` back to **10F6**.
That jump bypasses the earlier `about.act` loading call at 1093.

Within the shared scene loop, `1B29:04E5` calls shared initialization. The
initial actor scheduler call is later at `1B29:0569`, and the first ABOUT body
callback call is at `1B29:0587`. The ordinary loop later calls the actor
update at `1B29:063B` and conditionally the scheduler at `1B29:0647`.
The executable thus supplies a concrete ordering for the signal producer
relative to these actor calls. Whether a retained actor advances depends on
its own PC/wait state; initializing the host is not evidence that the actor
program starts over at PC 0.

**Boundary:** the entry/resource/control/picture/shared-loop route above is a
static original-code trace, authenticated to source spans. This milestone's
host runner executes the four named functions, not the whole scene. It proves
actor preservation in the shared initializer, callback, navigation and UI
reset. It does not turn the behavior of all intervening services into a
whole-page preservation proof. The parent actor comparison composes the
qualified producer with explicitly supplied actor/resource fixtures.

## User controls and 16-bit behavior

The native callback `3619:0F7D` takes two words: a control ID and an event
kind. The reconstruction account can call kind 3 an **activation**, since
this branch performs selections and navigation. Kinds 1 and 2 are retained as
event codes here; mapping them to physical mouse gestures needs the upstream
input dispatch contract.

For activation kind 3:

| Control | Condition | Result |
|---|---|---|
| 100–118 | Signed ID lies within the inclusive range | Selected page = ID − 100; clear tracked control to FFFF; request scene 99 |
| 2, back | Current page is FFFF, or original entry page is not FFFF | Request the saved return scene at DS:BE44 |
| 2, back | Current page is a topic and original entry page is FFFF | Select overview FFFF and request scene 99 |
| 6, previous | Current page is zero | Select `page_count − 1`; if that word equals 19, decrement it again; request scene 99 |
| 6, previous | Current page is nonzero | Decrement the 16-bit page word; request scene 99 |
| 7, next | Always | Increment page as a 16-bit word; if signed page is at least signed `(page_count − 1)`, select zero; request scene 99 |
| Other | No matched branch | Preserve the data segment |

The original initialized page count at DS:4742 is **20**. Therefore normal
previous/next navigation wraps across pages **0–18**. The existence of a
separate page-19 drawing branch does not mean previous/next normally selects
it. The qualifier includes direct page-19 and abnormal raw-word fixtures only
to delimit the actual native rules, not to assert those inputs are reachable
through the normal UI.

For event kind 1, a topic control ID 100–118 is copied to DS:6A08; other IDs
leave tracking unchanged. Kind 2 sets tracking to `0xFFFF`. Other kinds do
nothing. All navigation paths return AX = 0. None writes a signal or an actor
record in the qualified cases.

Finite-width details are preserved, including decrements wrapping at zero
and signed comparison after increment. For example, with page count 20, a
raw page `0x7FFF` becomes `0x8000` on next and is retained because the latter
is negative under the signed comparison. A portable consumer must not replace
the recovered rule with an unbounded unsigned integer comparison if it claims
to cover such inputs.

## Text, drawing and audio are separate host paths

The source trace supports these relationships; this section's services are
not claimed as executed by the host qualification:

- **Body drawing:** `3619:0F0F` uses DS:6A08 to look up a control. If a control
  rectangle exists, it requests sprite 9 at that rectangle through the drawing
  endpoint `1B29:1102`. When current page is 19, it calls `1D88:165B` with
  arguments `(1, 224, 226, 65535)`, a palette-manipulation helper. The body
  contains no direct signal-0 store.
- **Help text:** `3619:0189` handles argument zero by looking for control 6.
  Its presence selects text lookup 6; absence selects text lookup 7 through
  `295E:000D`. A non-null returned text pointer is passed to `20AE:2856`.
  A nonzero callback argument suppresses that lookup/display path. The body
  contains no direct signal-0 store. This is a conditional help-display route,
  not evidence that text completion releases the animation.
- **Music selection:** shared scene code calls `1B29:03D6` after shared
  initialization. It selects a music entry through the scene-indexed byte
  table at DS:3C8B and compares it with DS:3C89. If different, it calls
  `1862:00DD` with the corresponding pointer from DS:3C71 and records the
  selected entry. Additional audio calls apply the existing settings. The
  earlier transition call at `1B29:051F` also follows the init call at 04E5.
- **Audio polling:** `1B29:06AE` calls `1862:05BF`. That routine skips its
  service call if DS:047F is FFFF; otherwise it derives a pointer from the
  active index and calls `1000:0365`. ABOUT's final exit calls `1862:0955`.
  These direct bodies do not establish any audio-completion-to-signal-0 rule.

The strongest demonstrated statement is therefore precise: **the initialized
signal is independent of audio/text conditions within the executed producer
and shared-initializer chain**. This is not a proof that no indirect audio or
text service anywhere in the program could ever affect the signal. It does
not supply audio duration, narration synchronization, music fidelity or device
timing. The nearby theories-screen audio sequence belongs to a different
scene and must not be used as evidence of ABOUT's trigger.

### Additional writer with unresolved caller

`3619:0E57` is a separate redraw helper. For a selected page other than FFFF,
it writes signal 0 = 1 at `0E9F`, requests the corresponding ABOUT picture,
sets scroll to zero and redraws. Its overview branch requests picture 0 with
scroll 320. The observed `3619:1061` callback assignments do not install this
helper, and its actual caller/reachability has not been established. It is
retained as an explicit unresolved source fact. Do not call `0EE5` the sole
possible signal-0 writer in the whole game.

## Harness API and reproduction

`scripts/about_host.py` exposes:

```python
HostFixture(
    current_page=0, entry_page=0xFFFF, return_scene=7,
    scene_request=0xFFFF, control_tracking=0x7777,
    scroll=73, pending_scroll=77, page_count=20, rng_seed=123456,
    signals=tuple(0xB000 + i for i in range(32)),
    actor_records=<exactly 3744 immutable bytes>,
)

oracle = AboutHostOracle(exe_path, fixture=HostFixture())
result = oracle.run("shared_init")
result = oracle.run("navigation", words=(100, 3))

result = execute_existing(machine, "about_init")
result = execute_existing(machine, "shared_init")
result = execute_existing(machine, "ui_reset")
result = execute_existing(machine, "navigation", words=(2, 3))
```

`HostFixture` is frozen. All word fields require exact Python integers in
0–65535, the seed requires 0–2^32−1, signals require an immutable tuple of
32 words, and actor records require immutable `bytes` of the exact length.
Booleans, mutable buffers, wrong counts and out-of-range values are rejected.

`AboutHostOracle` creates the pinned original image, preserves its initialized
DS and installs only the explicit fixture. Successive `.run` calls retain the
machine's state. `execute_existing` does not install a callback pointer, clear
signals, bind actors or otherwise construct host state. Its caller supplies
DS:3DE4 = FFFF as the declared stack guard. Shared initialization additionally
requires DS:97EF/97F1 = `0EE5:3619`; any other callback pointer is rejected
before execution. Only navigation accepts argument words, exactly two in an
immutable tuple. The machine must be the pinned `OriginalMachine` class.

The call wrapper uses `OriginalMachine.call`, which installs the declared
far-return frame and resets SS:SP, DS, ES and flags. It temporarily observes
CPU writes and instruction entries, chains and restores any existing code
observer, and removes only its own memory hook. An inherited observer is
reported; a caller that modifies execution through such an observer must
declare and qualify that extra behavior. The standalone accepted host cases
have no inherited observer and no service adapters.

The result includes complete `before_ds` and `after_ds` **bytes**, ordered
`ds_writes`, callback-entry snapshots, register results, instruction and write
counts, and code/actor/data hashes. It is a Python inspection result rather
than directly JSON serializable. The verifier serializes the explicit fixture,
expected patches, changed byte spans, hashes and complete ordered write log
into the JSON evidence. `static_contract(machine)` returns JSON-friendly
authenticated source anchors and unresolved items without executing code.

Reproduce with the original game and the pinned native dependencies supplied
externally. From the E55 package directory:

```sh
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/absolute/path/to/native/deps \
python3 scripts/about_host_verify.py \
  --game /absolute/path/to/original_game \
  --out /absolute/path/to/new-about-host-evidence
```

The dependency directory supplies Unicorn 2.1.4 and Capstone. The E53 loader
comes from the package's `baseline/E53/original_machine.py`; no modified loader
is substituted. The verifier refuses an existing output directory or an
output overlapping the supplied game, pins both original input hashes, checks
required case groups and test discovery, and binds outputs and sources to its
receipt. It also verifies that sources and original input files remain
unchanged during the run.

For the public native tests alone:

```sh
DINOPARK_GAME=/absolute/path/to/original_game \
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/absolute/path/to/native/deps \
python3 -m unittest discover -s tests -p test_about_host.py -v
```

These recovered rules describe behavior for a language-independent consumer.
They introduce no UIL grammar, compiler or downstream runtime, and do not
replace the existing UIL owner's producer/consumer boundary.
