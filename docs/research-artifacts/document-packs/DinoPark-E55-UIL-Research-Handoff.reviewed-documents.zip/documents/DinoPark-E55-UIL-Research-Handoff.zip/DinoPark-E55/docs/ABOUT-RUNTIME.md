# E55: ABOUT animation runtime

E55 extends the standalone E54 runtime to execute `ABOUT.ACT` program 0 as well
as all eight original `DINOMART.ACT` programs. This is a portable interpreter
for a bounded union of ACT operations. It consumes supplied logical ticks and
word signals; it does not synthesize an audio callback, infer a frame rate,
load a DOS executable, or render pixels.

The original files, E54 source/evidence, and the E51 reference model remain
unchanged. This extension is in the separate E55 tree.

## Public API and compatibility

```python
from dinopark_act.assets import decode
from dinopark_act.runtime import ACTRuntime, DinoMartRuntime

resource = decode(original_about_bytes)
player = ACTRuntime(resource)

first = player.tick(0)
signaled = player.tick(1, signals={0: 1})
later = player.tick(2, suspended=0, hidden=None)

draws = later.draws
actors = later.actors
state = player.snapshot()
records = player.actor_records(source_segment=0xB000)
signals = player.signal_bytes()

assert ACTRuntime is DinoMartRuntime
```

`DinoMartRuntime` is a compatibility alias. Constructor and method signatures
are unchanged. `TickResult` retains its immutable actor snapshots, ordered draw
tuples, released actor indices, aggregate waiting flag and dispatch-command
count. The last count is not an x86 instruction count.

The JSON-friendly snapshot format is now `dinopark-act-runtime-state-2`.
Existing actor field names remain, with the wait/cycle fields below added.
The active actor-record serialization still returns exactly 234 bytes per
selected actor. It does not include inactive actor records in that return value.

The constructor permits 1–16 selected actors, 1–256 sprites and 1–2,047 immutable
bytes per program. The dispatch budget remains 1–65,536 commands per actor
sweep, default 256. Existing integer checks reject Booleans and values outside
the declared unsigned widths. Ticks can repeat, skip, or wrap; their values are
not silently made monotonic.

## Original program and supported operations

The pinned original `ABOUT.ACT` SHA-256 is:

```text
924bb322aef40a241ec2badb1a3106e7c1b907f05801e752df7c6d5b9aab3e08
```

It contains ten sprites and one 74-byte program. Its fourteen opcode values are
`03 11 12 16 17 19 1A 1B 1C 1D 40 41 47 F3`. DinoMart also uses `10` and `4E`,
making the combined supported set sixteen values. Only five implementations
are new in E55:

| Opcode | Execution contract |
| --- | --- |
| `16` | Clear the selected 16-bit signal slot. |
| `19` | Install a wait for the signed current frame to equal the decoded operand; retain PC and yield. |
| `1A` | Sign-extend the reader's byte operand into the frame-cadence word. |
| `1D` | Install a wait for the selected signal word to be exactly one; retain PC and yield. |
| `F3` | Copy a bounded frame table, select forward/hold mode, initialize index to `FF`, and set the frame deadline to `tick - 1`. |

Opcode meanings and operand forms are bound to
`src/dinopark_act/data/opcode-contracts.json`, SHA-256
`976096549a0711330c119ef6557c5b1fd7144e2aa8b16afd219a05cffd7dd2b3`.
The unchanged operand decoder remains `src/dinopark_act/tokens.py`.
The independent implementation reference used for comparison is the preserved
`baseline/E51/contract_model.py`; the runtime does not import or call that model.

## Tick ordering

The ordering is part of the reproduced behavior:

1. Apply caller-supplied suspension/visibility masks and signal-word writes.
2. Expire eligible nonzero deadlines and perform eligible previous-coordinate
   and movement-cadence updates. The supported programs set no motion.
3. Visit visible, unsuspended actors in signed draw-order/actor-index order.
   An actor at opcode `03` has its cycle mode cleared here. Advance an eligible
   frame cycle once, then emit its draw tuple.
4. Evaluate conditional waits using the frame after that render-phase update
   and the current signal bank. Clear the released wait fields.
5. Advance each released PC by the retained instruction's decoded length,
   without executing that instruction again, and set its frame deadline to the
   current tick.
6. Schedule each eligible actor until it yields or reaches the explicit budget.

A wait installed during scheduling cannot release during that same tick call.
There is no second wait-release pass after a script clears a signal. Hidden
actors can release signal or matching-frame waits, but they do not advance
their frame cycles in the render phase. Suspended actors do neither. A skipped
clock interval advances a due cycle once per supplied tick call; it does not
automatically replay the intervening frames.

Signal values are preserved as words. `0`, `2`, and `65535` do not satisfy a
`1D` wait. A caller that supplies one on every tick may overwrite the program's
previous clear and trigger another cycle. That is an explicit input profile,
not an inferred property of the original signal producer.

## Frame tables, finite widths, and the neighboring-record read

`F3` copies exactly its decoded count bytes into actor offsets `AD..CC`, first
zeroing that 32-byte table. The operand reader fetches one additional lookahead
byte, but that byte is not copied into the actor table. The existing frame
offset is retained when a new table is installed.

When the frame deadline is due, the forward/hold rule reads the byte after the
current table index. An `FF` marker retains the index; otherwise the index
increments and wraps as an unsigned byte. The selected table byte becomes the
raw frame offset. The next deadline is:

```text
u32(current_tick + s16(u16(2 * frame_cadence)))
```

Deadline ordering uses signed 32-bit comparisons. Frame offsets used for
sprite selection and frame waits are signed bytes. Opcode `11` sets that raw
frame byte and clears cycle mode/index, while retaining the table contents.

The original initial index `FF` has a consequential address calculation:

```text
lookahead = actor + AE + FF = next_actor + C3
selected byte if held = actor + AD + FF = next_actor + C2
```

The implementation preserves both reads through serialized actor records. Its
declared host fixture is a bank of sixteen zero-initialized 234-byte records;
selected actors populate its active prefix, and inactive records remain zero.
ABOUT's single actor therefore initially reads the declared inactive second
record. With an active neighboring actor, the actual retained bytes at its
`C2/C3` offsets participate. A focused test supplies `02/FF` there and observes
index `FF` hold while selecting frame two.

Memory outside that bank is unavailable. A sixteenth active actor performing
the initial `FF` lookup raises `RuntimeStateError` rather than assuming a
seventeenth record or general DOS memory. This is a host bound, not a claim
about the original executable's behavior outside the fixture.

For the same reason, accepted `F3` inputs require 2–32 copied bytes, a first
non-marker frame and an `FF` marker inside the copied table. Signal operands
are restricted to the supplied 32-word bank. Unsupported operations, invalid
branch boundaries, malformed tables and unavailable reads fail closed. Host
tick failure is transactional: actor state and signal clears are committed
only after the entire tick succeeds. That host error policy is not presented
as original failure behavior.

## Actor-record fields added in E55

| Snapshot field | Record offset | Width |
| --- | --- | --- |
| `wait_opcode` | `94` | byte |
| `wait_a` | `95` | word |
| `wait_b` | `97` | word |
| `frame_cadence` | `A5` | word |
| `cycle_mode` | `AB` | byte |
| `cycle_index` | `AC` | byte |
| `frame_table` | `AD..CC` | 32 bytes |

The existing frame deadline at `A7` remains a dword. Word and dword fields are
serialized little-endian, including retained sign-extended operands. Program
operands themselves retain the qualified reader's encodings, including
big-endian coordinate words. All previously modeled actor fields and the
remaining zero-initialized bytes are still included in every 234-byte record.

## Hand-derived ABOUT timeline

For the ordinary increasing clock, signal zero supplied as one at ticks 1 and
60, and no suspension or visibility override:

| Tick | Observed draw / post-schedule state |
| --- | --- |
| 0 | No draw; startup sets `(x,y)=(13,108)`, then waits at PC `11` for signal zero. |
| 1 | Draw frame zero; release signal wait, install first table, wait for frame eight at PC `24`. |
| 2 | Select the first table entry, frame zero; next frame deadline is six. |
| 6, 10, …, 34 | Draw frames one through eight, advancing every four logical ticks. |
| 34 | After drawing frame eight, install the descending table and wait for frame five at PC `2E`. |
| 35, 39, 43, 47 | Draw frames eight, seven, six, five. At tick 47, clear signal zero and wait at PC `34`. |
| 60 | Draw frame five; release the next signal wait and install the repeating response table. |
| 61, 65, 69, 73, 77, 81 | Draw frames six, seven, eight, seven, six, five. At tick 81, branch back to clear signal zero and wait again. |

These tick distances are consequences of the supplied logical clock and the
program's cadence operand. They do not establish physical timing or audio sync.

## Verification

The focused runtime command is:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src \
python3 -m unittest discover -s tests -p 'test*runtime.py' -v
```

The accepted run has 29 passing tests: fifteen new ABOUT/cycle/wait tests and
the unchanged fourteen DinoMart tests. The initial E54-only run failed the new
API and unsupported-opcode checks; its source, test, log and receipt are retained
under `evidence/about-model/calibration-before`.

The model comparison is reproducible with:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 scripts/about_model_compare.py \
  /path/to/original_game --out /path/to/new-about-model-evidence
```

`about_profiles()` supplies eight deterministic profiles: idle, single trigger,
held one, repeated triggers, non-Boolean word values, suspension, visibility,
and repeated/skipped/signed/wrapped clock values. The comparison also replays
every preserved E54 DinoMart input profile against the extended runtime.

| Resource | Profiles | Ticks | Actor snapshots | Draw requests |
| --- | ---: | ---: | ---: | ---: |
| ABOUT | 8 | 1,059 | 1,059 | 982 |
| DinoMart | 6 | 2,491 | 19,928 | 13,718 |
| Total | 14 | 3,550 | 20,987 | 14,700 |

All comparisons passed: 4,910,958 actor bytes, 227,200 signal bytes, ordered
draw requests, release/wait status, and absence of reference diagnostics.
Inputs, outputs and source hashes are bound in
`evidence/about-model/accepted/{INPUTS,CASES,RESULT}.json`.

This is fresh comparison with the preserved E51 model. Independent original
executable acceptance, the native producer of signal zero, pixel rendering,
audio behavior and complete scene behavior are separate evidence obligations.
