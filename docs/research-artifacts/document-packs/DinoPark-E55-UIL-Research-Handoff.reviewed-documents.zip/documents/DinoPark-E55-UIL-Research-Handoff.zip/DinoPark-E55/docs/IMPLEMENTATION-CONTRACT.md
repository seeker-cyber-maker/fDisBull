# E55: ABOUT behavior and a language-independent reconstruction account

User direction: continue from E54 toward explaining how the game works without
committing to a source/target programming language, ready for the existing UIL
producer/consumer boundary. UIL means Universal Interaction Language in the
existing fDisBull proposal. Its grammar and implementation remain with that
owner; this task produces recovered behavior, evidence and research metadata.

## Acceptance

1. Recover ABOUT.ACT's minimum additional semantics in the separate E55 portable
   runtime while preserving all E54 DinoMart behavior and public compatibility.
   Compare exact actor records, signals and ordered effects against original
   executable instructions under declared inputs; do not infer audio timing.
2. Identify and qualify the native ABOUT host/signal producer as far as bounded
   original execution permits. Preserve exact conditions, call order and service
   assumptions, and state any remaining scene boundary.
3. Create a readable game-story map and deterministic, language-independent
   contract packet for the demonstrated animation/presentation rules. Bind
   semantic node IDs to original source spans and accepted evidence; preserve
   numeric width, overflow, rounding, time and order. Explicit unresolved items
   stay machine-visible. No invented canonical UIL serialization or compiler.
4. Relate the broader preserved mechanics/interface/persistence evidence to the
   story without claiming whole-game completeness from candidate counts or a
   few routes. Validate contract/source/evidence joins and repeatable export.
5. Preserve original and earlier milestones, independently review the changed
   seams, run meaningful combined checks, package/recheck/save deliverables.

## Ownership

- Parent: contract/export model, original actor comparison, integration,
  preservation, final reports and delivery.
- Runtime worker: live runtime.py, ABOUT tests, model comparator and contract.
- Native host worker: about_host scripts/tests/evidence and ABOUT-HOST.md.
- Story worker: GAME-STORY-MAP.md and its evidence; later export review.

All original_game and E51–E54 work is immutable. baseline/E54 is the complete
delivered E54 package; small convenience baseline/E51, E53 and fdisbull copies
retain exact original bytes. Native dependencies remain supplied externally.
No remote PR/comment/branch mutation, gameplay campaign, existing guide/Lab/Swift
change, or new downstream UIL runtime is included.
