# DinoPark E55: game story and UIL research handoff

E55 extends the bounded ACT interpreter to ABOUT, connects its original native
signal producer to the retained actor, and organizes the mechanics into
language-independent descriptions with explicit source and evidence links.

Start with [REPORT.md](REPORT.md), [docs/GAME-STORY-MAP.md](docs/GAME-STORY-MAP.md),
and [research/uil-input/ABOUT-STORY.json](research/uil-input/ABOUT-STORY.json).
The six files in `research/uil-input/` are **research metadata for the existing
Universal Interaction Language owner**. They are not canonical UIL syntax,
a new language, or an implemented UIL game runtime.

## Run the current ACT tool

Python 3.12 is the qualified interpreter version. The processor tool uses the
included hash-pinned fDisBull `0.20.0.dev0` wheel directly; no wheel installation
is needed. Original game containers stay external to this package.

```sh
python3 scripts/act.py inspect /path/to/original_game/ABOUT.ACT --out about-inspection.json
python3 scripts/act.py play /path/to/original_game/ABOUT.ACT --ticks 84 --signal 1:0:1 --signal 60:0:1 --out about-playback.json
python3 scripts/export_story.py /path/to/original_game --verify research/uil-input
python3 scripts/export_story.py /path/to/original_game --out new-research-packet
```

Outputs must be new paths. Signal events use `TICK:SLOT:VALUE`, where TICK is the
zero-based tick-call index, SLOT is 0–31 and VALUE is a raw 0–65535 word. These
are explicit playback inputs, not inferred physical page/audio timings.

The public class is `ACTRuntime`; `DinoMartRuntime` remains a compatibility
alias. Runtime snapshots use `dinopark-act-runtime-state-2`; CLI playback uses
`dinopark-e55-playback-2`. New fields preserve ABOUT waits, cadence, frame lists
and the original neighboring-record reads. See
[ABOUT-RUNTIME.md](docs/ABOUT-RUNTIME.md) for exact domain limits.

## Verify or reproduce the bounded original comparisons

Portable public tests need only the bundled wheel and Python standard library:

```sh
python3 scripts/check.py --out portable-tests
```

Original instruction tests additionally need the external game, Unicorn 2.1.4
and Capstone distribution 5.0.9. Install `requirements-native.txt` in your own
environment or supply an existing dependency directory through `PYTHONPATH`.

```sh
python3 scripts/check.py --native-game /path/to/original_game --out native-tests
python3 scripts/about_original_compare.py /path/to/original_game --out new-about-original
python3 scripts/about_host_verify.py --game /path/to/original_game --out new-about-host
python3 scripts/about_host_actor_compare.py /path/to/original_game --out new-about-host-actor
```

The original executable SHA-256 is
`2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`.
ABOUT.ACT and DINOMART.ACT are separately pinned. The original comparisons
perform normal MZ relocation and execute unpatched instructions. Drawing and
device pumping remain explicit adapters in actor-only comparisons; the four
host routines need no service adapters. This is not a whole DOSBox scene run.

## Files and boundaries

| Location | Purpose |
|---|---|
| `src/dinopark_act/` | ACT inspection, typed bounded runtime, existing canvas, semantic research catalog |
| `research/uil-input/` | 122 source-linked ACT rules, six ABOUT story nodes, 22 broader rule cards, source/evidence maps and export receipt |
| `docs/ABOUT-HOST.md` | Original native initialization, navigation, source anchors and unresolved page-service scope |
| `docs/GAME-STORY-MAP.md` | Mechanics, lifetimes, numeric/order requirements and remaining evidence holes |
| `evidence/` | Current acceptance, reviews, original observations and explicitly retained failed calibration evidence |
| `baseline/E54/` | Complete prior milestone, byte-identical to the saved E54 archive payload |
| `baseline/E51/`, `baseline/E53/`, `baseline/fdisbull/` | Pinned reused readers, native loader and processor package |

`MANIFEST.json` is a complete final package inventory. Historical calibration
failures remain labeled and separate from accepted receipts. In particular,
the incomplete early host test log is preserved under
`evidence/about-host/calibration-pre-export/`; the complete rerun is under
`evidence/about-host/qualified/`.

To rebuild and check a delivery, use new output paths outside the source tree:

```sh
python3 scripts/package_e55.py --out /path/to/new-DinoPark-E55.zip
python3 scripts/verify_delivery.py /path/to/new-DinoPark-E55.zip --game /path/to/original_game --native-deps /path/to/native-dependencies --out /path/to/new-delivery-check
```

Packaging refuses original game containers identified by the preserved input
names/hashes or game-container extensions. It retains observation `.bin`
streams, the processor wheel, previous negative archive fixtures and nested
milestone manifests.

Finite tests and rule counts establish the stated local scopes. They do not
prove a whole reconstructed game equivalent to its original, make the current
UIL proposals a canonical grammar, or close the remaining presentation,
interface, resource-lifetime and session-persistence work.
