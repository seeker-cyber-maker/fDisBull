# Portable DinoMart software canvas

`dinopark_act.raster.DinoMartCanvas` turns the bounded interpreter's actual
five-word drawing requests into palette-index pixels and dirty tiles. It is
ordinary Python and imports neither fDisBull nor an emulator. It uses the
software kind-3 semantics qualified against the original animation wrapper in
[KIND3-CONTRACTS.md](KIND3-CONTRACTS.md).

## API

```python
from dinopark_act.raster import DinoMartCanvas

canvas = DinoMartCanvas(
    resource.sprites,
    scroll=0,
    active_page=0,
    clip=(0, 0, 199, 319),  # top, left, bottom, right; inclusive screen bounds
    background=None,
)

for request in tick.draws:
    receipt = canvas.draw(request)

frame = canvas.frame_indices()  # 64,000 bytes, row-major 320 × 200
dirty = canvas.dirty_bytes()    # 1,040 bytes, both original dirty pages
arena = canvas.arena_bytes()    # 196,608 bytes, including segmented storage
```

Every request has the original form
`(sprite_index, caller_kind, world_x, y, mirror)`. The canvas forces kind 3,
subtracts scroll from x using original word wrapping, and applies the qualified
router and raster rules. A valid caller kind is accepted but does not select a
different destination. Mirror must be 0 or 1.

The returned receipt is small: acceptance, rejection/acceptance reason,
original raster-entry identifier, signed screen position, forced kind, selected
dirty page, dirty indices written, and raster address-progression facts. The
entry identifier names the original routine whose behavior is modeled; the
portable canvas does not execute that machine code.

The software pixels occupy one destination surface. `active_page` selects the
dirty-map page, with the original Boolean rule: active 0 selects page 1, and
any nonzero byte selects page 0. It does not create two software pixel buffers.

## Background and persistence

The host chooses when to restore a background:

| Supplied background | Initial state |
| --- | --- |
| `None` | The complete 196,608-byte arena is zero. |
| 64,000 bytes | The visible frame receives those bytes; remaining arena bytes are zero. |
| 196,608 bytes | The complete software arena receives those bytes. |

Mutable buffers are copied, so later caller edits cannot change the canvas.
Each `draw()` preserves previous pixels wherever the new sprite is transparent
or absent. Dirty flags also accumulate. To restore a chosen background for the
next logical frame, construct a new canvas using that background, then apply
the next frame's ordered requests.

This is an explicit host policy. Original game background restoration, hidden
actor cleanup, display-page presentation, and the physical clock are not
implemented by this class. A fresh canvas for every frame is useful for the
current pilot because the runtime emits that frame's ordered drawing requests;
retaining one canvas across frames instead keeps earlier sprite pixels until
something overwrites them.

## Original behavior retained

The wrapper's drawing and dirty coordinates differ. Rendering uses
`world_x - scroll`, whereas dirty marking uses original world x and y with the
full sprite dimensions. The dirty marker runs even if the router rejects every
pixel. Its signed-word arithmetic, 640 × 200 world bounds, 40 × 13 tile grid,
and page selection are retained.

The pixel implementation also retains the qualified original segment and
offset progression. It does not replace those rules with a generic rectangular
blit. In particular, clipped negative x can start with a wrapped offset; row
normalization uses the original signed comparison; and clipped top-row
selection retains the original y-counter behavior. Palette index zero can be
opaque: opacity comes from the sprite commands, not from the color value.

The package modules `_route.py` and `_sprite.py` are byte-identical copies of
`scripts/kind3_route_reference.py` and `scripts/kind3_sprite_reference.py`. Those
frozen E52 references were already checked against original instructions, and
the E54 wrapper corpus extends that qualification to destination kind 3. The
portable canvas is a reusable execution layer over those models; it is not an
independently authored second raster algorithm.

## Input boundaries and failure behavior

The canvas accepts 1–256 decoded `Sprite` records. It checks immutable command,
color, pixel, and opacity arrays against a fresh decoding of each sprite record,
valid dimensions and bounds, and the qualified resident payload limit of
65,520 bytes. This prevents inconsistent decoded arrays from silently becoming
an alternative image source.

Scroll must be a signed 16-bit integer. Active page must be an integer byte.
The four clip values must be ordered signed words. Request fields may be signed
words or raw unsigned words, with the additional sprite-index and Boolean
mirror restrictions. Python booleans are rejected as numeric inputs.

Unusual but valid signed clip coordinates are not silently clamped to the
visible screen. If their routed pixel addresses leave the declared software
arena, the draw raises `ValueError`. Invalid requests and out-of-arena draws
leave committed pixels and dirty flags unchanged. This transactional behavior
is a host API guarantee, not a claim about the original program's invalid-input
behavior.

## Verification

Run the portable tests with only the package source on `PYTHONPATH`:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=dinopark_e54/src \
python3 -m unittest discover -s dinopark_e54/tests -p 'test_raster.py' -v
```

The eight tests use a hand-specified asymmetric 3 × 2 sprite with transparency
and an opaque zero-colored pixel. Expected frame bytes are constructed from
literal destination coordinates. They cover normal and mirrored pixels,
negative-coordinate and bottom clipping, segment-offset wrap, world-coordinate
dirty marking after scroll and rejection, nonboolean active-page values,
background copying, persistence, malformed inputs, and transactional rejection
of an address outside the arena. They require no original game binary.

`scripts/pipeline_compare.py` supplies actual ordered requests from selected
original-verified runtime observations to both this canvas and unchanged
original rendering instructions. Its software cases compare the full arena;
all cases compare visible palette-index frames and both dirty pages after each
draw and at the final frame. Planar original-code cases use the explicitly
declared four-plane device adapter described in the kind-3 contract. The canvas
itself has no VGA device emulation.

The integrated evidence replays previously saved original actor observations;
those observations are not counted as additional unique original actor ticks.
Actor execution and rendering are composed at their qualified drawing-request
boundary, with a declared background reset before each selected frame.
