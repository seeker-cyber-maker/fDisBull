# Resume DinoPark from E53

The completed E53 milestone is **Resource Lifetimes and Connected Rendering**.
Start with `REPORT.md`, then `inventory/PROGRESS.json`. Preserve E53 and the
embedded unchanged E52 archive; create a new milestone directory for further
research. Do not modify original game inputs or earlier deliverables.

## Pinned inputs and continuity

- DINOPARK.EXE: 268,480 bytes, SHA256
  `2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`.
- STRINGS.DAT: 13,445 bytes, SHA256
  `23aca0367d8fb65d5eee69035a7ed04bda7e9816b769f00dadd1e0c86adeae32`.
- E52 archive: SHA256
  `46c74b45ca3e9e5578ee897a704576c031c307e2353361347f1b7829b2b62b36`.
- All 191 original files, 325 recorded E52 working files and six E47–E52
  archives were rehashed unchanged. Prior recovery retains separate guide,
  Lab and Swift materials; E53 does not replace them.
- All 927 candidate identities and all 81 E52 routine-contract records are
  retained. E53 appends 35 scoped records, yielding 116 registry records.
- Physical byte classification is unchanged: 1,948 ranges / 268,480 bytes,
  18,480 bytes in the actual undecoded ledger category, 155 unresolved indirect
  observations at 152 physical sites. No E53 indirect site is removed.

Do not revive E51's old 19,146 traversal headline as the ledger count. E52
reconciled its 78 already-classified table bytes; its corrected ledger metric
is carried forward unchanged. No semantic completion percentage is justified.

## Canonical E53 evidence

Use the five exact paths and SHA256 values in `inventory/PROGRESS.json`:

- `evidence/handles/accepted`: 1,088 fixtures / 1,121 original calls.
- `evidence/allocator/accepted`: 208 fixtures / 1,103 original calls.
- `evidence/resources/accepted`: 611 cases, including all 242 string records.
- `evidence/router/accepted`: all 421 E52 cases plus 12 pin-state cases.
- `evidence/router-allocated/accepted`: the same 421 E52 cases in actual
  create → draw → free sequences.

Every accepted family has zero mismatches. Independent reviewers replayed the
entire resource and allocator matrices byte-identically, reviewed all handle
and router receipts, checked original byte anchors, and ran focused fault
probes. Repeated runs are verification, not additional behavioral cases.

All new executions use Unicorn 2.1.4 and ordinary MZ relocation. No opcode is
patched. The resident and allocated router corpora use no service adapters.
Handle reload-dispatch cases adapt allocation and restore; allocator
initialization adapts successful DOS AH=48h responses; resource wrappers adapt
seven CRT stream operations and capture the fatal entry as a terminal event.
Those boundaries remain explicit and are not proof of actual backing devices,
DOS filesystem behavior or complete shutdown.

Read `evidence/counting/COUNTING-NOTES.json` before interpreting instruction
totals. They are emulator code-hook visits, including intercepted entries in
the handle and stream families, not native retired-instruction measurements.
The derived original-code counts and corrected wording are recorded without
altering the accepted raw receipts or any semantic verdict.

## Facts to retain in reconstruction

Handles are five bytes: offset, segment, flags. A resident block's header is
one paragraph before its data. Header words +0/+2/+4 are previous header,
paragraph count including header, and owner handle offset; byte +8 is flags.
`80` means allocated, `20` pinned, `40` discardable. `08` indicates nonresident
state and low bits select a backend; discard also marks the handle with `10`.

`0688` is a Boolean pin, not a reference count. It tests the nonresident flag
and can reload/write metadata before validating pool segment and offset.
`074B` returns null early on `08|10`. `0766` does no pool validation and returns
`((header_paragraphs−1)&FFFF)*16`. `0797` clears the pin; on its invalid-handle
callback path, returned ES follows callback-preserved or clobbered CX.

`0688`'s allocation-failure callback uses `LES DX,[BP+8]`, shifting the expected
far argument: original handle segment plus the next caller stack word.

`011B` rejects sizes at or above 1 MiB but restores DI/SI/ES from shifted saved
values on that branch. The far return still succeeds. `0269` allocates the full
word product but clears only its low 16 bits: 65,536 requested bytes clear zero,
65,538 clear two. Owner-mismatch free clears the record flag before error 6,
leaving the heap block allocated. Splitting absorbs a one-paragraph remainder.
Compaction preserves pins, updates moved handles, and chooses the later block
for equal-size best-fit ties across a pinned barrier.

The indexed string routine `295E:000D` reads a DWORD offset from
`uint16(index*4)`, then uses one shared buffer. It ignores both read results,
can retain stale text on EOF, strips LF only, and tests the preceding offset
for an empty string. The read wrapper truncates `size*count` to a byte-count
word. The length wrapper sign-extends the byte at FILE+4.

## Next authorized direction

The resident conventional lifetime is now a qualified integration baseline.
The most useful next step is the actual backing-store boundary:

1. Trace `3EE1:0A6F` eviction and the backend/link helpers from real initialized
   descriptors. E53 executes only its no-backend early failure return.
2. Replace the `0688` reload adapters only after the selected original backend
   contract is proved; retain all current fixtures and distinctions.
3. Establish resize `3EE1:0891` / `0A21` and shutdown behavior separately.
4. Connect actual resource loading and scene-owned lifetimes to established
   rendering, preserving the difference between stream adapters and DOS I/O.

Open details include near-1-MiB paragraph overflow, malformed heaps, callback
policies, partial four-byte string-index reads, and fatal cleanup. These are
research obligations, not completed or silently fixed behavior.

For fDisBull v0.20, first pin the actual build and run it on the original
inputs. E53 has not executed or validated that release. Use the saved byte
anchors and edge contracts as regression fixtures; preserve tool output,
original bytes, CS context and a minimal reproducer for any real discrepancy.
Do not label an oracle or fixture correction as a decompiler defect.

## Verification discipline

`scripts/build_e53_inventory.py` validates canonical case completeness, nested
pass checks, source hashes, static byte bindings, generated fixture identity,
cross-mode pixels and all original file hashes before creating its output.
Unknown evidence labels are rejected; omitted rejection checks fail. The
independent review found and the final code fixes those two gate weaknesses.
Their failing pre-fix regressions remain in the calibration history.

Follow `docs/REPRODUCE.md`. Keep accepted directories immutable and send reruns
to new paths. A fresh extraction must verify payload hashes, run the focused
suite without skips when original inputs are supplied, and reproduce all
twelve inventory files byte for byte. The whole binary remains unfinished.
