# DinoPark E54 — ACT processor and DinoMart interpreter

This package contains a real consumer of the current fDisBull processor API,
a standalone interpreter for the eight original `DINOMART.ACT` programs, and
a portable software canvas for the qualified animation drawing boundary.
The interpreter and canvas use Python's standard library. They do not import
fDisBull, Unicorn, Capstone, DOSBox or a native game executable.

Python 3.12 was used for the accepted runs. Commands below start in this
directory. The original game is supplied separately and remains read-only.
Outputs must use new paths.

## Inspect an ACT resource

```sh
python3 scripts/act.py inspect /path/to/original_game/DINOMART.ACT \
  --out /path/to/new-inspection.json
```

The launcher checks and zip-imports the pinned fDisBull wheel from
`baseline/fdisbull`. Its exact SHA-256 is
`74655dee308f60ae7fd6cc8bcb44fec4fe31e93054916d09648fa23611d3195a`.
A separate uploaded wheel bearing the same `0.20.0.dev0` name is older and
does not contain this processor API. Do not replace the pinned wheel by version
name alone.

Inspection preserves resource identity, program identity, file offsets,
instruction bytes, operand-reader lookahead, branch targets, delayed wait
resumes and conservative completeness. It does not execute the inspected code.
All 48 embedded programs in the 57 original ACT resources can be inspected.
See `docs/PROCESSOR.md` for the direct fDisBull API.

## Replay DinoMart with explicit logical ticks

```sh
python3 scripts/act.py play /path/to/original_game/DINOMART.ACT \
  --ticks 401 --out /path/to/new-playback.json

python3 scripts/act.py play /path/to/original_game/DINOMART.ACT \
  --programs 0 --ticks 40 --out /path/to/new-program-0.json
```

The replay JSON contains actor snapshots and ordered draw requests. An optional
`--suspend 100:140` suspends the selected actors for tick-call indices 100 through
139. `--start-tick` sets the initial uint32 logical clock; `--instruction-budget`
bounds dispatch work per actor sweep. Tick count is a simulation choice, not
a recovered frames-per-second value.

The supported execution subset is exactly the 11 opcode values used by all
eight original DinoMart programs: `03 10 11 12 17 1B 1C 40 41 47 4E`.
Other ACT programs may inspect successfully but are rejected by this runtime
when they require unsupported instructions. Nothing silently becomes a no-op.

## Embed the interpreter and canvas

Set `PYTHONPATH=src`, then use the independent runtime directly:

```python
from pathlib import Path
from dinopark_act.assets import decode
from dinopark_act.runtime import DinoMartRuntime
from dinopark_act.raster import DinoMartCanvas

resource = decode(Path("/path/to/original_game/DINOMART.ACT").read_bytes())
player = DinoMartRuntime(resource)

for logical_tick in range(40):
    event = player.tick(logical_tick)
    # This example chooses a fresh zeroed background for each host frame.
    # Supply the reconstruction's background here when it is available.
    canvas = DinoMartCanvas(resource.sprites, scroll=0, active_page=0)
    for request in event.draws:
        canvas.draw(request)
    index_frame = canvas.frame_indices()  # 320 * 200 palette indices
    dirty_pages = canvas.dirty_bytes()    # Two complete 520-byte tile maps
```

For persistent drawing, retain one canvas across calls. For restoration, create
a new canvas with a supplied 64,000-byte background, or a complete 196,608-byte
software arena. That choice belongs to the host; original scene background
restoration has not been reconstructed here. Palette indices require a verified
scene palette before they become original colors. Index zero can be opaque;
the sprite opacity mask, not its color value, controls transparency.

The canvas applies horizontal scrolling and the original kind-3 geometry. Its
dirty marker uses unscrolled world coordinates and can mark tiles even when
the sprite is rejected by clipping. See `docs/RASTER.md` and
`docs/KIND3-CONTRACTS.md` for bounds and original entry points.

## Run the public tests

The portable tests use authored fixtures and do not require original assets:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 scripts/check.py \
  --out /path/to/new-portable-test-receipt
```

To include original-code rendering checks, provide the original game and
Unicorn/Capstone in the Python environment. The accepted dependency versions
are recorded in `requirements-native.txt`.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 scripts/check.py \
  --native-game /path/to/original_game \
  --out /path/to/new-complete-test-receipt
```

The original tests fail if required assets or dependencies are absent. They
are not silently counted as successful skips.

## Reproduce the bounded comparison layers

Each command writes a new output directory. These are separate experiments;
their counts are not additive estimates of whole-game coverage.

```sh
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=src:baseline/fdisbull/fdisbull-0.20.0.dev0-py3-none-any.whl \
python3 scripts/inspect_validation.py /path/to/original_game \
  --out /path/to/new-processor-evidence

PYTHONDONTWRITEBYTECODE=1 python3 scripts/runtime_model_compare.py \
  /path/to/original_game --out /path/to/new-model-evidence

PYTHONDONTWRITEBYTECODE=1 python3 scripts/runtime_original_compare.py \
  /path/to/original_game --out /path/to/new-original-actor-evidence

PYTHONDONTWRITEBYTECODE=1 python3 scripts/kind3_verify.py \
  /path/to/original_game --out /path/to/new-kind3-evidence

PYTHONDONTWRITEBYTECODE=1 python3 scripts/pipeline_compare.py \
  /path/to/original_game --out /path/to/new-pipeline-evidence
```

The final three require the native verification dependencies. The pipeline
defaults to the source-bound original actor evidence already included in this
package; `--actor-evidence` can select a freshly reproduced actor corpus.
It replays the portable runtime against selected saved original actor records,
then executes their actual draw tuples through original rendering code and the
portable canvas. It does not claim a single complete original scene run.

## Evidence and boundaries

- `evidence/processor-validation`: full resource/program inspection.
- `evidence/runtime-model/accepted`: typed runtime versus preserved E51 model.
- `evidence/runtime-original/accepted`: fresh original x86 actor execution,
  complete actor/signal bytes and ordered drawing/device requests.
- `evidence/kind3/accepted`: original wrapper, resident-resource route,
  software/planar raster and dirty-map checks.
- `evidence/pipeline/accepted`: composed runtime-to-pixel comparisons.
- `evidence/reviews`: independent source, observation and preservation checks.
- `evidence/integrated-tests`: final public test run on the combined source.

Original actor execution uses authenticated far-return adapters for drawing
and the device pump. The rendering experiment separately executes the real
drawing wrapper and its resident-resource services without interceptions.
Planar output uses an explicit four-plane, full-byte mode-zero/map-mask device
boundary. VGA latches, scanout, palette setup, original display initialization,
wall-clock pacing, sound and whole-scene behavior are outside these results.

The original game, E53 and prior fDisBull review remain preserved. This package
adds component evidence; it does not replace the 927-candidate inventory,
reclassify the historical byte ledger or assert whole-binary completion.
See `REPORT.md`, `HANDOFF.md` and `PROGRESS.json` for the completed result and
the next narrowly scoped integration targets.

## Check a delivered archive

The package manifest records every included payload's size and SHA-256.
The verifier extracts to a new directory, checks those bytes and the canonical
evidence bindings, runs the complete public suite from the extracted source,
and reproduces both real-asset CLI outputs exactly:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_delivery.py \
  /path/to/DinoPark-E54-ACT-Interpreter.zip \
  --game /path/to/original_game --out /path/to/new-delivery-check
```

Supply `--native-deps /path/to/existing/dependencies` if the native verification
dependencies are in a separate directory. Original game files and native
verification dependencies are not bundled. All generated verification output
stays outside the extracted package.
