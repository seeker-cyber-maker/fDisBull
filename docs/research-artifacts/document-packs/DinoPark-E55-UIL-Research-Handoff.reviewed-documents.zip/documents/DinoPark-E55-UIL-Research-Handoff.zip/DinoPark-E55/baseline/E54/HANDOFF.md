# DinoPark E54 handoff

**Date:** 28 October 2026. **Milestone:** ACT processor and bounded DinoMart
interpreter/rendering pilot completed. Continue from E54; keep the completed
E53 and preceding fDisBull assessment as preserved baselines.

## Implemented public surface

- `src/dinopark_act/processor.py`: actual current `fdisbull.processor` consumer;
  `ACTProgram`, `ACTProcessor`, `inspect_program`, `inspect_bytes`.
- `src/dinopark_act/runtime.py`: standalone `DinoMartRuntime`, explicit uint32
  ticks, suspension/visibility masks, word signals, ordered draw requests and
  full 234-byte actor records for the declared zeroed fixture.
- `src/dinopark_act/raster.py`: standalone `DinoMartCanvas`, 320×200 index
  frames, two dirty-map pages and full software arena. It consumes actual
  runtime draw tuples and retains the qualified original software quirks.
- `scripts/act.py`: hash-pinned `inspect`/`play` CLI. `README.md` has executable
  examples, direct embedding and reproduction commands.

Runtime opcode subset: `03 10 11 12 17 1B 1C 40 41 47 4E`. It covers all eight
original DinoMart programs, not every program the processor can inspect.
The independent runtime and canvas import neither fDisBull nor an emulator.

## Canonical accepted evidence

| Receipt | Accepted result |
| --- | --- |
| `evidence/processor-validation/RESULT.json` | 57 resources, 1,514 sprites, 48 programs, 679 instructions; zero wrapper mismatches |
| `evidence/runtime-model/accepted/RESULT.json` | 2,491 ticks, 19,928 actor snapshots, 13,718 draw requests; zero mismatches |
| `evidence/runtime-original/accepted/RESULT.json` | Same six profiles and counts against fresh original x86; all actor/signal bytes, returns and ordered service requests match |
| `evidence/kind3/accepted/RESULT.json` | 358 original rendering cases, 179 software plus 179 planar; zero mismatches |
| `evidence/pipeline/accepted/RESULT.json` | 16 original actor checkpoints, 64 surface/frame batches, 308 original draw calls; zero mismatches |
| `evidence/cli/RESULT.json` | Real-asset inspect and suspended play, plus 14 subprocess tests |
| `evidence/integrated-tests/RESULT.json` | 63 combined public tests pass, zero failures/errors/skips, after per-suite discovery guard |
| `evidence/reviews/` | Independent processor, original-runtime, preservation, CLI, raster/pipeline and packaging-code reviews |

The native/model comparison families reuse the same 2,491 fixture ticks. Do
not sum their counts as new unique coverage. The pipeline replays the typed
runtime against 16 selected saved original actor observations and makes fresh
original rendering calls. It adds zero original actor ticks. Its four surface
configurations are software/planar × scroll 0/320, with supplied active pages
0/1 and a fresh declared background for each frame.

Historical failure/calibration artifacts are retained in explicitly named
directories. They are not the canonical final receipts. In particular,
`integrated-tests-before-discovery-guard` is the initially valid 63-test run
on the earlier runner; `test-discovery-guard` demonstrates the missing-suite
failure and correction in a disposable copy. Use `integrated-tests` for the
final combined result.

## Exact input and dependency identity

| Input | SHA-256 |
| --- | --- |
| `DINOPARK.EXE` | `2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c` |
| `DINOMART.ACT` | `c56a83b45a5a33c7d816c02b9af873e3cef986d0038e180933feea1776d6c214` |
| Current fDisBull wheel | `74655dee308f60ae7fd6cc8bcb44fec4fe31e93054916d09648fa23611d3195a` |
| Older separately uploaded wheel | `23922b2b79f53dfa75596b416478ff4082eb69c95103564523982f45dd1cede2` |
| E53 final ZIP | `ad83f9ae8cb689ee9ee603914aadc1f18299155d061f43b27e8918a035f9b848` |

Both wheels bear `0.20.0.dev0`; only the current offline-bundle wheel contains
the needed processor foundation. The package retains it under
`baseline/fdisbull`; the launcher checks its hash. Original assets are supplied
separately. Native verification used Unicorn 2.1.4 and Capstone distribution
5.0.9 (module reports 5.0.7); portable execution does not need these.

## Critical recovered behavior

- Keep file offsets, ACT program offsets and relocated x86 CS:IP separate.
- ACT container words are little-endian; instruction words are big-endian.
- Branch displacement is biased, not ordinary signed-byte arithmetic:
  `raw < 128 ? raw : 126 - raw`, added after instruction length.
- Waits retain PC until release. Deadline zero is a nonreleasing sentinel in
  the qualified update path. Rendering occurs before new script visibility
  changes in a tick.
- The actual draw wrapper is `1B29:1102`. It forces kind 3, subtracts scroll
  before router `1F0B:1174`, then marks dirty tiles at `1B29:11A4` using the
  unscrolled world position and full sprite dimensions even after rejection.
- The back page is `!active_page`, not XOR one for arbitrary byte values.
- Sprite opacity is separate from its palette index; zero can be opaque.

The actor harness uses authenticated draw/device-pump far-return adapters;
the separate rendering harness executes the actual wrapper, router, resident
lock/unlock, raster and dirty-marker path with no intercepted calls. All
original opcode bytes remain unchanged. Instrumentation counters are
code-hook visits, not retired instructions.

## Explicit remaining limits

The canvas and pipeline use supplied backgrounds, resident resources, scroll,
clip and page fixtures. Full-scene background restoration, palette selection,
real-time pacing, sound, native signal producers, scene callbacks and original
resource loading are not reconstructed by this pilot. Planar verification
models four planes and mode-zero full-byte/map-mask writes; VGA latches,
scanout and original mode initialization are outside its scope. No whole-game
or SMT equivalence proof has been performed.

Bounds and transactional failure behavior are host policies, not claims about
original malformed-input acceptance. Full 234-byte actor equality applies to
the supplied zero-initialized state and supported instructions; it is not
arbitrary DOS save-state compatibility.

## Next useful implementation slice

1. Target `ABOUT.ACT` program 0: 74 bytes, 20 instructions, 14 opcode values.
   Extend the runtime minimally for its signal, F3 frame-list and frame-wait
   behavior using the preserved full opcode contracts.
2. Identify the native source that sets signal 0 to exactly 1 and its audio or
   scene dependency. A synthetic pulse remains a fixture, not original timing.
3. Qualify the presentation's actual palette, background and restoration path
   through the now-connected kind-3 renderer.
4. Compare one complete bounded original presentation with the reconstructed
   host under the same external events. Then consider THEORIES or MANLEY.

Keep the E53 backlog: original backing-store eviction/reload and links,
allocator resize `3EE1:0891`/`3EE1:0A21`, shutdown, actual CRT/DOS file access,
fatal cleanup, and scene-owned resource lifetimes. `INTRO.DMO` remains a
separate recorded-input grammar task.

## Continuity and previous deliverables

The exact original-game file set and all 367 recorded protected files remain
unchanged. `baseline/E53/DinoPark-E53-Progress.json` and the previous handoff
are included unchanged. The historical 927-candidate inventory and byte
ledger are retained; E54 adds component evidence without reclassifying them.

- [E53 final source/evidence package]([private Library link omitted])
- [E53 report]([private Library link omitted])
- [Prior fDisBull/ACT assessment]([private Library link omitted])
- [Prior fDisBull/ACT assessment evidence]([private Library link omitted])

The E54 archive has a complete per-file hash manifest. Its separate delivery
receipt binds the ZIP, safe fresh extraction, accepted source/evidence hashes,
all 63 public tests and exact real-asset CLI outputs from the extracted tree.
