# E54: ACT processor and DinoMart interpreter pilot

Date: 2026-10-28. Continue from the completed fDisBull/ACT assessment. All edits are confined to this new E54 tree. Original assets, E53 and earlier research, and fDisBull sources are immutable inputs.

## Acceptance

1. A real ACT processor using the pinned current fDisBull processor API inspects every original embedded program and exposes source identity, byte offsets, raw operands/read extent, authoritative opcode meaning, branch/wait/resume facts and conservative completeness.
2. A standalone bounded DinoMart interpreter executes the eight original programs with explicit logical ticks and suspension, producing actor state and ordered draw requests. Verify fresh against original executable behavior, not only the prior model.
3. Investigate and, if the original boundary can be qualified, connect the animation destination-kind-3 path. Any declared device/service boundary stays explicit; final pixels require actual evidence.
4. Deliver an executable CLI, focused tests, bound receipts, a reproducible package and honest handoff. No whole-game or wall-clock equivalence claim.

## Ownership and stable seams

- Parent owns CLI/integration/original-state oracle, preservation, packaging and report.
- Decoder worker owns processor.py and its tests/inspector evidence. Reuse assets.py and tokens.py read-only; all operation meanings come from data/opcode-contracts.json. Expose ACTProgram and inspect_bytes(data, name=...), and document the final API for integration.
- Runtime worker owns runtime.py and its focused tests/reference comparisons. It can consume assets.ActorFile and tokens.token directly and must work without importing fDisBull. Expose a DinoMartRuntime and explicit tick/snapshot interface, documenting state fields and exact byte-record serialization needed for an original-code comparator.
- Rendering worker owns new scripts/docs/evidence prefixed kind3, investigating actual original router paths. It must not edit earlier milestones or claim software-memory tests cover VGA semantics.

assets.py is an unchanged E51 codec copy. tokens.py changes only its codec import to the package-relative form. The actual current fDisBull wheel is pinned under baseline/fdisbull and may be put on PYTHONPATH as a zip import; no dependency installation is necessary for its pure processor API.

The native original-code harness can use baseline/E53/original_machine.py with the already available Unicorn/Capstone under ../dinopark_e52/private/deps. No original opcode patches are permitted for new Unicorn comparisons. Original I/O or drawing adapters must be reported explicitly. Avoid counting code-hook visits as retired CPU instructions.
