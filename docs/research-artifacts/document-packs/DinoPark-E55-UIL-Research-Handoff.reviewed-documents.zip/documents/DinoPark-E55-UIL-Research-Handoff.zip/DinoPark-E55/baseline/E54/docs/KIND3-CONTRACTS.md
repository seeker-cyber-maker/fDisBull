# Original animation kind-3 rendering contract

This E54 connection starts at the animation drawing wrapper in the supplied
`DINOPARK.EXE`, executes the original router and raster code, and compares the
resulting memory with a separate pixel calculation. It supports the bounded
DinoMart ACT pilot. It does not recreate a complete game frame or claim physical
VGA output.

## Original path and coordinate systems

The animation renderer calls `1B29:1102` with five word arguments:
`(sprite_index, caller_kind, world_x, y, mirror)`. The wrapper's original
instructions establish two different coordinate contracts:

| Boundary | Original behavior |
| --- | --- |
| `1B29:1102` to `1F0B:1174` | Forces destination kind 3, ignores the caller's kind, and subtracts the signed word at `DS:3DEE` from x. |
| Resource acquisition | The router calls original resident service `3EE1:0688` and repairs the sprite descriptor's command/color pointers from the resident handle. |
| Raster | The router selects an original clipped or fast raster function through its original function pointer. |
| Resource release | The router calls original resident service `3EE1:0797`. Both resident pin bits return to their original unpinned value. |
| `1B29:1102` to `1B29:11A4` | Marks dirty tiles using the original world x and y, plus the full sprite width and height. The dirty call still occurs when the router rejects the draw. |

`evidence/kind3/accepted/STATIC.json` contains the freshly decoded original
instructions for the wrapper, dirty marker, and router, together with their byte
hashes and the pinned executable hash. In particular, the wrapper's far call at
`1B29:112A` uses kind 3 and scrolled x. Its call at `1B29:115C` uses world x for
the dirty marker. These are separate calls, and the latter is not gated on the
router accepting the former.

For example, sprite 79 is 90 × 18 pixels at world position (4, 27). With scroll
160 its screen x becomes −156, so its pixels are rejected. The wrapper still
marks world tile columns 0–5 in rows 1–2: 12 tiles on the selected dirty page.
This prevents a mistaken reconstruction in which offscreen rendering and dirty
tracking share the same clipped coordinates or early return.

## Two destination branches

| Router state | Selected output | Original raster entries |
| --- | --- | --- |
| `DS:A27E == 0` | Kind 3 selects the same software surface pointer (`DS:A0C3/A0C5`) as kind 1. | Clipped `191D:1478`; fast `191D:1735`. |
| `DS:A27E != 0` | Kind 3 selects page `!DS:4292`. The page is looked up by the planar raster through the segment table at `191D:002E`. | Clipped `191D:08FB`; fast `191D:0ABE`. |

The page choice is Boolean inversion of the active-page **byte**, not XOR 1:
zero selects page 1, and any nonzero value selects page 0. The corpus includes
active values 0, 1, 2, and 255. Two distinguishable page segments (`A000`, `A400`)
are supplied so that selecting the wrong page changes the compared output.

The frozen `kind3_route_reference.py` preserves the earlier E52 kind-1/2
geometry model without editing it. The independent reference invokes kind 1
only for its geometry and software-surface selection, which are the same
original branch arms used by kind 3 here. The emulated CPU receives kind 3 from
the original wrapper. This reference reuse does not bypass the kind-3 branch in
the observed execution.

## Dirty map

The original dirty marker writes to two 520-byte pages at `DS:91DB`. Each page
has 40 columns and 13 rows of 16 × 16 pixel tiles. It uses the same Boolean
back-page choice, `!DS:4292`, in both rendering modes.

Bounds calculations use original signed-word arithmetic. Negative start x/y
are clamped to zero; starts at x ≥ 640 or y ≥ 200 return without writes. Right
and bottom tile limits come from `(x + width + 15) >> 4` and
`(y + height + 15) >> 4`, with signed word wrapping before the shift. Tile loops
are additionally bounded at 40 columns and 13 rows. The independent
`dirty_indices()` implementation expresses that contract without executing or
consulting the observed dirty writes. Whole dirty-map bytes are compared, not
only the tiles predicted to change.

## Explicit fixture and device boundaries

The CPU executes the pinned, relocated original DOS instructions using the
unchanged E53 `OriginalMachine`. There are no original opcode patches,
intercepted calls, or substituted resident resource services in these tests.
The host supplies a bounded setup around those instructions:

- Actual decoded `DINOMART.ACT` sprite descriptors, resident payloads, handles,
  and block headers. The original lock and unlock instructions run against
  these supplied structures; original allocation and file loading do not run.
- Valid clip, scroll, page, function-pointer and surface globals.
- A patterned initial background so transparent pixels, clipped pixels, and
  untouched pages have observable nonzero values.
- A software surface with pitch 320, or a planar surface with pitch 80.
- A caller stack and the original mutable raster scratch words.

Software drawing writes ordinary emulated memory. Its independent expected
pixels use the unchanged E52 sprite reference, including the previously
qualified segmented-address and clipped-row behavior.

Planar drawing has an explicit device adapter. Original port instructions set
the graphics-controller index/mode and sequencer map mask. Each original byte
or word write in the `A0000..AFFFF` aperture is applied to the selected members
of four independent 64 KiB planes. The declared operation is a full-byte,
mode-zero replacement write: data rotation zero, replace operation, set/reset
disabled, and bit mask `FF`. No other VGA raster operation is modeled. Reads
of graphics mode return the model's current mode, and unexpected ports, widths,
indices, or write modes fail the check.

Expected planar pixels are computed independently from the decoded sprite's
opacity and color arrays, the predicted clipping bounds, the mirror flag, and
the selected page segment. They do not replay or inspect the observed aperture
writes. All four full plane arrays are compared after every draw, including
the other page and bytes outside the visible 320 × 200 image. The flat Unicorn
aperture itself is not a substitute for these planes.

This boundary does not model VGA latches, display scanout, palette setup,
original mode initialization, physical timing, or the device pump. The
supplied background is not original background restoration. Sequential draws
therefore verify ordered compositing into this declared starting surface;
they do not establish a complete animation-frame presentation pipeline.

## Reusable integration API

`scripts/kind3_rendering.py` exposes a verification helper, not a portable
shipping renderer:

```python
from kind3_rendering import Kind3Renderer
from dinopark_act.assets import decode

resource = decode((game / "DINOMART.ACT").read_bytes())
renderer = Kind3Renderer(
    game / "DINOPARK.EXE",
    resource.sprites,
    backend="planar",       # or "software"
    scroll=160,
    active_page=0,
)
receipt = renderer.draw((sprite_index, caller_kind, world_x, y, mirror))
assert receipt["passed"]
assert renderer.frame_indices() == renderer.expected_frame_indices()
assert renderer.dirty_bytes() == renderer.expected_dirty_bytes()
```

`draw()` accepts actual ordered tuples emitted by the standalone interpreter.
Repeated calls retain the observed and expected surface and dirty-map states.
`frame_indices(page=None)` returns 64,000 palette-index bytes for the selected
back page, or the explicitly requested page 0/1. Its `expected_` counterpart
returns the independently calculated image. `dirty_bytes()` and
`expected_dirty_bytes()` return all 1,040 dirty-map bytes. The receipt also
includes original call order, exact arguments, flags, port events, observed
code addresses, memory hashes, plane hashes, image hashes, and named checks.

An optional `machine=` parameter permits reuse of a pinned `OriginalMachine`
between independently initialized fixtures. Construction resets it. A
comparison failure invalidates that fixture for further accepted evidence;
construct a new fixture before continuing. Inputs are explicitly bounded to
five original words, an available sprite, and mirror 0/1. Constructor options
also validate the selected backend, scroll word, page byte, and clip bounds.

## Comparison scope and reproducibility

Every case compares the complete 1,114,112-byte emulated physical image,
excluding the 64 KiB caller stack and 34 bytes of original mutable renderer
scratch. Planar cases also exclude the flat 64 KiB device aperture from this
ordinary-memory comparison, because all four independent device planes are
compared separately. The write hook still restricts CPU writes to the actual
512-byte stack window plus arguments, the declared scratch, dirty map,
descriptor pointer words, two resource flag bytes, and selected output arena.
Rejected draws cannot write output or resource pointers.

The checks also require exact wrapper/router/raster arguments, correct call
order, correct handle arguments, pinned flags at draw time, released flags on
return, preserved BP/SI/DI and DS, returned SP, and a clear direction flag.
Reported execution counts are code-hook visits, not claims about retired
instructions on physical hardware.

Run the corpus from the workspace containing E52 dependencies and E54:

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=dinopark_e52/private/deps:dinopark_e54/src:dinopark_e54/scripts \
python3 dinopark_e54/scripts/kind3_verify.py \
  dinopark_recovery/original_game \
  --out dinopark_e54/evidence/kind3/new-run
```

The output directory must be new and cannot overlap original inputs. A single
case can be selected with `--case` and its exact ID from `CASES.json`. For
focused contract checks:

```bash
PYTHONDONTWRITEBYTECODE=1 \
DINOPARK_GAME="$PWD/dinopark_recovery/original_game" \
PYTHONPATH=dinopark_e52/private/deps:dinopark_e54/src:dinopark_e54/scripts \
python3 -m unittest discover -s dinopark_e54/tests -p 'test_kind3*.py' -v
```

Original input hashes and verification-source hashes are recorded in the
accepted result. The six focused tests include a deliberately corrupted
independent plane expectation: that comparison must fail, demonstrating that
the checker detects disagreement rather than merely completing execution.

The standalone corpus uses the 13 actual sprite/frame choices and their
original DinoMart positions, plus declared scroll, mirror, active-page, edge
clipping, and rejection fixtures. It qualifies this rendering boundary.
Evidence that the new interpreter itself supplies matching ordered requests
belongs to the separate integrated runtime-to-rendering run.

## Accepted evidence

The completed corpus in `evidence/kind3/accepted/RESULT.json` records:

| Measure | Result |
| --- | ---: |
| Cases | 358 |
| Mismatches | 0 |
| Software / planar cases | 179 / 179 |
| Accepted / rejected draws | 194 / 164 |
| Fast / clipped raster calls | 142 / 52 |
| Compared ordinary-memory bytes across cases | 363,647,092 |
| Compared independent planar bytes across cases | 46,923,776 |
| Original code-hook visits | 3,397,319 |
| Original opcode patches / intercepted calls | 0 / 0 |

`CASES.json` contains each check and observed execution receipt.
`focused-tests/RESULT.json` and `focused-tests/unittest.log` bind the six focused
tests to their source files and show six passes with no skips. The independent
reference corruption test passes only when the intentionally wrong expected
plane makes the original/reference comparison fail.

Pinned input SHA-256 identities, confirmed unchanged after the corpus:

- `DINOPARK.EXE`:
  `2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`
- `DINOMART.ACT`:
  `c56a83b45a5a33c7d816c02b9af873e3cef986d0038e180933feea1776d6c214`

The complete case-receipt SHA-256 is
`abc99e984a21a82bf4870c12ebbfa8765181fe5a30a70da4961c31859ded2541`.
The result also binds the verifier, helper, both reference models, original CPU
harness, and asset decoder by their individual source SHA-256 values.
