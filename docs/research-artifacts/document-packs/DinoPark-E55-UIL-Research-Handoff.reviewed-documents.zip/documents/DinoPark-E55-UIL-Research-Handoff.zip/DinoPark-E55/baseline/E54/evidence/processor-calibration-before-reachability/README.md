# Calibration before conservative reachability fix

The prior inspector called all not-yet-visited linear offsets unreachable even when graph traversal stopped at its budget. The focused budget regression now fails on that label. The final version keeps unvisited offsets separate and only reports local unreachable offsets after graph traversal closes without unresolved edges. No underlying decoder/original semantic claim changed. Prior source and all-resource output are preserved here with their hashes.
