# DinoPark E54: ACT processor and a working DinoMart interpreter

**Date:** 28 October 2026  
**Status:** The bounded processor/interpreter/rendering pilot is implemented and verified.  
**Original executable:** `DINOPARK.EXE`, SHA-256 `2127315b475b560f8c0fe409769fd6d137e26d9390d2fafc7d03a60a266a827c`.

## 1. Result

The current fDisBull development build can support a custom processor module
for DinoPark's embedded ACT animation programs. E54 now contains that module,
a small standalone interpreter for all eight original DinoMart programs, and
a portable software canvas that consumes the interpreter's actual draw
requests. This makes the proposed reconstruction component concrete.

The strongest new behavioral result is a fresh comparison against unchanged,
relocated original x86 instructions: the portable interpreter matched
**19,928 complete actor snapshots and 13,718 ordered draw requests across
2,491 logical ticks**, with zero mismatches. A connected rendering experiment
then checked **64 frame batches and 308 original draw-wrapper calls** against
the portable canvas. Pixel indices, dirty maps and complete software arenas
matched within the declared fixtures. These experiments establish bounded
component behavior; original full-scene timing and presentation remain open.

The complete combined public suite passed **63 tests, with zero failures,
errors or skips**. Preservation checks found all **367 recorded protected
files unchanged**, including the original game's complete 191-file entry set,
140 E53 files and 36 files from the preceding fDisBull review. No original game
or fDisBull source was edited. Evidence: [original actor comparison][native],
[pipeline comparison][pipeline], [combined tests][tests] and
[preservation review][preservation].

## 2. How this relates to the “videos”

The preserved asset inventory identifies compressed pictures, masked sprites,
embedded ACT animation programs and native scene orchestration. It does not
identify conventional AVI/FLI/FLC/MPEG-style movie assets among the supplied
files. This inventory observation does not prove that the executable could
never support another format. `INTRO.DMO` is a separate recorded-demo/input
mechanism whose remaining record grammar is still outstanding.

That distinction makes ACT a useful processor target: the visually animated
presentation can be driven by small authored programs. A reconstruction can
retain those original program bytes and execute their recovered behavior,
while its own host supplies surfaces, palette, clocks, input, audio and scene
services. Assets with no embedded ACT program can still be animated by native
callbacks. A zero program count is therefore not a “static image” verdict.

The preceding assessment documented this asset context and proposed DinoMart
as the smallest useful executable integration target. E54 implements that
target and adds fresh original-code evidence. The next education/presentation
target remains `ABOUT.ACT`, whose signal and frame-list behavior requires more
host integration. [Prior assessment][assessment]; [preserved E53 handoff][e53handoff].

## 3. What was implemented

### ACT processor using the actual current API

`src/dinopark_act/processor.py` consumes the real `fdisbull.processor` types:
`ProcessorInfo`, `Location`, `Successor`, `DecodedInstruction` and
`decode_instruction`. It does not simulate that interface with a similarly
named local class. A processor instance binds one exact immutable program
object and gives it an address space containing the resource SHA-256 and
program index.

The public entry points are `ACTProgram`, `ACTProcessor`, `inspect_program`
and `inspect_bytes`. Resource inspection computes source hashes and program
file offsets from the validated original container. Each decoded instruction
retains its stored opcode, consumed bytes, inspected bytes, operand values,
reader scratch, authored mnemonic, qualified meaning, original dispatcher
anchor, control-flow information and source coordinates.

Several details matter for faithful inspection:

- Container fields and sequence lengths use little-endian words; instruction
  word operands use big-endian signed decoding.
- A reader may inspect a byte belonging to the following instruction without
  consuming it. The report separates `size` from `read_size` and retains the
  extra lookahead bytes.
- Branches retain the raw encoding, effective adjustment and target, and
  distinguish valid instruction boundaries from out-of-range or interior
  byte positions.
- Waits can retain their PC and resume only through a later update/release
  step. Their successors are labeled as blocked or delayed resume rather
  than ordinary immediate fallthrough.
- Linear decode completeness and reachable-graph completeness are reported
  separately. A traversal stopped by a budget cannot declare unvisited
  instructions unreachable.

The inspection driver parsed all **57 ACT resources, 1,514 sprites, 11
script-bearing resources, 48 programs and 679 stored instructions**. Those
instructions use 32 distinct opcode values; 22 instructions inspect lookahead
bytes. The wrapper/identity/control-flow regression had zero mismatches with
the preserved operand reader. Because it shares that qualified reader, this
layer is not an independent semantic proof. [Processor documentation][processordoc];
[processor validation][processor].

### Exact fDisBull dependency identity

The wheel extracted from the supplied offline runtime bundle contains the
processor interface needed here. Its SHA-256 is:

```text
74655dee308f60ae7fd6cc8bcb44fec4fe31e93054916d09648fa23611d3195a
```

The separately supplied standalone wheel has the same `0.20.0.dev0` filename
and version label but different, older contents. The launcher validates the
current wheel by hash and imports its pure processor API directly. The
reconstructed runtime and canvas do not depend on fDisBull or an emulator.
This is a consumer of the processor foundation; E54 does not add native
project-database import for arbitrary virtual machines. [Processor
documentation][processordoc]; [preservation and dependency audit][preservation].

### Standalone typed interpreter

`src/dinopark_act/runtime.py` executes the **11 opcode values used by all eight
original DinoMart programs**:

```text
03 10 11 12 17 1B 1C 40 41 47 4E
```

They cover terminal/yield behavior, draw order, direct frame offset,
visibility, biased branch, base sprite, frame count, coordinates, group and
deadline wait. Other instructions fail validation instead of silently
becoming no-ops. The host supplies explicit uint32 logical time, a suspension
mask, an optional visibility mask and optional updates to the 32 word-valued
signal slots. This particular subset preserves signals but does not consume
signal opcodes.

`DinoMartRuntime.tick` returns immutable actor snapshots and ordered draw
tuples. The runtime preserves the recovered finite-width arithmetic,
signed comparisons, render/schedule order, delayed wait advancement and the
zero-deadline sentinel. Its record serializer reproduces every byte of the
234-byte actor layout for the declared zero-initialized fixture. Unmodeled
fields stay zero because this subset never writes them; the serializer is not
an arbitrary original save-state importer.

The runtime validates program boundaries and sprite references, and limits
dispatch work with an explicit instruction budget. A failed host tick leaves
the previously committed state unchanged. That transactional behavior is a
portable API policy; it does not claim original malformed-input or failure
semantics. [Runtime contract][runtimedoc]; [runtime source][runtime].

### Portable canvas and original animation wrapper

`src/dinopark_act/raster.py` implements `DinoMartCanvas`, consuming the same
five-word tuples returned by the runtime. It produces a 320 × 200 palette-index
frame, both original dirty-map pages, and the complete software arena for
verification. It preserves the frozen E52 software route/raster model rather
than replacing its segmented-address details with a new approximate blitter.

Tracing the actual actor drawing call resolved a previously open integration
point. The original renderer calls `1B29:1102`; this wrapper forces destination
kind 3, subtracts horizontal scroll from x, and calls router `1F0B:1174`. The
resident path locks the sprite resource, updates descriptor pointers, executes
the selected original raster, releases the resource, and then invokes dirty
marker `1B29:11A4`.

The dirty marker receives the **unscrolled world coordinates and full sprite
dimensions**, even when the router rejects drawing. This is observable:
sprite 79 at world `(4,27)` with scroll 160 draws no pixels but still marks
its 12 world tiles. The selected back page is Boolean inversion of the active
page byte: zero chooses page 1; any nonzero value chooses page 0.

Software kind 3 uses the qualified software-destination geometry. The planar
branch selects the original planar functions and uses an explicit four-plane
device model. The portable canvas is a software implementation; the pipeline
compares its resulting visible pixel indices with both original branches.
The canvas copies supplied backgrounds and retains previous draws until the
host creates a new canvas. Original frame-background restoration is not
implemented. [Original kind-3 contracts][kind3doc]; [portable canvas][rasterdoc].

## 4. Verification and what each layer establishes

| Layer | Accepted result | Meaning |
| --- | --- | --- |
| Processor inspection | 57 ACTs; 48 programs; 679 instructions; zero wrapper mismatches | Resource identity, decoded records and conservative graph facts |
| Runtime against preserved E51 model | 2,491 ticks; 19,928 actor records; 13,718 draws; zero mismatches | Independent portable implementation regression against the earlier model |
| Runtime against fresh original x86 | Same six profiles and 2,491 ticks; zero mismatches | Complete actor/signal bytes, update/scheduler returns and ordered service requests |
| Original kind-3 rendering | 358 cases: 179 software and 179 planar; zero mismatches | Original wrapper/router/resident-resource/raster/dirty behavior within declared surfaces |
| Connected runtime/rendering | 16 actor checkpoints × four surface configurations = 64 frame batches; 308 draws; zero mismatches | Actual runtime draw tuples produce matching indices and dirty maps through the qualified rendering boundary |
| Combined public tests | 63 passed; zero failures, errors or skips | Public behavior, malformed-input rejection, bounds and CLI behavior |

The two runtime comparison families use the **same 2,491 fixture ticks**. Their
counts must not be added into 4,982 unique behavioral fixtures. The 4,982 number
in the native receipt is instead the number of original update plus scheduler
calls. Similarly, the connected pipeline reuses 16 saved original actor
observations and adds fresh rendering calls; it does not add new original actor
ticks or constitute a complete original scene run. [Model][model],
[native][native], [kind 3][kind3], [pipeline][pipeline], [tests][tests].

### Actor comparison details

The six profiles cover ordinary playback, a preserved signal-pulse fixture,
suspension, repeated/skipped ticks, signed-clock boundaries and uint32 wrapping,
and visibility changes combined with suspension. The comparison checks
**4,663,152 actor bytes and 159,424 signal bytes**, without masking actor fields,
plus every ordered drawing request and relevant return value.

The native harness executes unchanged original instructions with ordinary MZ
relocation and supplied actor/resource/tick state. Its two authenticated
far-return adapters are the draw request and device pump. It validates their
call sites and return frames, checks original code and script memory remain
unchanged, and checks drawing/pump order. The raw original observation stream
is included with per-case offsets, lengths and hashes. Independent review
parsed all records, replayed the new runtime against them and inspected the
adapter boundaries.

There were **11,577,857 code-hook visits**, including **27,436 intercepted
service entries**. These counters are instrumentation visits; they are not
presented as hardware-retired instruction counts. No actual device pump,
audio completion or final pixels are implied by this actor-only experiment.
[Original receipt][native]; [independent runtime review][nativereview].

### Drawing and connected pixel comparison details

The original kind-3 corpus includes 194 accepted and 164 rejected draws, with
142 fast and 52 clipped raster calls. It compares ordinary memory and explicit
planar storage, validates route/renderer arguments, resource pin state,
service order, dirty bytes and return state. There are **no opcode patches
and no intercepted calls in this rendering experiment**.

The connected experiment selects 16 original actor checkpoints covering
ordinary animation changes, suspension/resumption, visibility overrides and
clock wrapping. Each runs under software and planar configurations at scroll
0 and 320, using active-page values 0 and 1. Every selected frame begins from
the same declared pre-draw background on both sides. Draws accumulate in their
actual order within the frame.

All **308 individual draw comparisons** and **64 final frame comparisons**
matched. Final checks cover **4,096,000 visible-frame bytes, 66,560 dirty-map
bytes and 6,291,456 complete software-arena bytes**. The 308 original calls
divide into 154 accepted and 154 rejected draws. The raw final frame and dirty
records are included in `FRAME-OBSERVATIONS.bin`.

The software canvas reuses the frozen qualified route/raster model. Planar
expectations also use independently decoded sprite opacity/indices, and
original instructions provide the observed output. This does not establish
VGA latches, scanout, display initialization, palette selection, physical
timing or full original background restoration. Pixel-index equality is the
qualified result; original screen-color and scene equivalence require their
remaining host contracts. [Kind-3 receipt][kind3]; [pipeline receipt][pipeline];
[raster/pipeline review][pixelreview].

## 5. Corrections caught during implementation

The evidence retains initial failures and pre-fix calibration artifacts.
One processor reporting defect was found: after a graph traversal stopped at
its budget, it could label unvisited instructions unreachable. The corrected
report distinguishes those states, with a focused regression check.

CLI checks reproduced three further failures: budget exhaustion emitted a
traceback, an invalid runtime sprite state emitted a traceback, and a small
compressed resource could request more than 16 Mi pixels of decompression
before runtime rejection. The CLI now returns structured errors for the two
expected runtime exceptions, caps actual input reads at 16 MiB, and checks
playback sprite count and aggregate expansion before decoding surfaces.
Existing output paths and input-overwrite aliases are refused.

The resulting CLI suite has 14 passing subprocess tests. Fresh real-asset
commands inspected all eight DinoMart programs and their 102 instructions,
then replayed 401 ticks with suspension on indices 100–139, producing 3,208
actor snapshots and 2,043 draw requests. These CLI counts are an additional
public-entry-point check, not new original-code proof. [CLI receipt][cli];
[CLI independent review][clireview].

The final runner review also caught a missing-suite detection gap. In a
disposable copy with one required test file omitted, the previous runner
incorrectly passed the other 49 portable tests. The corrected runner requires
every listed suite to discover tests and fails explicitly when one is absent.
The negative reproduction and both receipts are retained under
`evidence/test-discovery-guard`; the canonical combined run was repeated after
the correction. No original test file was removed.

## 6. Preservation, package and use

E54 was implemented in a separate directory. Its preservation baseline records
367 original/prior-work files; the independent audit verifies their sizes,
hashes and the original game's exact 191-file set. The prior E53 progress and
handoff are copied into `baseline/E53` for continuity. Their historical
927-candidate inventory, 116 total contract records, 1,948 ledger ranges,
152 physical indirect sites and 18,480 undecoded ledger bytes remain historical
E53 metrics. E54 does not silently reclassify those bytes or assign a new
whole-game coverage percentage. [Preservation review][preservation];
[preserved progress][e53progress].

The package includes the portable source, current processor dependency,
preserved reference code, public tests, comparison drivers, raw observations,
accepted receipts, calibration failures, independent reviews and reproduction
instructions. Original game assets and executables remain separate inputs.
Native emulator dependencies are needed only for original-code verification.

The quickest entry points are:

```sh
python3 scripts/act.py inspect /path/to/original_game/DINOMART.ACT \
  --out /path/to/new-inspection.json

python3 scripts/act.py play /path/to/original_game/DINOMART.ACT \
  --ticks 401 --out /path/to/new-playback.json
```

For embedding, load the resource, construct `DinoMartRuntime`, supply explicit
ticks, and feed each returned draw tuple to `DinoMartCanvas`. `README.md`
contains the complete short example and every reproduction command. The
separate delivery-check receipt records archive hashing, safe fresh extraction,
source/evidence binding checks and tests run from the extracted package.

## 7. Next reconstruction target

**The next useful slice is `ABOUT.ACT` with its actual host signal source.**
It is one 74-byte program with 20 instructions and 14 distinct opcode values.
It waits for signal 0 to equal 1, uses F3 frame lists and frame waits, clears
the signal and loops. Implementing its required instructions is a manageable
extension, but a supplied test pulse cannot establish original speech or
presentation timing. First identify and qualify the native producer of that
signal and its audio/scene dependency, then compare state, draw order, pixels
and the complete presentation timeline under the same inputs.

The next acceptance sequence should therefore be:

1. Add the minimum required frame-list, signal and frame-wait semantics while
   retaining the original reader's lookahead and word-value behavior.
2. Execute the corresponding original native scene setup and signal producer,
   documenting any remaining service boundary.
3. Establish the actual background, palette and restoration path for that
   presentation, using the now-qualified kind-3 drawing connection.
4. Compare a complete bounded original presentation with the reconstructed
   host, including its external events and timeline.

The E53 resource backlog remains intact: backing-store eviction/reload,
allocator resize and shutdown, real file loading and fatal-cleanup paths, and
scene-owned lifetimes still need their own evidence. `INTRO.DMO` remains a
separate input-playback task. No Z3 run or whole-reconstruction equivalence
proof is claimed by E54. [Prior assessment][assessment]; [E53 handoff][e53handoff].

[assessment]: [private Library link omitted]
[processor]: evidence/processor-validation/RESULT.json
[processordoc]: docs/PROCESSOR.md
[runtime]: src/dinopark_act/runtime.py
[runtimedoc]: docs/RUNTIME.md
[model]: evidence/runtime-model/accepted/RESULT.json
[native]: evidence/runtime-original/accepted/RESULT.json
[nativereview]: evidence/reviews/runtime-original-review.json
[kind3]: evidence/kind3/accepted/RESULT.json
[kind3doc]: docs/KIND3-CONTRACTS.md
[rasterdoc]: docs/RASTER.md
[pipeline]: evidence/pipeline/accepted/RESULT.json
[pixelreview]: evidence/reviews/raster-pipeline-review.json
[tests]: evidence/integrated-tests/RESULT.json
[preservation]: evidence/reviews/preservation-review.json
[cli]: evidence/cli/RESULT.json
[clireview]: evidence/reviews/cli-review.json
[e53handoff]: baseline/E53/DinoPark-E53-Handoff.md
[e53progress]: baseline/E53/DinoPark-E53-Progress.json
