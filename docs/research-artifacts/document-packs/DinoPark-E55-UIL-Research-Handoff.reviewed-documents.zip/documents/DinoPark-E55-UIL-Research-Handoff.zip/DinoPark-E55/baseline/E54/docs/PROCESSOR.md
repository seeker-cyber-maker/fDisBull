# ACT processor and inspector

E54 adds an actual `fdisbull.processor` consumer for DinoPark ACT programs. It does not modify fDisBull, execute ACT instructions, or import a custom VM into the native project database.

## Current fDisBull dependency

Use the wheel under `baseline/fdisbull`, SHA-256:

```text
74655dee308f60ae7fd6cc8bcb44fec4fe31e93054916d09648fa23611d3195a
```

It is the newer wheel from the verified offline bundle. A separately uploaded wheel with the same `0.20.0.dev0` label is older and does not provide this API. The pure processor interface can be zip-imported directly from the pinned wheel; native decoder and optional managed dependencies are not needed for ACT inspection.

From the E54 directory:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:baseline/fdisbull/fdisbull-0.20.0.dev0-py3-none-any.whl python3 -m unittest discover -s tests -p test_processor.py -v
```

The standalone animation runtime imports the asset/token modules without importing fDisBull.

## Public Python API

```python
from dinopark_act.processor import (
    ACTProgram, ACTProcessor, inspect_program, inspect_bytes,
)
from fdisbull.processor import Location, decode_instruction

resource_report = inspect_bytes(original_act_bytes, name="DINOMART.ACT")

program = ACTProgram(
    resource_hash=resource_sha256,
    index=program_number,
    file_offset=first_instruction_file_offset,
    code=original_program_bytes,
    name="DINOMART.ACT",
)
processor = ACTProcessor(program)
instruction = decode_instruction(
    processor, program, Location(processor.info.address_space, 0)
)
program_report = inspect_program(program, max_instructions=65535)
```

`ACTProgram` is frozen and requires immutable `bytes`, a lowercase SHA-256 digest, a non-Boolean program index, a valid file offset and a nonempty name. Program length is 1–65,535 bytes. The processor binds one exact program object. Passing another object to that processor is rejected, even when its bytes happen to be equal.

`inspect_bytes` computes the actual resource hash and program file offsets from the validated container. Direct `ACTProgram` construction accepts caller-supplied resource provenance, which it cannot independently authenticate without the original container. The program byte hash is retained independently in every report.

The address space is:

```text
dinopark.act.sha256:<resource-sha256>:program:<index>
```

Addresses use byte offsets. The processor indexes the full bounded program once; `decode` returns `None` for an offset that is outside the program or is not a verified linear instruction boundary. A malformed tail is recorded as an error, and boundaries beyond that error are not invented.

## Instruction facts

Each returned `DecodedInstruction` uses the real fDisBull type and carries:

| Field | Meaning |
| --- | --- |
| `opcode`, `opcode_hex`, `mnemonic` | Raw opcode and authored inspection name |
| `meaning`, `route`, `dispatcher_target`, `claim_scope`, `notes` | Preserved E51 opcode-contract metadata |
| `size`, `bytes` | Consumed instruction length and exact bytes |
| `read_size`, `read_bytes`, `lookahead_hex` | Full reader access extent, including an extra byte where applicable |
| `arguments`, `operands`, `scratch_hex` | Qualified reader's decoded arguments and scratch output |
| `file_offset`, `resource_sha256`, `program_index`, `program_sha256` | Explicit source identity and coordinates |
| `flow`, `retains_pc` | Local control effect and whether a wait/terminal/error retains PC |
| `branch` | Predicate text, encoded/effective displacement, biased adjustment and target validity |
| `release`, `resume_offset_unwrapped` | Wait-release mechanism and delayed continuation, where one exists |

Mnemonic names are authored labels. They are not recovered source symbols. Operation meanings come from the complete 256-entry E51 contract registry, not the older token decoder's incomplete short-label map. The registry is authenticated against SHA-256 `976096549a0711330c119ef6557c5b1fd7144e2aa8b16afd219a05cffd7dd2b3`.

## Branch and wait behavior

All 17 branch opcode forms retain their original operand source. Encoded displacement bytes below 128 mean `0..127`; bytes `80..FF` mean `-2..-129`. The final target includes the consumed instruction length. Opcode 66 consumes no operands and gets effective displacement zero. Opcode 90 exposes its encoded third byte but uses the comparison byte as the effective displacement, matching the original scratch overwrite.

Targets are traversable only when they lie inside the bounded program and match a verified linear boundary. A target in an operand, beyond a malformed prefix or outside the program remains unresolved. Original 16-bit segment wrapping and jumps to another loaded program cannot be reconstructed from a local file offset alone; the report preserves the raw arithmetic target and names that limitation.

Wait instructions produce a `blocked` edge to their current location and, where supported, a `resume` edge to the next instruction. A resume edge describes a possible later updater release; it is never emitted as immediate fallthrough. Timer waits expose the nonzero-deadline sentinel and signed comparison. Wait 01 and the six high-bit wait values receive no invented autonomous resume. External actor mutation is outside this local graph's scope.

Opcode 03 is terminal for ordinary scheduling and has no successor. The 191 default-diagnostic routes retain PC and report `diagnostic_stop`; they do not acquire an invented normal fallthrough.

## Report completion and reachability

`inspect_program` returns all linearly decoded instructions and a separate graph traversal from entry zero. Traversal includes syntactically possible branch alternatives and delayed resume edges; conditions are not evaluated.

- `linear_complete`: the reader partitioned the complete supplied program without truncation or unsupported count errors.
- `traversal_closed`: reachable local successor traversal ended without a pending budget item or unresolved edge.
- `reachable_complete`: traversal closed and no reached diagnostic instruction was encountered.
- `complete`: linear and reachable checks completed, with no diagnostic instruction or unresolved edge anywhere in the decoded partition.
- `unvisited_offsets`: decoded offsets not visited by this traversal, including when its budget stopped early.
- `unreachable_offsets`: only populated after traversal closes; these are locally unreachable under the declared entry and successor rules, not globally dead game code.

`complete` never means termination, eventual wait release, executed instruction semantics, native callback coverage, correct timing, renderer equivalence or whole-scene completion. A self-loop can have a complete static description. A resource with zero embedded programs can also have a complete empty inspection; native callback animation remains separate.

The first implementation labeled not-yet-visited offsets unreachable after a budget stop. A focused regression demonstrated that labeling defect. The final code separates unvisited offsets and requires closed traversal before reporting local unreachable offsets. The prior source/results and failing log remain under `evidence/processor-calibration-before-reachability` and `evidence/processor-reachability-gap.log`.

## Bounds and malformed inputs

`inspect_bytes` accepts at most 64 MiB and preflights total sprite dimensions before invoking the unchanged validating codec. The total decoded-sprite budget is 16 Mi pixels. The original container, sprite, directory and sequence checks remain in the frozen codec. These are inspection-tool bounds, not claims that the original game rejected the same inputs.

Negative variable counts, missing operands and missing F0–FE lookahead are reported without guessing an instruction boundary. F7's unusual consumed length is preserved. Graph budget values are integer 1–65,535 and do not limit the separate bounded linear partition.

## Fresh evidence

`tests/test_processor.py` has 21 public tests, including all 256 opcode routes, all 17 branch encodings, every biased displacement byte, mixed endianness, F3/F7 lookahead, wait/terminal/diagnostic behavior, invalid targets, source identity, budgets and decompression limits. The initial missing-module failure and a later reachability regression failure are retained. Passing tests do not establish untested native semantics.

Run the all-resource validation with:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:baseline/fdisbull/fdisbull-0.20.0.dev0-py3-none-any.whl python3 scripts/inspect_validation.py /path/to/original_game --out /path/to/new_evidence
```

The output directory must not exist or overlap the input game directory. The accepted run covers all 57 original ACT files, 1,514 sprite records, 11 script-bearing files, 48 programs and 679 instructions using 32 opcode values. Twenty-two stored instructions use lookahead. Every program's linear and declared local graph checks completed.

The comparison verifies the new wrapper's metadata, source offsets, raw/read bytes, arguments and scratch against the preserved E51 parser. Because the new adapter reuses that parser, this is a wrapper/contract regression, not an independent semantic oracle or a fresh original-x86 comparison. Runtime/original execution evidence belongs to the separate E54 integration family.
