# Bounded DinoMart interpreter

The E54 `dinopark_act.runtime` module is a standalone typed interpreter for the
eleven opcode values used by the eight original DINOMART programs. It executes
the recovered behavior directly and does not call fDisBull, the E51 reference
model, an emulator, the original executable, a renderer or a wall clock.

The supplied fixture has zero-initialized actors, context zero, display mode
zero, original sprite dimensions and explicitly supplied logical ticks. This
is a reconstruction component with a declared compatibility boundary, not a
general ACT engine or complete DinoMart scene implementation.

## Public API

```python
from dinopark_act.assets import decode
from dinopark_act.runtime import DinoMartRuntime

resource = decode(original_act_bytes)
player = DinoMartRuntime(resource, instruction_budget=256)
result = player.tick(0)

result.draws        # ordered (sprite, destination_kind, x, y, argument) tuples
result.actors       # immutable ActorSnapshot objects, after scheduling
result.released     # actor indices whose deadline released this update
result.waiting      # aggregate scheduler waiting status
result.executed_commands  # semantic command count, not CPU instructions

state = player.snapshot()          # JSON-serializable state and word signals
records = player.actor_records(source_segment=0xB000)
signals = player.signal_bytes()    # 32 little-endian words / 64 bytes
```

`DinoMartRuntime(resource, *, program_indices=None, instruction_budget=256)`
accepts a decoded `ActorFile`. `program_indices` selects programs in actor
order; the default instantiates every program in the resource. The bounds are
1–16 actors, 1–256 sprites and 1–2,047 immutable bytes per program. Sprite
dimensions retain the codec's bounded width/height contract. The command budget
is an integer from 1 through 65,536, applied separately to each actor's dispatch
sweep. The default of 256 matches the prior bounded reference driver.

The resource and program checks are eager, including unsupported instructions
in otherwise unreachable linear portions of a program. Unsupported opcodes,
truncation, out-of-range base sprites, branches into operands and continuations
outside the program raise `ProgramValidationError`. These bounds are the
portable component's supported-input policy, not a claim that original DOS
code rejected the same malformed inputs.

### Tick inputs

```python
result = player.tick(
    time,                    # explicit uint32 logical time
    suspended=0,             # uint16 actor mask, assigned each call
    hidden=None,             # None preserves visibility; mask assigns it
    signals={0: 65535, 31: 2} # optional word-slot updates
)
```

Boolean values are rejected where integers are required. Tick values may
repeat, skip or wrap; no wall-clock rate or monotonic host-time assumption is
introduced. High mask bits without a corresponding actor have no effect,
matching the declared original mask fixture. The default suspension mask zero
resumes every selected actor, so callers must repeat a persistent suspension
mask on subsequent calls. A missing `hidden` mask retains current visibility.

Signal slots are 0–31 and values are unsigned 16-bit words. The DinoMart subset
does not consume or modify signals; externally supplied values are preserved
without Boolean normalization. The E51 pulse profile is included to verify that
those external fields remain untouched by the interpreter.

The tick works on immutable snapshots and commits its state only after all
actors finish the bounded pass. An input, state-bound or budget failure leaves
the previously committed snapshot unchanged. This transactional host API is
an intentional defensive policy, not original diagnostic/error-path behavior.

## Supported instructions

| Opcode | Effect in this runtime |
| --- | --- |
| `03` | Terminal/yield behavior, retaining its PC |
| `10` | Assign the raw draw-order byte |
| `11` | Assign the raw frame-offset byte; cycling is already zero in this subset |
| `12` | Assign visibility; hiding sets the retained dirty byte |
| `17` | Biased-byte relative branch |
| `1B` | Set base sprite and cache its dimensions for display mode zero |
| `1C` | Assign the raw frame-count byte |
| `40` / `41` | Assign 16-bit X / Y using the decoded big-endian word operand |
| `47` | Assign the 16-bit group field |
| `4E` | Set a wrapped 32-bit deadline and block while retaining the command PC |

No frame-cycle, motion-setting, signal-opcode, sound, callback or scene-change
opcode is silently accepted. The width/height cache is based on the selected
base sprite, as in the recovered handler. The direct frame offset does not
replace those cached dimensions. Drawing interprets that offset as a signed
byte and emits word-valued coordinates.

The native render request's second argument is preserved as destination kind
**3**. This module emits draw requests only. It does not map kind 3 to a convenient
surface or claim the earlier kind-1/2 software-router checks cover this path.

## Execution order and details

Each tick applies the explicitly supplied masks/signals, then performs:

1. Deadline release and the eligible previous-coordinate/cadence update.
2. Rendering requests in signed draw-order bucket order, with actor order as
   the tie-breaker. Suspended or invisible actors and buckets outside 0–15 do
   not draw.
3. Advancement of released command PCs without executing the released wait
   again; the frame deadline is set to the current tick.
4. Scheduling in actor order until a command yields or the explicit budget
   is exhausted.

Although this subset never assigns motion, the original update still writes
previous coordinates and the byte-sized next-motion tick. Those bytes are
preserved by the typed state and verified in complete actor-record comparisons.
The next-motion byte and deadline comparisons use the recovered signed-width
rules. A deadline equal to zero is the original sentinel: a `4E` command whose
sum becomes zero remains blocked through this ordinary update path.

Opcode `03` has a contextual distinction. An unblocked actor already at `03`
when the scheduler visits it is skipped without becoming blocked. If the same
opcode is reached inside a dispatch sweep, it returns the yielding result and
the actor becomes blocked. The static eighth DinoMart program takes the latter
path on its first scheduling pass.

The branch arithmetic is:

```text
adjustment = raw_byte if raw_byte < 128 else 126 - raw_byte
next_pc = (current_pc + instruction_length + adjustment) modulo 65536
```

Validation requires the resulting PC to be a decoded instruction boundary in
the bounded program. For the first DinoMart script, `17 8A` at local `0019`
continues at `000F`: `0019 + 2 - 12 = 000F`.

### Actor-record serialization

`actor_records(program_base=0, program_stride=2048, source_segment=0x2F)`
returns 234 bytes per selected actor. Script pointers are placed at
`program_base + actor_index * program_stride + local_pc`; the actor index is
the selected instance's index, not the source resource's program number.
The source segment is a caller-supplied coordinate for comparison. The method
rejects overlapping script slots and layouts extending past the 64 KiB segment.

Fields serialized at the recovered offsets include base sprite, coordinates
and previous coordinates, blocked flag, frame count/offset, group, dimensions,
frame deadline, draw bucket, visibility, dirty byte, timer deadline, next-motion
byte and suspension. All other bytes are zero because this component's initial
fixture is zeroed and its declared opcode subset never writes them. This is
not arbitrary actor import/export, a DOS save-state format, or a substitute for
the original constructor/resource loader.

## Verification

The initial focused suite was run before `runtime.py` existed and failed on
the missing public module. That receipt is retained as
`evidence/runtime-model-calibration-initial.log`.

Fourteen focused public-behavior tests then passed. Their expected outcomes
include a hand-derived first-program timeline, a complete explicitly populated
234-byte record, render-before-script frame changes, draw ordering, suspension,
visibility override, terminal context, signed fields/deadlines, zero deadline,
word-signal preservation, validation and transactional budget failure.

Run them with:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src \
  python3 -m unittest discover -s tests -p test_runtime.py -v
```

The independent implementation was also compared against the unchanged E51
Python reference model on all eight original DINOMART programs:

| Profile | Ticks | Actor snapshots | Ordered draw requests |
| --- | ---: | ---: | ---: |
| Preserved idle | 401 | 3,208 | 2,247 |
| Preserved pulsed | 1,601 | 12,808 | 8,929 |
| Preserved suspended | 401 | 3,208 | 2,043 |
| Repeated/skipped clock | 13 | 104 | 72 |
| Signed clock and uint32 wrap | 10 | 80 | 53 |
| Visibility and suspension | 65 | 520 | 374 |
| **Total** | **2,491** | **19,928** | **13,718** |

Every tick matched all 234 bytes per actor, all 64 signal bytes, ordered draw
requests, aggregate release/wait statuses and the absence of diagnostics.
This compared 4,663,152 actor bytes and 159,424 signal bytes, with zero mismatches.
The first three are the original E51 clock/signal profiles scoped to DinoMart;
the remaining three are explicit constructed boundary profiles.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 scripts/runtime_model_compare.py \
  /path/to/original_game --out /path/to/new-comparison-directory
```

The script pins the original DINOMART.ACT hash, refuses an existing output
directory or overlap with the input directory, and records every tick input,
check, draw request and expected/actual combined-state hash. Runtime/parser/
reference/test/driver source hashes are retained in the result.

Accepted evidence: `evidence/runtime-model/accepted/RESULT.json` and
`evidence/runtime-model/accepted/CASES.json`. This is implementation-to-reference
regression, not a fresh original-x86 replay. Parent-owned original-code and
kind-3 rendering comparisons provide their own acceptance scopes and receipts.

## Remaining boundary

The component does not provide real-time pacing, resource loading/lifetime,
palette handling, final pixels, native scene callbacks, animation-option UI,
audio or the remaining ACT opcode families. Its synthetic clock and masks must
not be presented as original full-scene timing. The original broader E51
contracts, E52 rendering evidence and E53 resource evidence remain preserved
inputs for later integration.
