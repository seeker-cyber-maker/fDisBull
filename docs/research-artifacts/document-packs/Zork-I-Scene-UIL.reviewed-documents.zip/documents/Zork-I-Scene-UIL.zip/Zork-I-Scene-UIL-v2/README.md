# Zork I: named scenes and window interaction UIL

This playable package extends the existing Zork I release 88 / serial 840726
conversion with named scene rules and a recovered kitchen-window interaction.
It contains **110 named scenes, all 352 encoded directional exits, 12 live
Boolean selectors and three door entities**. The scene evaluator selects named
destinations and effects directly. The window evaluator handles opening,
closing, repeats, initial-hint dismissal and their ordered effects.

The complete game runs through a **mixture of recovered semantic UIL and
explicitly retained low-level IR**. Most room callbacks, routine-selected exits,
the parser, hazards, arrival behavior and background events still use preserved
implementations. Resolving a handler's address does not recover its body.

Package format version 2 identifies the scene artifact schema. The manifest
records the implementation's verified local source commit and, when published,
its GitHub commit with the same tree. These commit IDs can differ because the
local history was reconstructed; the publication receipt records the mapping.

## Play

Requires Python 3.10 or later. Verification for this delivery uses Linux and
Python 3.12.14. The consumer uses only the Python standard library. It needs no
fDisBull installation, original story file, Z-machine interpreter, Frotz, native
debugger, network connection or third-party Python package.

Extract the ZIP, open a terminal in this directory, and run:

```sh
python3 play.py --checkpoint progress.json
```

Enter ordinary commands at the prompt. Continue in a fresh process with:

```sh
python3 play.py --resume progress.json --checkpoint progress.json
```

The checkpoint captures complete game and continuation state and binds the exact
scene/UIL/UDL package. This is scene package version 2. Its additional interaction
changes the package identity, so a checkpoint from the earlier scene package
cannot be substituted. The included consumer can still load a separately
supplied version 1 scene package with that package's matching checkpoint.
The game's own SAVE/RESTORE slot remains distinct from the external checkpoint;
interoperability with original DOS `.SAV` files is not claimed.

## Exercise the recovered window interaction

The included 27-command route covers examination, a closed-window traversal
refusal, first and repeated close attempts, opening, repeated opening, entry,
closing from inside, another blocked traversal, reopening, a pronoun command,
and residual examination/look-through behavior:

```sh
python3 play.py --commands window-commands.json \
  --transcript window-results.json --checkpoint window-progress.json
```

The reference route finishes Behind House, ready for the next input, at
**10 points and 27 moves**. The new interaction qualifies only open/close;
other verbs on the same window retain their original code.

Each admitted open/close attempt first dismisses the initial examination hint.
Its remaining effects depend on the live door state:

| Request | Ordered effects after hint dismissal |
| --- | --- |
| Open a closed window | Opening narration, open-state write, newline. |
| Close an open window | Closing narration, closed-state write, newline. |
| Request the current state again | One shuffled response with its RNG and bag-state effects, then newline; no door-state change. |

The initial-hint fact and open state have different meanings. The producer
qualifies the hint's writer and its examination consumer; the remainder of
examination stays residual. Door state is shared with the scene exits, so an
open/close change immediately affects the next ordinary traversal decision.

Repeat feedback uses a shared live bag of three responses. Each response is
selected once within a cycle, but an immediate repeat across a cycle boundary
is allowed. The adapter preserves a random draw even when only one choice
remains, both swap assignments even when they address the same slot, and the
cursor update before output. Residual handlers use this same state.

The door operation does not count a second turn. The existing turn-count
primitive and residual scheduler remain responsible for action completion.

## Retain the earlier house check

The original 16-command house route is also included:

```sh
python3 play.py --commands house-commands.json \
  --transcript house-results.json --checkpoint house-progress.json
```

It covers the first/repeated mailbox openings, content removal, an empty
reopening, blocked and conditional exits, movement, a closed-window refusal,
opening the window, entering the kitchen and returning to the mailbox. Its
reference endpoint is West of House at **10 points and 16 moves**.

The scene layer supplies `scene.select_exit` and `scene.move_actor`; the earlier
mailbox and turn-count primitives remain available. Each result's
`scene_recovery` and `recovery` records distinguish semantic execution, direct
rule links, residual handlers, fallbacks and partial effects.

## Inspect the representations

| File | Purpose |
| --- | --- |
| `Zork-I.scenes.json.gz` | Complete runnable version 2 package: preserved conversion, scene UIL, dispatch UIL, interaction UIL and source UDL. |
| `Zork-I.scene-rules.json` | Address-free scenes, destinations, live predicates, resources and residual references. |
| `Zork-I.rule-links.json` | Named action/handler links and selection order; unqualified handler bodies remain low-level. |
| `Zork-I.interaction-rules.json` | Address-free window open/close, hint dismissal and shuffled-response definitions. |
| `Zork-I.scene-definitions.json.gz` | UDL connecting rules to original objects, operations, typed references, live fields, dependencies and guards. Includes the interaction correspondence. |
| `ZORK_SCENES.md` | Primitive contracts, execution phases, compatibility and remaining scope. |
| `VERIFICATION-ZORK-WINDOW.md` | Current source verification report, copied from the implementation repository. |
| `evidence/window-followup/verification.json` | Matching current implementation verification receipt. |
| `evidence/portable-verification.json` | Fresh isolated portable-player and checkpoint/resume checks for the included files. |
| `evidence/source-publication.json` (when included) | Publication receipt linking the verified local commit to the published GitHub commit and their shared tree. |
| `VERIFICATION-ZORK-SCENES-2026-10-30.md` | Historical scene/dispatch verification before the window addition. |
| `evidence/zork-scenes-2026-10-30/verification.json` | Historical receipt for that earlier scene package, not evidence for the new package by itself. |
| `manifest.json` | Payload byte lengths and SHA-256 hashes, implementation identity and evidence provenance. It excludes itself; a separate archive digest identifies the whole delivery. |
| `player/fdisbull_player/` | Eight standalone consumer modules and a minimal package initializer. |

Inspection views are the exact documents embedded in the runnable package.
Gzip is used only for storage; Python loads compressed artifacts directly.
Generated narrative, retained executable data and source witnesses are private
game-derived content. This delivery is separate from the generic fDisBull
software distribution.

## The previous conversion is preserved

`preserved/` contains byte-identical copies of the earlier mailbox-intent
package, executable Word16 IR and original UDL mapping. They are independent
reference/fallback artifacts, not relabeled scene UIL.

```sh
python3 play_preserved_ir.py --checkpoint ir-progress.json
python3 play_preserved_intents.py --checkpoint intent-progress.json
```

Use a different checkpoint for each representation. The scene package embeds
the exact preserved mailbox-intent package and does not require these separate
copies at runtime. The earlier portable scene delivery is also retained
separately; this version does not overwrite it.

## Method and limits

The window recovery begins with its already-resolved object/callback link,
then follows typed references through small qualified consumers. Its replaced
callback prefix and helpers contain 39 instructions across 157 bytes including
routine headers. Hint-consumer evidence and resource/table dependencies are
additional. Prior story, object, action, dispatch and executable-IR setup is
reused; this is not a cold-recovery measurement or a demonstrated speedup.

The producer does not confuse text references with code addresses merely
because their numeric values match. Source machinery stays in UDL and the
residual adapter. Named door intent, state conditions and narration remain
independent of the original argument stack and packed calls.

Unqualified live state or changed dependencies select residual execution before
semantic effects begin. An output/write failure after effects start retains
completed effects and fault evidence. It never retries the original algorithm,
which could duplicate a random draw, output or state mutation. The previous
completed checkpoint remains the recovery point after a runtime fault.

Routine exits, missing-direction hazards, most room and arrival behavior,
parser/scope admission, other window verbs and background scheduling remain
explicit residual IR. Existing nested-input continuation state is preserved,
including the resolved caller locals required by the Loud Room. These are
compatibility obligations, not source addresses in the semantic scene model.

The current report and portable receipt identify the actual checked source,
package, routes and boundaries. Historical reports remain labeled historical.
No document claims all possible game paths, whole-game intent recovery or
platform execution beyond recorded checks. macOS and Windows remain unverified.

Background links in the copied source guides refer to repository documentation:
https://github.com/seeker-cyber-maker/fDisBull
