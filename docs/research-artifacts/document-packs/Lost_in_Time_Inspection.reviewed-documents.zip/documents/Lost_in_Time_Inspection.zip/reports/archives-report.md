# Lost in Time archive inspection

## Scope and method

Inspected the two user-supplied ZIP archives locally. Validated all ZIP paths, rejected path traversal and symbolic-link entries, enforced a 1 GB total extraction bound, and extracted releases into separate directories. Did not execute any game binaries. Read the CD's ISO 9660 directory directly from 2352-byte Mode 1 sectors, then extracted the filesystem's 26 files. Parsed STK/ITK member tables with bounds checks for every entry. Decoded selected language resources in memory with a bounded LZSS decoder, checking exact declared output size and exact input consumption.

## Actual releases

| Property | English archive | Italian-labelled CD archive |
| --- | --- | --- |
| ZIP bytes | 15,460,115 | 525,176,084 |
| ZIP entries | 28 files | 1 directory + BIN + CUE |
| Extracted bytes | 17,895,777 | 607,509,968 including CUE |
| Format | Ready-to-run-style flat DOS game directory | Mixed-mode CD image, not a plain ISO file |
| Game data files | 28 | 26 ISO filesystem files, 41,861,870 bytes |
| Executable | LOST.EXE, 105,253 bytes | LOST.EXE, 101,532 bytes |
| Executable packing | MZ DOS, LZEXE 0.91 signature | MZ DOS, LZEXE 0.91 signature |
| MDO.DEF | LANG:LG_US; CDROM:NO; MOUSE:YES | blank LANG; CDROM:YES; MOUSE:YES |
| INTRO.STK members | 215 | 522 |
| .TOT members | 61 | 61; exactly the same names |
| .IMD members across six .ITK files | 419 | 497 |

English source: `upload/Lost-in-Time_DOS_EN(1).zip`.
CD source: `upload/Lost-in-Time_DOS_IT_ISO-Version.zip`.

The English files are extracted at `lost-in-time/releases/english`.
The original CD files are extracted at `lost-in-time/releases/italian-cd/lostintime_ita`.
The CD data files are available at `lost-in-time/releases/italian-cd/data`.

The English release contains paired BATCOM, COMMUN1, PARTIE1, PARTIE2, PARTIE3, and PARTIE4 ITK/LTK files, INTRO.STK, LOST.EXE, setup files, configuration, and documentation. MDO.DEF explicitly identifies US English and a non-CD install. The README says a mouse is required and a joystick is unsupported. README.DOX is a period text documentation transcription, including a release-information wrapper dated 1993-10-31, story background, and manual material. That wrapper is provenance of the bundled documentation, not a verified original game release date.

The CD has the same main data families plus INSTALL.COM, INSTALL.INF, LOST.LIC, and VERSION. Its VERSION. file says `1.000`, `09.06.93`, and `LOST IN TIME`; the date string's format was not independently resolved. The ISO volume label is LOST, and its embedded creation/modification metadata is 1993-10-27 19:18:20. File timestamps mostly fall in October 1993. These are image metadata, not proof of the retail release date.

## CD language findings

The filename labels the CD Italian, but INTRO.STK contains multiple language-resource families. Decompressing MENU members verifies:

- .USA: English.
- .ITA: Italian.
- .ALL: German.
- .DAT: French.
- .ANG: English; 59 of 60 resource payloads are byte-identical to matching .USA files.
- .ESP: also English in the sampled menu; 59 of 60 payloads are byte-identical to matching .USA files.

Only INTRO differs for ANG/ESP versus USA. Therefore, do not claim verified Spanish support based on the .ESP extension. The CD definitely contains English resources alongside Italian, German, and French text. Runtime selection and spoken-language content have not been tested.

The English INTRO.STK contains 61 .TOT, 60 .USA, 57 .EXT, 1 .EX1, 14 .SND, 14 .ADL, 4 .LET, and 4 .GDR resources.
The CD INTRO.STK contains 61 .TOT, 60 .USA, 57 .EXT, 1 .EX1, 14 .SND, 14 .ADL, 8 .LET, 4 .GDR, 61 .DAT, 61 .ITA, 61 .ALL, 60 .ESP, and 60 .ANG resources.

## Mixed-mode CD layout

CUE layout:

- Track 01: MODE1/2352, INDEX 01 at 00:00:00.
- Track 02: AUDIO, PREGAP 00:02:00, INDEX 01 at 04:36:01.

The BIN contains 258,295 raw sectors. Track 02 begins at file sector 20,701 and spans the remaining 237,594 sectors: 558,821,088 bytes, about 52 minutes 47.92 seconds of audio. The audio content was not listened to; it must not be called speech or music specifically from this evidence alone. The audio accounts for most of the large image size.

The CUE names `LOSTIT.BIN`, but the actual archive member is `LostIT.bin`. This case mismatch can block image loading on case-sensitive hosts. Preserve the original and, when launching, use a working CUE copy with the exact actual filename. No original was modified during this inspection.

## Resource and executable differences

Shared files that are byte-identical: CAT2.INF, CAT3.INF, CAT4.INF, LOST.ICO, SETUP.CMP. Every paired main ITK/LTK resource file and both LOST.EXE / SETUP.EXE executables differ. The two versions should remain separate baselines.

The .STK/.ITK directory layout observed in every inspected container is a 16-bit little-endian count followed by 22-byte entries: 13-byte NUL-terminated name, 32-bit size, 32-bit offset, and 1-byte packing flag. All extents fit their containers. The .ITK members are .IMD resources; flags are zero. Many INTRO.STK script/text members use packing flag one; selected text samples decoded successfully. The .LTK structure has not been fully decoded; it should not yet be labelled an object-coordinate table.

The CD's larger IMD count and substantially larger payloads establish content/asset differences. They do not prove extra puzzles, longer story, higher-resolution art, or a specific encoding change. The 61 common .TOT names provide promising anchors for cross-release scene/script comparison, but bytecode semantics and object click positions remain unverified.

## Practical starting point

Use the English non-CD directory as the simplest first execution baseline. Keep the full CD image and its audio track available for the richer comparative baseline. Since both EXEs carry LZEXE 0.91 signatures, static disassembly of the packed file alone will initially see the loader/decompressor; unpacked memory or explicit unpacking will be needed to inspect the actual interpreter code.

## Evidence files

- `archive-inventory.json`: original ZIP members, sizes, compression sizes, CRC32 values.
- `cd-inventory.json`: ISO metadata and all data-file extents/sizes/timestamps.
- `resource-inventory.json`: every parsed STK/ITK member name, size, offset, packing flag.
- `release-file-comparison.json`: case-normalized file comparison and exact equality results.

All four are in `lost-in-time/analysis` next to this report. User-facing documentation can cite these local inspection results. No external research was used.
