LOST IN TIME — INSTALLATION AND RELEASE INSPECTION
Completed: 29 October 2026

RESULT

fDisBull 0.22.0 and fdisbull-player 0.22.0 are installed in this conversation's
Linux x86-64 workspace. Both supplied game archives were inspected and extracted
separately. All four reference artifacts shown in the user's screenshot were
located and recovered intact. No original game executable was run in this task.

1. INSTALLED TOOLS AND VERIFICATION

Workspace root:
  [private-local-path]

fDisBull command:
  [private-local-path]

Standalone player:
  [private-local-path]

DOSBox backend to pass to fDisBull:
  [private-local-path]

The supplied installer requires Python 3.13.5 exactly. That interpreter was
installed locally with uv from its Python standalone distribution. All seven
Python packages were installed from the supplied offline wheel directory with
the installer's required hashes; no substitute Python packages were used.
The installer verified its SHA256SUMS and both positive and negative Z3 checks.

The DOSBox backend initially could not start because this Ubuntu environment
lacked libncurses.so.6. The matching Ubuntu 24.04 package was downloaded from:
https://archive.ubuntu.com/ubuntu/pool/main/n/ncurses/libncurses6_6.4+20240113-1ubuntu2_amd64.deb
It was extracted into tools/fdisbull-runtime-lib. A small wrapper adds that
local library directory before launching the unmodified supplied DOSBox wrapper.
The system's libtinfo6 is the same required version. System directories were
not changed. The local ncurses package and wrapper are included in this bundle.

The final fDisBull doctor result is PASSED: 13 of 13 checks passed on its own
disposable authored DOS target. These cover genuine dependencies/native decoding,
backend inputs and launch, execution breakpoint, execution overlay, native save,
screenshot, click with coordinate frame, data watch, bounded instruction trace,
native restore, offline temporal interpretation, and restart/export of evidence.
The successful receipt, trace and images are included under doctor/.

This proves the supplied debugger backend works here. It is not a Lost in Time
playthrough or an assertion that either game release is fully compatible.

Both actual LOST.EXE files were also identified and inspected with fDisBull.
Both are valid 16-bit x86 DOS MZ executables. Both contain the LZ91 packing
signature. Static inspection of the disk executables initially sees packed
code and its loader; actual interpreter recovery requires unpacking or a
capture of executable memory after decompression.

Packaging observation: the supplied Capstone wheel metadata is version 5.0.9,
whereas its imported module reports 5.0.7. The bundled code was not changed;
the doctor's native decoding check passed. This is recorded for provenance.

Re-run the acceptance command with a NEW output directory:
  tools/fdisbull-venv/bin/fdisbull doctor --backend dosbox \
    --executable [private-local-path] \
    --output [private-local-path]

2. THE TWO ORIGINAL GAME RELEASES

English ZIP: Lost-in-Time_DOS_EN(1).zip
  Compressed size: 15,460,115 bytes (14.74 MiB).
  Contents: 28 files totaling 17,895,777 bytes (17.07 MiB).
  Layout: flat installed-style DOS game directory, not disk images.
  Main executable: lost.exe, 105,253 bytes.
  Configuration: LANG:LG_US and CDROM:NO.
  Data: INTRO.STK and six .ITK/.LTK resource families named BATCOM,
    COMMUN1, PARTIE1, PARTIE2, PARTIE3 and PARTIE4.
  Also present: SETUP.EXE, SETUP.CMP, configuration and documentation.
  Local directory: lost-in-time/releases/english

Italian-labelled ZIP: Lost-in-Time_DOS_IT_ISO-Version.zip
  Compressed size: 525,176,084 bytes (500.85 MiB).
  Contents: a 607,509,840-byte BIN and a 128-byte CUE.
  Actual format: mixed-mode CD image, not a plain .ISO file.
  Track 1: MODE1/2352 data. Track 2: CD audio.
  Extracted ISO filesystem: 26 files totaling 41,861,870 bytes (39.92 MiB).
  Main executable: LOST.EXE, 101,532 bytes.
  Configuration: blank LANG and CDROM:YES.
  Additional files: INSTALL.COM, INSTALL.INF, LOST.LIC and VERSION.
  VERSION. contains 1.000 / 09.06.93 / LOST IN TIME. The regional date
    convention has not been resolved.
  Volume label: LOST. Image creation metadata: 1993-10-27 19:18:20;
    this is not independently verified retail-release history.
  Original image directory: lost-in-time/releases/italian-cd/lostintime_ita
  Extracted data directory: lost-in-time/releases/italian-cd/data

The CUE references LOSTIT.BIN but the archive contains LostIT.bin. A working
copy named LostIT-linux.cue now uses the actual case. The original CUE is
unchanged. To use the copy included here, place it beside LostIT.bin.

The audio track begins at file position 04:36:01 and spans approximately
52 minutes 47.92 seconds. It accounts for 558,821,088 bytes of the BIN.
It has not been listened to, so its music/speech content and language are
unverified. Most of the CD image's size is this audio track.

3. RESOURCE COMPARISON AND LANGUAGES

INTRO.STK has 215 members in the English release and 522 on the CD. Both have
61 .TOT script members with exactly the same filenames. The six .ITK files
contain 419 .IMD members in the English release and 497 on the CD.

Only CAT2.INF, CAT3.INF, CAT4.INF, LOST.ICO and SETUP.CMP are byte-identical
between releases. The main executables and all six ITK/LTK pairs differ.
The increase in resources does not itself establish extra puzzles or scenes.

The CD is not Italian-only. Selected decompressed MENU resources contain:
  .USA: English
  .ITA: Italian
  .ALL: German
  .DAT: French
  .ANG: English
  .ESP: English in the sampled menu

For both ANG and ESP, 59 of 60 payloads match their USA counterparts exactly;
only INTRO differs. Spanish support is therefore not established by the ESP
extension. Runtime selection and full per-language coverage remain untested.

All observed STK/ITK directories use a two-byte little-endian member count
followed by 22-byte entries: 13-byte name, four-byte size, four-byte offset,
one-byte packing flag. Every listed extent was bounds-checked. Selected
packed text resources decoded to their exact declared sizes. This identifies
resource structure, not the semantics of the script bytecode. LTK semantics
and real object click regions have not yet been decoded.

4. RECOVERED REFERENCE PACK

All four files are in lost-in-time/reference:
  Lost_in_Time_Complete.zip
  Lost_in_Time_Live.txt
  Lost_in_Time_Live.md
  Lost_in_Time_World.json

The TXT and MD are byte-identical (173,840 bytes each). Their copies and the
World JSON inside Complete.zip match the separate files exactly.

Complete.zip contains 15 files: the three files above, four act documents,
a narrator contract, an initial save, state_engine.py, validate_world.py,
README/implementation documents, and two previously recorded validation
reports. The World JSON identifies itself as adaptation version 1.0.0,
custom schema 1.0, created 2026-10-29.

Observed counts:
  4 chapters; 38 scenes; 188 authored actions; 117 item IDs;
  124 feature records; 68 exits; 121 distinct Boolean flag IDs;
  265 reference-solution transitions; 28 explicit adaptation notes.

Independent structural checks found no broken scene/action/exit/destination,
inheritance, source or solution references. The supplied state runner was not
rerun; its recorded route-completion claims remain prior package results.

The pack explicitly describes original narration and a guide-derived puzzle
specification, not an executable reconstruction. Its original compiler did
not run the game. It merges camera views, fixes some randomized codes,
changes timed encounters to turns, simplifies some inventory/dead-end rules,
and supplies an authored epilogue. Listed video references are metadata/link
records without watched footage or verified timestamps.

The JSON has no pixel coordinates, click bounds, executable addresses,
resource offsets, binary fingerprints or fDisBull format field. It can serve
as a semantic checklist for comparison, but cannot directly drive verified
clicks in either original release.

5. CONSEQUENCES FOR UIL AND HARNESS WORK

The installed package exposes generic DOS debugging and scene machinery.
No dedicated Gob/Coktel/Lost in Time decoder was found in its Python wheel.

Its formats are distinct:
  fdisbull-text-slice-1: standalone player declarations/transitions.
  fdisbull-il-1: UIL/UDL variables, resources and blocks.
  fdisbull-scene-1: screenshot/object interaction scenes.

The recovered World JSON uses its own schema and requires conversion before
use with these interfaces. The standalone player is not a UIL interpreter.
Verified harness scenes must retain actual camera/view identity, pixel-space
coordinates, conditions/effects and per-release evidence. Shared script names
are useful correspondence anchors but do not prove equivalent behavior.

Recommended next investigation: launch the English non-CD release, capture
its first playable view, locate the current TOT/script and object hitboxes,
and map those observations to the reference pack. Keep the CD as a separate
comparison baseline and test its English language option when launching it.
No playthrough, scene conversion or binary patching was performed here.

6. EVIDENCE AND REPRODUCTION

This bundle contains inspection inventories, resource tables, the full
archive-comparison report, reference-pack audit, fDisBull executable
inspection output, install log, successful backend receipt/trace/images,
the small runtime wrapper, ncurses package/license, and corrected CUE copy.
It does not duplicate the game archives or the original reference pack.

The original user-provided offline kit and game/reference files remain the
inputs for reproducing this workspace. Python and virtual-environment files
are derived installation state; their complete directory trees are not
duplicated in this evidence bundle.

If rebuilding: install Python 3.13.5 locally, extract the supplied offline kit
under tools/, put its Python bin first on PATH and run the kit's install.sh
with a new absolute tools/fdisbull-venv destination. Extract the included
ncurses .deb into tools/fdisbull-runtime-lib, install the included wrapper as
tools/fdisbull-dosbox with executable permissions, then run the doctor above.

All findings here are based on the supplied files, local tool output and
direct archive inspection. External game walkthroughs were not re-researched.
