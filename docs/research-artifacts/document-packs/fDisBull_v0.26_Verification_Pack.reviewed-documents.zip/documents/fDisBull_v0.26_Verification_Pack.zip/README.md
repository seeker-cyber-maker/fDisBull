# fDisBull v0.26 installation and bounded analysis

Verified on 30 October 2026.

## Result

The supplied Linux x86_64 offline package is installed and usable. The official installer passed its checksum, dependency, version and Z3 checks. The native DOSBox diagnostic passed all 13 checks. A bounded run of the new Z-machine processor successfully inspected the original Zork story and exported its complete result.

The native diagnostic used an authored disposable target. The Zork run was static analysis of an original story file. Neither result establishes general game compatibility, native timing parity, complete story recovery or a playable route.

## Package identity and installation

| Field | Verified value |
| --- | --- |
| Release | fDisBull 0.26.0; fDisBull Player 0.26.0 |
| Source commit | 8ba24d62b5010d3a6a5d604524aad72e2e047b77 |
| Python | 3.13.5, as required by the supplied installer |
| Uploaded archive size | 102,472,053 bytes |
| Uploaded archive SHA-256 | 035146ade72ba0a125e765234c988446809298546073428d1b1e9ab605f4931c |
| Archive members | 25 |
| Native DOSBox-X size | 139,610,160 bytes |
| Native DOSBox-X SHA-256 | 45fb6ffebe01de70599403a10a4a7d4a3b003621e910c36cc63449846ad3d346 |
| Installed interpreter | [private-local-path] |

The uploaded archive digest matches the published [v0.26.0 release asset](https://github.com/seeker-cyber-maker/fDisBull/releases/tag/v0.26.0). The kit's own installer verified its contents and installed the supplied wheels with no package-index fallback and required hashes.

A separate Python 3.13.5 runtime was installed for the kit. The default system Python was not changed. The native executable required libncurses.so.6, which was absent from this host. The matching Ubuntu Noble libncurses6 package, version 6.4+20240113-1ubuntu2, was extracted into a private compatibility directory. It matches the installed libtinfo6 version. There was no system-wide package installation.

The source companion is a separate release asset; it is not part of the uploaded kit. GOG unpack commands still require the external innoextract program.

Evidence: [kit manifest](package/manifest.json), [kit checksums](package/SHA256SUMS), [installer log](installation/install.log), and [GitHub metadata](package/github-evidence.json).

## Resolved local setup incidents

The first extracted copy of DOSBox-X was only 104,415,232 bytes and failed its expected checksum. Investigation established that both the complete uploaded archive and the original tar member matched their published or bundled digests. Only the extracted local copy was short. That member was restored atomically from the original archive, its full length and digest were checked, and the official installer then passed. The cause of the first extraction's truncation is unestablished. This is not evidence of a defective release archive. No checksum was altered or bypassed.

The first Zork analysis executed to its instruction budget but could not preserve its oversized response: the output directory had mode 0755, while fDisBull requires a private directory. The response explicitly reported output_unavailable, reason not_private, with no artifact. Inspection of the shipped analyzer confirmed that this command is read-only, deterministic and creates no analysis database. The owned output directories were corrected to mode 0700 and the same bounded analysis was run again. The successful response was exported through output-export; it was not reconstructed from a truncated preview.

Both the initial failed output-delivery response and successful response are included. The historical extracted-binary integrity finding is labelled as a resolved incident.

## Native debugger diagnostic

All 13 checks passed:

1. Genuine dependencies and native decoding.
2. Backend inputs.
3. Launch of the authored target.
4. Execution breakpoint.
5. Execution overlay.
6. Native save.
7. Screenshot.
8. Click with coordinate frame.
9. Data watch.
10. Bounded instruction trace.
11. Native restore.
12. Offline temporal interpretation.
13. Restart and export of stored evidence.

The diagnostic reports native_state_restored as true. No fDisBull or DOSBox process remained in the process inspection after completion.

Its observation contract matters for further reverse engineering: execution breakpoints and trace registers are before-instruction observations; data watches are after-access observations with instruction completion unknown. A REP instruction may still have work remaining. A changed program counter or one watched access must not be promoted automatically to a complete consumer transaction.

The diagnostic identifies the supplied wrapper as its executable input. That wrapper's hash is a different identity from the DOSBox-X binary hash above; this is expected.

Evidence: [native receipt](native/receipt.json), [CLI response](native/doctor-response.json), [trace](native/trace.json). The authored target is a finite debugger acceptance exercise, not a compatibility test of Lost in Time, Colonization, Syndicate or Zork's DOS interpreter.

## Original Zork: new Z-machine processor

The static analysis used the existing original file at:

~~~text
[private-local-path]
~~~

No story bytes or DOS executable bytes were changed.

### Recovered header and extent

| Field | Result |
| --- | --- |
| Format | Raw Z-machine version 3 story |
| Release | 88 |
| Serial text | 840726 |
| Source SHA-256 | 0ae5ac229e79094ff368b6669356444af0f35e21d862a1baaa546989085c15fd |
| Physical file size | 92,160 bytes |
| Header-declared story size | 84,876 bytes |
| Bytes beyond declared extent | 7,284 bytes |
| Story checksum | Matched; header value 41,257 |
| Initial PC | 20,229 (0x4F05), story-byte address |
| Static memory boundary | 11,859 |
| High memory boundary | 20,023 |
| Object table address | 688 |
| Global table address | 8,817 |
| Dictionary address | 15,137 |
| Abbreviations address | 496 |

The 7,284 trailing bytes are outside the declared story extent. Their purpose was not investigated in this run; they are not automatically disposable or classified as executable code. The values labelled objects, globals, dictionary and abbreviations by the result are addresses, not counts.

This supplies direct evidence that this story contains Z-machine VM instructions. It does not identify every implementation detail of the separate DOS interpreter executable.

### Bounded analysis outcome

| Measure | Result |
| --- | --- |
| Instruction budget | 250 |
| Decode attempts | 250 |
| Instructions decoded | 250 |
| Total decoded instruction bytes | 1,134 |
| Candidate routine headers | 14 |
| Remaining frontier entries | 19 |
| Unresolved transfers | 3 indirect calls |
| Return sites retained | 19 |
| Reported issues | 0 within this bounded traversal |
| Stop reason | instruction_budget |
| Worklist drained | No |
| Runtime reachability proven | No |
| Game intent recovered | No |

The unresolved call sites are story offsets 36,122; 36,150; and 36,167. Their packed routine addresses require runtime operand values. These are explicit analysis limits, not demonstrated corrupt instructions.

The first instruction at 0x4F05 is decoded as a call with packed routine address 0x2A39. The processor identifies a candidate routine header at 21,618 and instruction entry at 21,625 after its three local-variable defaults. Both caller and callee locations use the story address space, independently of native x86 addresses.

The analyzer follows candidate static successors. Call continuations assume the callee returns; caller-dependent return destinations are not resolved through a simulated call stack. Decoding a target does not prove that the game executes it. Zero reported issues within 250 attempts is not a whole-file correctness claim.

The successful command took approximately 0.187 seconds as measured by its subprocess driver. This is one local bounded run, not a comparative performance benchmark. Its complete result was 230,258 bytes and was retrieved using the output-artifact mechanism.

Evidence: [complete analysis](analysis/zork-analysis.json), [run receipt](analysis/zork-run-receipt.json), [successful response](analysis/zork-response-retry.json), [export receipt](analysis/zork-export-response.json).

### Reuse command

The installed runtime can be invoked without importing the source checkout:

~~~sh
[private-local-path] -I -m fdisbull \
  --output-artifact-dir /var[private-local-path] \
  --max-output-bytes 8192 \
  zmachine-analyze \
  [private-local-path] \
  --max-instructions 250
~~~

The output directory must remain private. When the response supplies an artifact identifier, retrieve that result with output-export instead of repeating a command solely to see its full output.

## What v0.26 changes for this investigation

The package contains a genuine Z-machine v3 processor and the projectless zmachine-disasm and zmachine-analyze commands. This gives the processor-module work a concrete shipped implementation for qualified raw v3 stories: instruction facts, operand roles, candidate successors and routines, unresolved transfers, overlaps, return sites and analysis frontiers.

It does not provide Z-machine execution, automatic puzzle recovery, native guest address mapping, or a persisted Z-machine guest analysis database. Early v3 stories lacking the required length/checksum fields and other VM versions are outside the documented supported profile.

The LE loading implementation remains the existing static subset: preferred object mapping and internal 32-bit offset fixups, with original container bytes retained. It is useful for the Syndicate static investigation. It does not add DOS-extender execution, LX support, external imports, selector/far fixups, compressed or iterated pages, or general executable rewriting.

For DinoPark, the release strengthens funded transaction recovery: a committed purchase is separated from a pending notice/return, and supported failures preserve a qualified stopped guest in recovery_required. These are shipped implementation findings from package review; DinoPark itself was not run in this verification.

Pinned primary references:

- [Z-machine processor scope](https://github.com/seeker-cyber-maker/fDisBull/blob/8ba24d62b5010d3a6a5d604524aad72e2e047b77/docs/ZMACHINE_PROCESSOR.md).
- [DinoPark recovery contract](https://github.com/seeker-cyber-maker/fDisBull/blob/8ba24d62b5010d3a6a5d604524aad72e2e047b77/docs/DINOPARK_FUNDED_RECOVERY.md).
- [Release](https://github.com/seeker-cyber-maker/fDisBull/releases/tag/v0.26.0).

## Guide skill and PR #33

The v0.26 wheel contains the five guide resources accepted in PR #27. Their contents match that accepted guide version.

The expanded guide in [PR #33](https://github.com/seeker-cyber-maker/fDisBull/pull/33) remains open and unmerged at the recorded check. Its head is 8655d1c30a318323e5e1de8488bd92899e3ef96c; its base is the v0.26 source commit. GitHub reported it mergeable with a clean mergeability state. CI results were not separately refreshed for this report.

These three PR #33 references are absent from the release:

- routes-and-discoveries.md
- formats-and-engine-reuse.md
- engine-source-examples.md

The release therefore does not yet contain the extended coverage for unused code, bug transactions, speedrunner and completionist routes, partial media specifications and qualified cross-game engine reuse. The installed environment was kept as the released v0.26 package so its verification remains meaningful. No merge or release publication was performed.

## Next substantive format question

For Colonization, the prior evidence identified a 494,910-byte VICEROY.EXE with a declared MZ extent of 132,709 bytes and a 362,201-byte appended region. The useful next question is which resident open/seek/read path consumes the first block of that region, and what on-disk extent and runtime destination it establishes. The resident RTLink/Plus marker alone is not a recovered overlay grammar.

For Lost in Time, the unresolved compact-media issue is the original music completion contract. The next useful observation is one original start, progress, completion and stop cycle, including the active player state and status/timer/yield behavior. The possibility of a one-frame music track causing rapid restart or CPU load remains an unobserved risk. Unknown music duration and looping behavior should remain preserved until the original consumer is located and observed.

The original Zork inputs survived locally. Original Lost in Time, Colonization, Eternam and Syndicate targets were not present in the two checked workspaces during this verification; those games were not reanalyzed. Existing recovery packs and repository findings remain the starting point for recovering those inputs.

## Pack contents and preservation

This pack contains the readable report, machine-readable verification summary, package metadata and checksums, install log, original authored native diagnostic evidence, and the complete bounded Zork analysis. It excludes the uploaded kit and original game binaries. It contains no edits to the fDisBull repository.

Analysis depth is explicitly bounded. No native game compatibility, complete code coverage, route optimality, newly demonstrated game bug, or general media-truncation safety is claimed.

