# Recorded native route format

`route.json` uses format **`lost-in-time-native-route-1`**. It contains the 35 observed click/run stages from the retained exploration playthrough: 31 clicks and 4 waits. `build_route.py` reconstructs the manifest from `exploration/receipts.jsonl` and `../bilge_source/bilge_interface_evidence.json` without operating the emulator or changing a database.

## Authority and scope

The manifest copies each selected receipt's original request and selected before/after state. Commands and descriptions are authored annotations. Source target IDs connect the observed points to recovered geometry; they do not replace the observations with a simulated result.

The route uses receipts through record 73, the final re-entry capture. The top-level `source_receipts` object records the exact JSONL prefix length, SHA-256 and record count. A later save record or later appended exploration does not silently extend this fixed route. Record numbers are one-based.

The source packet's path, format and SHA-256 are recorded under `source_packet`. Its full action rules and limitations remain available there.

## Top-level fields

| Field | Meaning |
|---|---|
| `format` | Schema identifier `lost-in-time-native-route-1`. |
| `route_id` | Stable ID for this complete hold/bilge route. |
| `source_receipts` | JSONL path and exact observed prefix identity. |
| `source_packet` | Source geometry packet identity. |
| `coordinate_space` | 320×200 guest-frame click coordinates and rectangle convention. |
| `state_fields` | Fields copied into every recorded state. |
| `image_policy` | How retained capture associations are assigned. |
| `execution_policy` | Boundaries between empirical route data and runner behavior. |
| `stages` | Ordered list of 35 stage objects. |
| `validation` | Counts and consistency checks performed by the builder. |

## Stage fields

| Field | Meaning |
|---|---|
| `number`, `id` | One-based route position and unique stable stage ID. |
| `command` | Short text command for a user or headless interface. Commands may repeat; IDs are unique. |
| `description` | Authored paraphrase of the action and observed presentation. |
| `receipt_record_1based` | Original click/run receipt record. |
| `action_kind` | `click` or `wait`; native `run` requests become wait stages. |
| `request` | Verbatim original request, including point, duration and explicit right button when present. |
| `duration_ms` | Convenient copy of `request.ms`. |
| `button` | `left` for clicks whose original request omitted a button, `right` when explicit, or `null` for waits. The original request remains unchanged. |
| `target_source_id` | Stable target ID in the bilge source packet, or `null` for a UI special/wait. |
| `special_action` | `acknowledge`, `put_away`, `open_inventory`, `select_inventory_item`, `wait`, or `null`. |
| `target_binding` | Source geometry evidence, observed inventory slot, or explicit special-action classification. |
| `source_point` | Original point transformed into the source rectangle's space, or `null` when no object rectangle applies. |
| `recorded_before`, `recorded_after` | Selected empirical state, copied without normalization. |
| `recorded_frame_before`, `recorded_frame_after` | Original frame metadata, including native frame ID and state revision. |
| `images.before`, `images.after` | Retained capture association object or `null`. |
| `image_notes` | Explanation for an absent boundary image. |
| `readiness_note`, `timing_note` | Optional notes for observed transition behavior that a runner must preserve. |

Each recorded state contains exactly these fields:

```json
[
  "script", "camera", "subview", "selected_item",
  "animation", "animation_request", "inventory_mode", "inventory_kind",
  "mouse_buttons", "hotspots", "origin"
]
```

Script casing is preserved. An animation value such as 1547 or 1153 is a recorded intermediate value, not a synthesized stable-state marker. Some fields can already appear complete while other fields are still changing.

## Source rectangle bindings

Object and navigation clicks have `target_binding.kind = "source_object_or_navigation"`. The binding retains the raw target ID, source assignment reference, observed active rectangle and expected translated rectangle. The builder checks that the active rectangle matches the source rectangle after applying the observed popup origin.

For a popup, `source_point.coordinates = request.point − recorded_before.origin`. For a main object or navigation edge, the source coordinates are the original guest-frame point and the transform origin is `[0,0]`. Containment uses `x <= px < x+width` and `y <= py < y+height`.

The lamp pickup is an example:

```json
{
  "target_source_id": "hold.camera2.lamp",
  "source_point": {
    "space": "popup_local",
    "coordinates": [57, 44],
    "rect_xywh": [48, 29, 19, 32],
    "inside": true,
    "origin_used": [8, 52],
    "original_game_point": [65, 96]
  }
}
```

The source packet names shared navigation records `bilge.navigation.left` and `bilge.navigation.right`. Hold navigation stages reuse those **MENU.TOT geometry records** and explicitly set `target_binding.shared_menu_geometry_reuse = true`. Their observed script and camera remain the hold's values. This exception applies to shared geometry; it does not relabel the actual room.

## Inventory and other UI actions

The inventory selection is a separate special action. The observed item 14 slot is `[152,58,18,18]`; the recorded click `[161,67]` becomes slot-local point `[9,9]`. The binding retains `item_id: 14` and the recorded slot. A runner should locate the item again if the live inventory differs.

Opening inventory by right click, putting away a selected item by right click, and acknowledging a response by left click are distinct specials. A special does not inherit a scene-object action merely because its point overlaps a registered object rectangle. Acknowledgement effects are copied from the receipt even where the selected state fields do not change.

## The four waits

| Stage | Receipt | Duration | Observed purpose |
|---|---:|---:|---|
| `wait_for_water_response` | 26 | 3,000 ms | Complete the first water inspection before its displayed response. |
| `wait_for_pumping` | 50 | 3,000 ms | Complete the pumping animation before acknowledging its response. |
| `wait_for_corkscrew_target` | 58 | 800 ms | Complete raw target 3 registration from `[191,36,0,0]` to `[191,77,14,11]`. |
| `wait_for_hold_transition` | 66 | 1,500 ms | Finish the hold transition after the script name has changed but old bilge hotspot geometry remains. |

The corkscrew wait begins with both animation fields already −1. The hold wait begins with script `emam1017` while the target table still describes the bilge. A runner must not drop these waits because one flag looks settled.

## Images

Each non-null image object names an actual retained PNG, its hash, source capture record and frame ID. An association is assigned only when the capture lies in the same interval between actions and its selected state and frame ID match the boundary.

The first use has `reuse: false`. Reusing the same capture at an adjacent stage boundary has `reuse: true`, a `reused_from` stage/side reference and an explicit association label. This reuse is of a known capture. The initial manifest does not substitute a nearby stable scene for an uncaptured intermediate state.

The generated route links **47 of 70 before/after image positions**, using **24 retained images**. The remaining 23 positions are `null`. The runner may add separately labeled visual calibration, including an illustrative stable scene if appropriate, but it must preserve the empirical state and must not claim that an animation intermediate has a retained capture when it does not.

## Rebuilding and validation

From this directory:

```bash
python build_route.py
```

The builder also accepts `--receipts`, `--source-packet`, and `--output`. It writes only the selected output JSON.

Validation checks the exact 35 observed action records; 31 clicks and 4 waits; unique IDs; all 34 adjacent selected-state boundaries; 23 source target bindings; one inventory-item binding; point containment; observed/source rectangle agreement; camera, subview and script context; and hashes of every assigned capture. A changed source trace fails a check instead of silently inventing replacement behavior.
