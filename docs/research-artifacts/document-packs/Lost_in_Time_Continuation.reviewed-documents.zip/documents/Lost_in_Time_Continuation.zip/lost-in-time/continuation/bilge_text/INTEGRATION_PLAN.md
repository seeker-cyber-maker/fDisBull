# Bilge UIL extension — integration contract

The recovered continuation already preserves a complete 38-scene, guide-derived adventure. This extension keeps that world and its `state_engine.Game` unchanged and adds source-backed behavior using the installed **fDisBull 0.22.0** interaction evaluator. It does not reconstruct or claim the lost 0.21 candidate package or its old test receipts.

## Executable format

Use `format: fdisbull-il-1`, `role: uil`, typed variables, ordered primitive blocks, declared resources, and per-block evidence. The actual installed API is:

```python
validate_il(document)
execute_il(document, state=None, capabilities=(), max_steps=1024)
```

The existing evaluator supports `set`, `add`, `subtract`, `if`, `require`, `text`, `load_graphic`, `play_sound`, and `click`. Conditions are `eq`, `bit_test`, `not`, and `and`. An OR condition can be represented by De Morgan's law if needed, but this extension should prefer direct branches corresponding to the source.

Variable declarations retain original byte widths and signedness. A semantic label belongs with evidence until its meaning is established; otherwise use neutral offset-based names. Each bounded program declares only its explicit inputs and outputs, and the host passes an exact state with no undeclared keys.

The evaluator commits pure state/text programs atomically. It returns `pending_host` for graphics, sound or click effects: those effects have not occurred, and returned `proposed_state` is not native committed state. A failed `require`, unsupported operation, bad state or exhausted step budget cannot become a claimed original-game success.

## Scope for this increment

Recover a bounded bilge action or branch from `EMAM1018.TOT`, record the exact decompressed-script hash and source offsets, translate it into existing typed IL, and compare its declared state/text result against original-game observations. Build only branches whose operations and inputs are actually known. An unresolved shared callback remains a named omission, not an invented effect.

Native geometry belongs to the recovered interface packet and context-specific fDisBull scene definitions. Stable action identifiers link the semantic programs to the same source targets, but a shared name alone is not parity proof. The native controller must reobserve current script, camera, subview, item selection, modal state and hotspot registration before input.

## Existing adaptation and recovered distinctions

| Adaptation entry | Current behavior | Recovered distinction |
|---|---|---|
| `a_hold` → `a_bilge` | Travel requires carrying the lamp. | Original first entry requires selected lamp1. After the bilge has been visited, the source replaces the opening's raw target11 with21; return entry requires empty hands. A single inventory-presence guard cannot express both native routes. |
| `a_find_lamp` | Searching behind a barrel immediately grants the lamp. | Native entry is camera2 barrels → subview6 lamp closeup → separate pickup selecting item1. The guide's single action abstracts this staging. |
| `a_find_oil` | Search cask immediately grants `palm_oil`. | Original cask → cask detail → bottle closeup → separate pickup yields selected oil14. The full sequence is retained in native bindings. |
| `a_oil_pump` | Consumes `palm_oil`; sets `a_pump_oiled`. | Oil14 must target the closeup handle. Native receipts and VM snapshots show owned byte6383 changing1→0, selected item14→−1, and pump-oiled byte12660 changing0→1. |
| `a_pump_water` | Requires `a_pump_oiled`; sets `a_bilge_drained`. | Original handle use requires camera2/subview1 and empty hands. The handle branch tests oiled12660!=0; its drain assignment12659=1 follows animation. That flag commits before the final message dismissal. |
| `a_find_corkscrew` | Requires drainage; searching beneath chain immediately grants corkscrew. | Source separates chain closeup/subview3 and raw target3 pickup, item10/flag12662. Visibility and actual pickup must remain distinct in a native route. |
| No equivalent guide action | The authored room has no first/repeat dirty-water inspection history. | Source and native recording distinguish first dead-rat response65 from repeat refusal66 using flag12661. The first flag commits after acknowledgement, even after the animation has finished. |

These are differences in abstraction and coverage, not a finding that the guide is wrong. Source rules, script hashes and geometry are recorded in `../bilge_source/bilge_interface_evidence.json`; the five bounded state comparisons and their actual byte-bank/receipt references are in `native_comparison.json`. Only those five comparisons constitute native parity checks for this extension. Other route facts retain their source/native investigation provenance in the sibling evidence files.

Two presentation properties are already established directly from the preserved adaptation: it combines camera views into one semantic room, and its public bridge returns a static scene-description template. The native host must preserve view identity. A source-backed text extension should derive descriptions from its confirmed state so a drained bilge is not repeatedly presented as standing water after a restore.

## Deliverables and ownership

New implementation files belong only in `bilge_text/`. Source extraction and rule evidence belong to the separate `bilge_source/` owner. The coordinator owns native input and project databases. Existing `text/bridge.py`, world data, source receipts and baseline native checkpoints remain unchanged by this extension.

The intended outputs are bounded IL JSON programs, an action-to-source/binding catalog, a small executable demonstration or adapter if the recovered branches justify it, and focused comparison cases. Positive and refusal cases must retain their evidence level: source model evaluation, original runtime observation, or repeated native qualification.

## Acceptance

1. Every produced program passes the actual installed 0.22 validator and evaluator.
2. At least one recovered positive branch and a meaningful refusal or alternative branch have independent expected results from source evidence.
3. Native effects remain the original engine's authority; pure IL evaluation is never reported as a real click.
4. Program state and native variable correspondence are explicit; scene positions come from the shared recovered target packet.
5. The complete 38-scene adaptation remains available with its original provenance, while new source-backed coverage is reported separately.
