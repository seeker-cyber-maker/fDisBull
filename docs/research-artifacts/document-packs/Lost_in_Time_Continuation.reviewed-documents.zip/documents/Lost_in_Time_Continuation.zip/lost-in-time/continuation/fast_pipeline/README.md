# Fast source → UDL → UIL → Z experiment

This directory turns the recovered bilge and hold evidence into a broad investigator blueprint, typed UDL descriptions, executable UIL branch models, and two real `fdisbull-il-scene-1` packages for the pinned Z integration candidate. The acceptance claim is **source-backed conditional behavior, not formal verification or whole-game equivalence**.

The final inputs describe **51 source actions, 23 native targets and 12 source views**. Executable coverage is deliberately smaller: **six previously qualified bilge models and one freshly lowered poster model**, linked to 11 source action IDs. Every complete broad action description remains behind an unconditional compiler refusal; only its separately named, qualified branch model can execute.

## Artifacts

| Artifact | Meaning |
|---|---|
| `investigator_blueprint.json` | Private scene/object/action projection with source identities, guards, effect order, transitions, source acceptance tiers and UNKNOWNs. This is an investigator format, not a new canonical Z schema. |
| `udl.json` | Bundle of 51 typed, execution-blocked descriptions plus seven executable branch models. Every contained program uses actual `fdisbull-il-1`, role `udl`. |
| `uil.json` | The seven executable models with role `uil`. Existing `change_role` validates and copies metadata; this stage performs no new semantic compilation. |
| `z_scene.json` | Actual candidate Z package for the six bilge models: seven contexts, nine objects, one shared typed state and `partial: true`. |
| `z_poster_scene.json` | Separate actual candidate Z package for the new hold-poster model, with one context and one object. |
| `entry_state.json`, `poster_entry_state.json` | Explicit typed model entry witnesses. These files do not claim to be the current original-game state. |
| `poster_validation.json` | All 256 signed-byte counter cases and two out-of-scope guard refusals for the fresh slice. |
| `benchmark.json` | Exact artifact hashes, input/runtime identity, per-stage wall times, minimal checks and candidate player outcomes. |

The complete guide-backed adventure remains separately available under `../text/`: **38 authored scenes and 188 actions**. It is neither presented as source-faithful nor flattened into the candidate's 32-program envelope limit.

## Rebuild

From `[private-local-path]`:

```bash
tools/fdisbull-022-venv/bin/python continuation_work/lost-in-time/continuation/fast_pipeline/compile.py
```

The default inputs are the 31-rule bilge packet and the finalized 20-rule hold extension. `--extra-packet PATH` can explicitly select the additional compatible packet. The source packet, exact extracted members, ASTs, text records, source inventory, prior model catalog, parser profile and lowering code are identified in the output. Missing declared source members refuse the rebuild. Existing bilge AST identities and freshly rebuilt model contents must match their prior catalog; they are not silently requalified under new hashes.

The compiler uses installed **fDisBull 0.22.0** for source lowering and IL evaluation. Candidate scene/player checks run in a separate subprocess with `PYTHONPATH` pointing to:

```text
work/fdisbull-z-candidate
commit c107d1576d46d7dc353c8043cb81be5005e8926b
```

That is pending PR18 integration source, not an installed Z feature of 0.22. No package upgrade, debugger, database, native game execution or cloud API is involved.

After extracting the continuation elsewhere, supply the candidate checkout explicitly with `--candidate-source /absolute/path/to/fdisbull-z-candidate`. Use the matching installed interpreter and the extracted `fast_pipeline/compile.py` path. For play, set `PYTHONPATH` to that checkout's `src` and `player` directories and use the extracted scene/state paths. The candidate must be at the pinned commit above; the compiler checks it. The checkout and offline runtime are external dependencies, not embedded copies in the continuation archive.

## Play the fresh poster slice

From the same workspace root:

```bash
PYTHONPATH=work/fdisbull-z-candidate/src:work/fdisbull-z-candidate/player \
tools/fdisbull-022-venv/bin/python -m fdisbull_player \
  --backend-command "tools/fdisbull-022-venv/bin/python -m fdisbull.il_scenes continuation_work/lost-in-time/continuation/fast_pipeline/z_poster_scene.json --state continuation_work/lost-in-time/continuation/fast_pipeline/poster_entry_state.json" \
  --backend-timeout 3
```

Commands include `look`, `examine poster` and `inspect poster`. `examine` is a passive description; `inspect` executes the recovered branch. The first three inspections select original USA text31, text32 and text33. Each increments the signed-byte counter. The same command can launch the bilge package by changing the scene/witness filenames to `z_scene.json` and `entry_state.json`; start with `inspect water`.

These are **investigator test interfaces**. Bilge public context IDs distinguish mapped states such as oiled/stuck, so player-knowledge parity is unqualified. Do not use this package as a blind or spoiler-free player benchmark. The broad blueprint and UDL evidence also contain private puzzle knowledge and must not be substituted for a public observation.

The bilge package has disconnected branch entry conditions. It does not supply room navigation, oil acquisition/application, inventory selection or a complete bilge puzzle. The retained drain effect can be tested with the explicit pump witness recorded in `benchmark.json`; it does not execute original menu/animation dependencies.

## What the new poster slice establishes

The new lowering reads bounded `EMAM1017.TOT` AST sub2758, selects camera0 and empty hands, and checks that the selected body contains exactly the counter switch and increment. Original script/text hashes, selected opcode bytes, text ranges and readable fragments are checked. For signed byte `c` at VM offset12637:

- `c == 0` selects text31.
- `c == 1` selects text32.
- Other values select text33.
- The increment follows `c′ = ((c + 1 + 128) % 256) - 128`.

All **256 typed counter inputs** are checked against that direct rule, including `127 → −128` and `−1 → 0`. Those are conditional handler-domain checks, not 256 reachable native click states. Original geometry hides the removed poster when the counter is−1; the Z package suppresses that object and rejects a direct attempted action against it. Wrong-camera and selected-item inputs refuse the branch without effects. The source profile's signed-read/byte-write evidence is retained; equivalence to the original DOS interpreter is not formally proved.

The six bilge models remain the previous four complete selected-response models and two retained-effect projections. Their initial-state, callback, text-stream and completion-boundary limits remain attached. In particular, a projected puzzle flag must not be confused with completion of the original animation or menu sequence.

## Measurement and proof budget

`benchmark.json` separates source hashing, broad projection, rule typing, lowering-input closure, warm bilge AST lowering, fresh poster AST lowering, role copying, Z envelope construction, checks, writes and the candidate subprocess. The role-copy figure is not a compiler optimization or a speedup measurement.

Times cover one local rebuild using existing decoded evidence. They exclude acquisition, extraction, decoding, prior manual analysis, prior branch implementation and native investigation. Previously decoded AST/text artifacts remain trusted derived inputs under recorded identities; hashing them again is not a new proof that the decoder interpreted the whole game correctly.

The current proof budget is limited to schema/identity checks, three representative bilge guard/effect checks, structural closed-world refusal for all 51 broad descriptions, the fresh poster's finite-byte domain, and a small candidate-player check. No old full test suite or native replay is repeated.

## Friction relevant to fDisBull

Current v1 has no executable opaque intrinsic, native callback contract, or string/array VM state type. This experiment preserves unknown effect signatures as metadata and refuses their execution. Candidate Z additionally requires exact shared declarations/defaults, one binding per `(verb, item)`, explicit entry witnesses and bounded package sizes. These are concrete seams for source-block decoding, dependency closure, content-addressed lowering reuse, shared-state adaptation and composable scene serving. They are not implemented here by inventing new core opcodes or silently ignoring unknown behavior.
