# Continuation: hold to bilge

## Outcome

Extend the recovered Lost in Time investigation beyond the opening inspection harness: recover the lamp and enter the bilge through ordinary input, describe its source-backed views and rules, and express a bounded new behavior in the installed fDisBull UIL format. Retain a playable independent text adaptation and a distinct native authority.

## Recovery boundary

Workspace maintenance removed the prior local 0.21 pilot and environment before its blocked save completed. Library recovery found a separate 0.22 continuation archive, preserving the same English game, a 38-scene adaptation, typed `fdisbull-il-1` examples, native observations and bootstrap. This is the active baseline. Its receipts are historical; new results will be separately recorded. The lost package's 14/6 checks are not claimed as reproduced or present in this archive.

## Owners and sequence

1. Root restores the matching 0.22 offline environment and cold-boots a new native session at its actual mount path.
2. `bilge_source` recovers EMAM1018 geometry, conditions and transitions, plus the hold entry route. It never controls the emulator.
3. Root follows ordinary guest inputs, captures fresh context, and qualifies useful named targets/outcomes. There is one emulator/database owner.
4. `uil_extension` uses the existing typed IL and explicit source facts to model a bounded action and document differences from the authored adaptation.
5. Root integrates and compares relevant positive and negative cases, then packages the continuation with a concise knowledge pack.

## Invariants

- Preserve the original game and historical checkpoints; regenerate at the new path rather than rewriting checkpoint identity.
- Distinguish scene/camera/subview, source offsets/VM offsets/native addresses, and visible/ready/enabled.
- Derive popup translations from live state. Recovered archives already contain different valid origins for different click contexts.
- Input queued does not establish action success. An incomplete action is observed before any retry.
- Existing adaptation remains authored; source models and original-game outcomes are separate authorities.
- No generic compiler or full-game equivalence claim from a few recovered blocks.

## Acceptance evidence

Fresh bootstrap; original-game lamp ownership and bilge entry; at least one bilge target with source geometry plus a real input/result; typed UIL block validation with relevant refusal cases; fresh text continuation at its public interface; saved provenance and honest coverage boundaries.
