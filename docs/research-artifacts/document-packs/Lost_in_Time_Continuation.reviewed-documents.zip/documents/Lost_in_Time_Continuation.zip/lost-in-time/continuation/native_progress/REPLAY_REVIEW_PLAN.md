# Bilge native route: independent acceptance plan

## Scope

Review the reusable wrapper as a bounded controller of the supplied English game through fDisBull 0.22 ordinary guest input. The game remains authoritative. This is not a general Gob interpreter, a universal click host, or proof of complete game parity. Qualify only named route steps and response acknowledgements supported by fresh native receipts. Root owns emulator execution and all project/checkpoint writes; this reviewer uses source and saved observations only.

Sources inspected: `explore.py`, `../harness/original_host.py`, `../bootstrap/cold_boot.py`, and `../bilge_source/bilge_interface_evidence.json` (especially `coordinate_contract`, `arrival_subview_ambiguity`, `first_visit_initialization`, `targets`, `action_rules`, and `inventory_helpers`). Existing exploration captures are witnesses, not a guarantee that the current runtime matches them.

## Acceptance contract

1. **Identity and ownership.** Require the matching English executable/resource identity, the selected project and compatible checkpoint, and one debugger owner. Restores create a fresh paused frame and invalidate previous context tokens, frame modes and memory bindings. Re-resolve the variable bank from independent witnesses; never silently trust a historical absolute RAM address. Close/reap the owned debugger on failure and normal exit. Receipt status must describe what actually completed.

2. **Fresh input context.** Before every mutating command, obtain or validate a fresh observation containing script, camera, subview, selected item, relevant flags, active target rectangle, popup origin, presentation/readiness and live frame mode. A public action API must reject a missing/stale context token; a closed route runner may instead observe and validate each step internally. Token identity must include a session/restore epoch and change after every attempted input or guest progression, including incomplete attempts. Read-only observation must not advance the game.

3. **Presentation is part of readiness.** A matching script, camera, flag or registered rectangle alone is insufficient. Require a qualified main view or the specific closeup; exclude narration, inventory, loading, unknown screens, outstanding input delivery and active animation. A response may be observable without being ready for the next object action. `continue` must recognize a specific qualified response/popup before using its observed dismissal input; it must not become a generic click-through loop.

4. **Geometry is live.** Read the target's current XYWH from `17964 + raw_id*8`. Check positive dimensions, canvas bounds, source conditions, correct registration and the intended point inside the live rectangle. For popup objects, require the expected local rectangle at `18204 + subview*88 + raw_id*8`; translate by current i32 offsets 220/224 and require equality with the active rectangle. Never replay a previous popup origin. X=1000 is disabled. Select the source packet's interior point or another independently justified point that avoids competing rectangles; a generic rectangle center is unsafe for some exits/navigation overlaps.

5. **Inputs and completion.** Use the current frame mode and ordinary click/key APIs only; do not write VM memory or invoke source handlers. Bound each guest-time/host-time wait. Input acceptance is not success: distinguish rejected-before-input, delivered/incomplete, recognized response and terminal state. After an incomplete run, stop the route and observe; do not repeat the action automatically. Log the attempt before/with input so a later observation error cannot erase delivery history. Settle a pending mouse release without re-clicking.

6. **Native evidence and UIL comparison.** Store before/after fields, selected target/raw ID, live geometry/origin, input point, frame/mode identity, run outcome and the precise qualified result. For text-only responses, a screenshot or independently qualified recognizer is needed to claim displayed text; matching a state flag is not text parity. UIL guard variables passed through by the evaluator are not native output assertions. Compare only explicitly retained puzzle effects at the original handler's completion boundary.

## Route-specific gates

| Step | Required distinction / observed result |
|---|---|
| Lamp | Hold camera2 barrels raw12 opens subview6; lamp raw1 uses translated local `[48,29,19,32]`. Pickup establishes item1 ownership, selected item1, lamp-present flag12643=0 and popup closure. Ownership stride is40: `5784 + item_id*40 + 39`, not60. |
| First bilge entry | Hold camera1 raw11 `[246,118,57,30]`, opening-era flag20808=0, visit20826=0 and **selected item1**. Possession alone does not satisfy this branch. |
| Arrival | Confirm scriptEMAM1018. Initial narration can have camera0/subview1 while only main raw11/raw12 rectangles exist. Do not advertise cask-detail readiness until its translated raw1 geometry and presentation are observed. Dismiss the specific narration before the first object action. |
| Oil route | Main cask -> cask detail -> oil bottle are three distinct object clicks. Oil pickup establishes item14 ownership/selection, bottle-present12658=0 and the disabled bottle target. Do not compress the native route to one cask click. |
| Water | First response text65 can be visible while12661 remains0; compare `water_checked=1` only after its required acknowledgement and handler completion. Repeated response uses a separate source branch. After draining, water target X=1000 must make it unavailable. |
| Pump | Main pump and pump handle are separate targets. Selecting oil14 and opening the handle does not oil it. Handle use establishes12660=1 and consumes/deselects item14. A bare-hand pump-work response precedes completion; compare12659=1 after the handler/acknowledgement finishes. Subview may then become0; UIL passthrough subview1 is excluded from native parity. |
| Corkscrew, if exposed | Chain closeup subview3 raw3 uses local `[79,41,14,11]`, requires drained state and an uncollected item. Pickup establishes item10 ownership/selection and12662=1; the target must then become unavailable. |
| Return / revisit | Return establishes holdEMAM1017. Re-entry uses **raw21**, nonzero20826 and **empty hands**; selected lamp/oil/corkscrew does not enter. Raw11 is no longer the first-entry target even though coordinates coincide. Revisit must preserve existing puzzle/ownership state rather than rerun first-visit initialization or restore an earlier checkpoint. |

## Useful negative checks

Prefer a small guard-level replay of real saved observations with an input-call spy, supplemented by Root's focused native acceptance route. Synthetic mutations below test pre-input refusal only; they must not be described as native behavior. Do not modify native memory to manufacture negatives.

| Negative input / observation | Required result |
|---|---|
| Token from another session, before restore, or before the last attempted action; wrong script/camera | Reject before any click/key; offer fresh observation. |
| First-entry narration snapshot with camera0/subview1 but no translated cask raw1 | Cask-detail action unavailable; only its qualified acknowledgement may proceed. |
| Main target rectangle remains registered beneath a popup/inventory, or a modal/animation/loading state is present | Reject object/navigation action; geometry does not override presentation. |
| Active X=1000, zero/negative dimensions, outside-canvas point, mismatched local translation, or stale popup origin | Reject without input. |
| Lamp owned but selected item=-1 on first entry; selected item1 on revisit; correct coordinates but wrong raw11/raw21 registration | Reject the chosen entry branch without relabeling it as successful travel. |
| Frame mode changes since observation, mouse release remains pending, or guest execution stops before budget completion | Do not dispatch another ordinary action; settle only an already qualified delivery or return incomplete and observe. |
| Water/pump message frame with retained flag still0 | Do not report terminal puzzle completion. Acknowledgement must have its own qualified context. |
| Unsupported target/verb, missing source condition, or ambiguous bank/frame recognition | Explicit refusal or incomplete coverage; no guessed coordinate or native state patch. |

## Evidence sufficient to accept

Review the wrapper's input gates and failure paths; run only meaningful guard negatives covering the distinct failure classes above. Root then demonstrates one fresh supported route, including first entry, an actual bilge object/flag result, and a return/revisit if claimed. A durable checkpoint claim additionally needs one clean close/reopen/restore with the same project and paths. Record any unsupported step as a coverage boundary. Do not broaden native testing merely to accumulate cases once the concrete replay risks are resolved.

Implementation review remains pending until `bilge_native.py` is available.
