LOST IN TIME — CONTINUATION
29 October 2026

Start here
==========

The preserved 38-scene text adaptation now has a working headless host. The
original English DOS game has a separate, bounded host with verified bucket,
stool and first-poster interactions, plus an explicit continue/back action.
The original game decides the outcomes of those clicks.

Knowledge_Pack.txt explains what was recovered, the architecture, decisions,
verification, unresolved questions and next investigation. UIL_Design.txt gives
the representation and evidence rules. coverage.json is the machine-readable
coverage ledger. The two transcript files are preserved under inputs/.

The archive preserves the directory layout used in this workspace. Its root
contains lost-in-time/continuation/ and a small tools/ runtime supplement.
Commands below run from that archive root, not from the continuation directory.

1. Play the complete text adaptation
===================================

Any Python 3.10+ is sufficient for ordinary headless play:

  python3 lost-in-time/continuation/text/bridge.py --repl \
    --save-dir lost-in-time/continuation/text/saves

Examples: look, inventory, look behind barrel, examine stool, recap, undo.
Use save to record the live checkpoint; use quit to exit. Resume with:

  python3 lost-in-time/continuation/text/bridge.py --repl \
    --save-dir lost-in-time/continuation/text/saves --resume

The terminal runner accepts exact declared phrases, action IDs and travel IDs.
A narrator or voice adapter can resolve ordinary language privately, then submit
one declared action. The runner owns state and checks the prerequisites.

For JSON lines, omit --repl. For example:

  {"op":"observe"}
  {"op":"execute","command":"look behind barrel"}
  {"op":"execute","command":"inventory"}
  {"op":"save","slot":"live"}

text/README.txt documents all operations, context tokens, explicit hints, saves,
the private action catalogue and the narrator contract. This interface has been
tested with the installed fDisBull JsonLineBackend, Player and LiveSession.
No actual ChatGPT Live voice session is connected by this archive.

2. Run the original-game harness
===============================

The current workspace already has the supplied fDisBull 0.22.0 environment at
tools/fdisbull-venv/ and the backend wrapper at tools/fdisbull-dosbox. The complete
Python environment and original offline kit are not duplicated in this pack.

After extracting this pack elsewhere, install the supplied offline kit or point
the commands at your existing compatible fDisBull Python and backend. See
Environment.txt. The included runtime/game/ contains the working copy of the
user-provided English release; the large CD image is not duplicated here.

Native checkpoints contain the exact mounted game-directory path. Generate a
new checkpoint at the destination using the supplied bootstrap, which starts a
fresh original process and verifies its opening screen and native state:

  tools/fdisbull-venv/bin/python \
    lost-in-time/continuation/bootstrap/cold_boot.py \
    --game-dir lost-in-time/continuation/runtime/game \
    --backend "$PWD/tools/fdisbull-dosbox" \
    --output "$PWD/lost-in-time/session-01"

The output directory must be new. The result prints a checkpoint ID. Use it:

  tools/fdisbull-venv/bin/python \
    lost-in-time/continuation/harness/original_host.py \
    --project lost-in-time/session-01/original-session.fdb \
    --game-dir lost-in-time/session-01/game \
    --backend "$PWD/tools/fdisbull-dosbox" \
    --checkpoint CHECKPOINT_ID_PRINTED_BY_COLD_BOOT \
    --save-dir lost-in-time/session-01/saves

Send one JSON request per line:

  {"op":"observe"}
  {"op":"execute","command":"inspect bucket"}
  {"op":"continue"}
  {"op":"execute","command":"inspect poster"}
  {"op":"execute","command":"back"}
  {"op":"execute","command":"inspect stool"}
  {"op":"continue"}
  {"op":"save","slot":"live"}
  {"op":"load","checkpoint":"live"}

Closing standard input closes the host and emulator. The named action host
covers these opening interactions only. A second poster inspection follows a
different original branch and is refused before input. The nail's geometry and
one successful original click are recovered, but nail is not yet a named host
action. There is no silent fallback to the authored adaptation.

To load a saved slot in a later host process, use the same project, game mount,
backend and save directory, then send the load request. The startup --checkpoint
sets the explicit baseline; it does not silently resume a later slot.

3. Important evidence
=====================

  text/validation-original.json            11 original validation categories
  text/validation-bridge.json              8 categories; 265 route transitions
  integration-text.json                   Independent exact-command regression
  harness/original-qualification.json      Real actions, sequential continuation,
                                          save/restore and fresh-process repeat
  harness/bucket-inspect.uil.json          Original-script-backed UIL fragment
  harness/bucket-il-validation.json        4 no-item cases; 4 held-item refusals
  resources/opening-hotspots.json          Source offsets, typed operands, boxes
  state-verification/native-hotspots.json  Independent saved-memory geometry
  state-verification/stool-underside-verification.json
                                          Corrected nail geometry and translation
  bootstrap/validation.json                Fresh boot without loading a state
  integration/original-jsonl-report.json   Independent client/host integration
  runtime/evidence/                       Actual original-game frames/checkpoints

The historical failure receipt for the text command-precedence defect is kept
beside the fixed-source receipt. Its failure is superseded by the fix and the
independent passing checks; it is not an outstanding defect.

4. Reproduce the source recovery
================================

  python3 lost-in-time/continuation/resource_tools/opening_hotspots.py \
    lost-in-time/continuation/runtime/game/intro.stk \
    [private-local-path]

The decoder deliberately covers selected original blocks. It rejects malformed
or unsupported structure and does not claim to implement the complete Gob VM.
The pinned ScummVM and DOSBox-X source references are included with the evidence.

The earlier installation and two-release inspection is preserved separately at
lost-in-time/Lost_in_Time_Inspection.zip. It predates this continuation's actual
game execution; its statements about unexecuted work describe that earlier stage.
