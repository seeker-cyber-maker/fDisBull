# Fast source acceptance experiment: hold extension

## Result and boundary

The retained Gob resources support **two additional bounded scene descriptions, five object/navigation targets, and twenty action rules** without a new emulator run. The source packet is `hold_interface_evidence.json`, rebuilt by `build_hold_packet.py`. It covers the poster, wooden knot, opening through the partition, smooth post and route to the upper decks. Every rule remains a source description until its dependencies are lowered explicitly. This packet does not make the whole hold or the whole game executable.

The scene `description` fields are **private analyst summaries containing puzzle spoilers**. Separate state-qualified observation candidates avoid disclosing hidden objects or the foothold solution in ordinary player output. The sibling pipeline owns the executable Z/UDL/UIL representations; this report records only source recovery and its acceptance boundary.

An independent read-only review checked the five geometry/dispatch bindings, principal effects, counter width, conditional exit-X override and private/public description separation. No new native tests or shared-database writes were required. The x86 comparison uses a new private database in this directory.

## What the code establishes

Offsets in this table are decimal printed operand offsets in decompressed `EMAM1017.TOT`. Ordinary AST opcode offsets are one byte earlier. Exact archive extents, decoded member hashes, ASTs and text entry ranges are retained in the packet and nearby files.

| Target | Source availability and rectangle `[x,y,w,h]` | Principal action behavior |
|---|---|---|
| Poster, camera 0, raw 13 | `12637 != -1`; `[50,59,48,35]` at 6297 | Bare hands choose text 31/32/33 using counter 12637, then increment it at 2822. Wet sponge 6 removes the poster at 2909 and enables the knot geometry. |
| Knot, camera 0, raw 14 | `12637 == -1` and `12655 == 0`; `[68,60,20,10]` at 6358 | Corkscrew 10 sets knot-removed byte 12655 to 1 at 3343, disables knot X and enables hole X. There is no corkscrew-removal helper call in this branch. |
| Hole, camera 0, raw 15 | `12655 != 0`; `[68,60,20,10]` at 6436 | First bare-hand inspection sets byte 12641 and assigns destination `EMAM1101` at 3658; repeat inspection follows a different presentation/text path. Destination content is unresolved. |
| Post, camera 1, raw 14 | Upper-deck visit byte 20827 is zero; `[96,0,50,151]` at 6835 | Knife 9 causes a foothold sequence, calls removal for knife 9 and lamp 1, then assigns `EMAM1019`, camera 3 at 3522/3551. |
| Upper-deck exit, camera 1, raw 20 | Byte 20827 is nonzero; base X 1000 is patched to X 96 at 7895 | Bare hands perform the return transition to `EMAM1019`, camera 0 at 3849/3864. A selected item returns without that transition. |

The post's identity is bound to hover text 79 in the original language resource. Calling it a door would be an unsupported naming inference. This is a concrete reason to include resource binding in the minimum source proof.

The rectangle record is joined to a hotspot's coordinate-variable references and raw ID, then to the direct call in the raw-target switch at opcode 4034: raw 13 → routine 2758, raw 14 → 3256, raw 15 → 3567, and raw 20 → 3769. Camera context distinguishes the knot and post, which share raw ID 14. The strict hotspot parser reads the 33-record block at 10313; the packet retains the exact records used.

The complete primary parses are routine 2758 through 3256, routine 3256 through 3567, and geometry routine 6231 through 7984. Together these cover 2,562 source bytes and 203 nested AST commands. Official `degob` decodes the selected hole and exit routines successfully, but the independent bounded parser stops on media opcode `0xfe` at 3614 and return opcode `0xe0` at 3785. Their packet entries therefore have a lower acceptance tier. No partial parse is labeled complete.

## Minimum verification before accepting a source scene

1. **Pin the input and decoder.** Check the archive/member identity, decompression bounds and decoded hash. Reuse the pinned extractor and official decoder rather than rebuilding those tools for each object.
2. **Check just the relevant structures.** Bound the required action and geometry blocks by declared length and command count. Record unsupported commands and keep their coverage incomplete.
3. **Bind the scene interface.** Connect script, camera, geometry record, raw target, dispatch call, label resource and selected-item branch. Labels inferred from a walkthrough or progression are hypotheses until this binding exists.
4. **Preserve direct semantics and dependency boundaries.** Keep variable width, signedness, write order, selected item, availability predicates, text IDs and destination assignments. Inventory, media, text waits, popup cleanup and redraw helpers remain explicit dependencies; they cannot silently become no-ops.
5. **Choose an acceptance scope.** This is enough for a source-backed investigator model and blocked UDL descriptions. An executable headless projection additionally needs every projected operation implemented and its branch contract checked. A live harness click additionally needs current context, input readiness, coordinate transforms and runtime qualification; static rectangle containment alone does not supply those facts.

This avoids repeating the previously qualified 35-stage native bilge route for a new helper-free source leaf. It does not eliminate a targeted native check when a particular rendering, input-routing or engine-profile question remains material.

### Poster byte semantics

The poster inspection counter is a signed byte, with `-1` used as the removed sentinel. The pinned ScummVM interpreter source casts `OP_LOAD_VAR_INT8` reads to `int8`; its assignment path invokes `WRITE_VARO_UINT8`, which expands to `Variables::writeOff8`, whose value parameter is `uint8`. The source-profile model therefore stores modulo 256 and reads signed values; the increment is `((n + 1 + 128) % 256) - 128`. A saturating three-state inspection model would change the source semantics.

These are interpreter-source facts, with file hashes retained in `integer_semantics`. They are **not an all-values test of the original DOS runtime**. The scene action also needs the target-availability predicate `12637 != -1`; an exhaustive raw handler test at -1 is distinct from a callable player action. The poster leaf has no subroutine calls in its selected branch, but its text primitive still represents response/presentation behavior at the chosen headless abstraction level.

## Measured costs

`source_pipeline_timings.json` records the exact commands and separate wall/CPU fields. These are single local runs, sensitive to process startup and cache state. Analyst wall time was not instrumented from task start and is deliberately left unknown.

| Work | Wall time | CPU measure | Scope |
|---|---:|---:|---|
| One archive directory, six member extractions and comparison with cached bytes | 16.68 ms | 16.68 ms process user + system | Includes the original archive read and decompression; not a C decompiler |
| Six fresh official `degob` invocations | 18.57 ms total; 2.46–4.21 ms each | 17.15 ms summed child CPU | Complete selected entrypoint outputs; helpers may recur in separate outputs |
| Three primary bounded ASTs, dispatch and hotspot records | 2.50 ms | 2.29 ms process CPU | Includes equality checks against retained ASTs |
| Confirmation of two explicit parser gaps | 0.034 ms | 0.034 ms process CPU | Expected incomplete results remain incomplete |
| Packet build and structural validation | 47.47 ms | 47.18 ms child CPU | Includes Python subprocess startup |
| Supplied-container/script-candidate inventory | 172.47 ms | 172.45 ms process CPU | 30-second budget; finished without a budget skip |
| New fDisBull MZ project import | 267.62 ms | 227.16 ms process CPU | Separate private static database, no emulator |
| Bounded entry-recursive x86 analysis | 6.81 ms | 6.35 ms process CPU | 10,000-instruction cap; stopped at its implemented static fixed point after 16 decoded instructions |

The checked script sections total less than a tenth of a second of decoder/parser/packet work in these measurements. This is **not the elapsed time to discover, interpret, review or author the scene**. The separate inventory and x86 baseline are additional measurements, and existing tool setup/cached research is not included. Do not convert output byte counts or these CPU numbers into a claim of human speedup.

## C-like script versus x86 ASM

`degob` produces a C-like presentation of **Gob resource bytecode**. It does not reconstruct original C from `lost.exe`. That presentation directly exposes the camera and selected-item branches, text resource IDs, variable writes and target rectangles that the scene conversion needs.

The fresh fDisBull baseline analyzes the immutable `lost.exe` MZ entry. It stores 16 instruction rows, covering 29 linear bytes; the exported assembly is 1,104 bytes. The visible instructions copy memory and use a far return. Its recorded issues explicitly include unresolved string-memory addresses and abstract-stack invalidation. A static queue fixed point therefore provides no proof that the engine, dynamic target or scene logic has been recovered. No unpacking/runtime follow-up was performed, and no Gob-to-x86 region mapping was established.

This experiment supports selecting the **script layer for the scene task**. It does not support a matched claim that C is a particular factor faster than ASM. Any separate reading microbenchmark that begins with C already supplied must say so and exclude the cost of recovering that C unless it is actually measured. Source extraction and Gob decoding are measured here; x86-to-C recovery is not.

## Breadth without pretending every script is a room

`script_candidate_inventory.json` inventories all 13 supplied STK/ITK/LTK files. Seven resource directories validate, containing 634 members. All 61 distinct TOT members are extracted and hashed from `intro.stk`; 59 have the supported resource boundary for this name scan. `EMAMADL.TOT` and `DATAOBJ.TOT` remain unscanned at the code level. Six LTK files are recorded as unparsed by the STK/ITK utility, not treated as empty.

The scan finds 272 explicit literals matching known TOT stems, including 171 locally parsed assignments to script variable 4532. The candidate graph records byte offsets and possible destinations. A locally valid assignment or matching string has **not** been proved reachable or aligned with a complete control-flow traversal. Libraries, shared menus and sequences can be TOT files, so 61 scripts is not a room count. The inventory adds zero accepted scenes and zero native qualifications.

## Reproduction and public boundary

From the workspace root:

```bash
python continuation_work/lost-in-time/continuation/native_progress/fast_source/build_hold_packet.py
python continuation_work/lost-in-time/continuation/native_progress/fast_source/measure_source_pipeline.py
python continuation_work/lost-in-time/continuation/native_progress/fast_source/inventory_script_candidates.py
```

The ASM baseline command is `tools/fdisbull-022-venv/bin/python continuation_work/lost-in-time/continuation/native_progress/fast_source/measure_static_asm.py`. It intentionally refuses to overwrite its private database. Retain the existing baseline rather than rerunning it for unrelated verification.

The public requirements PR may carry the acceptance tiers, schema requirements, synthetic examples, counts, timing methodology and explicit unknowns. Decompiled game script and language-resource excerpts remain private evidence. The public report should not imply the hold packet already supplies a whole-game interpreter or general live-click calibration.
