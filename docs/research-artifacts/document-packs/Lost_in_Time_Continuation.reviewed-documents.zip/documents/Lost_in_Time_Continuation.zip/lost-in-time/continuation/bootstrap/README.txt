Fresh original-game bootstrap
============================

Purpose
-------
The fDisBull native state loader checks the exact mounted game-directory path,
as well as executable/backend identity and mounted-file hashes. An old native
checkpoint is therefore not a portable launch shortcut after moving this pack.
Do not rewrite its metadata to evade that check.

cold_boot.py provides the reproducible alternative: copy the supplied English
game into a new working directory, retain the original screenshot evidence in a
SQLite backup of the seed project, and start a fresh DOS process. It never loads
a checkpoint. The startup route uses the previously observed keyboard and mouse
inputs. It then verifies the native state and records a new checkpoint for that
destination. The source game directory, seed project, and installed fDisBull are
not modified.

Prerequisites
-------------
- The supplied English non-CD release, extracted so lost.exe and intro.stk are
  directly inside the selected game directory. This helper verifies the exact
  supplied executable and INTRO.STK hashes; the Italian CD release is outside
  this bootstrap's qualified scope.
- The working fDisBull 0.22.0 Python environment and its native DOSBox backend.
  In the current workspace these are tools/fdisbull-venv/bin/python and
  tools/fdisbull-dosbox. Use their absolute paths from another directory.
- The continuation pack's runtime/english.fdb, containing original executable
  and screenshot evidence. Its native states are retained as historical
  evidence, but none is loaded by this helper.

Run from the directory that contains this README
-----------------------------------------------

/path/to/fdisbull-python cold_boot.py \
  --game-dir /path/to/extracted/english \
  --backend /path/to/working/fdisbull-dosbox \
  --output /path/to/new/lost-original-session

The output directory must not exist. Choose a new destination on retries; this
prevents accidental overwriting of game progress or prior investigation data.
Use --seed-project /path/to/runtime/english.fdb if the seed is elsewhere.

The JSON result prints project, game_dir, and checkpoint. Supply those three
values to the original harness, using the same backend:

/path/to/fdisbull-python ../harness/original_host.py \
  --project /path/to/new/lost-original-session/original-session.fdb \
  --game-dir /path/to/new/lost-original-session/game \
  --backend /path/to/working/fdisbull-dosbox \
  --checkpoint CHECKPOINT_ID_PRINTED_BY_COLD_BOOT

Then send one JSON object per line, for example:
{"op":"observe"}
{"op":"execute","command":"inspect bucket"}
{"op":"continue"}

Closing standard input ends the host and closes its emulator. The original
game's state remains authoritative for that host; this bootstrap does not add
simulated puzzle actions or broaden the harness's qualified action coverage.

What is checked
---------------
1. Exact supplied English lost.exe and intro.stk identities.
2. All bounded startup runs complete their requested guest time.
3. A newly observed 320x200 frame supplies the mode ID for the real dismissal
   click at (160,178). No captured numeric mode ID is reused for input.
4. Fourteen quiet-hold pixel samples match the recorded reference, including
   stable room landmarks and a quiet dialogue band, excluding cursor positions.
5. The three opening hotspot rectangles form one unique 24-byte signature in
   conventional RAM. Its variable-block origin is resolved from this signature.
6. Original native fields show no held item, main view 0, subview 0, and initial
   poster/bucket flags all 0.
7. A real screenshot and native checkpoint are exported only after those checks
   pass. The emulator is closed even on failure; validation records close/reap.

The helper is intentionally bounded to this release and startup route. If a
different build, timing, or screen fails a check, it writes a failure receipt
and stops. Its pixel samples are recognition evidence for the recorded view,
not a general scene classifier or a substitute for the native-state checks.

Completed validation
--------------------
validation.json records a successful fresh boot in an isolated copied mount.
The baseline screenshot is fresh-hold-ready.png. All 14 pixel samples passed;
the unique hotspot signature was at physical 0x44918, with variable origin
0x40294. Fields were held_item=-1, view=0, subview=0, poster_315d=0,
bucket_316b=0, and bucket_316c=0. The emulator was closed and reaped.

The run's working game copy, project, and native state remain under
qualified-run/ in the current workspace. They need not be distributed: the
recipe, seed evidence project, original uploaded game, and the already supplied
offline fDisBull installation reproduce them at a new destination.
