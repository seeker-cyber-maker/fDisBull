# Bounded diagnosis of session01 database corruption

29 October 2026. Read-only inspection; no emulator launched, no fDisBull code changed, and no database or WAL file modified by this investigation.

## Finding

**The exact cause remains unknown.** The failure is concrete missing database-page content, rather than only a failed native checkpoint identity check. A definite connection-lifetime defect exists in the copied bootstrap helper, and the installed SQLite version also falls within the range of a documented WAL race. Neither has been proven to cause this particular failure.

The root investigator's fresh `Project.create(..., image="mz")` path is an appropriate way to continue the game work without trusting this damaged project. This report does not certify any later session.

## Observed database state

The following main files were opened with SQLite's `immutable=1` URI option, which avoids creating or modifying sidecars and does not apply WAL contents. Therefore these results describe the main database files specifically. The root separately observed the ordinary live connection fail during `load_state`.

| File | Main bytes / pages | Main-file quick_check |
|---|---:|---|
| `runtime/english.fdb` | 2,486,272 / 607 | `ok` |
| `harness/original-session.fdb` | 10,862,592 / 2,652 | `ok` |
| `native_progress/session01/original-session.fdb` | 2,502,656 / 611 | `database disk image is malformed` |

All three main headers declare 4096-byte pages and WAL read/write format. The two historical source databases had zero-length WAL files at inspection. Session01 had a 78,312-byte WAL: one 32-byte header plus 19 complete 4,120-byte frames. Its parsed frame records refer only to pages at or below 610; committed sizes in those frames are 609 or 610. This is a structural inventory of the bytes, not a recovery or checksum-validity claim.

The decisive localization is in SQLite's `dbstat` output for the session01 main file: the `debug_artifacts` B-tree refers to leaf pages **616** and **709**, both beyond its physical 611-page extent. They are reported as corrupted. Neither missing page appears in the retained WAL frames. Thus the retained database/WAL pair does not contain those page bodies at their expected locations.

Reading artifact rows succeeds for the older imported screenshots and states, then fails as the traversal reaches the new tail. The B-tree/index count reports 22 artifacts, but scanning the data stops after the old `nail-click-target.png` row. The bootstrap's own exported PNG and native state file exist separately, and its receipt recorded successful reads/exports before closure. The bootstrap run row remains present with `ended=NULL`, whereas the subsequent failed exploration run has its close timestamp. This is consistent with incomplete persistence of the newer tail and close updates. It does not reveal which process or operation lost them.

## Concrete bootstrap lifecycle problem

`bootstrap/cold_boot.py` performs its SQLite backup as:

```python
with sqlite3.connect(seed_uri, uri=True) as source:
    with sqlite3.connect(project_path) as target:
        source.backup(target)
```

It then opens `Project(project_path)` while both `source` and `target` are still referenced local variables. Python's SQLite connection context manager manages transactions; it does **not** close the connection. Consequently the backup connections are not deterministically closed before the native investigation starts.

The narrow correction is to close both backup connections before opening `Project`, for example with `contextlib.closing()` or explicit `try/finally` closures. This is a real ownership/lifetime correction, independently of whether it explains the corruption. SQLite normally supports multiple connections, and the backup API is itself a supported way to copy a live database; it would be incorrect to claim that merely using the backup API or having two connections proves corruption.

No correction was applied during this read-only diagnosis.

## Installed fDisBull behavior inspected

The installed 0.22 sources are under `tools/fdisbull-022-venv/lib/python3.13/site-packages/fdisbull/`.

- `Project.__exit__` explicitly closes all owned debugger sessions and then its own SQLite connection.
- `Project.transaction` commits completed transactions and rolls back exceptions. Artifact storage uses that transaction wrapper and SQL-bound BLOB values.
- `Project._create_image` explicitly selects WAL mode, commits the initial image, checkpoints with `TRUNCATE`, and closes its creation connection before returning a new Project owner.
- `DebugSession.close` stops/reaps the backend, records a close event, and updates the run's end timestamp.
- `DOSBoxRPC` uses subprocess pipes and passes only its two child pipe descriptors. The inspected close path clears the stored parent pipe descriptors after closing them. This inspection found no direct database write, manual WAL unlink, or demonstrated descriptor-reuse error in that path.

These observations narrow the inquiry; they do not prove the absence of another defect.

## Relevant SQLite version boundary

The installed Python is 3.13.5 and reports **SQLite 3.49.1**. SQLite's official WAL documentation identifies a WAL-reset race affecting versions through 3.51.2, fixed in 3.51.3 and selected backports. It requires concurrent write/checkpoint activity from separate threads or processes. The observed version is affected, but this investigation did **not** establish the required concurrent timing. Treat it as a dependency consideration, not an assigned cause.

## Disposition

Preserve the damaged session01 database, its WAL/SHM, bootstrap receipt, and separate native-state export as diagnostic evidence. Continue on a new, independently checked project. Correct deterministic backup-connection closure before reusing this helper. If the database issue is investigated separately, a small isolated reproduction and recorded connection/checkpoint timing are needed before assigning blame to the helper, fDisBull, SQLite, or the filesystem.

## Primary references

- [Python 3.13: SQLite connection context manager](https://docs.python.org/3.13/library/sqlite3.html#how-to-use-the-connection-context-manager)
- [SQLite: safe backup approaches](https://www.sqlite.org/howtocorrupt.html#backup_or_restore_while_a_transaction_is_active)
- [SQLite: WAL file lifecycle and WAL-reset bug](https://www.sqlite.org/wal.html)

Local evidence: `bootstrap/cold_boot.py`, `native_progress/session01/bootstrap-receipt.json`, the three database paths above, and the installed `project.py`, `debugger.py`, and `dosbox_rpc.py`.
