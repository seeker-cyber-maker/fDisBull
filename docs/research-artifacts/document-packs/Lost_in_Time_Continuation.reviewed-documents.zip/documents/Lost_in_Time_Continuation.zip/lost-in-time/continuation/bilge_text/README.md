# Source-backed bilge UIL branches

This extension adds **six small `fdisbull-il-1` programs** using the existing UIL role and the installed fDisBull 0.22.0 evaluator. The complete 38-scene authored adventure remains under `../text/`; these programs do not replace it or turn its guide-derived rules into original-game facts.

## What each program establishes

| Program | Source-selected behavior | Coverage |
|---|---|---|
| `water-first.projection.uil.json` | In camera 1 or 2 with empty hands and byte12661 = 0, report the dead-rat text and project byte12661 = 1 at handler completion. | **Terminal-state projection.** Native animation and menu/dialogue operations remain explicit omissions. |
| `water-repeat.uil.json` | In those water views with byte12661 nonzero and empty hands, return text66 while preserving mapped state. | Complete selected response leaf. |
| `water-small-pipe.uil.json` | In camera 1, selected item35 returns text50. | Complete selected response leaf. No inferred camera2 counterpart. |
| `pump-stuck.uil.json` | In camera2, subview1, empty hands and byte12660 = 0, return text69. | Complete selected response leaf. |
| `pump-gentleness.uil.json` | In the same pump context, selected item11 or33 returns text3. | Complete selected response leaf. |
| `pump-work.projection.uil.json` | In the pump context, empty hands and byte12660 nonzero, return selected source text71 and project byte12659 = 1 after the pump animation path. | **Retained-effect projection.** Native animation, menu, view rebuild and geometry effects remain explicit omissions. |

"Complete selected response leaf" means every operation in that selected leaf body is represented. It does not mean the complete caller, sibling branches, whole function, renderer or game is recovered. A model refusal means the supplied state is outside that selected branch; the original game's sibling branch may do something else.

## Completion is a separate boundary

The source order matters. For first dirty-water inspection, the original script starts animation1500, displays text65, calls shared menu routines, then assigns byte12661 = 1. The native recording confirms that the rat response can be visible with the animation complete while byte12661 remains0. Acknowledging the response then changes that flag to1. The first-water projection describes that later retained effect.

The pump has a different boundary. Byte12659 changes to1 after the pump animation while the final message and subview1 remain visible. Dismissing that message later changes subview1 to0. The pump projection compares **only the retained drain flag**, not the full native state after all callbacks. Its `$subview` value is an input guard passed through by the pure evaluator; the omitted MENU closeup callback changes the real subview.

Each projection lists omitted original AST nodes, opcode ranges and call targets under `evidence.scope.omitted_operations`. Explicit `retained_output_variables`, `guard_or_passthrough_variables` and `selected_text_resources` separate projected effects from model input context. Selected EMAM1018 text resources are not a reconstruction of the complete display stream: omitted menu routines may add or clear text. Pure IL completion is never permission to write native memory, dismiss unqualified dialogs automatically, or declare a real click successful.

The source-backed variable mapping is:

| Variable | Native VM byte offset | Type | Meaning within this bounded scope |
|---|---|---|---|
| `$selected_item` | 244 | i32 | Selected inventory item; −1 denotes empty hands in the selected branches. |
| `$camera` | 13435 | i8 | Original bilge camera. |
| `$subview` | 13364 | i8 | Original closeup selector; insufficient alone to identify a ready popup. |
| `$water_checked` | 12661 | i8 | Original flag tested by the dirty-water response branch. |
| `$pump_oiled` | 12660 | i8 | Original flag tested by the bare-hand pump branch. |
| `$water_drained` | 12659 | i8 | Original flag set after the pump animation path. |

Offsets are relative to a freshly qualified Gob VM bank, not absolute DOS addresses. Initial values in each program are convenient test inputs, not a claim that the corresponding branch is initially reachable.

## Shared geometry

Programs link targets from `../bilge_source/bilge_interface_evidence.json`:

- `bilge.camera1.water`
- `bilge.camera2.water`
- `bilge.camera2.pump_handle`

They do not duplicate a hard-coded click map. `catalog.json` connects program identity, program hash, scope and target identity. A native consumer must still require the current registered rectangle, popup origin, presentation, selected item, modal/input state and fresh context token. The bilge's introductory narration can retain subview1 without displaying the handle or cask closeup, so camera/subview equality alone cannot establish readiness.

## Build and verify

From the workspace root:

```bash
tools/fdisbull-022-venv/bin/python continuation_work/lost-in-time/continuation/bilge_text/build_bilge_il.py
tools/fdisbull-022-venv/bin/python continuation_work/lost-in-time/continuation/bilge_text/verify_bilge_il.py
tools/fdisbull-022-venv/bin/python continuation_work/lost-in-time/continuation/bilge_text/compare_native.py
```

The builder consumes the independently decoded ASTs, exact script bytes, source inventory and localized text records under `bilge_source/`. It rejects a different script hash, unexpected branch shapes, changed selected cases and unlisted operations. Source references use **AST opcode offsets**, one byte earlier than the matching degob parameter offset shown for many instructions.

`validation.json` records **26 passing cases** through the actual 0.22 validator/evaluator: selected positive branches, alternative nonzero flag values, wrong cameras/subviews/tools, branch-history refusals, and a malformed typed byte. Expected text IDs and mapped state changes are stated separately in the test truth table. Whole-state equality in these tests checks evaluator behavior, including guard-variable passthrough; it is not a full native-state parity claim. These checks do not run DOS.

`native_comparison.json` records **five matching state comparisons**, **three expected boundary/scope counterexamples**, and **five geometry bindings** against the coordinator's ordinary-input native recording. The comparator hashes and checks nine screenshot/VM-bank pairs, reads the original field-query receipts, matches saved context and active rectangles, and executes the IL using native input values. It never launches the game or modifies native state.

| Native comparison | Modeled value | Observed value | Interpretation |
|---|---:|---:|---|
| First water, after acknowledgement | checked1 | checked1 | Retained flag matches. |
| First water, response visible before acknowledgement | checked1 | checked0 | Expected early-boundary difference. |
| Repeat water response | camera1, empty hands, checked1 | same | Selected branch context remains unchanged at this recorded response. |
| Unoiled handle response | camera2, subview1, empty hands, oiled0 | same | Selected branch context remains unchanged at this recorded response. |
| Pump, during animation | drained1 | drained0 | Expected early-boundary difference. |
| Pump, after animation before final dismissal | drained1 | drained1 | Retained flag matches. |
| Pump, after final dismissal | drained1 | drained1 | Retained flag still matches. |
| Pump, post-dismissal subview | subview1 | subview0 | Expected omitted-callback difference; this field is excluded from native effect parity. |

The same native evidence independently records selected oil14 becoming empty hands, oil-owned byte6383 changing1→0, and pump-oiled byte12660 changing0→1 while drained remains0. This is a native observation, not an implemented oil/inventory-callback UIL model. The automated comparison does not recognize screenshot text or claim whole-display parity. Camera2 water, small-pipe water and the gentleness response are currently source-model tested only.

For direct API use:

```python
import json
from pathlib import Path
from fdisbull.interaction_il import execute_il

program = json.loads(Path("programs/water-first.projection.uil.json").read_text())
state = {name: spec["initial"] for name, spec in program["variables"].items()}
state.update({"$camera": 1, "$selected_item": -1, "$water_checked": 0})
result = execute_il(program, state=state)
# This is a modeled terminal result, not an observed emulator transaction.
```

The native runtime remains the authority for original-game effects. Compare explicitly retained outputs at their documented boundary, and keep intermediate observations that explain why an earlier or broader comparison would fail.

## Text-only JSONL branch tool

`play.py` exposes these six models through standard input/output using the locally installed evaluator. It has no API key, cloud dependency, native-controller access or persistent game state. Each request produces one JSON response. A ChatGPT-driven text interface can use `observe` to obtain the branch schema, then submit the player's chosen branch with explicit current inputs and consume its selected source text and retained semantic effects.

Run this from the workspace root:

```bash
tools/fdisbull-022-venv/bin/python continuation_work/lost-in-time/continuation/bilge_text/play.py <<'JSONL'
{"op":"observe","branch_id":"bilge.water.first"}
{"op":"execute","branch_id":"bilge.water.first","state":{"$camera":1,"$selected_item":-1,"$water_checked":0}}
{"op":"execute","branch_id":"bilge.water.first","state":{"$camera":0,"$selected_item":-1,"$water_checked":0}}
JSONL
```

The successful request returns `status: complete`, retained output `{"$water_checked":1}`, and the decoded readable text with its original USA text ID65, byte range and resource hash. The camera0 request returns `status: refused`, empty retained outputs and no text. A refusal describes this branch model's coverage or invalid inputs, not a new original-game response.

Use `{"op":"observe"}` to list all branches:

- `bilge.water.first`
- `bilge.water.repeat`
- `bilge.water.small_pipe`
- `bilge.pump.stuck`
- `bilge.pump.gentleness`
- `bilge.pump.work`

`observe` describes required variables and their types. `execute` requires exactly that explicit state, without missing or extra keys. The evaluator checks integer widths, signedness and branch guards. The tool verifies document hashes against `catalog.json`, verifies catalog output scopes against the validated programs, and exposes only catalog-listed retained outputs and selected text resources. It does not return guard-variable passthrough values as semantic state changes. Malformed input, an invalid model or incomplete evaluation returns no effects.

For example, the pump projection requires this complete supplied state:

```json
{"op":"execute","branch_id":"bilge.pump.work","state":{"$selected_item":-1,"$subview":1,"$camera":2,"$pump_oiled":1,"$water_drained":0}}
```

Its semantic output contains only `{"$water_drained":1}` and selected source text71. Its response retains the warning that actual native drain commitment and closeup dismissal occur at different boundaries.

`cli_validation.json` records five checks through the actual JSONL subprocess: schema observation, successful first water, wrong camera guard, Boolean supplied for an integer byte, and a missing state variable. All five passed. This tool is a branch-model interface; the preserved `../text/` runtime remains the broader 38-scene adventure, and original-game clicks belong to the separate native host.
