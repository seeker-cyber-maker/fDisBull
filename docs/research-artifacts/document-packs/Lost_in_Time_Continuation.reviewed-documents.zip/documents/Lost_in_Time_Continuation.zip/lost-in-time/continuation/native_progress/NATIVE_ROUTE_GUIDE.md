# Play the recovered bilge route through text commands

`bilge_native.py` provides a guided text interface to the **original English Lost in Time game**, running headlessly through the installed fDisBull 0.22.0 DOS backend. The game owns inventory, puzzle flags, responses and room transitions. The controller reads that state, qualifies the next supported interaction and delivers ordinary guest input.

The supported route has **35 stages: 31 clicks and 4 waits**. It goes from the hold to the lamp, enters the bilge, retrieves oil, inspects the water, oils and works the pump, retrieves the corkscrew, returns to the hold and revisits the drained bilge. Commands are limited to the next stage of this recorded route. This is a bounded native controller, not a whole-game interpreter or an unrestricted natural-language adventure engine.

## Evidence status

At the time this guide was prepared:

- `session02/bootstrap-receipt.json` records a successful fresh boot and a passing database integrity check.
- `qualified_reference/calibration.json` contains before/after captures for all 35 stages. Its scope explicitly requires a separate strict replay.
- `qualified_reference/qualification.json` records `mode: "ordinary-input-calibration"` and completion of 35/35 stages. Its passing status is **calibration evidence**.
- `replay01/qualification.json` separately records `mode: "strict-scene-replay"`, `status: "passed"` and **35/35 completed stages**. It records 30 guarded scene clicks and one direct response-acknowledgement gesture; the route also retains its four waits. The stale-context rejection check passed, and the final observation is complete and ready.

The strict replay's final native observation is `EMAM1018`, camera 0, empty hands, oil consumed, pump oiled, water drained, corkscrew owned/taken and bilge visit count 2. These claims belong to that specific retained replay, not to every future run.

For any later run, read its own `qualification.json`: require `status: "passed"`, `completed_stages: 35`, `expected_stages: 35`, a complete/ready final observation and passing recorded checks. An output directory or a sequence of accepted inputs alone does not establish completion.

## Current environment and paths

These commands use the installed 0.22 Python environment and the 0.22 offline backend. The backend wrapper loads its bundled private libraries; no separate library-path setup is needed for these examples.

```bash
LIT_WORK=[private-local-path]
LIT_CONT="$LIT_WORK/continuation_work/lost-in-time/continuation"
LIT_PY="$LIT_WORK/tools/fdisbull-022-venv/bin/python"
LIT_DOSBOX="$LIT_WORK/tools/fdisbull-0.22.0-linux-x86_64-offline/bin/dosbox"

"$LIT_PY" -c 'import fdisbull; print(fdisbull.__version__)'
```

The version check should print `0.22.0`. Set `LIT_WORK` to the actual workspace root if the files have moved. Native checkpoints retain mount identity; changing this variable does not relocate an existing checkpoint.

The controller validates these supplied English game identities:

| File | SHA-256 |
|---|---|
| `lost.exe` | `691eaa1541ac7e61dedad32f6b0e4e5c41c2f0b6248702870c2b9f30b80cf47e` |
| `intro.stk` | `30e3a2a7d30cb86c5fd0f9e4ae323af55b52057262b2ebbb59a94ba54a499eda` |

The exact source members, script offsets and geometry are documented in `../bilge_source/SOURCE_REPORT.md` and `../bilge_source/bilge_interface_evidence.json`.

## Start from a fresh boot

`fresh_boot.py` imports the executable into a new project, makes a private game copy, starts a new DOS process and follows the observed title/opening inputs. It verifies quiet-hold pixels and native fields before saving the starting checkpoint. It does not restore an old checkpoint to manufacture a fresh start.

Choose a **new output directory**; the bootstrap refuses an existing output directory.

```bash
"$LIT_PY" "$LIT_CONT/native_progress/fresh_boot.py" \
  --game-dir "$LIT_CONT/runtime/game" \
  --backend "$LIT_DOSBOX" \
  --output "$LIT_CONT/native_progress/my_boot"
```

The resulting `my_boot/bootstrap-receipt.json` records the project path, private mount path, backend and checkpoint artifact. The directory also contains `original-session.fdb`, `game/`, `fresh-hold-ready.png` and the exported native checkpoint. The project database is still needed to resolve checkpoint artifact IDs.

Use this receipt as `--bootstrap` in the commands below to run from the newly created start. The retained reference start is `session02/bootstrap-receipt.json`.

## Guided text play

Start the JSONL interface from the retained starting checkpoint:

```bash
"$LIT_PY" "$LIT_CONT/native_progress/bilge_native.py" \
  --bootstrap "$LIT_CONT/native_progress/session02/bootstrap-receipt.json" \
  --restore-mount \
  --output "$LIT_CONT/native_progress/play01"
```

`--restore-mount` explicitly restores changed files in this checkpoint's private game directory when matching saved/pristine bytes are available. It saves replaced bytes under the output directory's `previous-mount/` and records the operation in `mount-restoration.json`. The save/restore section below explains why this matters.

The process prints an initial JSON observation. Useful fields include:

| Field | What the client should do with it |
|---|---|
| `context_token` | Use this exact token for the next `execute` request. |
| `ready`, `errors` | Offer an action only when ready; display the errors when qualification fails. |
| `description` | Display the authored description for the next stage. |
| `available_commands` | Offer the supported command. This guided route normally exposes one next command. |
| `next_stage` | Stable stage ID; it is also accepted as the command. |
| `native` | Observed room, camera, selected item, inventory/puzzle flags and live hotspots. |
| `target` | Qualified live rectangle and point for the next click, when applicable. |
| `complete`, `halted` | Distinguish route completion from a stopped/incomplete attempt. |

Send one JSON object per line. A basic exchange is:

```json
{"op":"observe"}
```

Copy the token from that response into the next request. The placeholder below must be replaced; a literal placeholder is rejected.

```json
{"op":"execute","command":"turn right","context_token":"TOKEN_FROM_LATEST_OBSERVATION"}
```

A successful execution response contains a new `observation`, including the next command and context token. Continue using the returned command/token pair. The route includes commands such as `inspect barrels`, `take lamp`, `enter bilge`, `look closer`, `take oil`, `select oil`, `oil handle`, `work pump`, `take corkscrew`, `continue` and `wait`.

The same short command can occur more than once. For example, `continue` acknowledges a specific currently qualified response, and `wait` advances a particular recorded transition. Neither is a general click-through or idle loop.

### Context tokens and results

Every `execute` request requires a current context token. The token contains a new session epoch and revision. The revision advances for a qualified execution attempt, including one that later ends incomplete, and for saving. A restore creates a new epoch and resolves the VM binding again. Read-only `observe` does not advance the guest.

- A missing or stale token returns `status: "rejected"`, `input_delivered: false`, and `reason: "stale-or-missing-context"`.
- A command that is not the current stage's command or ID is rejected before input.
- A failed readiness check returns `native-context-unqualified` before input.
- An `incomplete` result may follow an already delivered click. Read its delivery field, diagnostic and receipts. The host halts instead of automatically repeating the input.

The output `receipts.jsonl` records prepared attempts and their completed/incomplete results. A queued click or accepted transport request is not itself action success.

To close the interface:

```json
{"op":"quit"}
```

## Run the complete strict route

The closed replay loop observes and validates each stage internally, supplies fresh tokens, preserves all four waits and stops on a mismatch:

```bash
"$LIT_PY" "$LIT_CONT/native_progress/bilge_native.py" \
  --bootstrap "$LIT_CONT/native_progress/session02/bootstrap-receipt.json" \
  --restore-mount \
  --replay \
  --output "$LIT_CONT/native_progress/my_replay"
```

`replay01` is the retained passing strict replay evidence directory for this continuation. Use a new output directory for another run so its receipts and backups are separate.

The controller reads the fixed calibration from **`native_progress/qualified_reference/calibration.json`**. It checks the route hash and reference image hashes. `--output` chooses the new run's evidence directory; it does not select a different calibration.

Strict replay checks native context, source/live geometry, selected item, puzzle effects and sampled reference pixels at stable boundaries. It defines guarded `fdisbull-scene-1` click actions. The repeated-water-refusal acknowledgement is retained as an observed UI gesture with state-preservation checks rather than a fabricated state transition. Waits use bounded guest execution.

The calibration file contains all 70 before/after boundary captures. Exact transient animation/registration frames are retained as evidence but are excluded from exact-timing readiness gates; the explicit following waits establish the next ready state.

### Calibration is a separate operation

`--calibrate` follows the same recorded route with ordinary inputs and captures reference frames/VM snapshots. It does not establish strict scene-replay success. For a separate calibration inspection run:

```bash
"$LIT_PY" "$LIT_CONT/native_progress/bilge_native.py" \
  --bootstrap "$LIT_CONT/native_progress/session02/bootstrap-receipt.json" \
  --restore-mount \
  --calibrate \
  --output "$LIT_CONT/native_progress/calibration_check"
```

This produces `calibration_check/calibration.json` if all stages complete. The strict runner continues to use the retained `qualified_reference/calibration.json`; generating another output does not automatically replace that reference.

## Geometry proof and coordinates

`route.json` preserves 35 original requests and their empirical before/after states. `build_route.py` verified every adjacent selected-state boundary, 23 object/navigation bindings and one inventory-slot binding. The other clicks are explicit UI gestures. All four native `run` requests remain wait stages.

Coordinates are **320×200 guest-frame pixels**. Source rectangles use `[x,y,width,height]`. A point is inside when `x <= px < x+width` and `y <= py < y+height`. fDisBull scene areas convert those dimensions to `[x,y,x+width,y+height]`.

For an object closeup:

```text
local point = recorded game point − recorded popup origin
current game point = local point + current popup origin
```

The native popup origin is read from signed 32-bit VM fields 220 and 224. The local source rectangle is checked against its source table. The active rectangle must equal the translated local rectangle, with positive dimensions and complete registration.

| Target | Recorded game point | Observed origin | Local point retained by the route | Source local XYWH |
|---|---|---|---|---|
| Lamp | `[65,96]` | `[8,52]` | `[57,44]` | `[48,29,19,32]` |
| Cask detail | `[177,96]` | `[144,56]` | `[33,40]` | `[0,19,68,44]` |
| Oil bottle | `[199,105]` | `[144,56]` | `[55,49]` | `[38,30,35,42]` |
| Pump handle | `[110,90]` | `[48,46]` | `[62,44]` | `[14,27,105,40]` |
| Corkscrew | `[197,82]` | `[112,36]` | `[85,46]` | `[79,41,14,11]` |

Inventory oil selection is separate: the controller locates the unique live item 14 slot and clicks its center. In the recorded route, slot `[152,58,18,18]` gives point `[161,67]`, or slot-local `[9,9]`.

Main rectangles can remain registered underneath a popup. Initial bilge narration also uses subview 1 without the cask-detail geometry. These cases are why geometry, context and presentation checks are combined.

### Why the four waits remain

| Wait stage | Original duration | What must settle |
|---|---:|---|
| Water response | 3,000 ms | The water-inspection animation before the displayed response. |
| Pumping | 3,000 ms | The pumping animation before its response is acknowledged. |
| Corkscrew target | 800 ms | Raw target 3 from `[191,36,0,0]` to `[191,77,14,11]`. Both animation fields were already −1 before this wait. |
| Hold transition | 1,500 ms | The newly named hold script still had the previous bilge target table before this wait. |

The original requests and offsets are retained in `route.json`; `ROUTE_FORMAT.md` describes that manifest independently of the live runner.

## Save and restore

At a qualified stable boundary, request:

```json
{"op":"save"}
```

The host writes `live-slot.json` in its output directory and stores a native checkpoint artifact in the associated project. The slot records the project, checkpoint, private game directory, backend, route cursor and route/source identities. It also points to `disk-snapshot/`, containing copies of the small mutable `.inf`, `.cfg` and `.def` files at save time.

Saving changes the context revision. Send `{"op":"observe"}` again before the next `execute`. The JSONL `save` operation itself does not accept an execution token in this implementation. Saves are refused at the four wait boundaries or when current readiness is not qualified.

Restore the slot with the same project and mount identity:

```bash
"$LIT_PY" "$LIT_CONT/native_progress/bilge_native.py" \
  --slot "$LIT_CONT/native_progress/play01/live-slot.json" \
  --restore-mount \
  --output "$LIT_CONT/native_progress/play01_restored"
```

The retained completed reference slot is `qualified_reference/completed-slot.json`. It is at route cursor 35, so restoring it observes the completed route rather than exposing earlier commands.

### Exact mount contents matter

A native checkpoint does not snapshot the mounted directory. Guest close has been observed to change `cat.inf`. The retained `qualified_reference/mount-restoration.json` records restoration of that file to its checkpoint hash from the pristine game copy.

`--restore-mount` reads the checkpoint's disk manifest and, for each differing manifest-listed file, looks for bytes with the exact recorded SHA-256. A slot's `disk-snapshot/` is tried first, then `runtime/game/`. Replaced files are copied to the new output's `previous-mount/` before restoration. If matching bytes are unavailable, restoration stops with an error.

Keep the original private mount path and checkpoint-owning project available. Moving a slot JSON or exported native file alone does not make the saved state portable. At a new location, create a fresh boot/project at that location instead of editing checkpoint metadata to suppress an identity mismatch.

## Explicit limits

- The public text interface supports this fixed guided route. It does not parse arbitrary verbs or permit free exploration of the whole game.
- The DOS game remains authoritative. The route cursor schedules actions; it does not grant inventory, set puzzle flags or invoke recovered script handlers directly.
- The supported game identity is the supplied English release, with the installed 0.22 backend and retained calibration. Other releases, languages, emulator versions and altered assets are unqualified.
- Popup geometry is read and translated from live state, but the presentation references and outcome templates are calibrated to this observed route and its popup placements. General relocated popups or alternative click paths have not been qualified by this package.
- Pixel predicates sample the scene and response caption while excluding cursor-sensitive regions and the dynamic hover-label band. They are calibrated readiness evidence, not OCR or whole-image semantic understanding.
- Displayed text and terminal puzzle state can occur at different times. In particular, the first water-response capture precedes the eventual `water_checked` flag write. The controller preserves the acknowledgement/wait boundaries instead of treating a displayed response as immediate final state.
- An incomplete attempt is diagnostic evidence, not an invitation to resend the same click. Resume from an explicitly chosen qualified checkpoint or investigate the observed state.
- Source recovery and the separate bounded UIL programs do not establish whole-game interpreter equivalence. The source packet, native receipts and text projections retain their own stated scopes.

Primary implementation and evidence: `bilge_native.py`, `fresh_boot.py`, `route.json`, `qualified_reference/calibration.json`, `qualified_reference/qualification.json`, `qualified_reference/mount-restoration.json`, `exploration/receipts.jsonl`, and the bilge source evidence packet. A passing strict replay must be attributed to its separate run report.
