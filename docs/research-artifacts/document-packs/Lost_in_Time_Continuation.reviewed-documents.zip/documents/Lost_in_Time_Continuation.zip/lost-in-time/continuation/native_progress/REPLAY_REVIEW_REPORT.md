# Independent review: bilge native route

## Result

The reviewed wrapper fixes the three initial execution/reporting defects and the cleanup defect identified during independent review. The new pure guard suite passes **22/22 cases** using the installed fDisBull **0.22.0** interpreter. The implementation, test program, route, source packet and saved fixtures are hash-identified in `guard_validation.json`.

This is a code and saved-data review. The reviewer did not construct a Project, open SQLite, launch/control an emulator, deliver native input or write native memory. Native calibration, strict scene replay and reopen/restore acceptance remain the coordinator's separate evidence.

## Findings addressed

| Original finding | Reviewed correction |
|---|---|
| Quiet opening animation value 0 contradicted the blanket click requirement of -1 | Stage 1 explicitly permits 0 and requires its quiet-frame reference; subsequent click stages retain the -1 gate. Scene readiness freezes the observed qualified animation value. |
| Repeated-water acknowledgement had an already-matched semantic scene outcome | Stage 17 is explicitly dispatched as an observed neutral UI gesture with preservation checks. It does not invent a changed puzzle/scene outcome. |
| Transport exceptions after possible dispatch could report input_delivered=false | Delivery is marked unknown before dispatch; a returned receipt establishes delivery, while ambiguous errors halt the route. A synthetic generic transport failure exercises this path. |
| Commit failure could skip debugger shutdown | Finally-based cleanup closes the owned debugger and exits the project even when the first commit raises. A synthetic resource-owner test verifies both calls. |
| Stable stages lacked complete pixel references | Default replay requires the separately captured, hash-checked calibration frames and rejects a missing click-readiness image. Calibration remains an explicit separate mode. |

## Guard evidence

The suite includes positive controls for six actual source/context bindings, then tests distinct refusal classes:

- Arrival narration shares camera 0 / subview 1 with cask detail but lacks its active translated target; both context and source-target gates reject the detail action.
- The observed early corkscrew rectangle is `[191,36,0,0]` despite an animation value of -1. A synthetic byte-bank fixture preserving that observed incomplete row rejects pickup.
- Draining disables water at X=1000. A separate in-memory flag mutation demonstrates that geometry rejection does not rely only on the drained flag.
- First entry requires selected lamp item 1 and raw target 11; revisit requires empty hands and raw target 21. The coincident opening coordinates do not merge these cases.
- Popup source-local geometry and live origin must agree with active registration. A coherent translated fixture passes the resolver as a positive control; stale origin or altered local width fails.
- A real inventory snapshot demonstrates that the handle rectangle can remain registered while object interaction is blocked by inventory mode.
- A real transition snapshot demonstrates that the new script name can coexist with old-room geometry. Object readiness rejects it while the explicit wait context remains supported.
- Wrong camera, active animation, pending mouse release, missing image, mismatched presentation and wrong frame dimensions reject before input.
- Missing/foreign/stale context tokens return a pre-input refusal, leave cursor/revision unchanged and make zero stub dispatch calls.

The report clearly labels recorded-data checks, synthetic in-memory mutations and synthetic I/O/fault tests. Stubbed pixel results verify gate handling, not visual classifier accuracy. All test inputs are isolated from the live game and database.

## Geometry, persistence and limits

All 23 source-linked route steps were checked against their recorded active rectangles and interior points. Runtime target resolution checks source conditions, popup-local tables, current translation, full registered rectangles and canvas bounds. Existing fDisBull restore code checks the saved artifact, executable/version/emulator profile, exact mounted path and complete mounted-file manifest. New host instances establish a new token epoch and re-resolve the VM bank.

The host remains a **fixed calibrated route**. Dynamic input-coordinate translation alone does not establish arbitrary-origin replay because pixel anchors and some outcome rectangles are tied to recorded absolute positions. The route cursor schedules commands; native fields and observed outcomes remain authoritative. Incomplete attempts halt rather than automatically replaying input.

One reporting distinction was sent to the coordinator: calibration and strict scene replay should be explicitly distinguished in `qualification.json` by mode and action counts. A completed ordinary-input calibration is not itself strict scene replay acceptance. The reviewed CLI already distinguishes the modes, and each direct neutral gesture carries an explicit qualification kind; the top-level receipt should preserve that distinction as well.

The review does not establish a successful fresh native run, automatic text recognition, durable save/reopen, arbitrary save compatibility, a general bilge controller, or whole-game parity. Those claims require their own corresponding evidence.
