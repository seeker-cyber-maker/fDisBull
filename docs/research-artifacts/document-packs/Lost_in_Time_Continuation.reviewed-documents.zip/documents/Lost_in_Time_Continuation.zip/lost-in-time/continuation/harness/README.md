# Original Lost in Time: qualified opening host

`original_host.py` runs the supplied English DOS executable through fDisBull and
exposes a JSON-lines interface. The original game owns its variables and visible
results. The host currently covers three interactions in the opening hold, an
explicit response-dismissal command, and native save/load for the qualified hold
states. It is a bounded playable investigation slice, not a complete game port.

## What works

| Command | Original result | Qualified original state |
|---|---|---|
| `inspect bucket` | “It's empty...” | Main hold view, no held item, bucket byte `0x316c == 0` |
| `inspect stool` | Opens the stool close-up | Main hold view, no held item |
| `inspect poster` | The recorded 1840/1992 response | Main hold view, no held item, poster byte `0x315d == 0` |
| `continue` or `back` | Dismisses bucket/poster text or closes the stool inset | One of those three recognized responses |

`examine` and `look at` are accepted aliases for `inspect`. Read the available
commands returned by `observe`: a response must be dismissed explicitly before
another inspection. Continuing preserves original progress. The successfully
qualified sequential route is:

```
inspect bucket
continue
inspect poster
continue
inspect stool
continue
inspect bucket
continue
```

The bucket and poster bytes remain set after this route. A second poster
inspection follows a different original branch: an exploratory run observed its
byte advance from 1 to 2 and the first-response pixel predicate fail. The host
therefore rejects that branch before sending input. Its receipt and the reason
for the restriction are in `poster-repeat-counterexample.json`. That earlier
failed run retained its field/predicate receipt but did not commit the diagnostic
screenshot IDs it returned; no claim about the exact second-response text is
made here.

Picking up items, using a held item, turning the stool over, extracting the nail,
changing camera views, moving elsewhere and completing puzzles remain outside
this host's coverage. Unrecognized commands and unqualified views are refused.
The observation's `inventory: []` is accompanied by `inventory_complete: false`;
it does not assert that the original inventory is empty. No inferred inventory
or puzzle flags are committed to the game.

## Run the JSON-lines host

From the provided workspace root, using the installed fDisBull environment:

```bash
tools/fdisbull-venv/bin/python lost-in-time/continuation/harness/original_host.py
```

Send one JSON object per line. Each reply is the dispatch result directly at the
top level, as expected by installed `fdisbull_player.player.JsonLineBackend`.
Standard input EOF
closes and reaps the native process. Startup explicitly restores the selected
ready checkpoint. There are no automatic checkpoint rewinds inside actions.

Example input sequence:

```json
{"op":"observe"}
{"op":"execute","command":"inspect bucket"}
{"op":"continue"}
{"op":"execute","command":"inspect poster"}
{"op":"execute","command":"back"}
{"op":"save","slot":"progress"}
{"op":"reset"}
{"op":"load","checkpoint":"progress"}
```

`reset` is an explicit rewind to the configured ready checkpoint. `save` captures
the original emulator state; its slot file refers to the saved artifact in the
selected project database. Keep that database with its slot files. Save/load is
qualified for the main hold's quiet frame and bucket/poster text responses; use
`continue` before saving from the stool inset. Native saves do not roll back disk
files and require a compatible unchanged game directory.
Omitting the save slot or load checkpoint selects `live`. Load accepts `slot`
as an alias for the canonical `checkpoint` field.

The shared structured action form is supported:

```json
{"op":"act","action":{"context_token":"TOKEN_FROM_OBSERVE","verb":"examine","target":"bucket"}}
```

Use the token returned by the most recent observation. A stale token is refused
without advancing the guest. `execute` and `continue` also accept an optional
top-level `context_token`. The legacy `request` key is accepted as an alias for
`action`. Responses include original before/after fields, a scene receipt and
the resulting observation. `complete` describes the requested bounded operation;
`coverage.partial` remains true.

The default session database is `harness/original-session.fdb`. If a requested
project file does not exist, the host makes a SQLite backup of
`runtime/english.fdb` before using it. This preserves the source project's
historical evidence. Use one native session per game directory at a time.

```bash
tools/fdisbull-venv/bin/python lost-in-time/continuation/harness/original_host.py \
  --project /absolute/path/to/session.fdb \
  --game-dir /absolute/path/to/game \
  --backend /absolute/path/to/fdisbull-dosbox \
  --checkpoint ARTIFACT_ID \
  --save-dir /absolute/path/to/save-slots
```

## Starting from a new extraction

The supplied native ready checkpoint binds its original absolute game-directory
path and runtime identity. Copying that checkpoint into a different extraction
does not make it compatible with the new mount. The companion
`../bootstrap/cold_boot.py` starts the executable from entry in an isolated new
game directory and creates a new qualified ready checkpoint. It retains the
same-source historical screenshot artifacts by backing up the seed database.

Example, from the workspace root:

```bash
tools/fdisbull-venv/bin/python lost-in-time/continuation/bootstrap/cold_boot.py \
  --game-dir /absolute/path/to/extracted/english-game \
  --backend /absolute/path/to/fdisbull-dosbox \
  --seed-project lost-in-time/continuation/runtime/english.fdb \
  --output /absolute/path/to/new-original-session
```

Use the `project`, `game_dir` and `checkpoint` values in its
`bootstrap-receipt.json` as the corresponding host arguments. The cold-boot helper
owns its validation and receipt. The host qualification described below used the
original working directory and ready checkpoint; the independent integration
receipt at `../integration/original-jsonl-report.json` records the newly
bootstrapped mount. The three-action scene is qualified only
for the supplied English executable hash, not the other supplied release.

## Evidence and addresses

`opening.scene.template.json` is a genuine `fdisbull-scene-1` definition. The
registered scene and a portable fDisBull scene bundle are retained with each
qualification run. The bundle contains definitions and reference PNGs, with no
executable state. Runtime bindings must be resolved again after import/restore.

| Object | Original hotspot ID | Native half-open rectangle | Qualified click | Geometry assignment in decompressed `EMAM1017.TOT` |
|---|---:|---|---|---|
| Bucket | 11 | `[177,99,205,129]` | `(190,113)` | `0x1867` |
| Stool | 12 | `[104,93,133,123]` | `(114,106)` | `0x187a` |
| Poster | 13 | `[50,59,98,94]` | `(74,76)` | `0x1898` |

Those script offsets are source-resource byte offsets. They are distinct from
interpreter-variable offsets and physical RAM addresses. The decoded source is
in `../resources/opening-hotspots.json`; the independent native-memory mapping
is in `../state-verification/native-hotspots.json`.

The host qualifies the current interpreter variable base by reading the exact
24-byte bucket/stool/poster geometry signature at variable offset `0x4684`.
Its snapshot-specific candidate is physical `0x40294`; if that witness fails it
performs a bounded conventional-RAM scan and requires a unique signature. The
selected item at variable offset `0xf4` must be signed `-1`. Each runtime binding
uses that no-held-item witness, and action predicates additionally re-read the
exact geometry, view byte `0x347b` and subview byte `0x3434`.

The main-view conditions require view 0 and subview 0. The stool close-up is
observed as subview 2. Neutral byte names `poster_315d`, `bucket_316b` and
`bucket_316c` deliberately avoid assigning unproved whole-game meanings.

Each restore invalidates the old framebuffer and bindings. The host runs 80
guest milliseconds to obtain a fresh frame, resolves/rebinds the variable block,
and uses the current frame's mode ID for input. The old screenshot's numeric
mode ID is historical evidence only.

Cheap exact RGB predicates distinguish the recorded bucket text, poster text
and stool inset from the other captures. Calibration excludes all observed
cursor footprints. An additional quiet-text predicate gates action readiness.
The outcome predicate must be false before clicking. Scene actions deliver
actual guest input, wait within bounded guest/host budgets and accept success
only after the observed outcome matches. The bucket outcome also requires the
original byte `0x316b == 1`.

`continue/back` has an independent original-input qualification: a neutral click
at `(160,178)`, held for 80 guest ms, followed by 800 guest ms, returned all three
observed responses to the quiet main view. It checks the resulting frame,
geometry, subview and preservation of the measured original flags. That point
is a tested neutral input point, not a claimed decoded object hotspot.

## The bounded bucket UIL

`bucket-inspect.uil.json` is a genuine `fdisbull-il-1` document with role `uil`,
built from the recovered original handler at decompressed TOT range
`0x7b9..0x80b`. `build_bucket_il.py` rejects source shapes outside the extracted
subset and records exact source-resource hashes, ranges and localized text IDs.

The model requires held item `VAR32(61) == -1`. When `0x316c == 0`, it emits
original text 26, “It's empty...”, and sets `0x316b = 1`. With `0x316c != 0` and
`0x316b == 0`, it emits text 27, “Another bucket...”, and sets `0x316b = 1`.
Otherwise it emits text 26. It refuses the unresolved held-item fallback.

This UIL models the recovered branch. It contains no pending-click substitute
for an executed original action. The host runs the actual game, and qualification
compares its observed state/text with the independently evaluated source branch.
Only the text-26 branch has original visual execution coverage here. All four
no-held-item Boolean flag combinations and four held-item refusals pass the
installed fDisBull validator/evaluator in `bucket-il-validation.json`.

## Fresh verification

```bash
tools/fdisbull-venv/bin/python lost-in-time/continuation/harness/build_bucket_il.py
tools/fdisbull-venv/bin/python lost-in-time/continuation/harness/qualify_original.py
tools/fdisbull-venv/bin/python lost-in-time/continuation/harness/verify_jsonl.py
```

The qualification script also accepts `--project`, `--game-dir`, `--backend`
and `--checkpoint` for a separately prepared compatible session. It writes a
new timestamped evidence directory on each run. `original-qualification.json`
points to the latest run; the captured frames, normalized scene, scene bundle,
numbered geometry overlay and full receipts are retained in that directory.

The completed qualification has nine successful original inspections across two
native processes: the three isolated initial actions, a four-inspection
sequential route, the response used for save/load, and a fresh-process bucket
repeat. It verifies explicit continue, original flag preservation, unsupported
and stale-action refusal, second-poster refusal before input, native save/reset/
load and clean process reaping. Every tested outcome's larger comparison region
matches its independently captured reference exactly outside cursor masks:

| Initial action | Compared pixels | Differing pixels | Measured original state change |
|---|---:|---:|---|
| Bucket | 1,650 | 0 | `bucket_316b: 0 → 1` |
| Stool | 11,907 | 0 | `subview: 0 → 2` |
| Poster | 8,189 | 0 | `poster_315d: 0 → 1` |

`jsonl-qualification.json` separately records a real subprocess transport check
using the installed `JsonLineBackend`: observe → canonical structured `act` →
save → explicit reset → load → continue → unknown-operation rejection → EOF.
It checks the original bucket flag change, native slot restoration, the public
observation schema, preserved progress and exit code 0. These are bounded backend
operations; the stock Player's passive `examine` behavior does not stand for a
native click, and general Player/game coverage is not claimed. The source project and
installed fDisBull code were not modified by this harness work.
