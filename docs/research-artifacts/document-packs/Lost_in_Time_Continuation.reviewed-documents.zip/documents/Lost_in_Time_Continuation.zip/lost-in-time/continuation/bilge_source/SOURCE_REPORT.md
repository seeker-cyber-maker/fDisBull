# Lost in Time: bilge source recovery

## Result and qualification

The English `EMAM1018.TOT` bilge and shared `MENU.TOT` scripts decode successfully with the official ScummVM Tools `degob` at commit `16f178fbb0e03eb122029050dfd3189451a5c6f2`. The evidence packet contains **18 target records: 14 bilge targets and 4 hold route targets**, plus **31 source action rules**. It records geometry, selected-item conditions, puzzle flags, transitions, text IDs, and explicit media/shared-helper effects.

`bilge_interface_evidence.json` is a source evidence catalog, not an executable whole-game interpreter. `native_source_correspondence.json` separately compares 17 parent-produced VM snapshots with their native receipts. Static catalog fields for current visibility, activity, readiness, and native action verification remain `null`; a historical observation does not establish current readiness.

The complete hold decode remains **partial**: `degob` exits 1 on unsupported function opcode `0.4`. Six bounded hold decodes succeed: routines 147, 1965, 2310, 2758, 3871, and 6231. The report does not promote that partial whole-script result to a complete hold recovery.

## Primary evidence and offsets

The extracted members come from `intro.stk`, SHA-256:

`30e3a2a7d30cb86c5fd0f9e4ae323af55b52057262b2ebbb59a94ba54a499eda`

| Member | Archive offset | Stored bytes | Decoded bytes | SHA-256 of decoded member |
|---|---:|---:|---:|---|
| EMAM1017.TOT | 4,732 | 9,739 | 18,185 | `4cc26502fb10ce5675f44b30aadde5f5ebcb1be1ad350092a5cd34fb62b12a89` |
| EMAM1017.EXT | 61,590 | 37,483 | 37,483 | `b819ae0ad13c7e1427033d7292c3e95badc063de55927ece1f2259089b462e4a` |
| EMAM1017.USA | 51,766 | 2,986 | 5,414 | `ff3ae6c9a3f11765d264c0878cdb5c6cd9cbcbbe86dec30da6fa4e18721a0bb9` |
| EMAM1018.TOT | 14,472 | 8,093 | 13,227 | `69ad91a699b4e5bcc7dd67c8fd2e4c0bbb2b805b7a37c1765855b46411aa41eb` |
| EMAM1018.EXT | 99,074 | 23,782 | 23,782 | `4f8ab455092df7b2592550b7a68049754ff28edf6de78cf40124555f13a687fd` |
| EMAM1018.USA | 54,752 | 1,286 | 2,182 | `734289cec2a41e40fb57d1a135663958934e98cb8588d2c3fb82f48a749ba168` |
| MENU.TOT | 3,431,288 | 17,834 | 41,736 | `c9674e143ec2d9a7c706b22e0cd270543ebe11acd51b0f05fbcc1491ae8498d7` |
| MENU.EXT | 3,406,410 | 24,878 | 24,878 | `daa40eb45454fa98ff7d7ddf7b08250144b9ed3815e2e20ad07c8d3b236e9458` |
| MENU.USA | 3,449,122 | 4,952 | 8,551 | `3f2667583b568e8b6ed30a6a44756786cc0fe9ec1ce216bb422c6bfebf772d4e` |
| COMMUN.EX1 | 1,844,084 | 347,077 | 347,077 | `2c395a62a34282e1bad30e15acd20f1d0fb6585d34a92f89e13d15f5e355a763` |

`source_inventory.json` also preserves directory-record offsets and compression flags. Extraction reuses `resource_tools/gob_resources.py`; it does not replace the existing archive decoder.

All instruction offsets below are decimal **degob printed operand offsets in decompressed TOT members**. Ordinary opcodes are one byte earlier; bounded AST files retain their actual opcode offsets. Function offsets identify the four-byte block header. VM offsets identify bytes in the 21,880-byte variable bank, not EXE or native process addresses. Text resource offsets identify decompressed `.USA` entries.

## Hold lamp and entry routes

The source route is:

1. Hold camera 2, raw target 12, barrels `[30,73,152,65]`. Bare hands with lamp-present byte `12643==1` select animation 1400 and open subview 6. Geometry is at operand 7182; handler routine 2310 checks the flag at 2690 and requests subview 6 at 2720/2727.
2. Subview 6 has lamp target 1, local `[48,29,19,32]`, at operand 7812. With bare hands, routine 147 prints text 58, grants/selects item 1, clears byte 12643 and closes the popup: operands 1487, 1490/1497, 1500 and 1507.
3. Hold camera 1, first-entry raw target 11, `[246,118,57,30]`, requires **selected item 1**. Routine 1965 branches on selection at 2068. Bare hands give darkness text 45 at 2080. Lamp selection sets destination `EMAM1018` at 2160 and camera 0 at 2153. Possession alone is not the native action predicate.

The first-entry target is available while `20808==0` and `20826==0`. After the bilge has been visited (`20826!=0`, still `20808==0`), geometry routine 6231 disables raw 11 at 7934 and enables **raw target 21** at the same rectangle by writing X=246 at 7942. Target 21's handler is routine 3871: it returns immediately if an item is selected (3876/3888), then enters the bilge with **bare hands**. Flooded/drained state chooses animation 3100/3200; destination `EMAM1018` is written at 3996.

The parent native receipts corroborate first entry with lamp selected, later re-entry with raw 21 and bare hands, and retained puzzle state on re-entry. These observations are historical evidence, not permission to skip current-state checks.

## Bilge target geometry

Rectangles use `x,y,width,height` on the 320×200 game canvas. Native right/bottom bounds are `x+width−1,y+height−1`. Active target fields are four signed 16-bit words starting at `17964 + raw_id*8`.

| Stable ID suffix after `bilge.` | Raw ID | Camera | Local subview | XYWH | Assignment operand |
|---|---:|---:|---:|---|---:|
| camera0.barrel | 11 | 0 | — | `[108,99,48,34]` | 3443 |
| camera0.cask | 12 | 0 | — | `[175,80,86,50]` | 3461 |
| camera1.water | 11 | 1 | — | `[8,120,261,30]` | 3783 |
| camera1.chain | 12 | 1 | — | `[163,48,42,80]` | 3827 |
| camera1.to_hold | 20 | 1 | — | `[265,0,33,107]` | 3981 |
| camera2.water | 11 | 2 | — | `[62,117,246,32]` | 4089 |
| camera2.pump | 12 | 2 | — | `[98,73,41,44]` | 4133 |
| camera2.to_hold | 20 | 2 | — | `[16,0,41,118]` | 4285 |
| camera0.cask_detail | 1 | 0 | 1 | `[0,19,68,44]` local | 3665 |
| camera0.oil_bottle | 1 | 0 | 2 | `[38,30,35,42]` local | 3726 |
| camera1.corkscrew | 3 | 1 | 3 | `[79,41,14,11]` local | 4031 |
| camera2.pump_handle | 1 | 2 | 1 | `[14,27,105,40]` local | 4322 |
| navigation.left | 28 | any | — | `[0,0,40,200]` | MENU 35948 |
| navigation.right | 29 | any | — | `[279,0,40,200]` | MENU 35967 |

Water rectangles are active only while `12659==0`; the else branches place X at 1000 (3807/4113). Cask detail is populated only while `12658==1` (3653). Corkscrew local geometry is populated when `12659==1` (4019); normal access additionally requires `12662==0` in the chain handler.

Popup local geometry begins at `18204 + subview*88 + raw_id*8`. In MENU mode 2, routine 33901 copies local X/Y plus current `i32[220]`/`i32[224]` into active target fields at 34862/34899. Width and height copy at 34936/34969. The parent snapshots show these specific matching transforms:

| Popup | Observed origin | Observed active object XYWH |
|---|---|---|
| Lamp | `[8,52]` | `[56,81,19,32]` |
| Cask detail | `[144,56]` | `[144,75,68,44]` |
| Oil bottle | `[144,56]` | `[182,86,35,42]` |
| Pump handle | `[48,46]` | `[62,73,105,40]` |
| Corkscrew | `[112,36]` | `[191,77,14,11]` |

These origins belong to observed states. The harness should read them again when acting. Main target rectangles remain registered beneath some popups, so rectangle presence alone does not prove the intended object receives the click.

## Source-backed puzzle sequence

| Action | Required source state | Salient effect and source offsets |
|---|---|---|
| Inspect barrel | Camera 0, raw 11, selected −1 | Rum description, text 28 at 646. Corkscrew item 10 gives text 51 at 657. |
| Open cask | Camera 0, raw 12, selected −1, bottle flag 12658=1 | Animation 300, then subview 1 at 905/912. |
| Inspect cask detail | Camera 0, subview 1, raw 1, selected −1 | Animation 400, palm-oil text 64 at 206, then subview 2 at 209/216. |
| Take oil | Camera 0, subview 2, raw 1, selected −1 | Text 31 at 454; grant/select item 14 at 457/464; bottle flag 12658=0 at 486. |
| First water inspection | Camera 1 or 2, raw 11, selected −1, 12661=0 | Animation 1500; dead-rat text 65 at 719/813; shared callbacks; 12661=1 at 728/822. |
| Repeat water inspection | Same target, 12661≠0 | Refusal text 66 at 740/834. |
| Small pipe on water | Camera 1, raw 11, selected 35 | Text 50 at 751. Camera 2 lacks this special case. |
| Open pump closeup | Camera 2, raw 12, selected −1 with 12660=0 and 12659=0, or selected oil 14 with 12659=0 | Animation 1000; subview 1. Oil on the main pump does not yet consume oil. |
| Try dry handle | Camera 2, subview 1, raw 1, selected −1, 12660=0 | Stuck response text 69 at 260. |
| Pliers or acid on handle | Same closeup, selected 33 or 11 | Gentleness refusal text 3 at 352. |
| Oil handle | Same closeup, selected 14 | Progress counter +1 at 363; oiled flag 12660=1 at 374; text 70; consume item 14 and deselect at 384/391; animation 1600. |
| Work oiled pump | Handle selected −1 with 12660≠0; main pump additionally checks 12659=0 | Text 71 at 282/1157; animation 1100; drained flag 12659=1 at 303/1178; redraw and disable water X at 333/1208. |
| Inspect drained chain | Camera 1, raw 12, selected −1, 12659≠0 and 12662=0 | Animation 600; subview 3 at 1019/1026. |
| Take corkscrew | Camera 1, subview 3, raw 3, selected −1 | Text 68; grant/select item 10 at 551/558; 12662=1 at 564; invalidate local target at 571. |
| Return to hold | Camera 1 or 2, raw 20, selected −1 | Destination `emam1017` at 1533/1764, camera 0 at 1519/1750. Drain state affects animation, not permission to leave. |

The source does not require pliers to open the cask, and the chain yields a corkscrew after pumping. A one-step “search cask → obtain oil” text action is a declared compression of three native object interactions.

Inventory grant helper MENU routine 37091 writes item record ownership field 39 to 1 at 37096 and selects the item at 37113. Removal routine 37123 writes ownership 0 at 37129 and selection −1 at 37146. The decoder's `of 60` notation is array cardinality, not a 60-byte stride. Observed ownership bytes are lamp 1→5863, oil 14→6383, corkscrew 10→6223, consistent with 40-byte records from base 5784.

## Initialization and two readiness traps

Bilge first-visit initializer 3394 writes `12659=0`, `12661=0`, `12662=0`, and `12658=1` at 3399/3406/3413/3420. MENU runs this initializer only under `652==0` and the scene visit counter equal to zero: MENU 35988/36000/36018 → 26076 → bilge dispatcher 5210. It does **not** explicitly assign oil flag 12660. Re-entry must preserve the completed puzzle flags; the parent snapshots show visit counter 20826 advancing from 1 to 2 while drained and collected flags stay 1.

**Subview 1 is ambiguous on arrival.** The first-entry hold handler requests subview 1 at 2108/2115; MENU assigns it at 34842. Room startup resets target geometry but does not clear 13364. Bilge text 26 is printed at 3391 when visit counter 20826 is zero. The parent arrival receipt has camera 0/subview 1 with only main object targets; neutral input dismisses narration and gives subview 0. The true cask closeup also has camera 0/subview 1, but its translated target 1 geometry is present. Use geometry and presentation context, not only the selector.

**An animation-complete flag does not prove a fully registered target.** In native receipt 57, chain zoom had `animation=-1`, `animation_request=-1`, and raw target 3 partially populated as `[191,36,0,0]`. After 800 ms, receipt 58 shows `[191,77,14,11]`. The harness must wait for valid positive dimensions and the complete expected translated rectangle before emitting the corkscrew click.

There is also a timing limit on text-only projection. `dirty-water-first-response-vars.bin` still has 12661=0 while the dead-rat text is displayed. The source writes that flag after MENU22 and popup close; the later refusal snapshot has 12661=1. A bounded UIL projection that emits the text and immediately sets the flag models the completed semantic branch. It does not reproduce the native callback pause at that text.

## Reproduction and checks

The official decoder was built in `tools/scummvm-tools` from the pinned commit. Configure disabled optional compression/UI libraries. The build used the checked-in source with a direct `version.cpp` compile and `make -o version.o degob`, avoiding an unrelated version-object dependency fanout. `configure.log`, `build.log`, `decode_status.json`, and `opening_bounded_decode_status.json` retain outcomes, including the initial missing sparse `sound/adpcm.o` step before the sound directory was restored.

Example decode, from this folder:

```bash
../../../../tools/scummvm-tools/degob Lost extracted/EMAM1018.TOT extracted/EMAM1018.EXT extracted/COMMUN.EX1
```

Use the executable absolute path retained in `decode_status.json` if the bundle has been moved. `build_bilge_evidence.py` rebuilds the packet; `summarize_native_correspondence.py` reads the existing parent native captures without controlling the game.

Checks performed:

- All 10 extracted member lengths and SHA-256 values match the extraction inventory.
- Seven bilge routines independently pass the existing bounded parser's command count and exact-end checks: 147, 507, 617, 846, 1317, 3394, and 3426.
- All 16 bilge/hold object rectangles agree with bounded AST literal assignments; the two navigation rectangles come from the complete MENU decode.
- All 18 static candidate points lie inside their own rectangles. Candidate points are not blanket native-click verification.
- Every cited instruction operand offset occurs in a retained decode; all target/rule IDs resolve uniquely.
- Seventeen native snapshot readbacks agree with their parent capture receipts on script, camera, subview, selected item, popup origin, animation and animation request. Per-snapshot hashes and receipt record numbers are retained separately.

Animations, rendering, sound, cursor/UI operations, shared refusal logic and timing are not silently replaced by no-ops. They remain explicit effects or limitations for the UIL and harness layers to handle.
