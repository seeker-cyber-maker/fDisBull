# Independent review: fast source recovery, proof reuse and Z acceptance

Reviewed 29 October 2026. This is a read-only review of source and existing evidence. No emulator, native input, project database or expensive test suite was used. This document defines acceptance criteria; it does not claim that the new pipeline has already passed them.

## Recommendation

For Lost in Time, recover the existing Gob bytecode and its helper calls directly into a source graph, then lower the qualified subset into the existing UIL and PR18 Z envelope. Keep unsupported operations and incomplete paths in a separate source-coverage artifact. Reuse qualification of unchanged opcode and helper semantics, and rebuild only the affected scene obligations. A full native route should not be required for a description edit or a change to an already qualified pure leaf.

Z is the Zork-like consumer. It is not a solver or another executable rule language. Source recovery supplies UDL mappings; UIL contains the executable rules; Z presents the selected state and actions. A C rendering may help human review but is not a necessary extra translation step for a game whose relevant logic is already bytecode.

The first deliverable can be useful with explicit conditional acceptance: four selected response leaves, two retained-output projections, and an honest unsupported frontier. It must not turn these into a full bilge interpreter by changing their labels.

## Reviewed versions and evidence

| Item | Reviewed identity and relevant sources |
|---|---|
| Current main | `ed89abca061964385b176537bc9fd275dd02afa5`, fDisBull 0.23.0, under `work/fdisbull-scene-fast-path` |
| Main APIs | `src/fdisbull/proofs.py`, `udl_blocks.py`, `interaction_il.py`, `il_recovery.py`, `udc.py`; repository `AGENTS.md`, `docs/AGENT_QUICKSTART.md` and bundled investigate skill |
| PR18 Z candidate | `c107d1576d46d7dc353c8043cb81be5005e8926b`, under `work/fdisbull-z-candidate`; `src/fdisbull/il_scenes.py`, `docs/Z_SCENES.md`, `docs/Z_TEXT_PROJECTION.md` |
| Existing recovery | `bilge_source/EMAM1018-sub617.ast.json`, `EMAM1018-sub147.ast.json`, `bilge_interface_evidence.json`; `bilge_text/build_bilge_il.py`, `catalog.json`, programs and `native_comparison.json` |
| Native gate lessons | `native_progress/REPLAY_REVIEW_REPORT.md`, `guard_validation.json` and saved observations referenced there |

The old `tools/fDisBull` working tree has tracked v0.21 files alongside newer untracked additions. It was not treated as the current version. PR18 is a pinned candidate; its Z adapter is not part of the reviewed published 0.23.0 main.

## What the present APIs actually establish

`proofs.check_equivalence` compares caller-supplied finite-width models. It checks assumption satisfiability before equivalence, so contradictory guards produce `vacuous`. It can report equivalence, a counterexample, unknown or solver unavailability. Its provenance field is explicitly labelled `caller_asserted_not_independently_verified`. A matching source hash in that field does not establish that either expression correctly models those bytes.

`udl_blocks.verify_block` is narrower: independently constructed source and candidate symbolic expressions for declared u16 register outputs, using supported straight-line ASM or a restricted C-like statement subset. Candidate branches, text, resources and host effects are rejected. It does not verify Gob actions, memory aliasing, helper calls, flag behavior, ABI correctness or a scene's complete event stream. The general scalar proof API can support a separate Gob front end, but calling the existing block verifier a scene verifier would overstate it.

`change_role` preserves shared IL nodes and changes the UDL/UIL role metadata. This is useful interchange, not evidence of source fidelity. Likewise, an IL evaluator test is evidence about the authored model; it does not independently validate the source lowering that produced it.

`il_recovery.load_il` source-checks evidence entries with the exact file-bound `file`, `sha256`, `range` and `bytes` fields against attached immutable project files. Other evidence remains a claim. The existing bilge builder checks its own source hashes, while its `resource` evidence is not automatically subject to that project check. The fast pipeline must say which source-binding check it performed.

The current solver returns a result record, not an independently checkable formal proof object. A proposed cache is therefore a cache of previously qualified results under a stated trust policy unless a proof-object checker is separately implemented. Digest integrity proves that the record has not changed; it does not make an incorrect mapper correct.

## What to qualify once, and what remains live

| Evidence | Safe reuse boundary | Required invalidation or fresh check |
|---|---|---|
| Pure opcode semantics | Exact decoder/engine profile, operand widths, signedness, evaluation order and arithmetic policy | Any relevant semantic implementation or profile change |
| Helper summary | Exact helper bytes and transitive callees, input contract, writes, events, blocking behavior and observation phase | Changed helper/dependency, alias or unmodelled effect; unmet assumptions |
| Source action proof | Exact source spans, path guards, output/effect scope and candidate semantic identity | Changed source, assumptions, candidate, variable interface or dependency |
| Selected text mapping | Exact resource identity, decoding policy and source-ordered selection | Changed resource, decoder, text ordering or normalization |
| Static geometry formula | Qualified table layout, coordinate transform, target ID and activation conditions | Changed code/data/profile; current values are separate inputs |
| Saved native witness | Version-bound evidence of the recorded state and transition | Cannot establish another run's current readiness or input consumption |
| Current native action | No reusable live authorization from a previous run | Fresh context token, selection/inventory, modal/loading state, registration, translated geometry, readiness and post-input outcome |

Do not cache a VM bank address, a context token, a selected item, an observed frame, or a target's current enabled state as universal semantics. Reuse the resolver and its qualified formulas, then read the relevant native values when actually dispatching input.

The bilge evidence shows why phase belongs in a helper contract. The first water description can already be visible while the checked flag remains unset. The pump's retained drained flag matches later native state, but the model's pass-through subview differs after native dismissal. Menu helpers may also emit additional text. Thus a terminal flag projection must not claim full state parity, display-stream parity, or that omitted calls are harmless animation.

The existing `native_comparison.json` records five matching state comparisons and three intentional boundary counterexamples. It explicitly declines native text comparison and restricts its observations to one recorded route. Those receipts can be reused as evidence within their scope without replaying them during each pure compilation.

## Minimum acceptance criteria for the fast pipeline

### A1. Source identity and complete accounting

Each executable recovered action must identify original file bytes, opcode offsets, decoder/profile identity and the exact source region used. Parameter-display offsets must not be substituted for opcode offsets. Every visited operation is lowered, covered by a named helper summary, or explicitly retained as unsupported/omitted. Unknown branches stay in a machine-readable frontier. An unsupported branch cannot silently become an empty action.

For a projected action, list retained outputs, pass-through/guard variables, selected text, excluded effects and the native observation phase separately. Source-file hashes and evidence-span checks are both needed; one does not replace the other.

### A2. Scoped, non-vacuous semantic comparison

For each admitted action path, compare an independently constructed source model with the candidate UIL model under explicit satisfiable guards. State the widths, signedness, initialization and alias assumptions. Guard feasibility and equivalence are separate results. Preserve unknown, unavailable and vacuous results; only the qualified subset may be advertised as accepted.

The comparison must include guard/dispatch correctness and the declared outputs. A proof of a terminal assignment alone does not show that the correct branch selected it. Finite resource-selection and ordered text checks may be separate structural checks because the current scalar proof API does not directly model text streams. Do not report those structural checks as a solver proof of complete native output.

A useful negative is one source-faithful positive plus a deliberately wrong guard, constant, output or text selection that is rejected or produces a counterexample. Comparing two expressions derived from the same already-lowered UIL is not an independent source-lowering check.

### A3. Honest composition across unsupported helpers

A helper call can be removed from executable UIL only with an explicit projection contract or a qualified summary that covers every claimed observable effect. Retained-output equality must not be expanded to all declared variables. Composition must preserve ordering around blocking text, acknowledgements and delayed writes. If that ordering is not modelled, describe the resulting program as a phase-specific projection and keep its broader continuation unknown.

### A4. Compatibility with the actual PR18 adapter

The generated scene must load in the pinned `ILSceneBackend`, not only pass an independent schema approximation. The concrete requirements are:

- Exactly `format`, `programs`, `contexts`, `objects`, `partial` at the top level. Store the source graph, proof/cache manifests and unknown frontier alongside the scene, not as extra scene keys.
- Identical typed variable declarations and defaults in every program. The six existing models have different local declarations, so the adapter must produce a consistent shared bank. Padding guard variables must not accidentally expand their proven output scope.
- At most one binding per `(verb,item)` for each object. Use existing UIL `if`/`require` composition for first/repeat and other source dispatch. The envelope does not support guarded duplicate bindings.
- Exactly one matching context for an admitted witness. Missing or overlapping contexts give incomplete observations. State which source-reachable entry witnesses are supported; schema-valid arbitrary states are not automatically reachable.
- Unsupported media/input must remain incomplete with no commit. Pure state/text execution must use the shared evaluator. `partial` must remain true for the recovered subset.
- Check that passive observations leave state unchanged; stale action tokens reject; a successful pure commit can be followed by an incomplete observation outside coverage. Check only these relevant seams rather than rerunning unrelated native routes.

Public objects expose their binding verbs without filtering each program's guards, and an action's item need only be among visible objects or inventory. A truthful package must therefore encode any stricter inventory/selection prerequisite in its own IL. Private state, evidence and hidden facts must not leak through authored descriptions or identifiers. Current save slots are in memory; do not claim service-restart persistence.

### A5. Bounded native evidence for native claims

The default decode/build/proof/Z-play path should launch zero emulators and write zero native databases. Reuse hash-bound native witnesses for already investigated boundaries. New native claims still need a targeted anchor: an unfamiliar helper phase, newly resolved input binding, or changed native engine should receive a focused observation that answers that question.

For a harness action, fresh readiness and outcome remain mandatory even when its source semantics are cached. In particular, preserve the known negative cases: first arrival is not cask detail; incomplete geometry is not ready; drained water is disabled; first and revisit entrances have different raw targets and selection; local geometry plus current origin must equal active registration; modal/loading state can retain stale rectangles. Synthetic saved-data guard checks remain labelled synthetic and do not establish native execution success.

### A6. Measured reuse and honest receipts

Report source bytes decoded, cache hits/misses/invalidations, solver calls, native launches, elapsed time and output size separately. Cold and warm runs use the same pinned inputs and declared environment. A warm run may make zero solver calls only when every used result passes its explicit cache policy. Label it reused, not freshly proved.

A useful bounded performance test is: unchanged warm build reuses results; changing one candidate invalidates that action; changing one helper invalidates its dependents; unrelated qualified actions remain reusable; changing source identity cannot hit an old result accidentally. Make no speedup claim until measured. Deterministic manifests should be comparable while timestamps/run IDs stay outside semantic identity.

## Cache contract

A reusable key must bind source identity and spans, decoder/lifter implementation and semantic profile, typed interface/defaults, assumptions, guard, claimed outputs, ordered effects and phase, transitive helper dependencies, candidate semantic digest, and proof engine/checker policy. Record solver version/options in the receipt. Keep failure/unknown entries distinct from accepted entries.

Current UDC semantic hashing drops role/evidence/ID metadata but preserves actual variable keys and defaults. A new cache should use a documented schema-aware normalizer; dropping names, output lists, guards, text contents or phase would be unsound. Evidence-only edits may permit semantic reuse while still requiring fresh source-binding validation.

`compile_dos` intentionally requalifies unchanged blocks so that an old receipt cannot silently supply a missing solver or authorize changed inputs. The new fast scene path should not quietly alter that existing default. If cached acceptance is introduced, make its policy and result status explicit and preserve a force-recheck path. Source hashes and cache integrity are prerequisites, not substitutes for source-front-end qualification.

## C decompilation compared with x86 ASM

Readable C can expose structured conditions and repeated helper operations, making manual review easier. It can also add type-reconstruction, promotion, overflow, pointer/alias and undefined-behavior obligations, while obscuring flags, segment addressing or event order. ASM preserves instruction-level facts but is usually the wrong granularity for repeatedly analysing the same bytecode interpreter.

The current `asm_to_c` uses the same bounded ASM decoder; it is a readable view, not an independent oracle. The current C and ASM lifters both cover only a small straight-line u16 register subset. Neither turns an entire Gob scene into a verified program. For this game, keep bytecode as the semantic source and inspect native interpreter code only to establish missing opcode/helper behavior. Cache those qualified semantics rather than re-decompiling the interpreter for each scene.

## Prioritized maintainers' requirements

| Priority | Concrete friction | Small useful requirement |
|---|---|---|
| P0 | Existing source proof accepts scalar caller models; existing block verifier rejects scene control/text | Define a byte-bound source-front-end seam, explicit admitted operation set, scoped result and unsupported frontier; do not silently broaden the x86 verifier's claim |
| P0 | Current APIs have no reusable qualification lookup/dependency contract | Add or specify explicit cache identity, dependency invalidation and reused-result status without weakening UDC defaults |
| P0 | Z requires a shared bank and unique verb/item binding | Provide a thin UIL composition/packaging example using PR18's actual schema; avoid a competing Z language |
| P0 | Generic evidence may remain caller-asserted | Expose whether source spans were independently checked, what assumptions remain, and which retained outputs/events were qualified |
| P1 | Each block output invokes a separate solver path; project proof calls always solve and persist | Support a bounded projectless/batch qualification workflow with compact result summaries and full private artifacts; measure before optimizing |
| P1 | Unknown source regions and partial terminal projections can disappear in a playable package | Require machine-readable coverage and phase/effect exclusions alongside the package |
| P2 | C rendering is readable but not a general source verifier | Keep optional C views tied to original bytes and scope; prioritize Gob recovery and proof reuse over a general decompiler project |

The public PR can contain these requirements, synthetic examples and sanitized performance counts. Original game code, decoded copyrighted text/assets, native states and byte-retaining projects remain outside the public repository. Actual new pipeline results and its PR diff require a later bounded review.

## Initial public draft review

Read `work/fdisbull-scene-fast-path/docs/SCENE_RECOVERY_FAST_PATH.md` and `examples/recovery/benchmark_lift_paths.py` after the initial report. The draft correctly treats a later overwrite after an opaque helper as a conditional result rather than erasing the helper from a complete model. This requires normal return to the expected continuation and data/control-flow evidence that the write determines the retained value at the declared boundary. Its Z requirements match the pinned adapter.

Two cache clarifications were requested: name the candidate semantic digest, typed interface/defaults and checker/normalization policy explicitly in the reuse key; distinguish reused solver-result qualification from a fresh solver run or an independently checkable formal proof object, preserving the current UDC recheck default. Both changes and the normal-return/overwrite-boundary clarification were subsequently inspected in the updated public requirements and are resolved. The authored microbenchmark correctly separates parsing already available C from deriving that C through the ASM path, and scopes its timing to warm bounded in-process readers. No additional test suite or native replay was requested.

## Final bounded pipeline review

**Result: acceptable for the declared source-backed conditional profile/investigator scope. No remaining blocker for that claim.** This review does not qualify a general decoder, source-to-native equivalence, native signed overflow, player-knowledge parity, current native readiness or whole-game behavior.

### Resolved findings

- `compile.py` initially skipped checking an absent declared source member. It now refuses missing members and mismatched source hashes.
- The source-input receipt initially omitted decoded text and source inventory read by the imported lowerer. It now records those identities together with parser checks, parser/lowerer sources, prior catalog and the fresh poster AST/lowerer. Prior bilge AST hashes are checked against the saved catalog, and the regenerated warm models must equal the hash-checked prior model artifacts. Fresh hashes are explicitly described as identity tracking, with trusted derived AST/text inputs remaining an assumption.
- The bilge Z context IDs reveal the oiled/stuck state. The coordinator explicitly chose a narrower investigator interface rather than adding a new privacy-preserving dispatcher in this increment. The final benchmark states that player-knowledge parity is unqualified and that private model state can be inferred from context IDs. Do not present this package as a qualified fair-play projection.
- The hold packet's state-independent puzzle-solution descriptions are now marked private analyst summaries, with separate state-qualified public-description candidates. Static geometry/labels and runtime visibility remain separate.

### Hold source extension

The selected poster, knot and post effects agree with the retained decoder output. The upper-deck rectangle correctly records a base X=1000 disabled assignment followed by X=96 under the visit condition. The added hotspot records agree with the coordinate-variable slots and raw-target dispatch: 13→2758, 14→3256, 15→3567 and 20→3769; the two uses of raw14 are distinguished by camera. Event-loop helper dependencies remain explicit, so structural dispatch agreement is not represented as verified native input delivery.

All 20 full hold rule descriptions remain source records. Three poster inspection descriptions are now linked to one separately lowered selected branch model; that does not turn their larger surrounding handlers into fully executable contracts. The official-decoder-only and incomplete bounded-parser tiers remain separate.

### Fresh poster model

`poster.py` structurally selects camera0/empty-hands in AST sub2758, checks original TOT/USA hashes and cited opcode bytes, and lowers the complete selected body: text31 at count0, text32 at count1, text33 otherwise, followed by the signed-i8 increment. Its exact modeled update is `((count + 1 + 128) % 256) - 128`. The retained interpreter source confirms signed byte reads and byte-width storage for the selected profile; the module explicitly declines to infer original DOS arithmetic from this.

The saved validation contains all 256 distinct signed inputs and the correct expected text ID/update for each. Its source code also checks wrong-camera and wrong-selected-item refusal without events or mutation. The review inspected this test logic and independently checked the saved 256-case table; it did not rerun the entire pipeline. The final Z receipt records an inspection, hides the poster at count−1, and directly attempts the removed target to confirm rejection without state change. The model explicitly distinguishes conditional handler behavior at that sentinel from source geometry's disabled target, so exhaustive typed-domain coverage does not imply 256 reachable native states.

### Final artifact and performance ceiling

The final receipt contains **51 source action descriptions, 23 targets, 12 source views, seven executable selected models linked to 11 source action IDs, five complete selected response models and two retained-output projections**. All 51 broad UDL descriptions retain their unconditional compiler coverage stop. The separate bilge and poster Z packages use the actual pinned PR18 adapter. This is partial, disconnected branch play; movement, the full puzzle and native callbacks remain outside coverage.

All eight output digests listed by the final `benchmark.json` match their files. The final follow-up checked **23 identities** in total: those outputs, the compiler/check script, source packets, derived/lowerer inputs and the candidate module; all match. The measured rebuild totals **162.736335 ms**, with **2.832463 ms** for warm bilge AST lowering, **0.810958 ms** for fresh poster AST lowering, **1.431975 ms** for role copying, **44.452295 ms** for poster counter/guard checks and **71.742955 ms** for candidate Z validation/play in a subprocess. These supersede the earlier 207.345943 ms receipt and are recorded measurements, not a reviewer rerun. Acquisition, extraction, decoding, manual interpretation, earlier branch implementation and native investigation are excluded. No cached solver implementation or cold analyst speedup was demonstrated by these numbers.

| Reviewed local artifact | SHA-256 |
|---|---|
| `fast_pipeline/compile.py` | `c0fcaceb88b64599c5d74c41a81d241bc00f26a29fd6069c3bfa2204abe3a8fb` |
| `fast_pipeline/check_z.py` | `03cef430f11068a10624b61b7dbb740e619ebeae23272aa592f9d1faf89f11e8` |
| `fast_pipeline/poster.py` | `67b256d48eace4dd5889eeb934f6caa3dd44e5d00e86972adeaa399f6e8ae8b2` |
| `fast_pipeline/poster_validation.json` | `86616bd63fdafaaea34774077293e2dea318d7e000a419f5ffef564531fd8680` |
| `fast_pipeline/benchmark.json` | `9863631c01aa3aa7f64f300a34d5ec70503fae92eaa0d1a0b3c54843af183761` |
| `native_progress/fast_source/hold_interface_evidence.json` | `a22afc999add552386922413c0b252176d18ec8dca54925dc53f097e4943735a` |

Review stopped after the identified risks were addressed. No emulator, database, broad suite or native replay was started.
