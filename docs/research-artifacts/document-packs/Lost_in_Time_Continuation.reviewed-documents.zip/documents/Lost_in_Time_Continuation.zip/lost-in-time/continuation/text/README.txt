LOST IN TIME — HEADLESS ADAPTATION BRIDGE

Purpose

This is a runnable host for the existing 38-scene, 188-action text adaptation.
The preserved state_engine.Game remains authoritative for every puzzle rule,
inventory change, flag, transition, flashback stash and undo snapshot.

The host is independent of graphics and network services. A narrator can read
an observation, resolve a player's intent privately, submit a declared action,
and narrate only the returned result. The narrator must not invent state changes.

This remains the guide-derived adaptation. Original-game click bindings and
binary evidence are a separate workstream. In particular, the original game
has already contradicted one opening description: its bucket says it is empty,
while the adaptation says the bucket contains enough water. The reference files
are preserved; discrepancies.json records this finding.

Files

  bridge.py                 Complete exact-command JSONL/terminal host.
  reference-runtime/        Safe extraction of the prior Complete ZIP.
  verify_bridge.py          Integration and behavior checks.
  validation-original.json  Fresh run of all 11 original validation categories.
  validation-bridge.json    Fresh bridge/format/integration results.
  build_examples.py         Reproducible exporter for a bounded poster action.
  examples/                 A stock text-slice and an executable UIL document.
  contract.json             Interface/provenance contract, not a new UIL syntax.
  discrepancies.json        Observed original-versus-adaptation differences.

Start the full headless adventure

From this directory, with any Python 3.10+:

  python3 bridge.py --repl --save-dir ./saves

Supported exact commands include look, inventory, examine <feature>, recap,
undo, an action ID such as a_find_lamp, an exact declared action phrase/alias,
and go:<scene-id>. In terminal mode, save and restore use the live checkpoint.
Resume it when starting another process:

  python3 bridge.py --repl --save-dir ./saves --resume

Natural language is the narrator's job. The runner deliberately does not guess
which rule a loose phrase means. A model can map speech to a known action ID;
Game then checks all prerequisites before committing any change.

JSON-lines interface

  python3 bridge.py --save-dir ./saves

Write one JSON object per line; read exactly one JSON response per line.
There is no TCP listener, browser, API key or model provider dependency.

Examples, in order:

  {"op":"observe"}
  {"op":"execute","command":"look behind barrel"}
  {"op":"execute","command":"inventory"}
  {"op":"save","slot":"live"}

Every observation includes context.id and context.token. For a queued model
action, pass the observed token so a stale decision cannot execute:

  {"op":"execute","command":"a_find_lamp","context_token":"<returned token>"}

The stricter fDisBull action seam always requires a current token:

  {"op":"act","action":{"verb":"perform","target":"a_find_lamp","item":null,"context_token":"<returned token>"}}

Operations

  observe
    Current scene title/static description, feature objects, exits, inventory,
    status, turn and context token. No solution route, action list, future scene
    descriptions or private prerequisite diagnostics are included.

  execute: command, optional context_token
    Exact action ID/phrase, go:<scene-id>, look, inventory, examine, recap or undo.
    A declared current-scene command/alias takes precedence over a passive
    examine/recap fallback. For example, examine sarcophagus ends the flashback
    when the preserved game's prerequisites hold; ordinary examine stool is passive.
    Context-free execute is a convenience for a single sequential client.
    Queued/concurrent model decisions should always include context_token.

  act: action
    fDisBull-style envelope. Supported verbs are perform with a canonical action
    ID and go with a visible exit:<scene-id>. A current context_token is required.
    This is not an inferred generic <verb,item,target> mapping for all puzzles.

  catalogue: optional include_hints Boolean, default false
    PRIVATE current-scene/inherited/portable rules for intent resolution.
    It includes puzzle solutions. Do not narrate its contents or turn the action
    list into unsolicited choices. Hints are excluded unless explicitly asked.

  hint: action_id
    Explicit three-level hint progression. It records the requested level and
    does not advance the game's turn counter. It never runs automatically.

  state
    Full portable state, including undo and flashback stash. Treat as private
    resolver/save data, not narration.

  restore_state: state
    Validate and restore a complete portable state atomically. Missing/null,
    foreign-game or invalid state is rejected before changing current state.

  save: optional slot (default live)
  load: optional checkpoint (default live)
    Atomic, bounded JSON files in the configured save directory. Checkpoints
    bind to the exact canonical world data hash. Slot names contain only letters,
    digits, underscore or hyphen, at most 64 characters. A successful load changes
    the context token, invalidating decisions based on the previous observation.

Checkpoint states contain spoilers. Do not read their JSON aloud during voice
play. A save operation is explicit; JSONL mode does not silently save each action.
The fDisBull LiveSession wrapper can supply automatic turn checkpoints if desired.

Narrator contract

  1. Present only current observations and confirmed outcomes.
  2. Let the user choose actions. Do not solve or perform puzzles for them.
  3. Use the private catalogue only to map intent to a declared command.
  4. Pass the current context token when acting; re-observe after a rejection.
  5. Describe an item/flag/scene change only after a successful response.
  6. Ask for clarification when intent is ambiguous. Give hints only on request.
  7. Save explicitly before stopping; restore the same world-bound checkpoint.

Scene descriptions are the previous agent's static templates. They can mention
an object that has since changed. The narrator should adjust wording from actual
successful outcomes, without changing the template or fabricating a transition.
This host does not claim image-grounded visibility or original-game parity.

Relationship to fDisBull

The backend implements observe/act/save/load, the same seam used by the installed
fdisbull_player.JsonLineBackend. Fresh tests connect a separate bridge process
to that class, use the stock Player for look/inventory/examine/guarded travel,
and use LiveSession for a checkpointed turn.

The stock Player's generic verb parser is not the complete adventure interface.
The full 188-action model is driven by this host's execute or perform operations.
No fDisBull installation files were changed.

Why the whole game is not labelled fdisbull-text-slice-1

The installed LocalRuntime only accepts conjunctions of equality/carrying guards
and literal set/add/carry/drop/context effects. The existing adaptation requires
an OR condition for the two hose states, inventory snapshot/restore at flashback
boundaries, and undo. A direct whole-game export would otherwise lose behavior.
The bridge therefore retains the working original state runner rather than
silently removing these rules or claiming a false native conversion.

The two examples are intentionally smaller:

  examples/poster-action.text-slice.json
    Valid stock fdisbull-text-slice-1. Starts just before washing the poster,
    with a wet sponge already held. One action reveals a wooden knot.

  examples/poster-action.uil.json
    Valid fdisbull-il-1, role=uil. Typed Boolean state and require/set/text blocks
    express the same guard and outcome. The evidence names the exact adaptation
    file, action and digest; it claims no DOS-script or runtime provenance.

Run the stock player sample with the installed environment:

  [private-local-path] \
    --package examples/poster-action.text-slice.json --save-dir ./example-saves

Then: use wet sponge on poster

The example is not a fresh start of Lost in Time and is not a complete game.

UIL / UDL boundary for continued recovery

Use fDisBull's existing fdisbull-il-1 syntax for typed primitive blocks. UIL and
UDL are roles on that same syntax, not two incompatible JSON languages. A block's
evidence must say whether it came from the adaptation, decoded original scripts,
or a demonstrated original-game interaction.

An abstract adaptation location such as a_hold can merge several original camera
views. Its feature IDs are semantic names, not already verified engine object IDs.
Do not attach a click coordinate directly to a whole text location without the
original view identity and a qualified screenshot/state.

The intended link is:
  semantic action -> source-backed rules/blocks -> qualified host interaction

Text mode evaluates rules and emits narration. Harness mode must separately
validate the original view/object binding, issue the click, and observe its result.
The installed IL click instruction returns a pending host event; it does not
prove a click happened. Its proposed state must not be treated as committed
original-game progress until the host verifies the action.

Verification

The original validator freshly passed all 11 categories, including alternate
orders, portable recipes, blocked-action atomicity, save validation and undo.

Run the new independent-boundary checks using the installed fDisBull environment:

  [private-local-path] verify_bridge.py

All 8 categories passed. The route check compares each of the 265 command results
and entire saved states against a separate instance of the preserved runner.
Other checks cover stale context, public/private separation, explicit hints,
checkpoint corruption, process restart, real Player/LiveSession integration,
and both stock example formats. A focused regression covers both declared
sarcophagus phrases (also uppercase), verifying that they restore inventory and
return to c_middeck rather than being intercepted as passive reads. The source
catalogue was scanned for every command overlapping the bridge's read helpers.
These tests exercise the declared adaptation;
they do not execute the original DOS game or launch an actual ChatGPT Live call.
