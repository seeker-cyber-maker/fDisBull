CURRENT CONTINUATION
====================

Start with README.md for the complete text game, preserved fDisBull 0.22
runtime, source-backed bilge/hold models, fast Z/UDL/UIL pipeline and native route.
Read fast_pipeline/README.md for the new poster slice and pinned Z candidate.
The earlier recovered README is retained in history/Recovered_README.txt.
