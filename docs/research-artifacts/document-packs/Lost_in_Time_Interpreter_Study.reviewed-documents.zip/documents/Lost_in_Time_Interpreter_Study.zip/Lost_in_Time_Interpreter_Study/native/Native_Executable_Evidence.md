# Original LOST.EXE: native-format and interpreter evidence

## Conclusion

The original game executable is a 16-bit DOS MZ program packed with **LZEXE 0.91**. Static unpacking exposes an explicit **Borland C++ runtime copyright string**, plus direct references to `intro.stk`, `intro.tot`, `.TOT`, and `.EXT`.

This is strong evidence of a Borland C/C++ toolchain in the original native engine. It does **not** establish that every source module was C++, identify the exact compiler release, or exclude hand-written assembly routines. Native x86 instructions alone do not distinguish compiler output from hand-written assembly. The native executable is compatible with an engine/interpreter architecture; proving the game-script instruction set and control flow is better supported by the extracted TOT programs and the corresponding engine implementation than by filename strings alone.

No original game code was executed during this investigation. No emulator or fDisBull installation was used.

## Identity and executable structure

The source was `interpreter-study/game-data/LOST.EXE`, restored from the previously built compact ISO. Previous work preserved this executable unchanged; its SHA-256 was checked once against the prior receipt and matched:

`fc5e3745e4b5ee56e88682d8843295df926701fd8abd36feab16ff35a05332d7`

| Property | Packed original | Statically unpacked derivative |
|---|---:|---:|
| File size | 101,532 bytes | 186,998 bytes |
| MZ header size | 32 bytes | 8,704 bytes |
| Entry CS:IP, relative to load module | `181F:000E` | `0000:0000` |
| Entry file offset | `0x1821E` | `0x2200` |
| DOS relocation records | 0 in outer header | 2,115 reconstructed |
| Extra data after MZ-declared image | None | None |

The packed header contains the literal `LZ91` at file offset `0x1C`. The system `file` utility identified LZEXE v0.91, and the established UNLZEXE utility independently recognized the known decompressor code signature before unpacking. The unpacked header's declared image size matches the output size, and all reconstructed relocation words lie within its load image. These are structural checks, not a claim that the reconstructed MZ header is byte-identical to the publisher's executable before packing.

The packed entry point is the decompressor, not the game interpreter's dispatch routine. Inspecting that stub and finding assembly instructions would not answer how the game logic was authored. LZEXE's author explains that its compact decompressor runs after DOS loads the packed program, then launches the decompressed program. [1]

## What static unpacking revealed

The derivative `UNPACKED.EXE` has SHA-256:

`8abc7c6c5680d1c9bc625df7b254bfa0a1d17161eabf8601a09f3a4ee0a07dd7`

These offsets are **file offsets in the unpacked derivative**, not offsets in the packed original and not runtime addresses:

| Offset | Visible string | Evidential value |
|---|---|---|
| `0x2C2D4` | `Borland C++ - Copyright 1991 Borland Intl.` | Explicit Borland runtime/toolchain evidence; copyright year is not an exact compiler-version identifier |
| `0x2C2FF` | `Divide error` | Runtime diagnostic, consistent with a linked runtime library |
| `0x2C3B0` | `intro.stk` | Direct reference to the starting resource archive |
| `0x2C3E4` | `.tot` | TOT resource naming |
| `0x2C3E9` | `intro.tot` | Explicit starting program/resource name |
| `0x2C42F` | `.TOT` | TOT resource naming |
| `0x2C434` | `.EXT` | Related external resource naming |
| `0x2C8CC` | `.ITK` | Resource-container naming |
| `0x2D24C` | `.STK` | Resource-container naming |

The original entry sequence sets up DOS memory, segment registers, the stack, environment data, and runtime initialization before calling application code. This supports the runtime-library interpretation of the compiler string. `entrypoint-disassembly.txt` records the first 512 bytes of the unpacked load module.

## Bounded native cross-reference to intro.tot

The initial data segment is load-module-relative `0x2A0D`; `intro.tot` is at offset `0x0119` within that data segment. At unpacked **load-image offset `0x4CA7`**, code pushes DS and `0x0119`, supplies a local filename buffer, and calls a string-handling helper. Subsequent code passes that filename to a helper at `1FFA:02D2`, then passes `0x2C` and later a length of four to other helpers. It subsequently multiplies a returned value by four before allocation and initialization.

This is consistent with opening a TOT resource and reading a four-byte header field at `0x2C`, such as a variable count. That precise helper interpretation is an **inference** here: the helper bodies were not exhaustively named or traced. `intro-tot-reference-disassembly.txt` preserves the bounded instruction excerpt. It establishes that the filename is used by code rather than merely being an unused string; it does not by itself identify an opcode-dispatch loop.

The parallel resource/source investigation independently confirmed that the TOT header field at decimal 44 (`0x2C`) is the variable count and that storage allocation uses four bytes per variable. In the actual Italian `INTRO.TOT`, those bytes are `5e 15 00 00`: 5,470 slots, or 21,880 bytes. This agrees closely with the native instruction sequence above, while the qualification about unlabelled helper bodies remains.

An exact native interpreter dispatch address was not established in this bounded inspection. Pursuing one requires further function analysis and comparison with known TOT opcode handlers. It is unnecessary to infer original source language from assembly syntax, and filename references should not be presented as sole proof that all game logic is interpreted.

## Reproduction and provenance

`PACKED.EXE` is a preserved copy of the original; `UNPACKED.EXE` is a separate analysis derivative. The game-data copy was not modified. UNLZEXE is the historical unpacker, here using lpproj's small C99/modern-platform port (`0.8p1`, self-dated 2020-03-26), which retains the earlier UNLZEXE authorship/version history. [2]

The upstream source was retrieved through the web tool as rendered source lines 63–685 because raw executor network access was unavailable. Page extraction normalized indentation; no source statements were intentionally changed. Source, source hash, compile command, and provenance are preserved in `unpack-source/unlzexe.c` and `unpack-provenance.json`.

The utility was compiled with `cc -O2 -Wall -Wextra -std=c99` and invoked with explicit, separate input/output filenames: `unpack-source/unlzexe PACKED.EXE UNPACKED.EXE`. Only this unpacking utility ran, not either DOS executable.

Supporting machine-readable files: `native-inventory.json`, `unpacked-inventory.json`, `visible-strings.json`, and `unpacked-strings.json`.

## Sources

1. Fabrice Bellard, original LZEXE author, **LZEXE home page**: https://bellard.org/lzexe/ . Explains executable packing, the built-in decompressor, and versions 0.90/0.91. Retrieved 29 October 2026.
2. lpproj, **UNLZEXE 0.8p1 source**, modern-platform port of the historical unpacker: https://gist.github.com/lpproj/09ea43ecf64a77b3b81f1877103e1b37 . Its source contains the LZEXE 0.90/0.91 decompressor signatures, relocation reconstruction and static unpacking algorithm. Retrieved 29 October 2026.
