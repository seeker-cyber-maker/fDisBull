# Lost in Time: interpreter and script-format evidence

## Result and limits

Lost in Time has a bytecode interpreter. Its game data contains `.TOT` programs, with callable blocks, assignments, expressions, conditions, loops, hotspots, resource operations and movie calls. The DOS executable supplies the native runtime and device/media services. Disassembling the executable alone would miss substantial game logic stored in the archives.

The pinned ScummVM implementation selects **`Inter_v3` for Lost in Time**, including the supplied multilingual DOS CD family. It inherits function and drawing operations from `Inter_v2` and `Inter_v1`. This is the name of ScummVM's compatible interpreter implementation; it is not a recovered class name from the original executable. ScummVM's C++ implementation does not establish which language the original developers used for the DOS runtime. A native executable can contain both compiler output and hand-written assembly while executing an external script language.

All source line references below refer to ScummVM commit **`984277131e510e554a669e865828efb953c03941`**. The exact files and official URLs are recorded in `source_manifest.json`; selected source files are included under `source/` with their original license headers. This report documents format and execution architecture. It is not a full game-playthrough qualification or a claim that every bytecode operation has been independently implemented.

## 1. Exact CD-to-interpreter selection

The supplied `INTRO.STK` is **4,831,170 bytes**. Its MD5 over the first **5,000 bytes** is `6263d09e996c1b4e84ef2d650b820e57`. Both values match the official Italian DOS `CD v1.00` descriptor. The same descriptor signature is listed for six languages: English US, French, Italian, German, Spanish and English GB. Consequently the signature identifies this multilingual CD family; it does not uniquely identify the selected language.

The complete selection chain is:

| Step | Exact evidence |
| --- | --- |
| Detection hash convention | `engines/advancedDetector.cpp:984–1002`, default `_md5Bytes = 5000`; use at `558–566`. Gob's detector constructor does not override it (`detection/detection.cpp:87–91`). |
| CD descriptor | `engines/gob/detection/tables_lit.h:116–128`: `lit`, `CD v1.00`, the matching hash/size, `IT_ITA`, DOS, CD flags. Other language rows use the same hash and size. |
| Game ID | `gameidtotype.h:40–57`: `lit`, `lit1`, `lit2` all map to `kGameTypeLostInTime`. |
| Instance setup | `metaengine.cpp:146–163`: default `intro.tot` / `intro.stk`, game type from ID, then features, language and platform. |
| Interpreter | `gob.cpp:623–633`: `Init_v3`, `Video_v2`, **`Inter_v3`**, `Mult_v2`, `Draw_v2`, `Map_v2`, `Goblin_v3`, `Scenery_v2`, `SaveLoad_v3` with Lost screenshot mode. `Game` is shared and constructed at `gob.cpp:501`. |
| Inheritance | `inter_v3.cpp:49–73`, `inter_v2.cpp:61–141`, `inter_v1.cpp:58–169`. `Inter_v4` is selected for Woodruff at `gob.cpp:635–642`, not for this CD. |

Actual signature evidence is saved in `italian_cd_detection_evidence.json`.

Primary links: [CD detection](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/detection/tables_lit.h#L116-L128), [game ID map](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/gameidtotype.h#L40-L57), [engine selection](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/gob.cpp#L623-L642).

## 2. What the supplied CD bytes establish

The current archive inventory is `../resources/resource-inventory.json`. It reads and extracts the actual current CD, rather than assuming that the older English release has identical offsets.

- `INTRO.STK` has **522 members**, including **61 TOT**, **57 EXT**, and **61 Italian ITA** members. It also contains 61 French DAT, 61 German ALL, and 60 each of USA, ANG and ESP text members.
- All **61 TOT headers report format `1.3`**. The header string `1.3` and the interpreter class suffix `v3` are different concepts; the engine selection is established by the descriptor and game ID, not by equating those numbers.
- Sixty programs declare **5,470 variable slots**, corresponding to **21,880 bytes**. `EDIT.TOT` declares 998 slots, corresponding to 3,992 bytes. These are per-program declarations; the runtime's allocation/reuse behavior is a separate matter.
- All **154 populated header function offsets** lie in their script regions, and the checked callback block spans fit. This validates those header structures, not every instruction or runtime path.
- The total region after the 128-byte headers and before the first embedded resource/text section is **459,143 bytes** across the 61 programs. This is a region size, not a claim that every byte is a reachable instruction.

Selected decompressed members:

| Member | Total bytes | Script end offset | Region after 128-byte header | Main format |
| --- | ---: | ---: | ---: | --- |
| `INTRO.TOT` | 30,311 | 3,382 | 3,254 | 1.3 |
| `EMAM1017.TOT` | 18,693 | 14,105 | 13,977 | 1.3 |
| `EMAM1018.TOT` | 13,566 | 9,756 | 9,628 | 1.3 |
| `MENU.TOT` | 41,723 | 38,835 | 38,707 | 1.3 |
| `EDIT.TOT` | 12,061 | 10,218 | 10,090 | 1.3 |

The previous English `EMAM1017`, `EMAM1018`, and `MENU` totals were respectively 18,185, 13,227 and 41,736 bytes. Current parsing must use current member bytes and current offsets.

A compact, directly inspectable bytecode example exists in current `EMAM1017.TOT`. Its header start-function pointer targets **13241**. The block begins `01 06 4d 00`. At **13245**, the seven bytes `90 17 3b 00 15 0c 63` decode by the pinned runtime's handlers as:

```text
var32[59] = 12
```

Here `90` dispatches function `0.9` (`o2_assign`); `17 3b 00` selects the 32-bit variable at index 59, byte offset 236; `15 0c` is the signed-byte immediate 12; and `63` terminates the expression. This is a source-guided decoding of one real instruction, not recovered original variable names. It demonstrates why interpreting these bytes as x86 instructions would be the wrong abstraction for the script member.

## 3. Container, script and resource boundaries

An STK/ITK archive directory begins with a little-endian u16 member count, followed by **22-byte directory entries**: name[13], u32 stored size, u32 archive offset, u8 packing flag. Current extraction accepts the observed uncompressed/packed forms and validates each extent. See `DataIO::openArchive`, `dataio.cpp:235–320`, and the previously recovered bounded `gob_resources.py`. Archive decompression happens before TOT parsing.

TOT script offsets are relative to the **decompressed TOT member**. They are not offsets into STK, addresses in `LOST.EXE`, or addresses in the native process. Likewise, variable-bank byte offsets are neither script offsets nor native process addresses.

### TOT fixed header

All multibyte fields below are little endian. The header is **128 bytes**.

| Offset | Width | Interpretation from runtime |
| ---: | ---: | --- |
| 0–38 | 39 | Preserved header material; do not invent meanings for fields the reader does not consume. |
| 39 | 3 | ASCII major-dot-minor version; byte40 must be `.`. |
| 44 | 4 | Variable count. `Game::playTot` uses its low16 bits when allocating a new bank. |
| 48 | 4 | Text table offset. `0` means use a language sidecar; `FFFFFFFF` means no text table. |
| 52 | 4 | Embedded resource table offset; `0` and `FFFFFFFF` mean absent. |
| 56 | 2 | Animation/string sizing parameter `animDataSize`. |
| 59 | 1 | Shared `COMMUN.IMn` selector. This IM resource file is distinct from an IMD movie. |
| 60 | 1 | Shared `COMMUN.EXn` selector. |
| 61 | 1 | `communHandling`, used with the IM selector. |
| 100 | 28 | Fourteen u16 function offsets. Slot0 is start; slot13 is center. |

The first positive text/resource offset other than `FFFFFFFF` limits the script region; if neither is present, file size is the limit. Tables may occur in either order. The source's permissive header parser is not itself sufficient bounds validation for an extractor: reject offsets beyond file size, overlapping impossible table extents, truncated headers and invalid callback targets.

Sources: `TOTFile::load/getProperties`, `totfile.cpp:48–146`; `totfile.h:39–59`; `Script::loadTOT`, `script.cpp:378–399`; `Game::playTot`, `game.cpp:613–653`; `Inter::allocateVars`, `inter.cpp:370–374`.

Primary link: [TOT header parser](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/totfile.cpp#L77-L146).

### Resource tables and localized text

An embedded TOT resource table starts with i16 count and one opaque byte, then count×10-byte entries: i32 offset, u16 size, i16 width, i16 height. Nonnegative offsets are relative to the data area after this table. A negative offset identifies shared IM resource index `-offset-1`; that index addresses a u32 offset table in the shared IM file. See `resources.cpp:236–303,638–662,714–741`.

A sidecar EXT table has the same 3-byte/count×10-byte layout. Its offset is stored as 32 bits but interpreted as signed. Nonnegative offsets are relative to the end of the EXT table; negative values resolve to absolute shared EX offsets using `-offset-1`. Width bit 15 is the packed flag and is cleared before interpreting the remaining width/size bits. EXT resource IDs seen by script handlers are offset by **30000**. See `resources.cpp:306–339,553–563,665–711` and `resources.h:103–145`.

Do not assume the u16 EXT size is the whole length. In `getEXTResource`, width bits14,13,12 add respectively `1<<16`, `2<<16`, `4<<16` to size; if height is zero, the remaining width value also contributes `width<<16`, exactly as the implementation specifies. Packed entries are decompressed after obtaining that stored extent. The reported image width is `width & 0x0FFF`. Preserve the exact handling for the observed profile and refuse unimplemented combinations rather than guessing.

Localized text tables begin with u16 count/flags (`count & 0x3FFF`), then four-byte offset/size pairs. Offsets are relative to the text blob. `FFFF` offset or zero size represents absence. Italian resolves to `.ITA`; other languages use `.DAT`, `.ALL`, `.ESP`, `.USA`, `.ANG` and others. Text items may contain positioning/formatting commands as well as characters, so treating the entire blob as a plain C-string file loses structure. See `resources.cpp:345–387,455–550,576–596` and `resources.h:157–169`.

Primary link: [resource loader](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/resources.cpp#L236-L387).

## 4. Interpreter loop and bytecode encoding

`Game::playTot` loads the program/resources, sets animation sizing and runtime variables, seeks the start-function offset, then calls `Inter::callSub(2)` (`game.cpp:613–653`). `Script::call/push/pop` saves and restores script pointers and finished state (`script.cpp:453–489`). These are explicit program-counter/call-stack operations over TOT bytes.

`Inter::callSub` reads the next block type:

- Type **1**: `funcBlock`, a command block.
- Type **2**: hotspot evaluation, which reads an event/input block and invokes attached actions.
- Other values: unsupported block error.

A normal type1 block starts with `01`, u8 command count, then u16 span. `funcBlock` skips the span while executing; nested-control handlers use **block start + span + 2** as the block end. Therefore a bounded structural parser should check both declared span and command decoding, rather than assuming fixed-width instructions. `o1_setcmdCount` can update the remaining command-loop count (`inter_v1.cpp:1463–1465`).

Function opcode bytes are remapped before dispatch:

```text
h = raw >> 4
if h < 12:
    family = 0
    number = h
else:
    family = 16 - h
    number = raw & 15
dispatch_index = 16 * family + number
```

Thus raw `90` maps to function index09; raw `FE` maps to1E; raw `E5` maps to25; raw `D2` maps to32. Low nibbles of raw values belowC0 are ignored by this dispatch step. A disassembler must distinguish a **dispatch index** from the **encoded opcode byte**.

Sources: `Inter::funcBlock`, `inter.cpp:232–346`, particularly315–327; `Inter::callSub`, `348–367`; opcode execution tables at `72–117`.

The static registration map in `lost_opcode_map.json` contains **61 function handlers, 49 drawing/service handlers and 5 Gob handlers** for this pinned `Inter_v3` configuration, plus the full 256-byte raw-function mapping. These counts describe registered handlers, not how many operations the supplied game actually uses.

| Encoded form | Dispatch / meaning | Operand shape useful for a bounded reader |
| --- | --- | --- |
| `00` or `10` | Func00/01, call subroutine | u16 TOT target offset. |
| `50` | Func05, switch | Typed variable/expression cases and blocks; use v2 switch semantics. |
| `60` | Func06, repeat-until | Nested block and terminating condition; includes its own separator handling. |
| `70` | Func07, while | Boolean expression then nested block. |
| `80` | Func08, if | Boolean expression and conditional block(s); branch markers are structural. |
| `90` | Func09, v2 assignment | Variable descriptor, optional99+count, then count expressions. |
| `FE xx` | Func1E, drawing/service escape | One u8 secondary opcode, then that handler's operands. |
| `E0` | Func20, return | No expression operands. |
| `E5` | Func25, Gob operation | i16 command, i16 declared parameter count, then command-specific payload. |
| `FE 40` | Draw40, `totSub` | Length/flags byte, literal name or string expression, then flags byte. |
| `FE 41` | Draw41, `switchTotSub` | Two i16 operands. |
| `FE 83` | Draw83, `playImd` | String expression followed by eight numeric expressions. |
| `FE 84` | Draw84, `getImdInfo` | String expression plus five destination variable descriptors. |
| `FE 85` | Draw85, open ITK | String expression; append `.ITK` if no dot. |
| `FE 86` | Draw86, close ITK | No expression operands. |

The v3 function table replaces only speaker-on22, speaker-off23 and copy-sprite32 after inheriting v2. The v3 Gob table is **0,1,2,10,100**; it is not the entire v2 Gob table. In particular Gob100 is `o3_wobble` and consumes no additional script operand after cmd/count. Source: `inter_v3.cpp:49–73,111–113`; `inter_v2.cpp:1427–1439`.

Function0.4 is not registered in these tables. Encountering a raw4x byte at an alleged opcode boundary is a reason to investigate alignment, reachability or a decoder limitation, not to invent a new opcode meaning. This matters for the previous `degob` failure in `EMAM1017`.

Primary links: [dispatch loop](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/inter.cpp#L232-L374), [v2 registrations](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/inter_v2.cpp#L64-L141), [v3 overrides](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/inter_v3.cpp#L49-L73).

### Expressions and variables

Expressions are typed token streams, ordinarily terminated by byte99 (`63`hex). Array/string indexing uses terminator12, and parenthesized/function expressions use end-expression10. Looking for a raw63 byte without parsing token payloads is unsafe: a literal or string may contain the same byte.

| Token, decimal / hex | Payload / purpose |
| --- | --- |
| 17 /11 | u16 index of a 16-bit variable, scaled×2. |
| 18 /12 | u16 index of an 8-bit variable, scaled×1. |
| 19 /13 | i32 immediate. |
| 20 /14 | i16 immediate. |
| 21 /15 | i8 immediate. |
| 22 /16 | NUL-terminated immediate string. |
| 23 /17 | u16 32-bit-variable index, scaled×4. |
| 24 /18 | u16 index scaled×4, with a 16-bit access. |
| 25 /19 | u16 string-variable index scaled×4; optional character-index expression. |
| 16,26,27,28 /10,1A,1B,1C | Typed array descriptors: base, dimension count, dimensions, index expressions. |
| 29 /1D | Function selector then nested expression: square-root variants, square, absolute, random. |
| 1–11 | Unary negation, arithmetic, bitwise operators, grouping, logical not. |
| 30–37 /1E–25 | Logical OR/AND and comparisons. |

Source: `expression.h:37–121`; `Expression::parseVarIndex`, `expression.cpp:619–691`; `loadValue`, `699–834`; `parseExpr`, `1056` onward; `Script::evalExpr/evalBool/evalString`, `script.cpp:293–343`. There are also base-adjustment tokens14/15 and a97 separator handled at `expression.cpp:549–616`; a bounded reader may explicitly refuse them until implemented. The known TRUE/FALSE values are evaluator result types and overlap numeric token IDs; do not treat them as globally unique bytecode opcodes.

Type2 hotspot blocks have their own schema: after block type and u8 count, six configuration bytes precede the entries. Entry type flags can select an extra window byte or coordinate expressions instead of four immediate u16 coordinates. The remainder varies by entry type and includes action blocks/input information. See `Hotspots::evaluate`, `hotspots.cpp:1653–1710`, and `evaluateNew`, `1322–1619`. Do not parse a type2 block using the type1 four-byte header rule.

## 5. Consequence for valid video shortening

Movies are resources called by script operations. They are not the bytecode interpreter itself. At `Inter_v2::o2_playImd` (`inter_v2.cpp:951–998`), the program supplies:

```text
name, x, y, startFrame, lastFrame, breakKey, flags, paletteStart, paletteEnd
```

The name is a string expression; the remaining eight values are numeric expressions. A nonempty name opens a movie, while an empty name can refer to an already-open slot. Negative start/end values have control meanings. The handler may truncate the name to eight characters and may close the video after playback. So literal filename search alone cannot recover every possible call.

`o2_getImdInfo` exposes position, frame count and dimensions to script variables. `VideoPlayer::openVideo` writes frame count to variable7, `playFrame` writes current frame to variable11, and negative lastFrame can resolve to the movie's final index. These are observable script contracts, not merely media-decoder internals. Sources: `inter_v2.cpp:1000–1015`; `videoplayer.cpp:341–346,441–446,782–783`.

For further reductions, the useful next format task is a bounded **script-to-movie call map** that records name expression, frame-range expressions, code location, reachable entry point and relevant state conditions. Mark dynamic operands unresolved until data flow or runtime observation establishes their values. This can distinguish a simple transition played end-to-end from a movie used as a numbered image/state bank. Preserve untouched assets where that contract remains unknown.

An IMD that decodes correctly may still change game behavior if frame indexes, palettes, endpoint images or seek dependencies change. The earlier hold-frame build preserved logical frame counts and independently verified first/final pixels and palettes for its 20 changed clips; that result does not prove every intermediate frame access is safe. This interpreter study explains where the additional semantic evidence must come from.

Primary link: [IMD script handlers](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/inter_v2.cpp#L951-L1029).

## 6. Web and reproducibility notes

Two independently accessible official web pages corroborate the architecture:

- [ScummVM Tools README](https://github.com/scummvm/scummvm-tools/blob/master/README), script-tools section: `degob` decompiles Coktel TOT programs and lists `Lost` as a version selection; some decoding requires EXT/shared resources.
- [ScummVM API: Gob::Inter_v3](https://doxygen.scummvm.org/db/de8/class_gob_1_1_inter__v3.html), which lists the v2/v1 inheritance and inherited control-flow, variable, resource and movie operations.

Those web pages are supporting documentation, not replacements for the exact pinned source. The web fetch service refused the pinned GitHub source pages; their official raw contents were retrieved through the managed shell network and recorded in the source manifest. The wiki's Lost in Time page returned an access-denied screen and was not used as substantive evidence.

No executable, game archive or movie was modified by this source investigation. The research folder contains reports, signature evidence, a static opcode registration map, and selected source snapshots. Game-byte inventory and broader decoder qualification are separate artifacts produced by the parent task.
