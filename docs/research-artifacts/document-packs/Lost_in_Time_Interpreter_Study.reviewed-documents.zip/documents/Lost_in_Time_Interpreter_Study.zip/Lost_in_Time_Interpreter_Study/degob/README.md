# Lost in Time: recovered script decoder and bounded wobble repair

## Result

The official ScummVM Tools `degob` was recovered from commit
`16f178fbb0e03eb122029050dfd3189451a5c6f2`, built locally, and used with its
`Lost` variant. The pristine decoder exactly reproduces all three saved English
outputs, including the previously reported failure. Fresh Italian extraction was
decoded separately; its resource sizes and instruction offsets differ from the
English release.

The earlier `No such opcodeFunc: 0.4` error is caused by a specific operand-length
bug in this pinned decoder. It is not evidence that the original game uses an
unknown native machine instruction. A separately built, narrowly qualified
decoder corrects the observed screen-wobble instruction and completes the normal
decoder traversal of all 61 Italian TOT files without diagnostics.

| Dataset | Pristine upstream traversal | Qualified traversal |
|---|---|---|
| English EMAM1018 and MENU | 2 completed | 2 completed; byte-identical outputs |
| English EMAM1017 | Refused with function opcode 0.4 | Completed |
| All 61 Italian TOT files | 58 completed, 3 refused | 61 completed |

The three affected Italian scripts are `EMAM1000.TOT`, `EMAM1017.TOT`, and
`EMAM1104.TOT`. The other **58 Italian outputs are byte-identical** between the
pristine and qualified decoders. All successful runs returned zero and had no
stderr diagnostics or invalid/unknown-operator messages in their output.

**Scope:** “Completed” means that degob's traversal starting from the TOT header
entry points and following the function references it recognizes returned
normally. It does not prove that every byte or every indirect entry point was
decoded, that the pseudocode reproduces every engine behavior, or that gameplay
has been verified. The tool outputs pseudocode and offsets, not the original
authoring-language source or original variable names. No game resource, game
executable, existing resource parser, or previous evidence file was modified.

## Exact cause of the error

The relevant byte sequence is:

```text
e5 64 00 00 00
```

`e5` is the Gob interpreter function instruction whose normalized family/index is
`2.5`, also written `0x25`. It is followed by little-endian command 100 and
parameter count zero. The interpreter reads those two 16-bit fields, then
dispatches command 100 to `Inter_v3::o3_wobble`. That handler wobbles the back
surface and reads no further script operands. The complete observed instruction
is therefore five bytes long, including the opcode.

The pinned tool's `Script_v3` function table instead describes `o2_goblinFunc`
using **five** `PARAM_UINT16` fields. It advances ten operand bytes instead of
four, swallowing six bytes of the following instruction. Parsing then continues
at a false instruction boundary and ultimately reports function opcode 0.4.

| Release | Script | Opcode offset | Correct next opcode | Upstream's incorrect next opcode |
|---|---|---:|---:|---:|
| English | EMAM1017 | 8,915 | 8,920 | 8,926 |
| Italian | EMAM1000 | 4,222 | 4,227 | 4,233 |
| Italian | EMAM1017 | 9,072 | 9,077 | 9,083 |
| Italian | EMAM1104 | 1,742 | 1,747 | 1,753 |

These are decimal offsets in the **decompressed TOT member**, not addresses in
the DOS executable or offsets in the STK archive. Degob's printed line for the
wobble instruction uses its first operand position, one byte after the opcode.
The table describes the wrong resume position; it does not claim that the later
0.4 refusal occurs at that same position.

In the English hold script, the incorrect resume point is inside the next media
instruction; the subsequent bogus output includes `repeat` and an invalid
expression operator. In the Italian hold script, the correctly aligned next
instruction queries the CD track position, followed by an `INTRO` check and a
wait for the track to finish. This is also evidence that CD playback timing can
matter independently of IMD visual frames.

## Qualification of the repair

The repair is deliberately separate from upstream:

1. `degob-upstream` and the files under `source/` retain the pinned upstream
   implementation. All 70 fetched source/license/build files were rechecked
   against both their SHA-256 values and the upstream Git blob hashes.
2. `degob-lost-qualified` refuses game variants other than `Lost`.
3. Only function `0x25` with command **100** and parameter count **zero** is
   accepted by the added handler. It reads exactly those two fields, emits
   `o3_wobble();`, and resumes at the correct byte. Every other command/count
   combination at that instruction is explicitly refused with its byte offset.
4. The table is not globally changed from five fields to two. Other Gob game
   variants and unqualified Gob command shapes are not silently accepted.

The corrected traversal encountered exactly one qualified wobble in each of the
three affected Italian scripts and one in the English hold script. No other
Gob command was encountered by these traversals. That observation is bounded to
the code paths the decoder visits; it is not a raw-byte claim about unvisited
regions.

`lost-wobble-qualified.patch` contains the exact two-file change.
`patched-source/` contains the corresponding complete changed source files,
with upstream copyright/license notices retained. This is a local experiment;
no upstream change was published.

## Reproduction

Requirements: Python 3, a C++11-capable `g++`, GNU Make, and a POSIX build
environment. The recorded build used GCC 13 on Linux. Optional audio compression,
GUI, font, and Boost dependencies are disabled. Building from the saved source
does not need network access.

From this directory:

```bash
python3 build.py
```

This configures the saved upstream tree, builds the unmodified decoder, compiles
the version object directly to avoid an unrelated upstream all-tools dependency
fanout, copies `degob-upstream`, then creates and builds the isolated qualified
version. `build-manifest.json` records the compiler, complete commands, binary
hashes, and patch hash. `rebuild.log` and `patched-build.log` retain build output.

To reconstruct the bounded upstream source subset, if needed:

```bash
python3 fetch_source.py
```

This uses the saved pinned Git tree metadata, retrieves only the selected source
and dependencies from official GitHub URLs, and verifies every Git blob hash.
The subset comprises 70 files totaling 854,067 bytes. It preserves upstream
executable file modes and licenses. The script refuses a mismatched existing
source file; it does not treat local changes as upstream.

Example Italian decode, run from this directory:

```bash
./degob-upstream Lost \
  ../resources/extracted/EMAM1018.TOT \
  ../resources/extracted/EMAM1018.EXT \
  ../resources/extracted/COMMUN.EX1 > EMAM1018.upstream.txt

./degob-upstream Lost \
  ../resources/extracted/MENU.TOT \
  ../resources/extracted/MENU.EXT \
  ../resources/extracted/COMMUN.EX1 > MENU.upstream.txt

./degob-lost-qualified Lost \
  ../resources/extracted/EMAM1017.TOT \
  ../resources/extracted/EMAM1017.EXT \
  ../resources/extracted/COMMUN.EX1 > EMAM1017.qualified.txt
```

For the retained bounded survey and identity checks:

```bash
python3 survey.py
python3 audit_results.py
```

The survey defaults to the recovered project layout: Italian members in
`../resources/extracted/` and the three earlier English examples in
`../../continuation/bilge_source/extracted/`. With those defaults it writes in
this directory, retaining the original behavior. Both input directories and the
output location can be supplied explicitly.

For a portable packaged copy, run from its `degob/` directory:

```bash
python3 survey.py \
  --english-dir ../reference-english/extracted \
  --italian-dir ../resources/extracted \
  --output-root ../verification-results
```

The requested output directory must be new; an existing path is refused. This
command writes `verification-results/decode-survey.json` and the matching
`verification-results/decodes/` tree. Recorded output paths are relative to that
results directory. It leaves the packet's saved results intact.

For exact prior-output comparison, place `EMAM1018.decoded.txt`,
`MENU.decoded.txt`, and `EMAM1017.decoded.txt` in `reference-english/`, alongside
its `extracted/` directory. The comparison follows the supplied English input
directory rather than an old absolute path. The existing input files and prior
output texts are opened for reading only.

The survey runs each decoder process with four seconds of wall time, three
seconds of CPU time, 512 MiB of address space, and 16 MiB maximum per output
file. Failures remain explicitly partial in the manifest. Missing EXT files are
recorded rather than replaced by invented data.

`audit_results.py` compares already saved outputs and identities; it does not run
the decoder again. It confirms all three prior English outputs were reproduced
exactly, the 58 unaffected Italian outputs are unchanged, the four observed
wobble byte sequences match their recorded offsets, and all upstream source
files remain pristine.

## Contents and practical use

| Item | Purpose |
|---|---|
| `decodes/italian/upstream/` | All 61 pristine decoder attempts, including partial refusals |
| `decodes/italian/lost-qualified/` | All 61 qualified traversal outputs |
| `decodes/english/` | Reproduction and repair comparison for the three earlier examples |
| `decode-survey.json` | Per-run inputs/hashes, command, outcome, diagnostics, output hash and size |
| `decoder-validation.json` | Exact output comparisons and verified wobble offsets |
| `source-manifest.json` | Pinned upstream URLs and hashes for the saved source subset |
| `upstream-tree.json`, `upstream-commit.json` | Official GitHub metadata for the pinned revision |
| `build-manifest.json` | Build commands, compiler identity, binary and patch hashes |
| `source/COPYING`, `source/COPYING.BSD2`, `source/COPYRIGHT` | Upstream licensing and attribution |

The qualified Italian traversal emits 5,305 function declarations across the
61 files and 2,193,424 bytes of pseudocode. These are **printed declarations**,
not a count of verified unique runtime functions. The detailed per-file data
remain available in the manifest.

For key examples:

| Italian member | TOT bytes | Qualified pseudocode bytes | Printed function declarations |
|---|---:|---:|---:|
| EMAM1018 | 13,566 | 48,924 | 119 |
| MENU | 41,723 | 165,939 | 220 |
| EMAM1017 | 18,693 | 71,553 | 122 |

The pseudocode exposes VM variables, conditionals, function calls, scene/media
operations, hotspot registration and script transitions. It supports analysis of
the game's interpreted logic. It does not by itself establish which language
the original engine executable was written in; native executable/compiler
evidence is handled in the separate native-code investigation.

## Primary source map

ScummVM Tools source revision:

- [Pinned repository](https://github.com/scummvm/scummvm-tools/tree/16f178fbb0e03eb122029050dfd3189451a5c6f2)
- [Lost variant selects Script_v3](https://github.com/scummvm/scummvm-tools/blob/16f178fbb0e03eb122029050dfd3189451a5c6f2/engines/gob/degob.cpp)
- [Script_v3 table: incorrect five-u16 entry at function 0x25](https://github.com/scummvm/scummvm-tools/blob/16f178fbb0e03eb122029050dfd3189451a5c6f2/engines/gob/degob_script_v3.cpp#L487)
- [Instruction dispatch and entry-point traversal](https://github.com/scummvm/scummvm-tools/blob/16f178fbb0e03eb122029050dfd3189451a5c6f2/engines/gob/degob_script.cpp#L882-L950)

Independent runtime source revision `984277131e510e554a669e865828efb953c03941`,
also recovered in the surrounding project:

- [Inter_v2 reads command and parameter count](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/inter_v2.cpp#L1427-L1439)
- [Inter_v3 maps command 100 to wobble](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/inter_v3.cpp#L63-L71)
- [Wobble handler reads no further script operands](https://github.com/scummvm/scummvm/blob/984277131e510e554a669e865828efb953c03941/engines/gob/inter_v3.cpp#L111-L113)

The packet contains third-party GPL-licensed tool source and locally generated
analysis. The tool authors' names and licenses remain in the supplied source
files. The game's original files remain distinct from the open-source decoder.
