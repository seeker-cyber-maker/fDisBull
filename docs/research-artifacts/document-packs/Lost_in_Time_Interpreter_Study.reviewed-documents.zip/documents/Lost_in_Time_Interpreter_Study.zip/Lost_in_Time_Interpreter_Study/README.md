# Lost in Time: interpreter and file-format investigation

29 October 2026. This continues the media-format work and the earlier script recovery, using the supplied DOS CD's actual resources.

## Result

**Lost in Time runs compiled game scripts through a bytecode interpreter.** The game logic is not confined to native x86 code in LOST.EXE. There are two distinct consumers of data:

- The game interpreter executes **TOT bytecode**: conditions, assignments, loops, callbacks, hotspots, transitions and service calls.
- The media decoder consumes **IMD packets**: palette/image data, compressed blocks and frame-control records. These are not the game's puzzle-language instructions.

The compatible implementation is ScummVM's **Gob engine, Inter_v3**. The original executable is a separate native DOS runtime; static unpacking exposes a **Borland C++ runtime string**. That is strong toolchain evidence, not proof that every original source module was C++, or that assembly routines were absent.

This investigation also fixes a concrete problem in the previously used decompiler. The apparent unsupported opcode 0.4 was caused by a six-byte alignment error after a wobble command. With a guarded correction, the decompiler's traversal completes for all **61 Italian-CD TOT modules**, with no diagnostics. This does not establish exhaustive indirect-code coverage or gameplay equivalence.

## Evidence at a glance

| Question | Evidence from this investigation |
|---|---|
| Are there real programs outside the EXE? | INTRO.STK contains 61 TOT modules with versioned headers, entry points, callback offsets, command blocks and typed expressions. |
| Which interpreter variant matches? | The actual CD archive matches the pinned Lost in Time CD detector; GobEngine selects Inter_v3, inheriting v2 and v1 behavior. |
| Does the native EXE refer to these programs? | Unpacked code uses intro.tot and a helper sequence consistent with reading the variable-count field at 0x2C. |
| Is there an existing decompiler? | Official ScummVM Tools degob explicitly supports the Lost profile. Pristine and corrected binaries/source are included. |
| Is the previous 0.4 error a new instruction? | No: a mis-sized Gob100 instruction makes the tool resume six bytes into the following code. Correcting that consumption resolves the observed failures. |
| How does this connect to movie reduction? | Actual script calls name movies, request frame ranges, query media information and wait on CD position. A verified index records 1,041 direct media-service call sites. |

The sources and original-byte evidence are separate throughout. The source map describes a compatible interpreter; the native report describes what is established about the original binary.

## Native executable

The original LOST.EXE is **101,532 bytes**, DOS MZ, with an LZ91 signature at file offset 0x1C. It is packed with **LZEXE 0.91**. The packed entry point is the decompression stub, so disassembling only that entry would initially describe the packer rather than the game runtime.

Static unpacking into a separate file produces **186,998 bytes**, with 2,115 reconstructed DOS relocation records. Their targets are in bounds. This is a structurally checked derivative, not a claim that its reconstructed header is identical to the publisher's pre-packing file.

At unpacked file offset **0x2C2D4**, the original content says:

    Borland C++ - Copyright 1991 Borland Intl.

The native code uses intro.tot and then passes offset 0x2C and a length of four through helpers before multiplying a returned value by four for allocation. Independently, the actual INTRO.TOT header has 5,470 at that offset, and the compatible interpreter allocates four bytes per variable: **21,880 bytes**. Exact helper names remain an inference; an original native dispatch-loop address was not established in this pass.

See [native/Native_Executable_Evidence.md](native/Native_Executable_Evidence.md) for file-versus-load-image offsets, disassembly excerpts, packer provenance and the preserved packed/unpacked copies. No DOS game code was executed in this pass.

## Resource and script layers

The supplied INTRO.STK is 4,831,170 bytes and contains **522 members**. It includes 61 TOT programs, 57 EXT resource files, shared COMMUN.EX1 data, localized text sidecars, sound/music resources and fonts. STK directories contain member names, byte sizes, offsets and packing flags; compressed members are unpacked before their internal format is interpreted.

All 61 TOT files declare **format version 1.3**. This is distinct from ScummVM's class name Inter_v3. Sixty declare 5,470 variable slots, or 21,880 bytes. EDIT.TOT declares 998 slots, or 3,992 bytes. All 154 populated header callback offsets are inside their modules' script regions; the inspected type-1 callback block spans are in bounds.

The CD has an Italian text sidecar for every TOT module. It also has other language sidecars. The archive signature is shared by several language detector entries: it identifies the CD family, not Italian uniquely. The previously delivered configuration selected Italiano through the game's original setup program.

### TOT header

All multibyte fields below are little endian. The fixed header is 128 bytes.

| Offset | Size | Meaning |
|---|---:|---|
| 0x27 | 3 | ASCII version, observed as 1.3 |
| 0x2C | 4 | Variable count; allocation uses four-byte units |
| 0x30 | 4 | Text-table offset; zero selects external localized text |
| 0x34 | 4 | Embedded resource-table offset |
| 0x38 | 2 | Animation sizing parameter |
| 0x3B | 1 | Shared IM-resource file selector; distinct from IMD video |
| 0x3C | 1 | Shared EX-resource file selector |
| 0x3D | 1 | Shared-resource handling parameter |
| 0x64 | 28 | Fourteen 16-bit callback offsets; slot zero is the start entry |

The first valid positive text/resource offset bounds the script region; absent tables use the runtime's zero/FFFFFFFF conventions. The inspector preserves unassigned header bytes and checks actual boundaries instead of inventing additional fields.

EXT and embedded resource tables use a count followed by 10-byte descriptors containing offset, size and dimensions. Some EXT fields also encode packing and high size bits; negative offsets select shared resources. The detailed report documents these rules. Localized text files contain a table of offset/size pairs and formatted text items, rather than being plain strings concatenated together.

### Bytecode structure

A normal command block has:

    01 | command_count:u8 | span:u16 | variable-length instructions

Its stored span plus two gives the complete block length. Block type 2 describes hotspot/input handling. Control-flow commands contain nested blocks and expression streams, so treating every instruction as a fixed-size native opcode would lose alignment.

The raw instruction byte maps to a function family and number. With h = raw >> 4:

    if h < 12: family = 0; number = h
    otherwise: family = 16 - h; number = raw & 15
    dispatch_index = 16 * family + number

Examples include raw 90 for assignment, 80 for if, 50 for switch, and FE as a drawing/service escape. FE 83 calls playImd; E5 selects a separate Gob-command dispatcher. Expressions contain typed variable references, numeric/string literals, operators and terminators.

The pinned registration map contains 61 function handlers, 49 drawing/service handlers and five Gob handlers. These are registered operations, not a count of operations exercised by this particular game. See [research/lost_opcode_map.json](research/lost_opcode_map.json).

## An actual instruction from the CD

In EMAM1018.TOT at decompressed byte offset **3422 (0x0D5E)**:

    90 12 73 31 15 00 63

| Bytes | Interpretation |
|---|---|
| 90 | Assignment instruction |
| 12 | Signed-byte variable descriptor |
| 73 31 | Little-endian variable-bank byte index 0x3173 = 12659 |
| 15 00 | Signed-byte literal zero |
| 63 | Expression terminator, decimal 99 |

The resulting operation is:

    variable_bank_i8[12659] = 0

The enclosing block at 3418 has four assignments and ends exactly at 3450. A separate bounded parser verifies its declared command count and exact ending position. It also parses the larger conditional block at 147 through 503. These examples are actual compiled game instructions, not inferred pseudocode from screenshots.

The language separation is equally concrete: text item 26 in EMAM1017.ITA contains “Pieno di nulla...”, while the matching EMAM1017.USA item contains “It's empty...”. A script refers to the text ID; the language resource supplies its wording. Text items can include formatting commands, and the example extractor reports only readable fragments.

An additional independently checked assignment in EMAM1017.TOT at 13245 is 90 17 3b 00 15 0c 63, assigning 12 to 32-bit slot 59 (byte offset 236). Degob prints variable-bank byte offsets, so var32_236 refers to that same slot; it must not be mistaken for slot number 236.

## The decompiler problem and its correction

The previous English recovery stopped in EMAM1017 with:

    ERROR: No such opcodeFunc: 0.4!

The real instruction causing the problem is:

    E5 64 00 00 00

It contains one opcode byte, Gob command 100 as a 16-bit value, and parameter count zero as a 16-bit value. Runtime Inter_v2 reads those two words; Inter_v3's wobble handler consumes no further script bytes. The pinned upstream degob table incorrectly declares **five words**, consuming six bytes of the next instruction.

In the current CD's EMAM1017, the instruction starts at 9072. The correct next opcode is 9077; the old decoder resumes at 9083. Misalignment then produces the misleading opcode 0.4 error.

The correction is guarded: the experimental executable accepts only the Lost profile and only Gob command 100 with parameter count zero. Other Gob commands are refused with their offsets. It is not a general change to all games or all Gob commands. The pristine decoder is included separately.

| Dataset | Pinned upstream | Guarded correction |
|---|---:|---:|
| Three previous English examples | 2 complete, 1 refuses | 3 complete |
| Current CD's 61 TOT modules | 58 complete, 3 refuse | 61 complete |

The three affected CD modules are EMAM1000, EMAM1017 and EMAM1104. All 58 other output files remain byte-identical. The previous English outputs also reproduce exactly under the pristine tool. Root integration independently reproduced the current EMAM1017 failure and successful corrected result.

Here, “complete” means the tool's normal entry-point/reference traversal returned zero without diagnostics. It does not prove that every unreferenced byte or indirect entry point was decoded, that all decompiler semantics are correct, or that an equivalent new game engine exists. The decompiler emits structured pseudocode; it does not recover the original author's source text.

See [degob/README.md](degob/README.md), the qualified patch, decoder-validation.json, decode-survey.json and [integration-check.json](integration-check.json).

## Connection to the earlier movie reduction

The media-call index derived from the decompiler output contains **1,041 unique script opcode sites**. Every reported site was checked against its exact FE/secondary-opcode prefix in the decompressed TOT:

| Operation | Sites |
|---|---:|
| playImd | 451 |
| getImdInfo | 15 |
| openItk / closeItk | 21 / 30 |
| playCDTrack | 351 |
| getCDTrackPos | 123 |
| stopCD | 49 |
| readLIC | 1 |

The 451 playImd calls include 190 literal filenames, 207 requests to reuse the open movie, and 54 dynamic filename expressions. Its arguments include x/y, start/end frames, break key, flags and palette range. This provides a concrete route to deciding which frame positions matter before further reduction.

Cross-referencing the previous 20 framed movies finds eight direct literal-name calls with constant frame ranges. All eight request retained original records: first or final frames. No direct literal call is found for the other twelve in this index. That is not evidence those movies are unused; dynamic names, indirect execution and EXT/MULT animation keys remain outside this check. See [framed-video-call-check.json](framed-video-call-check.json).

The correctly decoded EMAM1017 sequence after wobble queries the current CD segment, checks whether it is INTRO, and waits until the reported position becomes -1. That confirms that media completion is part of script control flow. The earlier data-only ISO's opening smoke test remains valid, but this work does not extend it into a full-game audio-omission or frame-substitution guarantee.

## Reproduction

The included decoder executables are Linux x86-64 binaries, built and tested here. The source and portable build instructions are included for other systems; a macOS build was not tested in this session. Python tools use the standard library.

Extract and inspect the original script archive into a new directory:

    python3 inspect_format.py game-data/INTRO.STK new-resources

Decode the previously failing current-CD module:

    ./degob/degob-lost-qualified Lost resources/extracted/EMAM1017.TOT resources/extracted/EMAM1017.EXT resources/extracted/COMMUN.EX1

Reproduce the survey without replacing saved evidence:

    python3 degob/survey.py --italian-dir resources/extracted --english-dir reference-english/extracted --output-root new-survey

Regenerate the bounded examples and media index into new outputs:

    python3 build_examples.py resources/extracted new-examples
    python3 index_media_calls.py degob/decodes/italian/lost-qualified resources/extracted new-media-index.json
    python3 review_framing_calls.py new-media-index.json references/framing-manifest.json new-framing-check.json

Historical absolute paths in receipts identify the experiment inputs. The tools' arguments and packaged relative paths provide the relocation route. Prior game files and the previously delivered compact ISO are unchanged.

## Implication for fDisBull and UIL

This target has a recoverable intermediate language already. A Gob/TOT processor should model script identity plus decompressed instruction offset, typed variable-bank references, nested control flow, callbacks, hotspots and native service effects. Native x86 analysis remains useful for exact original-runtime behavior, missing handler semantics and runtime instrumentation.

The recovered opcode map and structured decodes can support a typed representation for UIL, but a complete translation still needs dynamic-call resolution, EXT/MULT handling and explicit input/media/timing effects. This package contains analysis and decoding tools; it does not claim a completed fDisBull processor module or a replacement game runtime.

The next bounded step is resolving dynamic movie names and requested frame intervals through shared script helpers and EXT/MULT records. That connects the recovered interpreter directly to further qualified video shortening.

## Detailed evidence and licenses

- [research/ScummVM_Interpreter_Evidence.md](research/ScummVM_Interpreter_Evidence.md): pinned interpreter selection, exact format fields and source-function references.
- [resources/resource-inventory.json](resources/resource-inventory.json): every member, script header and compared earlier-release member.
- [native/Native_Executable_Evidence.md](native/Native_Executable_Evidence.md): original binary, packer and toolchain evidence.
- [degob/README.md](degob/README.md): decoder recovery, guarded repair, surveys and source/build provenance.
- [Knowledge_Pack.txt](Knowledge_Pack.txt): continuation state in the requested eight sections.

ScummVM code retains its notices and GPLv3-or-later license; ScummVM Tools retains its own included COPYING/COPYRIGHT files. UNLZEXE provenance is preserved in the native evidence directory. Those code licenses do not relicense the supplied game assets.
