# DOS targets and the fDisBull LE module

Date: 2026-10-29. Scope: initial static autoanalysis of the three supplied DOS game packages, followed by an implemented LE module for fDisBull.

## Exec Summary

The missing support is implemented and usable: fDisBull can now load the supported DOS/4GW LE image, apply its internal relocations, and analyze the resulting flat x86-32 code using the existing native processor. The installed preview successfully reopened the resulting Syndicate project. This is an integrated loader module, not a new instruction-set decoder or a recovered game-script interpreter.

The main Syndicate executable previously identified as LE in released fDisBull 0.23.0 but failed import. With the new module, one 5,000-attempt pass decoded 5,000 instructions, identified 171 function candidates, and retained 6,126 cross-references. Entry is `0x3D85C`. An independent reader matched every byte of all four loaded, relocated objects. The original executable remains byte-for-byte retained.

The implementation has 132 passing focused tests covering LE and adjacent loaders, native processing, inspection, project persistence and patch isolation. The installed wheel also passed a separate authored-program smoke check. All 142 packaged fDisBull files matched the final checkout. This was static qualification: no supplied installer or DOS game was executed.

| Target | Selected image and scope | Stored instructions | Function candidates | Xrefs | Pending discovery work |
| --- | --- | ---: | ---: | ---: | ---: |
| Eternam, `ETERNAM.EXE` | MZ, x86-16, resident file image | 4,542 | 193 | 5,497 | 683 |
| Colonization, `VICEROY.EXE` | MZ, x86-16, resident image only | 4,009 | 85 | 5,214 | 759 |
| Syndicate, `SYNDICAT/MAIN.EXE` | LE, x86-32, new module | 5,000 | 171 | 6,126 | 392 |

Each row comes from exactly one 5,000-attempt analysis call on that main executable. All three stopped at the budget and remain incomplete, with `stable=false` and `entry_complete=false`. Instruction counts describe stored analysis discoveries, not percentages of the game recovered. Function entries are candidates, not original symbols. Issue records describe uncertainty in analysis, not defects in the game.

Eternam and Colonization used unmodified released **0.23.0**. Syndicate used the new module on upstream development commit `d31c1757f8e73b64783930b0e9932ecb80452eb1`, whose package version is **0.24.0**. This is not a same-version performance benchmark or an official 0.24.0 release.

## Architecture

### What the new module does

`src/fdisbull/le.py` supplies `load_le(data, entry=...)` and `inspect_le(data)`. The loader recognizes bare LE and a valid independent LE secondary header in an MZ container. It produces the existing `Image` model with format `LE`, architecture `x86`, and 32-bit little-endian decoding. Existing `NativeProcessor` and traversal code consume that image.

The path is: container recognition, LE object/page validation, preferred-address mapping, supported internal fixup application, then ordinary native analysis and project persistence. The real-mode MZ bootstrap remains a separately selectable `--image mz` view with its own address model and project.

The integration touches image selection, CLI choices, inspection, compact status reporting, complete relocation pagination, and memory-version patch handling. It does not replace the instruction decoder. No new plugin registry is needed.

### Syndicate mapping

The supplied main executable is 518,713 bytes. Its LE header is at file offset `0x28B8`; data pages start at absolute file offset `0x15C00`. Table offsets inside the LE header are header-relative, while that data-page offset is file-absolute. The entry calculation is object 1 base `0x10000` plus EIP `0x2D85C`, yielding `0x3D85C`.

| Object | Preferred base | Virtual bytes | File-backed bytes | Zero-filled bytes |
| --- | --- | ---: | ---: | ---: |
| 1 | `0x10000` | 261,620 | 261,620 | 0 |
| 2 | `0x50000` | 81,504 | 53,248 | 28,256 |
| 3 | `0x70000` | 3,072 | 0 | 3,072 |
| 4 | `0x80000` | 116,274 | 114,233 | 2,041 |
| Total | | **462,470** | **429,101** | **33,369** |

There are 105 pages under the 4,096-byte page model; the final stored physical page is 3,641 bytes. The physical payload ends at EOF. These are declared static linear addresses, not observed DOS/4GW runtime placement or selector values.

The main executable contains **10,060 fixup records but 10,055 unique writes**. Five four-byte pointers cross a page boundary and are represented twice. For example, the pointer at `0x10FFF` appears as page 1 offset 4,095 and page 2 offset -1. Both records target object 2 offset `0xE555`, producing `0x5E555`. The loader writes that value once and preserves the duplicate evidence. It rejects conflicting overlaps.

Actual source type is offset32 (`0x07`). Target flags `0x00` occur 6,710 times and encode a 16-bit target offset; `0x10` occurs 3,350 times and encodes a 32-bit offset. Both write a four-byte pointer. All actual object ordinals occupy one byte. Separate authored tests cover supported wider object ordinals and explicit zero-fill pages, which this sample does not itself qualify.

All three Syndicate LE executables load:

| Input | Entry | Objects | Pages | Fixups | Unique writes | Mapped bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Main game, `SYNDICAT/MAIN.EXE` | `0x3D85C` | 4 | 105 | 10,060 | 10,055 | 462,470 |
| Expansion, `DATADISK/MAIN.EXE` | `0x3F16C` | 4 | 112 | 10,470 | 10,470 | 491,113 |
| Launcher, `SYND.EXE` | `0x138F8` | 2 | 11 | 1,029 | 1,029 | 48,427 |

Only the main game received an autoanalysis pass. Launcher and expansion results are loading surveys.

### The other DOS formats

Eternam's `ETERNAM.EXE` is a 110,888-byte conventional MZ file: a 6,144-byte header, 104,744 file-backed module bytes, 1,433 segment relocations and no appended tail. Its declared entry `0000:0000` becomes `1000:0000` / `0x10000` under the selected static load segment. Turbo C runtime text is a compiler-runtime clue; it does not establish the source language of every routine. A separate 3,794-byte `FDD/tatou.com` requires explicit COM selection and was inspected, not analyzed.

Colonization's 494,910-byte `VICEROY.EXE` has a declared MZ extent ending at byte 132,709. The resident file module is 123,493 bytes after its 9,216-byte header. The loader provides a 171,776-byte minimum static allocation and applies 2,260 segment relocations. Entry `110D:071D` becomes `210D:071D` / `0x217ED` at load segment `0x1000`.

Its remaining **362,201 bytes are retained but not mapped**. An RTLink/Plus string at file offset 107,101 lies inside the resident extent and is a useful lead to an overlay manager. It is not proof that every appended byte is executable overlay code. The separate `OPENING.EXE` demonstrates the distinction: its 21,907-byte appended tail has an NB02 CodeView header and matching trailer. No RTLink overlay mapper or CodeView symbol importer was added in this task.

## Decisions

1. **Reuse the existing native processor.** The concrete blocker was LE object mapping and fixups, not an unknown instruction set. DOS/4GW supplies a protected-mode environment; finding that environment does not establish a separate game bytecode interpreter.
2. **Accept an explicit bounded profile.** The implementation supports little-endian level-zero i386/486 LE executables, 32-bit objects, 4 KB enumerated or zero-filled pages, BSS and internal offset32 fixups. It rejects unsupported encodings instead of producing a partially relocated image that looks complete.
3. **Keep original and mapped bytes distinct.** Exact source bytes remain stored. Fixup metadata records original mapped values, relocated values, metadata offsets, duplicate identities and source fragments. A pointer spanning noncontiguous file pages or BSS does not claim a single contiguous file offset.
4. **Keep patches memory-only for LE.** A child project version may change mapped bytes; parent analysis and the original container remain intact. Inverse fixups and a runnable LE rewrite are not implemented. File metadata and original fixup records remain inherited and carry an explicit warning.
5. **Keep ordinary replies small and detailed evidence complete.** Status summarizes counts rather than dumping every page and fixup. Standalone inspection previews at most 10,000 fixups with a warning. The imported project's `relocations` endpoint pages the full retained list, and `info` reports the full count.
6. **Stop after the initial budget.** There were no manual seeds, repeated main-game analysis passes, or game executions. Subsequent checks read stored state or use authored synthetic programs.

Explicit exclusions include LX, external imports, selector/far-pointer/self-relative fixups, fixup lists/chains/addends, unsupported object semantics, 16-bit objects, iterated/invalid/compressed pages, DLLs/drivers and other page sizes. `--module` does not relax the LE entry requirement. `refresh-metadata` remains unsupported for LE. Bounds include 64 MiB source and mapped budgets, 4,096 objects, 16,384 pages and 100,000 fixups.

## Tasks

Completed:

- Extracted the three supplied Inno Setup installers as data with innoextract 1.9.
- Installed and retained the released 0.23.0 baseline separately.
- Recorded original format inventories and bounded first-pass results.
- Implemented the LE loader and integrated it into fDisBull's normal workflow.
- Verified actual Syndicate mapping independently and byte-for-byte.
- Passed 132 focused tests in 6.86 seconds on the final code.
- Built a wheel, installed it in a separate environment, analyzed an authored two-instruction LE program and reopened the real stored Syndicate database through that installation.
- Verified all 142 wheel payload files against the final source tree.
- Added public module documentation and corrected older contradictory LE support statements.
- Saved local commit `8d8020addb9f80239acade1d917f15422c5d2ca9` on branch `feat/dos4gw-le-static-module-20261029`.

The preview wheel and source patch form the implementation handoff. No release tag, new GitHub PR, or remote push was made for this module. The earlier no-CD documentation PR is a separate piece of work.

### Using the preview

The module is built into the supplied fDisBull wheel, not installed as a separate third-party processor plugin. Python 3.12 or newer is required. Use an isolated environment:

```sh
python3 -m venv .venv-fdisbull-le
.venv-fdisbull-le/bin/python -m pip install ./fdisbull-0.24.0-py3-none-any.whl
.venv-fdisbull-le/bin/fdisbull import /path/to/MAIN.EXE /path/to/syndicate.fdb --image le
.venv-fdisbull-le/bin/fdisbull analyze /path/to/syndicate.fdb --max-instructions 5000
.venv-fdisbull-le/bin/fdisbull status /path/to/syndicate.fdb
.venv-fdisbull-le/bin/fdisbull relocations /path/to/syndicate.fdb --limit 50 --offset 0
```

Omit import/analyze when resuming the delivered database; open its stored status or disassembly directly. The preview was installed in this workspace at `dos-targets/le-venv/bin/fdisbull`. The original baseline remains at `dos-targets/venv/bin/fdisbull`.

## Research

Format interpretation was checked against primary Open Watcom source pinned to commit `5474be3542af05eee71be05fafc31bbe11f1415b`:

- [exeflat.h](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/watcom/h/exeflat.h): header, object, page-map and fixup definitions.
- [loadflat.c](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/wl/c/loadflat.c): object-relative entry and LE page writing.
- [obj2supp.c](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/wl/c/obj2supp.c): internal relocation writing, including duplicated cross-page records with a negative next-page source offset.
- [wdfix.c](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/exedump/c/wdfix.c): independent fixup record grammar.

The independent verifier was derived from those sources before inspecting the implementation, imports no fDisBull code, and compared every mapped byte. The source excerpts, license, verifier and comparison receipt are in `analysis/le-independent/`.

Evidence locations in the private analysis archive:

| Evidence | Path |
| --- | --- |
| Extraction and executable inventory | `extraction/` |
| Eternam baseline and database | `analysis/eternam/` |
| Colonization baseline and database | `analysis/colonization/` |
| Syndicate 0.23.0 rejection and LE survey | `analysis/syndicate/` |
| Integrated Syndicate pass, database and SVG | `analysis/syndicate/integrated/` |
| Independent reader and comparison | `analysis/le-independent/` |
| Final test result | `analysis/verification-receipt.json` |
| Installed wheel check | `analysis/wheel-verification/` |

Two audit qualifications are preserved. The initial Syndicate public `inspect` returned successfully but its large response could not be retained through the default artifact directory; the saved response explicitly reports incomplete delivery. A separate read-only `inspect_binary` export captured the full inspection document and preserved its 10,000-record preview warning. Also, the original receipt log contains nine of the eleven expected call entries. The last relocation-page response, render response, valid SVG and final summary exist, but the two missing timings cannot be recovered. `supplemental-evidence.json` marks those records as recovered from saved outputs with unavailable durations. No main-game analysis was repeated to repair either record.

## Questions

The new loader answers how to enter Syndicate's protected-mode code statically. It does not yet answer which routines implement music playback, which resource files contain scripts, or what DOS/4GW selectors and addresses are used at runtime. Native x86 code may be compiled C, assembly, or a mixture; disassembly alone does not prove that a program was hand-coded assembly. A resource interpreter, if present inside a game engine, needs its own evidence.

For Colonization, the next format question is the structure and dispatch behavior of the RTLink-associated appended data. The present analysis intentionally does not assign speculative load addresses to that tail. The NB02 data in the opening program is a separate symbol-information lead.

## Memory

- Preserve the three main `.fdb` projects and their exact input identities. They already contain the bounded first-pass results and retained bytes.
- Keep the released baseline and the development preview distinct when reporting results.
- The LE module is qualified for its stated static subset; unsupported variants should produce explicit failures, not automatic raw or stub fallbacks.
- Keep the original no-CD goal separate from loader development: identify the actual playback loop before relying on a one-frame media substitution. A valid tiny music file can still trigger a tight replay loop depending on the player. No media or original game code was changed here.
- The analysis archive contains byte-retaining private projects. The module code bundle contains source changes, documentation and the tool wheel, without the supplied commercial executables.

## Next

The immediate useful next investigation is to follow Syndicate's now-loaded entry and resource/playback call paths from the saved project, with a new explicit question and bounded budget. For format expansion, Colonization's RTLink overlay handling is the separate unresolved loader problem. Broader LE support should add one evidenced encoding at a time with authored fixtures and real-file checks. Native DOS/4GW execution and release qualification remain distinct future work.
