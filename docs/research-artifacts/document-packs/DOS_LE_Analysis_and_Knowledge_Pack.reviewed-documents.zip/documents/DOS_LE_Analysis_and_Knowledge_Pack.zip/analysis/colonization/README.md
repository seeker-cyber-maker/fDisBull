# Colonization: initial fDisBull autoanalysis

29 October 2026. Static inspection using the unmodified fDisBull 0.23.0
released core. No Windows installer or DOS game executable was executed.

## Result

The existing segmented x86-16 analyzer loads the resident portion of
`VICEROY.EXE` successfully. Exactly one `analyze --max-instructions 5000`
call took **0.996 seconds** and stored **4,009 instructions**, **85 function
candidates** and **5,214 xrefs**. It exhausted its budget and remains incomplete.
The nine captured CLI calls took 3.003 seconds in total; they all exited zero
and produced no stderr.

| Result | Count |
| --- | ---: |
| Instruction attempts | 5,000 |
| Decoded instructions | 4,009 |
| Function candidates | 85 |
| Xrefs | 5,214 |
| Pending code | 38 |
| Pending data | 177 |
| Deferred seeds | 539 |
| Pending segment scans | 4 |
| Pending seed phase | 1 |
| Total pending work | 759 |
| Issue records | 949 |

The issue count is not a count of invalid instructions or identified game bugs.
All stored work states are either decoded or pending. Reported details include
unknown segment/register state, uncertain far pointers and conservative stack
invalidation. One instruction can carry several such details. Derived function
analysis has not run; this is the initial recursive native traversal.

## Format and coverage boundary

`VICEROY.EXE` is 494,910 bytes. Its classic MZ header declares a 132,709-byte
file extent: 9,216 bytes of header followed by **123,493 resident module bytes**.
The loader applies 2,260 MZ relocations and models the minimum allocation as
171,776 bytes at static load segment `1000`. The declared `110d:071d` entry
becomes `210d:071d`, linear address `0x217ed`, under that model.

The remaining **362,201 bytes** are retained in the original source snapshot
but are not mapped into this resident image. The loader calls this quantity
`overlay_size`; the field describes bytes beyond the MZ extent, not proof of a
recovered executable-overlay catalog.

A `.RTLink(R)/Plus` runtime marker occurs at file offset 107,101, inside the
resident extent. It is a useful lead for locating the overlay manager. The
appended records and their runtime load destinations have not been parsed or
observed here. Treating the entire tail as contiguous extra resident code
would lose the original loading and address semantics.

`OPENING.EXE`, the launcher, contains a `viceroy` reference. Its own 21,907-byte
tail begins with `NB02` at file offset 67,271 and has the same signature at the
final trailer, offset 89,170. That is CodeView debug-data evidence, illustrating
why an MZ tail must not automatically be called executable overlay code.

## What a module should add

The resident executable already uses the supported x86-16 decoder. A new
instruction set is not required for that surface. The next useful extension is
format-aware handling of the appended payload and its loader: identify the
RTLink record layout and load/fixup/address transitions, preserving the identity
of whichever overlay occupies a given runtime range. CodeView symbols from
`OPENING.EXE` are a separate metadata opportunity; their presence does not
establish matching symbols for `VICEROY.EXE`.

Further traversal of the resident image may discover more code, but it cannot
substitute for understanding overlay loading. No initial-pass result here
establishes game logic recovery, an interpreter, or a full-game control-flow map.

## Artifacts and reproduction

`commands.json` records exact commands, timing, return codes and output sizes.
`summary.json` contains the compact machine-readable result. Each CLI response
is retained as JSON; the issues and functions views were limited to 20 records,
and the entry disassembly to 20 instructions. The original source is retained
inside the private `viceroy.fdb` project database.

The reproducible wrapper refuses an existing output database and executes only
one bounded analysis call. Supply your own tool, extracted game file and new
output directory:

```bash
python run_baseline.py --tool /path/to/fdisbull \
  --target /path/to/VICEROY.EXE --output /path/to/new-analysis
```

No manual seed, label, raw-image override, repeated analysis, derived
`auto-analyze` pass or native runtime observation was used. All facts above
come from the preserved command outputs, file headers and bounded marker reads.
