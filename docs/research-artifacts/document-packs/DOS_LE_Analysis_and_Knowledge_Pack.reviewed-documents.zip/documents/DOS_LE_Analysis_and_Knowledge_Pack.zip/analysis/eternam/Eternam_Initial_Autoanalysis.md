# Eternam CD: initial automatic analysis

The unmodified fDisBull 0.23.0 installation recognized and imported the CD game as a 16-bit DOS MZ, then performed exactly one automatic analysis call with a 5,000-attempt limit. It stored **4,542 instructions, 193 function candidates and 5,497 cross-references** in about one second. It stopped at the budget, with the entry traversal still incomplete. No manual seeds were added and no original game code ran.

## Input and loader

- Input: `games/eternam/ETERNAM.EXE`, 110,888 bytes.
- SHA-256: `1ed9504e918da578465b227fec06fd9d13fe3ffc4a0f99dbc7fee46cb9062cbc`.
- MZ header: 6,144 bytes; loadable file module: 104,744 bytes; 1,433 relocations; no appended overlay tail.
- Static load segment: `0x1000`; selected entry: `1000:0000` / linear `0x10000`.
- The mapped static version has a different hash from the original file because the loader applies its declared load model and relocations; use the source hash above for file identity.
- The inspection returned 309 visible strings, no native import/export tables, and two explicit qualifications about static DOS allocation and the lack of a code/data section partition.

## Bounded results

| Metric | Result |
| --- | ---: |
| Analysis attempts | 5,000 |
| Stored decoded instructions | 4,542 |
| Function candidates | 193 |
| Cross-references | 5,497 |
| New facts reported by analyze | 11,495 |
| Total native pending work, as reported | 683 |
| Pending code | 71 |
| Pending data | 227 |
| Deferred seeds | 378 |
| Pending segment scans | 6 |
| Pending derived-analysis work, separate scope | 192 |
| Issue records | 1,968 |
| Analyze command elapsed seconds | 0.999778 |

The stop flags are `budget_exhausted=true`, `entry_complete=false` and `stable=false`. The automatic data phase had processed zero data items at this point. Pending totals include phase bookkeeping and should be read directly from the JSON rather than reconstructed by summing only the displayed categories.

The first 20 issue records primarily expose unknown segment/effective-address values, abstract-stack invalidation, interrupt return assumptions and unresolved far-pointer values. They are analysis limitations or incomplete facts; the total is not a count of defects in the game. The first 20 function records are explicitly marked as candidates.

The stored entry disassembly begins with segment/runtime setup and an INT 21h DOS call. Static control flow follows decoded branch/call operands and preserves its calling-convention assumptions. This is useful native startup recovery; it does not yet identify game systems or establish coverage of the whole executable.

## Separate floppy inspection

`FDD/tatou.com` is a separate 3,794-byte bootstrap launched by the GOG floppy menu. Signature-only identify returns unknown, which is appropriate for headerless COM. Explicit `inspect --image com` accepts it and maps only its file bytes at `1000:0100` / linear `0x10100`. No floppy database was created and no floppy autoanalysis was run.

## Commands and retained evidence

The sequence was identify, inspect, import, one analyze call, status, analysis-status, issues (20), functions (20), and entry disassembly (20). The floppy identify and explicit COM inspection were auxiliary checks. All 11 commands returned zero and had empty stderr. The nine main commands totaled 2.946912 seconds of captured subprocess time; this is a single run, not a benchmark.

Each command has its full JSON output, stderr and a timing/return-code receipt. `summary.json` is the compact machine-readable result, `command-receipts.json` is the ordered command history, and `eternam.fdb` retains the analysis for continuation. No source change, re-analysis, manual entry seed, or runtime test was performed.

## Knowledge Pack

- **Exec Summary:** MZ autoanalysis works; the first bounded pass recovers thousands of native facts and remains incomplete.
- **Architecture:** Relocated 16-bit segmented DOS image; the separate floppy COM path is an explicitly selected raw DOS load model.
- **Decisions:** Use the direct GOG CD EXE; keep the original baseline tool and one 5,000-attempt run.
- **Tasks:** Loader inspection, import, bounded traversal and small result samples completed; full outputs and database retained.
- **Research:** Startup code, segment assumptions and candidate functions are visible automatically; no gameplay semantics claimed.
- **Questions:** Remaining entry paths, deferred seeds, data references and indirect/segmented transfers remain open.
- **Memory:** A budget stop is not stable or complete; issue and function counts carry their explicit qualifications.
- **Next:** Continue from the saved database only when a later task authorizes a larger pass or a targeted investigation.
