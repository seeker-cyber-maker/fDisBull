# Independent Syndicate LE loader verification

An independent bounded reader was written from pinned OpenWatcom header, dump and linker source before reading the new fDisBull LE implementation. It imports no fDisBull code. Its mapped, relocated object bytes were then compared with the new loader: **all four objects match byte for byte**. No autoanalysis was repeated and no game code ran.

## Actual input and mappings

- Input: `games/syndicate/SYNDICAT/MAIN.EXE`, 518,713 bytes.
- SHA-256: `bfbed760ab2def1fbe9f73588dc5a24747826c9b7660d615b02a8847d92bf078`.
- LE header at `0x28B8`; data pages at absolute file offset `0x15C00`.
- Entry object 1 plus object-relative EIP `0x2D85C` gives declared linear entry **`0x3D85C`**.
- 105 physical/logical pages in this input, 4,096 bytes per page; the final physical page is 3,641 bytes. The physical payload ends exactly at EOF.

| Object | Declared base | Virtual bytes | File-backed bytes | Zero-filled tail |
| --- | ---: | ---: | ---: | ---: |
| 1 | `0x10000` | 261,620 | 261,620 | 0 |
| 2 | `0x50000` | 81,504 | 53,248 | 28,256 |
| 3 | `0x70000` | 3,072 | 0 | 3,072 |
| 4 | `0x80000` | 116,274 | 114,233 | 2,041 |

The object bases define the chosen static linear address space. Table offsets are relative to the LE header, while the data-page file offset is absolute. Internal targets are object-relative offsets: adding the target object base yields the relocated value. The actual runtime DOS-extender placement and selectors were not observed.

## Fixup evidence

**10,060 records describe 10,055 unique writes.** All actual source types are internal 32-bit offset writes (`0x07`). Target flags are `0x00` for 6,710 records and `0x10` for 3,350 records. These choose 16-bit versus 32-bit encoded target offsets; both still write four bytes. All object ordinals in this input occupy one byte.

| Source linear address | Target | Expected written u32 | Reason selected |
| --- | --- | --- | --- |
| `0x10DFA` | Object 2 + `0xE2BD` | `0x5E2BD` | 16-bit target offset encoding |
| `0x10DD6` | Object 2 + `0x10AFC` | `0x60AFC` | 32-bit target offset encoding |
| `0x10C95` | Object 1 + `0x594` | `0x10594` | Intra-code-object target |
| `0x41560` | Object 3 + 0 | `0x70000` | Target in an entirely zero-filled object |
| `0x10D63` | Object 4 + `0x1BE3A` | `0x9BE3A` | Target in object 4 BSS |
| `0x10FFF` | Object 2 + `0xE555` | `0x5E555` | Same fixup represented from both sides of a page boundary |

There are five duplicate pairs. The first appears on page 1 at source offset 4,095 and page 2 at signed source offset -1; both describe the same four-byte word. Other observed negative offsets are -2 and -3. The independent reader groups equal writes and rejects disagreement. The implementation likewise records `duplicate_of` and does not add a base to already-relocated bytes twice.

## Implementation review

The reviewed module explicitly limits its accepted profile to flat 32-bit little-endian LE with internal offset32 fixups. Unsupported selectors, far pointers, relative source types, imports, lists, chains and additive records are rejected. Object ordinal width bit `0x40` and target-offset width bit `0x10` are decoded separately. Source offsets are signed and constrained to words intersecting the relevant page. Bounds checks cover source/target objects, page records, table extents, preferred-range overlap and entrypoint backing.

The actual-binary comparison passed for entry address, source preservation, record/write counts, all object sizes and every byte of each fixed mapped object. `implementation-comparison.json` binds that result to the reviewed `le.py` hash. The independent expected data is retained in `main-independent.json`; `verify_syndicate_le.py` reproduces it without using the implementation.

No blocker was found for the observed Syndicate profile. The actual sample does not exercise 16-bit object ordinals, explicit zero-fill page records, imports, selectors or other excluded encodings. Synthetic tests and wider format claims remain the implementation owner’s separate evidence. This is static loader verification, not a DOS/4GW emulator test or whole-game behavior proof.

## Primary references

Pinned OpenWatcom commit: `5474be3542af05eee71be05fafc31bbe11f1415b`.

- [exeflat.h](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/watcom/h/exeflat.h): object base addresses, header/table layout, LE page-number layout, source/target flags.
- [loadflat.c](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/wl/c/loadflat.c#L118-L134): entry EIP is stored relative to its group, while the object record retains the group’s linear address. Its data writer also accounts for page padding and last-page bytes.
- [obj2supp.c](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/wl/c/obj2supp.c#L680-L694): cross-page writes are emitted twice, with the next-page source offset reduced by a page. The internal-reference writer subtracts the target group base before encoding the offset.
- [wdfix.c](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/exedump/c/wdfix.c#L43-L72): independent record grammar for object ordinal and target-offset widths.

Selected primary sources and their license are retained under `primary/`; `primary-sources.json` records exact identities. The local verifier is newly authored and intentionally limited to the observed profile.
