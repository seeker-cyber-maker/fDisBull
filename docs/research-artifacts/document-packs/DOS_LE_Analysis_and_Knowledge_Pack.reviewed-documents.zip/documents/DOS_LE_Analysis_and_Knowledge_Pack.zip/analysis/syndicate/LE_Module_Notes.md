# Syndicate: bounded LE module

29 October 2026. Static analysis only; no game or DOS extender was executed.

## Baseline

The installed fDisBull 0.23.0 recognized the supplied `SYNDICAT/MAIN.EXE`
as LE/x86/32 at file offset `0x28B8`, but its inspection had no mapped
sections and default import refused the LE secondary executable. No analysis
was attempted after that failed import. The exact commands, exit statuses and
outputs are retained as `baseline-*` alongside this note.

## Implementation

The new `fdisbull.le` module supplies `load_le(data, entry=None)` and
`inspect_le(data)`. It supplies a real flat x86/32 `Image` to the existing
native processor. It is a loader extension rather than an invented guest ISA.
The parent integration selects it through automatic and explicit LE import.

Supported profile: little-endian level-zero LE, i386/486 CPU, 4096-byte pages,
32-bit objects at their declared preferred bases, ordinary enumerated pages,
zero-fill pages/BSS and internal 32-bit offset fixups. Fixup target offsets can
be 16 or 32 bits and object ordinals 8 or 16 bits. Signed cross-page source
offsets are handled, including identical duplicated fixup records on adjoining
pages. Conflicting or partially overlapping fixup writes are refused.

Original container bytes remain unchanged in `source_bytes`. The mapped image
receives the fixups. Each fixup retains its metadata-record file offset, source
object and logical address, original mapped value, relocated value and source
file fragments. A word spanning noncontiguous physical pages or BSS does not
claim one contiguous four-byte source-file interval. Inspection uses the
standard section schema and leaves contiguous source coordinates unknown when
the object has fragmented backing.

The module refuses LX, imported modules, selector/far-pointer fixups,
self-relative fixups, fixup lists/chains/addends, 16-bit objects,
iterated/invalid/compressed pages, DLLs/drivers and unsupported page sizes.
It caps source and mapped bytes at 64 MiB, objects at 4096, pages at 16384,
and fixup records at 100000. These explicit limits describe this implementation;
they do not imply the excluded formats are invalid executables.

This is preferred-address static loading. Runtime selectors, actual DOS/4GW
placement, interrupts, device state and full gameplay remain unverified.

## Fresh qualification

The 32 synthetic cases in `tests/test_le_loader.py` passed. They cover exact
object contents, target/object field widths, source preservation, cross-page
duplicate fixups, permuted physical pages, BSS provenance, entry restrictions,
malformed extents and explicit unsupported forms.

All three supplied Syndicate LE executables loaded through the module:

| Input | Entry | Objects | Pages | Fixup records | Unique writes | Mapped bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| `SYNDICAT/MAIN.EXE` | `0x3d85c` | 4 | 105 | 10,060 | 10,055 | 462,470 |
| `DATADISK/MAIN.EXE` | `0x3f16c` | 4 | 112 | 10,470 | 10,470 | 491,113 |
| `SYND.EXE` | `0x138f8` | 2 | 11 | 1,029 | 1,029 | 48,427 |

The original MAIN mapping has 429,101 file-backed bytes and 33,369 zero-filled
bytes. `le-loader-survey.json` retains the per-object measurements and timings.
These are loader results, not instruction-coverage or runtime measurements.
The parent will record the integrated bounded autoanalysis separately.

## Primary encoding references

Open Watcom commit `5474be3542af05eee71be05fafc31bbe11f1415b`:

- [LE header, object/page and fixup field definitions](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/watcom/h/exeflat.h).
- [LE page-map and data-page writer](https://github.com/open-watcom/open-watcom-v2/blob/5474be3542af05eee71be05fafc31bbe11f1415b/bld/wl/c/loadflat.c).

Observed Git blob identities were `c643661de51ff846cddf3b461d7fda26e8ca8dd2`
and `c9be486d12633bd119b878943916394c2e665de5`, respectively. The implementation
was authored against the format definitions; upstream C source was not copied
into fDisBull.
