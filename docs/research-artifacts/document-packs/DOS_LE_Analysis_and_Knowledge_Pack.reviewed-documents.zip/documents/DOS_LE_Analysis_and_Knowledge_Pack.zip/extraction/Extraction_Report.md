# Installer extraction and DOS target inventory

The three GOG installers were extracted as data with the official innoextract 1.9 Linux amd64 binary. No Windows installer or DOS game executable was run. All three reported Inno Setup 5.6.2 (Unicode) and returned exit status zero. Original uploads were preserved.

| Target | Installer bytes | Extracted files | Extracted payload bytes | Extraction seconds |
| --- | ---: | ---: | ---: | ---: |
| eternam | 464,480,408 | 202 | 602,728,014 | 7.318 |
| syndicate | 60,066,616 | 949 | 77,686,231 | 1.027 |
| colonization | 53,642,160 | 317 | 61,466,427 | 0.789 |

## Main targets

| Target | Executable | Format evidence |
| --- | --- | --- |
| Eternam CD | `eternam/ETERNAM.EXE` (110,888 bytes) | Plain MZ, 6,144-byte header, 1,433 relocations, 0000:0000 entry, no appended tail; Turbo-C runtime string. |
| Syndicate | `syndicate/SYNDICAT/MAIN.EXE` (518,713 bytes) | MZ bootstrap with LE header at 0x28B8; 32-bit protected-mode payload must be distinguished from the DOS stub. |
| Colonization | `colonization/MPS/COLONIZE/VICEROY.EXE` (494,910 bytes) | MZ with declared extent 132,709 bytes and 362,201 appended bytes; RTLink/Plus diagnostic supports investigating overlays. |

## Launch distinctions

- Eternam GOG CD configuration invokes `eternam`; the existing EXE takes precedence over the same-named BAT. The BAT instead names `intro` and `eter_cd`. The separate floppy choice launches `FDD/tatou.com`, a 3,794-byte COM bootstrap. These are different paths and should not be silently treated as the same executable.
- Syndicate GOG configuration launches `SYND.EXE` (105,981 bytes), itself MZ/LE. Its visible strings include `cd syndicat` and `main`/`smain` command templates. The `DATADISK` directory contains the expansion and a separate `MAIN.EXE` (553,529 bytes).
- Colonization launches `OPENING.EXE -g`; it contains a `viceroy` reference. `OPENING.EXE` is 89,178 bytes, with an NB02 debug trailer pointing exactly to the end of its 67,271-byte MZ extent. Its appended 21,907 bytes should not be described as overlays just because they are appended. It retains source/module/symbol-like strings, including `_main`.
- The bundled DOSBox and GOG Windows launch/configuration helpers are not the DOS analysis targets. Eternam also includes `ABOUTIPC.EXE`, recognized as a Windows NE program.

## Records and boundaries

`input-inventory.json` records 35 executable candidates, bounded headers, selected runtime strings with file offsets, and launch-file line references. Per-target JSON receipts and complete extraction logs are alongside it. `tools/extractor-provenance.json` records the official tool URL and verified published MD5, with its SHA-256.

An appended MZ tail is not automatically an overlay: it can contain resources, debug data or another executable. The RTLink identification is supporting evidence; no overlay directory has been recovered in this extraction step. Toolchain strings do not prove every source module used that language. No game semantics or runtime compatibility is claimed here.
