# PR 29: symbolic UIL and UDC orchestration revision

Status: revision in progress, 30 October 2026.

The text revision, checker and receipt are published at:
https://github.com/seeker-cyber-maker/fDisBull/pull/29
Head at delivery: `8338ccad28c7a0c6555a59f7a7b764b8c614999f`.

This ZIP is a repository overlay, not the complete fDisBull checkout. The new
Markdown documents link to existing RFC files that remain in that repository.
Open `GALLERY.html` to inspect both unchanged full-resolution illustrations
without needing the other repository files.

## Image transfer status

The full PNGs and gallery here are prepared for publication but are not yet
committed to GitHub. The separate delivery
`PR29-full-resolution-illustrations.patch` adds their exact bytes and changes the
published transfer note into the gallery. On the PR branch:

```sh
git apply --check /path/to/PR29-full-resolution-illustrations.patch
git apply /path/to/PR29-full-resolution-illustrations.patch
```

The asset patch was checked and applied in an independent local worktree; both
original PNG hashes matched afterward. Review and commit the result through the
repository's normal workflow. No automatic push occurs.

## New checks

```sh
python docs/uil-rfcs/0002/check_component_witnesses.py
```

Sixteen authored Python-only checks passed. They are small witnesses about
identity, sharing, activation state and inverse ambiguity, not a production
UDC implementation or proof of general compiler correctness. The 20 D01-D20
acceptance rows describe future production behavior. No new native game,
DOS-memory or decompiler-provider test was performed.

The first concept image's PR #30 header is an artwork error; the actual PR is
#29. The drawings' schemas and verification labels are not canonical APIs.
