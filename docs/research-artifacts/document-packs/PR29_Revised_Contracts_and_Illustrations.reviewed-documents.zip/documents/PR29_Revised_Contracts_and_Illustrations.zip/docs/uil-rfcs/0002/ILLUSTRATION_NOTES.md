# User-selected concept illustrations

**REVISION IN PROGRESS. Concept art, not an API or proof specification.**

The user selected both generated topographical diagrams for this PR revision.
Both full-resolution PNGs are included unchanged under `illustrations/`. Their
[identity manifest](illustrations/manifest.json) records the original hashes.
The captions below distinguish concept art from the reviewable specification.

| Asset | Resolution | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| `concept-topography-01.png` | 1536 x 1024 | 2556527 | `acfe1323b07e4c996e977f09ab885eb85d2839de7dabbcb63d350db91d373e7d` |
| `concept-topography-02.png` | 1536 x 1024 | 2427320 | `bf6f94819fcecda9a205f0c7bb0e0d2d587b8b1f3af00a0cae43ddeb469fcd6b` |

No rescaling, reencoding, cropping or new image generation was performed on the
retained originals. The visible original PR-number mistake is corrected in the
caption rather than silently altering the artwork.

## Captions and corrections to retain with the artwork

**First illustration:** an overview of diverging/rejoining analysis paths,
executable UDL, UIL, UDC and target scaffolds. Its automatically generated header
says PR #30. This is an artwork mistake; the actual proposal is **PR #29**.

**Second illustration:** a complementary view of the shared blueprint and its
possible implementation paths. The variable/function records are illustrative
sketches, not canonical UIL syntax or a requirement for fixed physical storage.

Both pictures are explanatory designs. `verified: true`, a tool logo/name,
endianness or a target arrow is not a qualification receipt, installed capability
or compiler benchmark. Stable semantic identity is distinct from backing
revision; endianness need not exist on an abstract integer; executable UDL
retains qualified backings; C and Z remain optional routes.

Use the [editable map](PIPELINE_MAP.md), [current component contracts](LABELS_ORCHESTRATION_AND_ROUNDTRIPS.md)
and [RFC](../0002-executable-rosetta-contracts.md) as the reviewable specification.

## Gallery

### 1. Branching analysis routes and executable backings

![Concept topography of alternative analysis paths into executable UDL and UIL](illustrations/concept-topography-01.png)

*Original generated concept art. The header incorrectly says PR #30; this is PR #29. The records and verification labels are illustrative, not an adopted schema.*

### 2. The common blueprint and alternative target realizations

![Concept topography from source recovery through UIL and mixed-language UDC implementations](illustrations/concept-topography-02.png)

*Original generated concept art. Addresses, stacks and physical storage are realization choices; observable aliasing, arithmetic and state identity remain contractual.*
