# Lost in Time representation-order experiment

Read `EXPORT_ORDER_REPORT.md` for the result and its limits. The experiment
compares joint, representation-first and hybrid export schedules using the same
seven retained source-backed branch models. It does not compare independent
agents discovering unseen source code.

## Contents

- `experiment/benchmark_order.py`: matched scheduler and exporters.
- `experiment/audit_results.py`: paired statistics and information-retention tests.
- `vendor/il_scenes.py`: unchanged fDisBull PR #18 consumer. Retrieved from
  https://github.com/seeker-cyber-maker/fDisBull/blob/c107d1576d46d7dc353c8043cb81be5005e8926b/src/fdisbull/il_scenes.py
  Git blob `9f349892065a6fd3e5ac026956899970d9fd3173`.
- `results/benchmark.json` and `results/runs.jsonl`: all 126 successful trials.
- `results/audit.json`: paired comparisons and semantic probes.
- `results/shared_knowledge_catalog.json`: private investigator facts, not live state.
- `results/examples/joint/memory/`: one canonical set of all 42 generated outputs.
  The other schedules generated identical bytes, so their duplicates are omitted.
- `results/implementation_identity.json`: source/tool identities.

This package does not include the original game, the 0.22 offline kit, or the
retained continuation's source ASTs. Use the previously supplied
`Lost_in_Time_Continuation.zip` version 2 and the preserved 0.22.0 Python
environment. The tested Python version is 3.13.5. This is a pinned experiment,
not an installation of a newer fDisBull release.

## Reproduce

Extract the earlier continuation separately. Set these paths to the actual
locations, then run from this experiment's extracted root:

```sh
PYTHON=/path/to/fdisbull-0.22-venv/bin/python
CONTINUATION=/path/to/extracted/lost-in-time/continuation

"$PYTHON" experiment/benchmark_order.py \
  --continuation "$CONTINUATION" \
  --z-module vendor/il_scenes.py \
  --output ./fresh-results \
  --repetitions 21 --batch-runs 126

"$PYTHON" experiment/audit_results.py \
  --continuation "$CONTINUATION" \
  --z-module vendor/il_scenes.py \
  --results ./fresh-results
```

Use a new output directory for a new benchmark. Interrupted batches can resume
with the same output path; `runs.jsonl` preserves completed workers. Do not mix
receipts from different runner versions or source inputs. The audit intentionally
expects the standard 21 repetitions in each of six cells.

The audit's catalog output may omit the additional human-reviewed identity-scope
annotation in the shipped catalog; all benchmark artifacts and their digests are
unaffected. A new timing run should not be expected to reproduce wall times.

## Scope and safety

All HUD values are isolated evaluator witness state. Native values and input
readiness are unknown; imported files cannot authorize clicks or restore the
original game. Partial branch packages are investigator interfaces and can
contain spoilers. The unresolved broad scene rules remain execution-blocked.
No native emulator, gameplay action or persistence test is started by these scripts.

## Project record

The measured report was added to existing fDisBull PR #20 at commit
`7aa4086af7e08b34307f916e047801dafc3fa0cf`:
https://github.com/seeker-cyber-maker/fDisBull/pull/20

It does not implement a new shared recovery graph or change the production merger.
