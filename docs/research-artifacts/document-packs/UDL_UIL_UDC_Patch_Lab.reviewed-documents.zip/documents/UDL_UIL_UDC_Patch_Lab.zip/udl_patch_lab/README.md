# UDL / UIL / UDC patch lab

See **REPORT.md** for the executed results and scope.

This authored native program computes an 8-bit number. Its patch splits the
higher-or-equal path into separate equality and higher paths, leaving unrelated
prefix/suffix code and existing handlers unchanged.

## Files

- `src/pre.S`, `src/post.S`: actual authored x86-64 reference programs.
- `run_lab.py`: backing qualification, patch application, UDL/UIL/UDC conversion and tests.
- `artifacts/*.udl.json`, `artifacts/*.uil.json`: shared `fdisbull-il-1` representations.
- `definitions/*.udl-backings.json`: executable source bindings and exact identities.
- `definitions/pre.native.udc.json`, `definitions/post.native.udc.json`: original-backed compiler profiles.
- `definitions/javascript.udc.json`: the single alternate compiler definition.
- `artifacts/pre.generated.js`, `artifacts/post.generated.js`: standalone generated programs.
- `artifacts/patch.layer.json`: guarded executable-code patch.
- `artifacts/uil.patch.json`: corresponding semantic tree delta.
- `results/`: executed checks, differences, examples, timings and provenance.

The intentionally incorrect `control.no_wrap.js` and `post.equal31.generated.js`
are test controls, not replacements for the normal outputs.

## Run the JS only

```sh
printf '%s\n' '{"$x":211,"$number":0,"$before":0,"$after":0,"$outcome":0,"$calls":0}' \
  | node artifacts/post.generated.js
```

The equality result is `30`; the pre-patch program produces `20` for the same input.

## Rebuild and verify everything

Requires Linux x86-64, Python >=3.12, GCC/binutils, Node, and fDisBull's shared IL.
No game files or network are required.

```sh
python run_lab.py --fdisbull-wheel /path/to/fdisbull-0.22.0-py3-none-any.whl --output ./rerun
```

Omit `--fdisbull-wheel` to use an installed compatible package. The exact wheel
used in the recorded run is identified in `results/provenance.json` and is not
bundled. Generated native loaders are rebuilt for each run, not distributed.
Only the authored fixture is executed; this is not an arbitrary-binary sandbox.
